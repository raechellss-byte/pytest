-- ============================================================
-- Tambah kolom identitas (No. ARC & No. NHI) ke tabel users.
-- Jalankan di: Supabase Dashboard proyek zhuanti -> SQL Editor -> Run.
--
-- Dipakai agar profil (Nama/ARC/NHI) tersimpan di AKUN (bukan lokal),
-- dan bisa dibaca lintas fitur (mis. Kesehatan / Sehat Rantau).
--
-- Aman dijalankan berulang (IF NOT EXISTS). Tidak mengubah RLS:
--   • users_select (select using true)  -> boleh dibaca
--   • users_update_self (auth.uid()=id) -> user boleh update barisnya sendiri
-- ============================================================

alter table public.users
  add column if not exists arc_no text,
  add column if not exists nhi_no text;
