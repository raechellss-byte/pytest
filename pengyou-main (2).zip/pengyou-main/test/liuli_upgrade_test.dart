import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:nihao_interpreter/features/liuli/liuli_common.dart';
import 'package:nihao_interpreter/features/liuli/liuli_data.dart';
import 'package:nihao_interpreter/features/liuli/liuli_practice.dart';
import 'package:nihao_interpreter/features/liuli/liuli_stats.dart';
import 'package:nihao_interpreter/features/liuli/liuli_store.dart';
import 'package:nihao_interpreter/features/liuli/liuli_sync.dart';

final store = LiuliStore.instance;

Future<void> boot(WidgetTester t, Widget home, {double height = 1600}) async {
  t.view.physicalSize = Size(800, height);
  t.view.devicePixelRatio = 1.0;
  addTearDown(t.view.reset);
  await t.runAsync(() async {
    await LiuliData.load();
    await store.ensureLoaded();
  });
  store.auto = false;
  await t.pumpWidget(MaterialApp(home: LiuliThemed(child: Scaffold(body: home))));
  await t.pump();
}

Map<String, dynamic> snap({
  String at = '2026-10-20T00:00:00Z',
  Map<String, dynamic> srs = const {},
  Map<String, dynamic> prog = const {},
  List<String> saved = const [],
  Map<String, dynamic>? set,
  String? resetAt,
}) =>
    {
      'app': 'liuli',
      'v': 2,
      'at': at,
      if (resetAt != null) 'resetAt': resetAt,
      'srs': srs,
      'prog': prog,
      'set': set ?? {'dailyGoal': 20},
      'saved': saved,
      'lists': const [],
      'miss': const {'recent': [], 'count': {}},
      'hist': const [],
    };

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  group('mergeLiuli (sinkron akun)', () {
    test('kartu yang terakhir dinilai menang, kartu lain digabung', () {
      final local = snap(srs: {
        '你好': {'iv': 3, 'reps': 2, 'at': '2026-10-22T10:00:00Z'},
        '謝謝': {'iv': 1, 'reps': 1, 'at': '2026-10-20T10:00:00Z'},
      });
      final remote = snap(srs: {
        '你好': {'iv': 9, 'reps': 3, 'at': '2026-10-21T10:00:00Z'},
        '再見': {'iv': 4, 'reps': 1, 'at': '2026-10-21T10:00:00Z'},
      });
      final m = mergeLiuli(local, remote);
      expect((m['srs']['你好'] as Map)['iv'], 3, reason: 'lokal lebih baru');
      expect((m['srs'] as Map).keys, containsAll(['你好', '謝謝', '再見']));
    });

    test('hitungan harian ambil terbesar, rentetan ikut yang terakhir belajar', () {
      final local = snap(prog: {
        'streak': 5, 'last': '2026-10-22', 'best': 5, 'total': 40,
        'daily': {'2026-10-21': 10, '2026-10-22': 3},
        'dates': ['2026-10-21', '2026-10-22'],
      });
      final remote = snap(prog: {
        'streak': 9, 'last': '2026-10-20', 'best': 12, 'total': 90,
        'daily': {'2026-10-20': 7, '2026-10-21': 4},
        'dates': ['2026-10-20', '2026-10-21'],
      });
      final p = mergeLiuli(local, remote)['prog'] as Map;
      expect(p['streak'], 5);
      expect(p['best'], 12);
      expect(p['total'], 90);
      expect(p['daily'], {'2026-10-20': 7, '2026-10-21': 10, '2026-10-22': 3});
      expect(p['dates'], ['2026-10-20', '2026-10-21', '2026-10-22']);
    });

    test('reset yang lebih baru tidak dihidupkan lagi oleh data lama', () {
      final local = snap(at: '2026-10-23T09:00:00Z', resetAt: '2026-10-23T09:00:00Z');
      final remote = snap(at: '2026-10-22T09:00:00Z', srs: {'你好': {'iv': 30, 'reps': 5}});
      expect((mergeLiuli(local, remote)['srs'] as Map), isEmpty);
    });

    test('sinkron pertama menggabung favorit; setelahnya yang terbaru menang', () {
      final local = snap(at: '2026-10-21T00:00:00Z', saved: ['你好']);
      final remote = snap(at: '2026-10-22T00:00:00Z', saved: ['謝謝'], set: {'dailyGoal': 30});
      expect(mergeLiuli(local, remote, union: true)['saved'], containsAll(['你好', '謝謝']));
      final m = mergeLiuli(local, remote);
      expect(m['saved'], ['謝謝']);
      expect((m['set'] as Map)['dailyGoal'], 30);
    });
  });

  testWidgets('snapshot ↔ applySnapshot, akurasi & prakiraan ulasan', (t) async {
    await boot(t, const SizedBox());
    final v = LiuliData.vocab;
    store.grade(v[0], 'good'); // jatuh tempo besok
    store.grade(v[1], 'again'); // jatuh tempo hari ini
    store.logAnswer(true);
    store.logAnswer(false);
    expect(store.accuracy(), closeTo(0.5, 0.001), reason: '2 benar dari 4 jawaban');
    final f = store.dueForecast();
    expect(f[0], greaterThanOrEqualTo(1));
    expect(f[1], greaterThanOrEqualTo(1));
    expect(store.srs[v[0].h]!.at, isNotNull, reason: 'waktu nilai dicatat untuk sinkron');

    final s = store.snapshot();
    store.updateSetting(() => store.dailyGoal = 50);
    store.applySnapshot(s);
    expect(store.dailyGoal, 20);
    expect(store.srs.containsKey(v[1].h), isTrue);
  });

  testWidgets('mode gelap: tema & warna ikut setelan', (t) async {
    await boot(t, Builder(builder: (c) => Text('${Theme.of(c).brightness}')));
    expect(find.text('${Brightness.light}'), findsOneWidget);
    store.updateSetting(() => store.dark = true);
    await t.pump();
    expect(find.text('${Brightness.dark}'), findsOneWidget);
    expect(LiuliColors.isDark, isTrue);
    expect(LiuliColors.card, isNot(Colors.white));
    store.updateSetting(() => store.dark = false);
    await t.pump();
    expect(LiuliColors.isDark, isFalse);
  });

  testWidgets('Statistik: ubin angka, dua grafik, kata tersulit', (t) async {
    await boot(t, const LiuliStatsScreen(), height: 2400);
    store.grade(LiuliData.vocab[0], 'good');
    await t.pump();
    expect(find.text('Akurasi 7 hari'), findsOneWidget);
    expect(find.text('Ulasan 7 hari ke depan'), findsOneWidget);
    expect(find.text('Aktivitas 30 hari terakhir'), findsOneWidget);
    expect(find.byType(LiuliBarChart), findsNWidgets(2));
    expect(find.text('Kata paling sulit'), findsOneWidget);
    // Grafik selebar kartu & bisa diketuk: ketuk batang pertama prakiraan.
    final chart = find.byType(LiuliBarChart).first;
    expect(t.getSize(find.descendant(of: chart, matching: find.byType(CustomPaint)).first).width,
        greaterThan(300));
    await t.tapAt(t.getTopLeft(chart) + const Offset(6, 60));
    await t.pump();
    expect(find.textContaining('kata jatuh tempo'), findsWidgets);
  });

  testWidgets('Tata bahasa: 20 pola × 4 soal, isi & susun bisa dijawab', (t) async {
    await t.runAsync(LiuliData.load);
    expect(LiuliData.grammar.length, 20);
    for (final g in LiuliData.grammar) {
      expect(g.q.length, 4, reason: g.t);
    }
    final g = LiuliData.grammar.first; // 了: 3 isi + 1 susun
    await boot(t, GrammarPracticeScreen(title: 'uji', questions: g.q));
    for (var k = 0; k < 3; k++) {
      final q = g.q[k];
      await t.tap(find.text(q.a).last);
      await t.pump();
      expect(find.textContaining('正確'), findsOneWidget, reason: q.q);
      await t.tap(find.textContaining('Soal berikutnya'));
      await t.pump();
    }
    // Soal susun: ketuk token sesuai urutan benar.
    for (final tok in g.q[3].tok) {
      await t.tap(find.text(tok).last);
      await t.pump();
    }
    await t.tap(find.text('Cek jawaban'));
    await t.pump();
    expect(find.textContaining('正確'), findsOneWidget);
    await t.tap(find.text('Lihat hasil'));
    await t.pump();
    expect(find.text('4 / 4 benar'), findsOneWidget);
  });

  testWidgets('Dialog: 10 situasi, latihan peran sampai selesai', (t) async {
    await t.runAsync(LiuliData.load);
    expect(LiuliData.dialogs.length, 10);
    final talk = LiuliData.dialogs.firstWhere((d) => d.id == 'izin');
    await boot(t, TalkScreen(talk: talk, practice: true), height: 4000);
    final mine = talk.lines.where((l) => l.mine).toList();
    for (final l in mine) {
      await t.tap(find.text(l.h).last);
      await t.pump();
      expect(find.textContaining('正確'), findsOneWidget);
      await t.tap(find.text('Lanjut →'));
      await t.pump();
    }
    expect(find.text('${mine.length} / ${mine.length} jawaban tepat'), findsOneWidget);
  });

  test('sinkron mati tanpa Supabase (mis. offline/tes)', () async {
    await LiuliSync.start();
    expect(LiuliSync.state.value, LiuliSyncState.off);
  });
}
