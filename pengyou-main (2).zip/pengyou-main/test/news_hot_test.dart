import 'package:flutter_test/flutter_test.dart';

import 'package:nihao_interpreter/screens/home/news_hot.dart';

// Judul asli dari tabel news (23 Okt 2026) — kejadian sama dari banyak media.
News n(String title, String at, {bool img = true, bool featured = false}) => {
      'title': title,
      'published_at': at,
      'image_url': img ? 'https://x/$title.jpg' : null,
      'is_featured': featured,
    };

final sample = [
  n('Kapolri Ungkap Kronologi Penangkapan Kapal Tanker Pengangkut 1 , 16 Ton Ketamin : 7 WNI da', '2026-10-23T08:45:00Z'),
  n('WNA Taiwan Manajer Kapal Tanker Pembawa 1 , 16 Ton Ketamine Jadi Tersangka , Terancam 12 T', '2026-10-23T07:30:00Z'),
  n('Polri Tetapkan WNA Taiwan Pengangkut 1 , 16 Ton Ketamine Sebagai Tersangka', '2026-10-23T07:15:00Z'),
  n('Polri Tetapkan WNA Taiwan Pengangkut 1 , 16 Ton Ketamine Sebagai Tersangka', '2026-10-23T07:15:00Z'),
  n('Topan Champi Lumpuhkan Taiwan , Ratusan Penerbangan Batal', '2026-10-23T07:15:00Z'),
  n('BI Nilai Kondisi Riil Perekonomian dan Pendekatan Akademis Penting Dipertemukan', '2026-10-22T11:15:00Z'),
  n('Taiwan Keluarkan Peringatan Bahaya Topan Champi , Lebih 100 Penerbangan Dibatalkan : Okezo', '2026-10-22T07:00:00Z'),
  n('Borneo FC Tekuk Tainan City 3 - 1 , Villa Tegaskan Pesut Etam Wajib Menang di Kandang', '2026-10-22T02:45:00Z'),
  n('Lima Orang Didakwa atas Rencana Menabrakan Mobil pada Komedian Taiwan yang Buat Lelucon te', '2026-10-21T18:45:00Z'),
  n('Hasil Borneo FC vs Tainan City di AFC Challenge League 2026 - 2027 : Menang 3 - 1 , Pesut', '2026-10-21T17:00:00Z'),
  n('Borneo FC vs Tainan City : Mauro Jeronimo Bisa Juara Grup D AFC Challenge League', '2026-10-21T01:45:00Z'),
  n('Bidik Investor Taiwan , SIER Siapkan Kawasan Industri Terintegrasi dan Fasilitas Hijau', '2026-10-20T14:00:00Z'),
  n('SIER Perkuat Peluang Investasi Indonesia - Taiwan melalui Solusi Kawasan Industri Terinteg', '2026-10-20T12:15:00Z'),
  n('UMKM Kalbar raup Rp113 , 51 juta di ISEF 2026', '2026-10-20T10:15:00Z'),
  n('Mauro Jeronimo Ungkap Kunci Borneo FC Jelang Duel Tiket Perempat Final Lawan Tainan City', '2026-10-20T06:15:00Z'),
  n('Perempat Final di Depan Mata , Borneo FC Targetkan Hujan Gol ke Gawang Tainan City', '2026-10-20T06:15:00Z'),
  n('Nilai Ekspor Tilapia RI Tertinggi di Dunia , Tapi Pasar Eropa Baru 8 , 1 Persen', '2026-10-17T08:15:00Z'),
  n('Jangan sampai ARC Anda kedaluwarsa', '2026-07-27T17:38:00Z', img: false),
];

final now = DateTime.parse('2026-10-23T18:30:00Z');

void main() {
  test('judul kejadian yang sama dikelompokkan, yang beda tidak', () {
    final stories = clusterStories(sample);
    int size(String word) =>
        stories.firstWhere((s) => '${s.article['title']}'.contains(word)).sources;
    expect(size('Ketamin'), 4);
    expect(size('Borneo'), 5);
    expect(size('Topan Champi'), 2);
    expect(size('SIER'), 2);
    expect(size('Tilapia'), 1);
    expect(size('Komedian'), 1);
    expect(stories.length, 9);
  });

  test('Hot hari/minggu/bulan: 1 berita per slide, kejadian berbeda', () {
    final b = buildBanners(sample, now);
    final hot = b.where((x) => x['__summary'] != null).toList();
    expect(hot.map((x) => x['__summary']), ['day', 'week', 'month']);
    final titles = hot.map((x) => '${(x['article'] as Map)['title']}').toList();
    expect(titles[0], contains('Ketamin'), reason: 'hari ini: 4 media');
    expect(titles[1], contains('Borneo'), reason: 'minggu ini: 5 media, beda kejadian');
    expect(titles[2], contains('Champi'), reason: 'bulan ini: kejadian ketiga');
    for (var i = 0; i < titles.length; i++) {
      for (var j = i + 1; j < titles.length; j++) {
        expect(sameStory(titles[i], titles[j]), isFalse);
      }
    }
    expect(hot[0]['sources'], 4);
    // "Lihat semua" hari ini: satu baris per kejadian (bukan 4 berita ketamin).
    expect((hot[0]['items'] as List).length, 2);
  });

  test('berita pilihan admin tampil dulu dan tidak diulang di slide Hot', () {
    final data = [
      ...sample.skip(1),
      {...sample.first, 'is_featured': true},
    ];
    final b = buildBanners(data, now);
    expect(b.first['is_featured'], isTrue);
    final day = b.firstWhere((x) => x['__summary'] == 'day');
    expect('${(day['article'] as Map)['title']}', isNot(contains('Ketamin')));
  });

  test('daftar berita Beranda: maks. 10, satu per kejadian, terbaru dulu', () {
    final many = [
      ...sample,
      for (var i = 0; i < 12; i++)
        n('Berita unik nomor $i tentang topik berbeda ${'abcdefghijkl'[i]}xyz$i',
            '2026-10-1${i % 9}T05:00:00Z'),
    ];
    final items = [for (final s in clusterStories(many)) s.article].take(10).toList();
    expect(items.length, 10);
    final titles = items.map((x) => '${x['title']}').toList();
    expect(titles.where((t) => t.contains('Ketamin')).length, 1, reason: '4 berita ketamin → 1');
    expect(titles.where((t) => t.contains('Borneo')).length, 1, reason: '5 berita Borneo → 1');
    expect(titles.first, contains('Ketamin'), reason: 'terbaru di atas');
  });

  test('tanpa berita baru: tetap ada slide dari berita terbaru', () {
    final b = buildBanners([sample.last], now);
    expect(b.length, 1);
    expect(b.first['__summary'], isNull);
  });
}
