import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:nihao_interpreter/features/liuli/liuli_common.dart';
import 'package:nihao_interpreter/features/liuli/liuli_data.dart';
import 'package:nihao_interpreter/features/liuli/liuli_store.dart';
import 'package:nihao_interpreter/features/liuli/liuli_write.dart';

final store = LiuliStore.instance;

Future<void> boot(WidgetTester t, Widget home, {double height = 1600}) async {
  t.view.physicalSize = Size(800, height);
  t.view.devicePixelRatio = 1.0;
  addTearDown(t.view.reset);
  await t.runAsync(() async {
    await LiuliData.load();
    await store.ensureLoaded();
    await LiuliData.hz();
  });
  store.auto = false;
  await t.pumpWidget(MaterialApp(home: LiuliThemed(child: Scaffold(body: home))));
  await t.pump();
}

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('set latihan harian: 6 karakter unik, tetap sama sepanjang hari', (t) async {
    await boot(t, const SizedBox());
    // Kata yang sedang dipelajari diprioritaskan.
    store.grade(LiuliData.vocab.firstWhere((v) => v.h == '謝謝'), 'good');
    store.writeDay = null; // paksa pilih ulang
    final set = store.todayWriteSet();
    expect(set.length, 6);
    expect(set.toSet().length, 6);
    expect(set.first, '謝', reason: 'dari kata yang terakhir diulas');
    expect(store.todayWriteSet(), set, reason: 'stabil dalam satu hari');

    final xp0 = store.xp;
    store.recordWrite(set.first);
    expect(store.writeToday, contains(set.first));
    expect(store.writeCount[set.first], 1);
    expect(store.xp, greaterThan(xp0), reason: 'menulis memberi XP');
  });

  testWidgets('tab Tulis ringkas: kartu harian, chip level, kisi 30 karakter', (t) async {
    await boot(t, const LiuliWrite(), height: 2400);
    expect(find.text('Latihan menulis hari ini'), findsOneWidget);
    // "Mulai latihan" atau "Lanjutkan" (tes sebelumnya sudah menulis 1 karakter).
    expect(find.textContaining(RegExp('Mulai latihan|Lanjutkan')), findsOneWidget);
    expect(find.text('Lv1'), findsOneWidget);
    expect(find.textContaining('tersisa)'), findsOneWidget,
        reason: 'Lv1 lebih dari 30 karakter → tombol tampilkan lagi');
    // Tidak ada lagi 400 kartu kata: hanya 6 (harian) + 30 (kisi) ubin karakter.
    expect(find.byType(InkWell).evaluate().length, lessThan(60));

    await t.tap(find.text('Lv2'));
    await t.pump();
    expect(find.textContaining('karakter'), findsWidgets);

    await t.enterText(find.byType(TextField), 'halo');
    await t.pump();
    expect(find.textContaining('kata cocok'), findsOneWidget);
    expect(find.byType(ListTile), findsWidgets);
  });

  testWidgets('sesi latihan: karakter satu per satu sampai ringkasan', (t) async {
    await boot(t, const WriteSessionScreen(chars: ['你', '好']), height: 1800);
    expect(find.text('Karakter 1 / 2'), findsOneWidget);
    expect(find.text('Animasi'), findsOneWidget);
    await t.tap(find.text('Lewati'));
    await t.pump();
    expect(find.text('Karakter 2 / 2'), findsOneWidget);
    await t.tap(find.text('Selesai'));
    await t.pump();
    expect(find.text('0 / 2 karakter ditulis'), findsOneWidget);
  });
}
