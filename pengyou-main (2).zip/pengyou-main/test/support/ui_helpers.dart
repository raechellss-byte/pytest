import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:google_fonts/google_fonts.dart';

/// Tes UI dengan tema app asli. Font Google tidak bisa dimuat saat tes (tanpa
/// internet) dan google_fonts melempar galatnya di future internal; hanya
/// galat itu yang diabaikan, galat lain tetap menggagalkan tes.
void uiTest(String name, Future<void> Function(WidgetTester t) body) {
  GoogleFonts.config.allowRuntimeFetching = false;
  testWidgets(name, (t) {
    final done = Completer<void>();
    runZonedGuarded(() async {
      await body(t);
      done.complete();
    }, (e, s) {
      // Kegagalan expect() tetap dilaporkan walau pesannya menyebut font itu.
      if (e is! TestFailure &&
          ('$e'.contains('PlusJakartaSans') || '$e'.contains('Nunito'))) {
        return;
      }
      if (!done.isCompleted) done.completeError(e, s);
    });
    return done.future;
  });
}
