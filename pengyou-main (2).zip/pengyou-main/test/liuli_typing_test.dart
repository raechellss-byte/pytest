import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:nihao_interpreter/features/liuli/liuli_data.dart';
import 'package:nihao_interpreter/features/liuli/liuli_store.dart';
import 'package:nihao_interpreter/features/liuli/liuli_typing.dart';

/// Tombol logis untuk tiap label keyboard (dipakai saat simulasi tekan tombol).
const _logical = <String, LogicalKeyboardKey>{
  '1': LogicalKeyboardKey.digit1, '2': LogicalKeyboardKey.digit2,
  '3': LogicalKeyboardKey.digit3, '4': LogicalKeyboardKey.digit4,
  '5': LogicalKeyboardKey.digit5, '6': LogicalKeyboardKey.digit6,
  '7': LogicalKeyboardKey.digit7, '8': LogicalKeyboardKey.digit8,
  '9': LogicalKeyboardKey.digit9, '0': LogicalKeyboardKey.digit0,
  '-': LogicalKeyboardKey.minus,
  'Q': LogicalKeyboardKey.keyQ, 'W': LogicalKeyboardKey.keyW,
  'E': LogicalKeyboardKey.keyE, 'R': LogicalKeyboardKey.keyR,
  'T': LogicalKeyboardKey.keyT, 'Y': LogicalKeyboardKey.keyY,
  'U': LogicalKeyboardKey.keyU, 'I': LogicalKeyboardKey.keyI,
  'O': LogicalKeyboardKey.keyO, 'P': LogicalKeyboardKey.keyP,
  'A': LogicalKeyboardKey.keyA, 'S': LogicalKeyboardKey.keyS,
  'D': LogicalKeyboardKey.keyD, 'F': LogicalKeyboardKey.keyF,
  'G': LogicalKeyboardKey.keyG, 'H': LogicalKeyboardKey.keyH,
  'J': LogicalKeyboardKey.keyJ, 'K': LogicalKeyboardKey.keyK,
  'L': LogicalKeyboardKey.keyL, ';': LogicalKeyboardKey.semicolon,
  'Z': LogicalKeyboardKey.keyZ, 'X': LogicalKeyboardKey.keyX,
  'C': LogicalKeyboardKey.keyC, 'V': LogicalKeyboardKey.keyV,
  'B': LogicalKeyboardKey.keyB, 'N': LogicalKeyboardKey.keyN,
  'M': LogicalKeyboardKey.keyM, ',': LogicalKeyboardKey.comma,
  '.': LogicalKeyboardKey.period, '/': LogicalKeyboardKey.slash,
  'Spasi': LogicalKeyboardKey.space,
};

DKey keyFor(String sym) => sym == kTone1
    ? dachenSpace
    : dachenRows.expand((r) => r).firstWhere((k) => k.sym == sym);

Future<void> press(WidgetTester t, DKey k) async {
  await t.sendKeyDownEvent(_logical[k.label]!, physicalKey: k.key);
  await t.sendKeyUpEvent(_logical[k.label]!, physicalKey: k.key);
  await t.pump();
}

final _han = RegExp(r'[㐀-鿿]');

void main() {
  group('data & layout 大千', () {
    test('urutan ketik sesuai IME: huruf dulu, nada terakhir', () {
      expect(typingSeq('ㄋㄧˇ'), ['ㄋ', 'ㄧ', 'ˇ']);
      expect(typingSeq('ㄢ'), ['ㄢ', kTone1]); // nada 1 = Spasi
      expect(typingSeq('˙ㄒㄧㄝ'), ['ㄒ', 'ㄧ', 'ㄝ', '˙']); // ˙ ditulis depan, diketik akhir
      expect(typingSeq('ㄕˋ'), ['ㄕ', 'ˋ']);
    });

    test('layout lengkap: 37 zhuyin + 5 nada, tanpa duplikat', () {
      final syms = [
        for (final r in dachenRows) ...r.map((k) => k.sym),
        dachenSpace.sym,
      ];
      expect(syms.length, 42);
      expect(syms.toSet().length, 42);
    });

    test('contoh nyata: 你好 → S U 3 C L 3, 謝謝 → V U , 4 V U , 7', () {
      String keys(String z) =>
          z.split(' ').expand(typingSeq).map((s) => keyFor(s).label).join(' ');
      expect(keys('ㄋㄧˇ ㄏㄠˇ'), 'S U 3 C L 3');
      expect(keys('ㄒㄧㄝˋ ˙ㄒㄧㄝ'), 'V U , 4 V U , 7');
      expect(keys('ㄗㄠˇ ㄢ'), 'Y L 3 0 Spasi');
    });

    test('SEMUA kosakata bisa diketik dengan layout 大千', () {
      final keys = {for (final r in dachenRows) ...r.map((k) => k.sym), kTone1};
      final vocab = [
        ...jsonDecode(File('assets/liuli/vocab.json').readAsStringSync()) as List,
        ...(jsonDecode(File('assets/liuli/vocab_kerja.json').readAsStringSync())
            as Map)['words'] as List,
        ...(jsonDecode(File('assets/liuli/vocab_plus.json').readAsStringSync())
            as Map)['words'] as List,
      ];
      for (final v in vocab) {
        final syls = '${v['z']}'.trim().split(RegExp(r'\s+'));
        final hanzi = '${v['h']}'.split('').where(_han.hasMatch).length;
        expect(syls.length, hanzi, reason: '${v['h']}: jumlah suku ≠ jumlah hanzi');
        for (final s in syls.expand(typingSeq)) {
          expect(keys.contains(s), isTrue,
              reason: '${v['h']}: simbol "$s" tidak ada di keyboard');
        }
      }
      expect(vocab.length, greaterThan(700));
    });
  });

  group('layar latihan (simulasi keyboard fisik)', () {
    setUp(() => SharedPreferences.setMockInitialValues({}));

    Future<void> boot(WidgetTester t) async {
      t.view.physicalSize = const Size(800, 1500);
      t.view.devicePixelRatio = 1.0;
      addTearDown(t.view.reset);
      await t.runAsync(() async {
        await LiuliData.load();
        await LiuliStore.instance.ensureLoaded();
      });
      LiuliStore.instance.auto = false; // tanpa suara saat tes
      await t.pumpWidget(const MaterialApp(home: ZhuyinTypingScreen()));
      await t.pump();
    }

    testWidgets('Kenal tombol: tombol benar maju, tombol salah ditandai',
        (t) async {
      await boot(t);
      await t.tap(find.text('Kenal tombol'));
      await t.pump();
      expect(find.text('Simbol 1 / 30'), findsOneWidget);

      String target() => t
          .widget<Text>(find.byWidgetPredicate(
              (w) => w is Text && w.style?.fontSize == 52))
          .data!;

      for (var i = 0; i < 3; i++) {
        await press(t, keyFor(target()));
        await t.pump(const Duration(milliseconds: 200));
      }
      expect(find.text('Simbol 4 / 30'), findsOneWidget);

      final cur = target();
      final wrong = dachenRows.expand((r) => r).firstWhere((k) => k.sym != cur);
      await press(t, wrong);
      expect(find.text('Simbol 4 / 30'), findsOneWidget, reason: 'salah → tidak maju');
      expect(find.textContaining('yang dicari'), findsOneWidget);

      await t.pump(const Duration(milliseconds: 500)); // habiskan timer kilatan
    });

    testWidgets('pilihan latihan diingat: mode tersimpan dipakai saat dibuka',
        (t) async {
      SharedPreferences.setMockInitialValues({
        'liuli_typing_mode': 'drill',
        'liuli_typing_hint': false,
      });
      await boot(t);
      await t.pump();
      expect(find.text('Simbol 1 / 30'), findsOneWidget);
      expect(find.textContaining('Tombol:'), findsNothing,
          reason: '"Sorot tombol" mati → petunjuk tombol disembunyikan');
    });

    testWidgets('Ketik kata: menyelesaikan satu kata penuh lewat keyboard',
        (t) async {
      await boot(t);
      expect(find.text('Kata 1 / 10'), findsOneWidget);

      // Kenali kata yang tampil dari hanzi besarnya, lalu ketik zhuyin-nya.
      final shown = t
          .widgetList<Text>(find.byWidgetPredicate(
              (w) => w is Text && w.style?.fontSize == 38))
          .map((w) => w.data!)
          .join();
      final v = LiuliData.vocab.firstWhere(
          (v) => v.h.split('').where(_han.hasMatch).join() == shown);
      for (final s in v.z.trim().split(RegExp(r'\s+')).expand(typingSeq)) {
        await press(t, keyFor(s));
      }
      await t.pump(const Duration(milliseconds: 450)); // jeda antar-kata
      expect(find.text('Kata 2 / 10'), findsOneWidget);
      expect(find.text('100%'), findsOneWidget, reason: 'tanpa salah → akurasi 100%');

      await t.pump(const Duration(milliseconds: 500));
    });
  });
}
