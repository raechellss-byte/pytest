import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:nihao_interpreter/features/liuli/liuli_common.dart';
import 'package:nihao_interpreter/features/liuli/liuli_data.dart';
import 'package:nihao_interpreter/features/liuli/liuli_guide.dart';
import 'package:nihao_interpreter/features/liuli/liuli_home.dart';
import 'package:nihao_interpreter/features/liuli/liuli_quiz.dart';
import 'package:nihao_interpreter/features/liuli/liuli_sentences.dart';
import 'package:nihao_interpreter/features/liuli/liuli_store.dart';
import 'package:nihao_interpreter/features/liuli/liuli_study.dart';
import 'package:nihao_interpreter/features/liuli/liuli_typing.dart';
import 'package:nihao_interpreter/features/liuli/liuli_write.dart';

const _logical = <String, LogicalKeyboardKey>{
  '1': LogicalKeyboardKey.digit1, '2': LogicalKeyboardKey.digit2,
  '3': LogicalKeyboardKey.digit3, '4': LogicalKeyboardKey.digit4,
  '5': LogicalKeyboardKey.digit5, '6': LogicalKeyboardKey.digit6,
  '7': LogicalKeyboardKey.digit7, '8': LogicalKeyboardKey.digit8,
  '9': LogicalKeyboardKey.digit9, '0': LogicalKeyboardKey.digit0,
  '-': LogicalKeyboardKey.minus,
  'Q': LogicalKeyboardKey.keyQ, 'W': LogicalKeyboardKey.keyW,
  'E': LogicalKeyboardKey.keyE, 'R': LogicalKeyboardKey.keyR,
  'T': LogicalKeyboardKey.keyT, 'Y': LogicalKeyboardKey.keyY,
  'U': LogicalKeyboardKey.keyU, 'I': LogicalKeyboardKey.keyI,
  'O': LogicalKeyboardKey.keyO, 'P': LogicalKeyboardKey.keyP,
  'A': LogicalKeyboardKey.keyA, 'S': LogicalKeyboardKey.keyS,
  'D': LogicalKeyboardKey.keyD, 'F': LogicalKeyboardKey.keyF,
  'G': LogicalKeyboardKey.keyG, 'H': LogicalKeyboardKey.keyH,
  'J': LogicalKeyboardKey.keyJ, 'K': LogicalKeyboardKey.keyK,
  'L': LogicalKeyboardKey.keyL, ';': LogicalKeyboardKey.semicolon,
  'Z': LogicalKeyboardKey.keyZ, 'X': LogicalKeyboardKey.keyX,
  'C': LogicalKeyboardKey.keyC, 'V': LogicalKeyboardKey.keyV,
  'B': LogicalKeyboardKey.keyB, 'N': LogicalKeyboardKey.keyN,
  'M': LogicalKeyboardKey.keyM, ',': LogicalKeyboardKey.comma,
  '.': LogicalKeyboardKey.period, '/': LogicalKeyboardKey.slash,
  'Spasi': LogicalKeyboardKey.space,
};

DKey keyByLabel(String label) => label == 'Spasi'
    ? dachenSpace
    : dachenRows.expand((r) => r).firstWhere((k) => k.label == label);

Future<void> press(WidgetTester t, DKey k) async {
  await t.sendKeyDownEvent(_logical[k.label]!, physicalKey: k.key);
  await t.sendKeyUpEvent(_logical[k.label]!, physicalKey: k.key);
  await t.pump();
}

final store = LiuliStore.instance;

Future<void> boot(WidgetTester t, Widget home, {double height = 1500}) async {
  t.view.physicalSize = Size(800, height);
  t.view.devicePixelRatio = 1.0;
  addTearDown(t.view.reset);
  await t.runAsync(() async {
    await LiuliData.load();
    await store.ensureLoaded();
  });
  store.auto = false; // tanpa suara otomatis saat tes
  await t.pumpWidget(MaterialApp(home: Scaffold(body: home)));
  await t.pump();
}

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('catatan salah → deck "Baru salah" & "Kata lemah"', (t) async {
    await boot(t, const SizedBox());
    final w = LiuliData.vocab.firstWhere((v) => v.h == '你好');
    store.recordMiss(w.h);
    expect(store.recentMissList().first.h, '你好', reason: 'terbaru di depan');
    expect(store.weakList().any((v) => v.h == '你好'), isFalse,
        reason: 'baru salah 1x → belum termasuk kata lemah');
    store.recordMiss(w.h);
    expect(store.weakList().first.h, '你好', reason: 'salah ≥2x → kata lemah');
    // Lupa di kartu SRS ("again") juga dicatat.
    final w2 = LiuliData.vocab.firstWhere((v) => v.h == '謝謝');
    store.grade(w2, 'again');
    expect(store.recentMissList().first.h, '謝謝');
  });

  testWidgets('deck "Kerja di Taiwan" dimuat paling atas, tanpa kata dobel', (t) async {
    await boot(t, const SizedBox());
    expect(LiuliData.decks.first.id, 'kerja');
    expect(LiuliData.decks.first.nameId, 'Kerja di Taiwan (PMI)');
    final kerja = LiuliData.vocab.where((v) => v.deck == 'kerja').toList();
    expect(kerja.length, 60);
    expect(kerja.map((v) => v.h), containsAll(['雇主', '居留證', '最低工資']));
    final hs = LiuliData.vocab.map((v) => v.h).toList();
    expect(hs.toSet().length, hs.length, reason: 'SRS per hanzi → tidak boleh dobel');
  });

  testWidgets('kosakata tambahan A1–B2: deck "Kata dasar", tiap level bertambah', (t) async {
    await boot(t, const SizedBox());
    expect(LiuliData.decks[1].id, 'dasar');
    int lv(int n) => LiuliData.vocab.where((v) => v.lv == n).length;
    expect(lv(1), greaterThanOrEqualTo(300));
    expect(lv(2), greaterThanOrEqualTo(300));
    expect(lv(3), greaterThanOrEqualTo(300));
    expect(lv(4), greaterThanOrEqualTo(300));
    final plus = LiuliData.vocab.where((v) => v.idx >= 20000).toList();
    expect(plus.length, greaterThan(600));
    final han = RegExp(r'[㐀-鿿]');
    for (final v in plus) {
      expect(v.z.split(' ').length, han.allMatches(v.h).length, reason: v.h);
      expect(v.ex, contains(v.h), reason: v.h);
      expect(v.exid, isNotEmpty, reason: v.h);
    }
    expect(LiuliData.vocab.map((v) => v.h).toSet().length, LiuliData.vocab.length);
  });

  testWidgets('data goresan tersedia untuk (hampir) semua karakter kosakata', (t) async {
    await boot(t, Builder(
      builder: (c) => TextButton(
          onPressed: () => openWriterDialog(c, '我們', 'wǒmen', 'kami'),
          child: const Text('buka')),
    ));
    final hz = await t.runAsync(LiuliData.hz);
    final han = RegExp(r'[㐀-鿿]');
    final missing = {
      for (final v in LiuliData.vocab) ...han.allMatches(v.h).map((m) => m[0]!)
    }.where((c) => !hz!.containsKey(c)).toList();
    expect(missing.length, lessThanOrEqualTo(2), reason: 'kosong: ${missing.join()}');
    // Kata dasar baru (我們) kini punya animasi goresan.
    await t.tap(find.text('buka'));
    await t.pump();
    await t.pump(const Duration(milliseconds: 300));
    expect(find.byType(CircularProgressIndicator), findsNothing, reason: 'data sudah termuat');
    expect(find.textContaining('belum tersedia'), findsNothing);
  });

  testWidgets('4 tingkat penguasaan selalu berjumlah total kosakata', (t) async {
    await boot(t, const SizedBox());
    final v = LiuliData.vocab;
    store.grade(v[10], 'easy'); // iv 4  → Belajar
    store.grade(v[11], 'easy');
    store.grade(v[11], 'easy'); // iv ~13 → Akrab
    for (var i = 0; i < 3; i++) {
      store.grade(v[12], 'easy'); // iv ≥21 → Dikuasai
    }
    expect(store.isFamiliar(v[11].h), isTrue);
    expect(store.isMastered(v[12].h), isTrue);
    final sum = store.newCount +
        store.learningCount +
        store.familiarCount +
        store.masteredCount;
    expect(sum, v.length);
    expect(store.learningCount, greaterThan(0));
    expect(store.familiarCount, greaterThan(0));
    expect(store.masteredCount, greaterThan(0));
  });

  testWidgets('Beranda: kartu penguasaan, level berwarna, deck otomatis', (t) async {
    await boot(t, LiuliHome(onGoTab: (_) {}), height: 7000);
    expect(find.text('Penguasaan kosakata'), findsOneWidget);
    for (final lv in [1, 2, 3, 4, 5, 6]) {
      expect(find.text('Lv$lv'), findsOneWidget, reason: 'lencana level $lv');
    }
    expect(find.textContaining('dikuasai'), findsWidgets);
    expect(find.text('Deck otomatis'), findsOneWidget);
    expect(find.text('Kata lemah'), findsOneWidget);
    expect(find.text('Baru salah'), findsOneWidget);
    expect(find.text('Favorit'), findsOneWidget);
  });

  testWidgets('Kuis: banner + Ulas SRS + 12 ubin mode termasuk Dikte', (t) async {
    await boot(t, LiuliQuizHome(onGoTab: (_) {}), height: 2600);
    expect(find.byType(LiuliBanner), findsOneWidget);
    expect(find.text('Ulas SRS'), findsOneWidget);
    expect(find.byType(ModeTile), findsNWidgets(12));
    expect(find.text('Dikte 聽寫'), findsOneWidget);
    expect(find.text('Ketik Zhuyin 注音'), findsOneWidget);
  });

  testWidgets('Dikte: hanzi tersembunyi, kata selesai lewat keyboard', (t) async {
    await boot(t, const ZhuyinTypingScreen(initialMode: 'dict'));
    expect(find.text('Kata 1 / 10'), findsOneWidget);
    expect(find.text('？'), findsWidgets, reason: 'hanzi disembunyikan');
    expect(find.text('Putar lagi (Enter)'), findsOneWidget);
    final missesBefore = store.misses.length;

    // Tanpa melihat jawabannya: tekan tombol "tebakan"; bila salah, pesan
    // koreksi menunjukkan tombol yang benar → tekan itu.
    for (var n = 0; n < 150 && find.text('Kata 2 / 10').evaluate().isEmpty; n++) {
      final err = find.textContaining('(tombol ');
      final key = err.evaluate().isNotEmpty
          ? keyByLabel(RegExp(r'\(tombol ([^)]+)\)')
              .firstMatch(t.widget<Text>(err).data!)!
              .group(1)!)
          : keyByLabel('1');
      await press(t, key);
      await t.pump(const Duration(milliseconds: 100));
    }
    expect(find.text('Kata 2 / 10'), findsOneWidget);
    expect(store.misses.length, greaterThanOrEqualTo(missesBefore),
        reason: 'kata yang salah masuk catatan');
    expect(store.misses, isNotEmpty);
    await t.pump(const Duration(milliseconds: 1500));
  });

  testWidgets('banner berangka besar ada di tab Belajar/Kalimat/Tulis/Panduan',
      (t) async {
    for (final tab in <Widget>[
      LiuliStudyEntry(onGoTab: (_) {}),
      const LiuliSentences(),
      const LiuliWrite(),
      const LiuliGuide(),
    ]) {
      await boot(t, tab, height: 2400);
      expect(find.byType(LiuliBanner), findsOneWidget,
          reason: 'banner di ${tab.runtimeType}');
    }
  });
}
