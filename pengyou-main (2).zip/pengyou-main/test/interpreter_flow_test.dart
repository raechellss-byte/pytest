import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:nihao_interpreter/screens/account/become_interpreter_screen.dart';
import 'package:nihao_interpreter/screens/account/interpreter_test_screen.dart';
import 'package:nihao_interpreter/screens/admin/admin_interpreters_screen.dart';
import 'package:nihao_interpreter/screens/profile/profile_screen.dart';
import 'package:nihao_interpreter/screens/search/search_screen.dart';

import 'support/ui_helpers.dart';

// Alur "Jadi Penerjemah", tes bahasa (dinilai AI) & "Cari Terdekat" di sisi
// aplikasi, dengan backend Supabase palsu. Logika database-nya dites di
// supabase/tests/tes_penerjemah_terdekat.sql, logika penilai AI di
// supabase/functions/screen-interpreter/index.test.ts.

const uid = '00000000-0000-0000-0000-0000000000aa';
const url = 'https://tes.supabase.co';

/// Satu permintaan ke backend palsu.
class Call {
  Call(this.method, this.path, this.query, this.body);
  final String method, path, query;
  final dynamic body;
  @override
  String toString() => '$method $path${query.isEmpty ? '' : '?$query'}';
}

final calls = <Call>[];
var nearest = <Map<String, dynamic>>[];
Map<String, dynamic> profileRow = {};
var adminRows = <Map<String, dynamic>>[];
Map<String, dynamic> screenResult = {};

final questionRows = [
  for (final (id, kind, ctx, prompt) in [
    ('q1', 'id_zh', 'Rumah sakit', 'Dokter, ibu saya demam.'),
    ('q2', 'id_zh', 'Apotek', 'Obat ini diminum berapa kali?'),
    ('q3', 'id_zh', 'Darurat', 'Tolong panggilkan ambulans.'),
    ('q4', 'zh_id', 'Rumah sakit', '請您先到一樓掛號。'),
    ('q5', 'zh_id', 'Dokumen', '請在這裡簽名。'),
    ('q6', 'intro', null, 'Perkenalkan diri Anda dalam bahasa Mandarin.'),
    ('q7', 'intro', null, 'Kenapa Anda ingin menjadi penerjemah?'),
  ])
    {'id': id, 'kind': kind, 'context': ctx, 'prompt': prompt},
];

String _jwt() {
  String part(Map m) => base64Url.encode(utf8.encode(jsonEncode(m))).replaceAll('=', '');
  return '${part({'alg': 'HS256', 'typ': 'JWT'})}.'
      '${part({'sub': uid, 'role': 'authenticated', 'exp': 4102444800})}.sig';
}

http.Response _json(http.Request req, Object? body) => http.Response(
    jsonEncode(body), 200,
    request: req, headers: {'content-type': 'application/json; charset=utf-8'});

final backend = MockClient((req) async {
  final path = req.url.path;
  final body = req.body.isEmpty ? null : jsonDecode(req.body);
  calls.add(Call(req.method, path, req.url.query, body));
  if (path == '/auth/v1/token') {
    return _json(req, {
      'access_token': _jwt(),
      'token_type': 'bearer',
      'expires_in': 3600,
      'refresh_token': 'r',
      'user': {
        'id': uid,
        'aud': 'authenticated',
        'role': 'authenticated',
        'email': 'calon@contoh.test',
        'app_metadata': {},
        'user_metadata': {},
        'created_at': '2026-10-01T00:00:00Z',
      },
    });
  }
  return switch (path) {
    '/rest/v1/service_categories' => _json(req, [
        {'id': 'c-medis', 'name_id': 'Medis / Rumah Sakit'},
      ]),
    '/rest/v1/interpreter_profiles'
        when req.method == 'GET' && req.url.query.contains('users') =>
      _json(req, adminRows),
    '/rest/v1/interpreter_profiles' when req.method == 'GET' =>
      _json(req, profileRow.isEmpty ? {'id': 'p-calon'} : profileRow),
    '/rest/v1/interpreter_test_questions' => _json(req, questionRows),
    '/rest/v1/interpreter_screenings' => _json(req, [
        {
          'total': 86,
          'verdict': 'pass',
          'scores': {'translation_id_zh': 90, 'translation_zh_id': 88},
          'answers': [
            {
              'kind': 'id_zh',
              'context': 'Rumah sakit',
              'prompt': 'Dokter, ibu saya demam.',
              'answer': '醫生，我媽媽發燒了。',
            },
          ],
        },
      ]),
    '/functions/v1/screen-interpreter' => _json(req, screenResult),
    '/rest/v1/users' => _json(req, {
        'id': uid,
        'full_name': 'Tes Calon',
        'email': 'calon@contoh.test',
        'role': 'interpreter',
      }),
    '/rest/v1/rpc/nearest_interpreters' => _json(req, nearest),
    _ => http.Response('', req.method == 'POST' ? 201 : 204, request: req),
  };
});

/// GPS palsu: null = izin lokasi ditolak.
class FakeGps extends GeolocatorPlatform {
  FakeGps(this.at);
  final (double lat, double lng)? at;

  @override
  Future<LocationPermission> checkPermission() async =>
      at == null ? LocationPermission.deniedForever : LocationPermission.whileInUse;

  @override
  Future<LocationPermission> requestPermission() => checkPermission();

  @override
  Future<Position> getCurrentPosition({LocationSettings? locationSettings}) async =>
      Position(
        latitude: at!.$1,
        longitude: at!.$2,
        timestamp: DateTime(2026, 10, 25),
        accuracy: 10,
        altitude: 0,
        altitudeAccuracy: 0,
        heading: 0,
        headingAccuracy: 0,
        speed: 0,
        speedAccuracy: 0,
      );
}

Call rpc(String name) => calls.singleWhere((c) => c.path == '/rest/v1/rpc/$name');
bool called(String name) => calls.any((c) => c.path == '/rest/v1/rpc/$name');

/// Beri jeda nyata (I/O aset, decode JSON) sambil memajukan frame
/// (animasi dropdown/dialog/loading).
Future<void> settle(WidgetTester t) async {
  for (var i = 0; i < 12; i++) {
    await t.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 25)));
    await t.pump(const Duration(milliseconds: 50));
  }
}

Future<void> boot(WidgetTester t, Widget screen) async {
  t.view.physicalSize = const Size(390, 2400); // lebar HP
  t.view.devicePixelRatio = 1.0;
  addTearDown(t.view.reset);
  await t.pumpWidget(MaterialApp(home: screen));
  await settle(t);
}

Future<void> pickCity(WidgetTester t, Finder dropdown, String city) async {
  await t.tap(dropdown);
  await settle(t);
  await t.tap(find.text(city).last);
  await settle(t);
}

Future<void> fillAndSubmit(WidgetTester t) async {
  await pickCity(t, find.byType(DropdownButtonFormField<String>), 'Taichung');
  await t.enterText(find.widgetWithText(TextFormField, 'Tarif per jam (NT\$)'), '400');
  await t.enterText(find.widgetWithText(TextFormField, 'Bio / pengalaman'),
      'Mahasiswa di Taichung, biasa mendampingi ke rumah sakit');
  await t.tap(find.text('Medis / Rumah Sakit'));
  await t.pump();
  await t.tap(find.text('Kirim Pendaftaran'));
  await settle(t);
}

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: url,
      publishableKey: 'sb_publishable_tes',
      httpClient: backend,
      authOptions: const FlutterAuthClientOptions(
        localStorage: EmptyLocalStorage(),
        detectSessionInUri: false,
        autoRefreshToken: false,
      ),
    );
    await Supabase.instance.client.auth
        .signInWithPassword(email: 'calon@contoh.test', password: 'rahasia-tes');
  });

  setUp(() {
    calls.clear();
    nearest = [];
    profileRow = {};
    adminRows = [];
    screenResult = {};
  });

  uiTest('Jadi Penerjemah + GPS: profil, bahasa, layanan & titik GPS terkirim',
      (t) async {
    GeolocatorPlatform.instance = FakeGps((24.1380, 120.6860));
    await boot(t, const BecomeInterpreterScreen());
    await fillAndSubmit(t);

    expect(rpc('become_interpreter').body, {
      'p_bio': 'Mahasiswa di Taichung, biasa mendampingi ke rumah sakit',
      'p_city': 'Taichung',
      'p_hourly_rate': 400.0,
    });
    final pairs = calls.singleWhere(
        (c) => c.method == 'POST' && c.path == '/rest/v1/language_pairs');
    expect(pairs.body, [
      {
        'interpreter_id': 'p-calon',
        'source_language': 'id',
        'target_language': 'zh',
        'proficiency': 'fluent',
      }
    ]);
    final services = calls.singleWhere(
        (c) => c.method == 'POST' && c.path == '/rest/v1/interpreter_services');
    expect(services.body, [
      {'interpreter_id': 'p-calon', 'category_id': 'c-medis'}
    ]);
    expect(rpc('set_my_location').body, {'p_lng': 120.6860, 'p_lat': 24.1380});
    expect(find.text('Pendaftaran Terkirim!'), findsOneWidget);
    expect(find.textContaining('posisi GPS Anda'), findsOneWidget);
  });

  uiTest('Jadi Penerjemah, izin GPS ditolak → tetap terdaftar, pakai pusat kota',
      (t) async {
    GeolocatorPlatform.instance = FakeGps(null);
    await boot(t, const BecomeInterpreterScreen());
    await fillAndSubmit(t);

    expect(called('become_interpreter'), isTrue);
    expect(called('set_my_location'), isFalse,
        reason: 'server mengisi titik dari kota (trigger 016)');
    expect(find.text('Pendaftaran Terkirim!'), findsOneWidget);
    expect(find.textContaining('pusat kota Taichung'), findsOneWidget);
  });

  uiTest('Cari per kota: kirim koordinat kota & tampilkan penerjemah + jarak',
      (t) async {
    nearest = [
      {
        'interpreter_id': 'p-calon',
        'full_name': 'Tes Calon',
        'rating_avg': 4.8,
        'rating_count': 12,
        'hourly_rate': 400,
        'distance_km': 0.15,
      },
      {
        'interpreter_id': 'p-jauh',
        'full_name': 'Tes Jauh',
        'rating_avg': 0,
        'rating_count': 0,
        'hourly_rate': 300,
        'distance_km': 9.2,
      },
    ];
    await boot(t, const SearchScreen());
    await pickCity(t, find.byType(DropdownButton<String>), 'Taichung');

    expect(rpc('nearest_interpreters').body,
        {'p_lng': 120.6736, 'p_lat': 24.1477, 'p_max_km': 20.0});
    expect(find.text('Tes Calon'), findsOneWidget);
    expect(find.text('Tes Jauh'), findsOneWidget);
    expect(find.text(' 0.1 km'), findsOneWidget); // 0.15 dibulatkan
    expect(find.text(' 9.2 km'), findsOneWidget);
    expect(find.text('NT\$ 400/jam'), findsOneWidget);
    // Urutan dari server (terdekat dulu) dipertahankan.
    expect(t.getTopLeft(find.text('Tes Calon')).dy,
        lessThan(t.getTopLeft(find.text('Tes Jauh')).dy));
  });

  uiTest('Cari Terdekat (GPS) memakai posisi pengguna; kosong → pesan jelas',
      (t) async {
    GeolocatorPlatform.instance = FakeGps((24.1369, 120.6851));
    await boot(t, const SearchScreen());
    await t.tap(find.byIcon(Icons.my_location));
    await settle(t);

    expect(rpc('nearest_interpreters').body,
        {'p_lng': 120.6851, 'p_lat': 24.1369, 'p_max_km': 20.0});
    expect(find.textContaining('Belum ada penerjemah terverifikasi'), findsOneWidget);
  });

  uiTest('Profil penerjemah: status lokasi & ajakan lengkapi pendaftaran',
      (t) async {
    profileRow = {'id': 'p-calon', 'user_id': uid, 'is_verified': false,
        'is_available': true, 'city': null, 'bio': null, 'location': null};
    await boot(t, const ProfileScreen());
    expect(find.text('Lokasi pencarian belum diatur'), findsOneWidget);
    expect(find.text('Lengkapi pendaftaran penerjemah'), findsOneWidget);
    expect(find.textContaining('Menunggu verifikasi admin'), findsOneWidget);
  });

  uiTest('Profil penerjemah lengkap & berlokasi: tanpa ajakan, lokasi diatur',
      (t) async {
    profileRow = {'id': 'p-calon', 'user_id': uid, 'is_verified': true,
        'is_available': true, 'city': 'Taichung', 'bio': 'Mahasiswa',
        'hourly_rate': 400, 'location': '0101000020E6100000'};
    await boot(t, const ProfileScreen());
    expect(find.text('Lokasi pencarian sudah diatur'), findsOneWidget);
    expect(find.text('Lengkapi pendaftaran penerjemah'), findsNothing);
    expect(find.textContaining('Menunggu verifikasi admin'), findsNothing);
  });

  test('pilih soal: 2 Indonesia→Mandarin, 2 Mandarin→Indonesia, 1 menulis', () {
    final picked = pickTestQuestions(questionRows, Random(3));
    expect(picked.map((q) => q['kind']), ['id_zh', 'id_zh', 'zh_id', 'zh_id', 'intro']);
    expect(picked.map((q) => q['id']).toSet().length, 5);
    expect(pickTestQuestions(questionRows.take(2).toList(), Random(3)).length, 2,
        reason: 'bank soal sedikit → pakai yang ada');
  });

  Future<void> answerAll(WidgetTester t) async {
    final fields = find.byType(TextField);
    for (var i = 0; i < fields.evaluate().length; i++) {
      await t.enterText(fields.at(i), '  jawaban ${i + 1}  ');
    }
    await t.pump();
  }

  Future<void> send(WidgetTester t) async {
    await t.ensureVisible(find.text('Kirim jawaban'));
    await t.tap(find.text('Kirim jawaban'));
    await settle(t);
  }

  uiTest('Tes bahasa: 5 soal, wajib diisi, dikirim ke AI, hasil lolos tampil',
      (t) async {
    screenResult = {
      'ok': true,
      'total': 86,
      'verdict': 'pass',
      'feedback': 'Terjemahan akurat. Perhatikan nada sopan.',
      'attempts_left': 2,
    };
    await boot(t, InterpreterTestScreen(random: Random(3)));
    expect(find.byType(TextField), findsNWidgets(5));
    expect(find.textContaining('Terjemahkan ke bahasa Mandarin'), findsNWidgets(2));
    expect(find.textContaining('Terjemahkan ke bahasa Indonesia'), findsNWidgets(2));
    expect(find.textContaining('Tulis dalam bahasa Mandarin'), findsOneWidget);

    await send(t);
    expect(find.text('Semua soal wajib dijawab.'), findsOneWidget);
    expect(calls.where((c) => c.path.startsWith('/functions/')), isEmpty);

    await answerAll(t);
    await send(t);
    final call = calls.singleWhere((c) => c.path == '/functions/v1/screen-interpreter');
    final answers = List<Map>.from(call.body['answers']);
    expect(answers.length, 5);
    expect(answers.first['answer'], 'jawaban 1', reason: 'spasi dirapikan');
    expect(find.text('Lolos tes bahasa'), findsOneWidget);
    expect(find.text('Skor 86 / 100'), findsOneWidget);
    expect(find.textContaining('Terjemahan akurat'), findsOneWidget);
    expect(find.text('Coba lagi dengan soal baru'), findsNothing);
  });

  uiTest('Tes bahasa belum lolos: catatan + coba lagi memuat soal baru', (t) async {
    screenResult = {
      'ok': true,
      'total': 35,
      'verdict': 'reject',
      'feedback': 'Banyak makna yang keliru.',
      'attempts_left': 2,
    };
    await boot(t, InterpreterTestScreen(random: Random(3)));
    await answerAll(t);
    await send(t);
    expect(find.text('Belum lolos'), findsOneWidget);
    expect(find.textContaining('Sisa percobaan hari ini: 2'), findsOneWidget);
    expect(find.textContaining('Banyak makna yang keliru'), findsOneWidget);

    await t.tap(find.text('Coba lagi dengan soal baru'));
    await settle(t);
    expect(calls.where((c) => c.path == '/rest/v1/interpreter_test_questions').length, 2);
    expect(find.byType(TextField), findsNWidgets(5));
  });

  uiTest('Tes bahasa: pesan dari server (mis. batas harian) ditampilkan', (t) async {
    screenResult = {'ok': false, 'error': 'Batas 3x tes per hari. Coba lagi besok.'};
    await boot(t, InterpreterTestScreen(random: Random(3)));
    await answerAll(t);
    await send(t);
    expect(find.text('Batas 3x tes per hari. Coba lagi besok.'), findsOneWidget);
    expect(find.byType(TextField), findsNWidgets(5), reason: 'jawaban tidak hilang');
  });

  uiTest('Profil: penerjemah lengkap yang belum tes → ajakan tes', (t) async {
    profileRow = {'id': 'p-calon', 'user_id': uid, 'is_verified': false,
        'is_available': true, 'city': 'Taichung', 'bio': 'Mahasiswa',
        'location': '0101000020E6100000'};
    await boot(t, const ProfileScreen());
    expect(find.text('Ikuti tes bahasa'), findsOneWidget);
    expect(find.text('Mulai tes'), findsOneWidget);
  });

  uiTest('Profil: hasil tes lolos tampil dengan skor', (t) async {
    profileRow = {'id': 'p-calon', 'user_id': uid, 'is_verified': false,
        'is_available': true, 'city': 'Taichung', 'bio': 'Mahasiswa',
        'location': '0101000020E6100000', 'ai_verdict': 'pass', 'ai_total': 86};
    await boot(t, const ProfileScreen());
    expect(find.text('Lolos tes bahasa · skor 86'), findsOneWidget);
    expect(find.text('Menunggu persetujuan admin.'), findsOneWidget);
    expect(find.text('Mulai tes'), findsNothing);
  });

  uiTest('Admin: hasil AI di kartu, yang lolos paling atas, jawaban bisa dilihat',
      (t) async {
    Map<String, dynamic> row(String name, String? verdict, num? total, String day) => {
          'id': 'p-$name', 'is_verified': false, 'city': 'Taichung',
          'hourly_rate': 400, 'bio': 'Bio $name',
          'created_at': '2026-10-${day}T00:00:00Z',
          'users': {'full_name': name, 'email': '$name@contoh.test'},
          'language_pairs': [], 'interpreter_services': [],
          'ai_verdict': verdict, 'ai_total': total,
          'ai_summary': verdict == null ? null : 'Ringkasan $name',
          'ai_flags': verdict == 'reject' ? ['jawaban_kosong_atau_asal'] : <String>[],
        };
    adminRows = [
      row('Ditolak', 'reject', 20, '24'),
      row('Belum', null, null, '23'),
      row('Lolos', 'pass', 86, '22'),
      row('Manual', 'review', null, '21'), // tanpa API key: admin menilai
    ];
    await boot(t, const AdminInterpretersScreen());
    final y = {
      for (final n in ['Lolos', 'Manual', 'Belum', 'Ditolak'])
        n: t.getTopLeft(find.text(n)).dy,
    };
    expect(y['Lolos']!, lessThan(y['Manual']!));
    expect(y['Manual']!, lessThan(y['Belum']!));
    expect(y['Belum']!, lessThan(y['Ditolak']!));
    expect(find.text('Tes masuk · nilai manual'), findsOneWidget);
    expect(find.text('AI 86 · Lolos'), findsOneWidget);
    expect(find.text('AI 20 · Ditolak AI'), findsOneWidget);
    expect(find.text('Ringkasan Lolos'), findsOneWidget);
    expect(find.text('jawaban kosong atau asal'), findsOneWidget);
    expect(find.textContaining('Belum ikut tes bahasa'), findsOneWidget);
    expect(find.text('Verifikasi'), findsNWidgets(4), reason: 'admin tetap 1 klik');

    await t.tap(find.text('Lihat jawaban').first);
    await settle(t);
    expect(find.text('Jawaban tes · Lolos'), findsOneWidget);
    expect(find.text('醫生，我媽媽發燒了。'), findsOneWidget);
    expect(find.text('90 / 100'), findsOneWidget);
    final q = calls.lastWhere((c) => c.path == '/rest/v1/interpreter_screenings');
    expect(q.query, contains('interpreter_id=eq.p-Lolos'));
  });
}
