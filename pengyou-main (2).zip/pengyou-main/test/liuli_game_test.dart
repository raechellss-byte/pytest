import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:nihao_interpreter/features/liuli/liuli_common.dart';
import 'package:nihao_interpreter/features/liuli/liuli_data.dart';
import 'package:nihao_interpreter/features/liuli/liuli_exam.dart';
import 'package:nihao_interpreter/features/liuli/liuli_game.dart';
import 'package:nihao_interpreter/features/liuli/liuli_game_ui.dart';
import 'package:nihao_interpreter/features/liuli/liuli_stats.dart';
import 'package:nihao_interpreter/features/liuli/liuli_store.dart';
import 'package:nihao_interpreter/features/liuli/liuli_sync.dart';

final store = LiuliStore.instance;

Future<void> boot(WidgetTester t, Widget home, {double height = 1600}) async {
  t.view.physicalSize = Size(800, height);
  t.view.devicePixelRatio = 1.0;
  addTearDown(t.view.reset);
  await t.runAsync(() async {
    await LiuliData.load();
    await store.ensureLoaded();
  });
  store.auto = false;
  await t.pumpWidget(MaterialApp(home: LiuliThemed(child: Scaffold(body: home))));
  await t.pump();
}

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('level: ambang XP naik bertahap', () {
    expect(xpForLevel(1), 0);
    expect(xpForLevel(2), 100);
    expect(xpForLevel(3), 250);
    expect(levelForXp(99), 1);
    expect(levelForXp(100), 2);
    expect(levelForXp(449), 3);
    expect(levelForXp(450), 4);
    expect(levelTitle(1), contains('Pemula'));
  });

  test('misi harian: 3 misi berbeda, selalu ada "Ulas", sama untuk tanggal sama', () {
    for (final d in ['2026-10-23', '2026-10-24', '2026-11-02', '2027-01-01']) {
      final q = questsFor(d);
      expect(q.length, 3);
      expect(q.first.kind, 'review');
      expect(q.map((x) => x.id).toSet().length, 3, reason: d);
      expect(questsFor(d).map((x) => x.id), q.map((x) => x.id));
    }
  });

  testWidgets('aksi → XP, misi selesai, bonus, lencana, toast', (t) async {
    await boot(t, const SizedBox());
    final msgs = <String>[];
    final sub = store.events.listen(msgs.add);
    addTearDown(sub.cancel);

    final xp0 = store.xp;
    store.grade(LiuliData.vocab[0], 'good');
    expect(store.xp, xp0 + kXp['review']!, reason: 'kartu dinilai = XP');
    expect(store.kindTotal['new'], 1, reason: 'kata baru tercatat');

    // Selesaikan ketiga misi hari ini.
    for (final q in store.todayQuests) {
      final need = q.target - store.questProgress(q);
      if (need > 0) store.award(q.kind, n: need);
      expect(store.questDone(q), isTrue, reason: q.title);
    }
    await t.pump();
    expect(msgs.where((m) => m.startsWith('🎯')).length, greaterThanOrEqualTo(2));
    expect(msgs.any((m) => m.startsWith('🏆')), isTrue, reason: 'bonus semua misi');
    expect(store.kindTotal['questall'], 1);

    store.finishTalk(LiuliData.dialogs.first.id);
    expect(store.badgesEarned.containsKey('talk1'), isTrue);
    await t.pump();
    expect(msgs.any((m) => m.contains('Dialog pertama')), isTrue);
  });

  testWidgets('Beranda & Statistik menampilkan misi, level, lencana', (t) async {
    await boot(t, LiuliQuestCard(onGoTab: (_) {}));
    expect(find.text('Misi hari ini'), findsOneWidget);
    expect(find.textContaining('XP ke level'), findsOneWidget);
    for (final q in store.todayQuests) {
      expect(find.text(q.title), findsOneWidget);
    }
    await boot(t, const LiuliStatsScreen(), height: 3200);
    expect(find.text('Lencana'), findsOneWidget);
    expect(find.byType(LiuliBadgeGrid), findsOneWidget);
    for (final b in liuliBadges) {
      expect(find.text(b.title), findsOneWidget, reason: b.id);
    }
  });

  testWidgets('ujian: 20 soal sah, semua benar → 100% & lencana', (t) async {
    await t.runAsync(LiuliData.load);
    for (final band in examBands.keys) {
      final qs = buildExam(band, Random(7));
      expect(qs.length, 20);
      expect(qs.where((q) => q.section == 'listen').length, 10);
      for (final q in qs) {
        expect(q.answer, inInclusiveRange(0, q.options.length - 1));
        expect(q.options.toSet().length, q.options.length, reason: q.ask);
        expect(q.options.length, greaterThanOrEqualTo(3));
        expect(q.audio != null || q.prompt != null, isTrue);
      }
    }
    final qs = buildExam('A', Random(3));
    await boot(t, ExamScreen(band: 'A', questions: qs), height: 2000);
    for (var k = 0; k < qs.length; k++) {
      await t.tap(find.text(qs[k].options[qs[k].answer]).last);
      await t.pump();
      await t.tap(find.text(k + 1 < qs.length ? 'Berikutnya →' : 'Selesai & lihat nilai'));
      await t.pump();
    }
    expect(find.text('100%'), findsOneWidget);
    expect(store.examBest['A'], 100);
    expect(store.badgesEarned.containsKey('exam'), isTrue);
  });

  test('sinkron: XP ambil terbesar, lencana & dialog digabung', () {
    Map<String, dynamic> s(Map<String, dynamic> game, String at) =>
        {'app': 'liuli', 'at': at, 'srs': {}, 'prog': {}, 'game': game};
    final m = mergeLiuli(
      s({'xp': 300, 'badges': {'talk1': '2026-10-20'}, 'talksDone': ['izin']}, '2026-10-22'),
      s({'xp': 120, 'badges': {'talk1': '2026-10-18', 'streak3': '2026-10-19'}, 'talksDone': ['pasar']},
          '2026-10-21'),
    );
    final g = m['game'] as Map;
    expect(g['xp'], 300);
    expect(g['badges'], {'talk1': '2026-10-18', 'streak3': '2026-10-19'});
    expect(g['talksDone'], containsAll(['izin', 'pasar']));
  });
}
