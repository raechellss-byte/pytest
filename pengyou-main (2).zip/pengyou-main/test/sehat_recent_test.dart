import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:nihao_interpreter/features/sehat/sehat_app.dart';
import 'package:nihao_interpreter/features/sehat/sehat_results.dart';
import 'package:nihao_interpreter/features/sehat/sehat_store.dart';
import 'package:nihao_interpreter/theme.dart';

import 'support/ui_helpers.dart';

// "Pencarian terakhir" di beranda Sehat: hapus satu / hapus semua + urungkan.

final store = SehatStore.instance;

Map<String, dynamic> hist(String q, int ts) =>
    {'query': q, 'county': 'taichung', 'countyLabel': '台中市', 'count': 5, 'ts': ts};

/// Riwayat terbaru di atas (kata yang bukan tombol keluhan umum).
void seed() => store.applySnapshot({
      'history': [hist('pusing', 4000), hist('alergi', 3000), hist('luka', 2000), hist('jerawat', 1000)],
    });

List<String> queries() => [for (final h in store.history) h.query];

Future<void> settle(WidgetTester t) async {
  for (var i = 0; i < 10; i++) {
    await t.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 20)));
    await t.pump(const Duration(milliseconds: 100));
  }
}

Future<void> boot(WidgetTester t) async {
  // Font tes lebih lebar dari font asli; di 390 px kotak keluhan & ringkasan
  // hasil sudah meluap sedikit (bukan bagian yang dites di sini).
  t.view.physicalSize = const Size(480, 2400);
  t.view.devicePixelRatio = 1.0;
  addTearDown(t.view.reset);
  await t.pumpWidget(MaterialApp(theme: buildAppTheme(), home: const SehatApp()));
  await settle(t);
}

Finder removeButton(String q) => find.descendant(
      of: find.ancestor(of: find.text(q), matching: find.byType(Row)).first,
      matching: find.byTooltip('Hapus dari riwayat'),
    );

void main() {
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
  });

  Future<void> prepare(WidgetTester t) async {
    await t.runAsync(store.ensureLoaded);
    store.saving = true; // sudah masuk akun
    seed();
  }

  uiTest('✕ menghapus satu pencarian, yang berikutnya naik; urungkan mengembalikan', (t) async {
    await prepare(t);
    await boot(t);
    expect(find.text('pusing'), findsOneWidget);
    expect(find.text('jerawat'), findsNothing, reason: 'hanya 3 terakhir');
    expect(find.byTooltip('Hapus dari riwayat'), findsNWidgets(3));

    await t.tap(removeButton('alergi'));
    await settle(t);
    expect(queries(), ['pusing', 'luka', 'jerawat']);
    expect(find.text('alergi'), findsNothing);
    expect(find.text('jerawat'), findsOneWidget, reason: 'yang ke-4 ikut tampil');
    final prefs = await t.runAsync(SharedPreferences.getInstance);
    expect(prefs!.getString('sehatrantau.v2.history'), isNot(contains('alergi')));
    expect(find.text('"alergi" dihapus dari riwayat'), findsOneWidget);

    await t.tap(find.text('Urungkan'));
    await settle(t);
    expect(queries(), ['pusing', 'alergi', 'luka', 'jerawat']);
    expect(find.text('alergi'), findsOneWidget);
  });

  uiTest('ketuk kartunya tetap mencari, bukan menghapus', (t) async {
    await prepare(t);
    await boot(t);
    await t.tap(find.text('luka'));
    await settle(t);
    expect(find.byType(SehatResultsScreen), findsOneWidget);
    expect(store.history, hasLength(4));
  });

  uiTest('"Hapus semua" mengosongkan riwayat; urungkan mengembalikan', (t) async {
    await prepare(t);
    await boot(t);
    await t.tap(find.text('Hapus semua'));
    await settle(t);
    expect(store.history, isEmpty);
    expect(find.text('pusing'), findsNothing);
    expect(find.byTooltip('Hapus dari riwayat'), findsNothing);
    expect(find.text('Hapus semua'), findsNothing);
    final prefs = await t.runAsync(SharedPreferences.getInstance);
    expect(prefs!.getString('sehatrantau.v2.history'), '[]');

    await t.tap(find.text('Urungkan'));
    await settle(t);
    expect(queries(), ['pusing', 'alergi', 'luka', 'jerawat']);
    expect(find.text('Hapus semua'), findsOneWidget);
  });

  test('urungkan tidak menimpa pencarian baru & tidak menggandakan', () async {
    await store.ensureLoaded();
    store.saving = true;
    seed();
    final removed = store.clearHistory();
    store.pushHistory('flu', 'taichung', 3); // pencarian baru sebelum urungkan
    store.restoreHistory(removed);
    store.restoreHistory(removed); // ketuk dua kali
    expect(queries(), ['flu', 'pusing', 'alergi', 'luka', 'jerawat']);
  });
}
