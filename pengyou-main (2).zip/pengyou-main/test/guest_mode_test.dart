import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:nihao_interpreter/features/liuli/liuli_data.dart';
import 'package:nihao_interpreter/features/liuli/liuli_home.dart';
import 'package:nihao_interpreter/features/liuli/liuli_store.dart';
import 'package:nihao_interpreter/features/liuli/liuli_sync.dart';
import 'package:nihao_interpreter/features/sehat/sehat_data.dart';
import 'package:nihao_interpreter/features/sehat/sehat_store.dart';
import 'package:nihao_interpreter/features/sehat/sehat_sync.dart';
import 'package:nihao_interpreter/screens/auth/login_screen.dart' show safeNext, nextQuery;

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('tujuan setelah login hanya rute internal', () {
    expect(safeNext('/belajar'), '/belajar');
    expect(safeNext('/sehat'), '/sehat');
    expect(safeNext(null), '/beranda');
    expect(safeNext('https://contoh.com'), '/beranda');
    expect(safeNext('//contoh.com'), '/beranda');
    expect(nextQuery('/belajar'), '?next=%2Fbelajar');
    expect(nextQuery(null), '');
  });

  testWidgets('Belajar: tamu tidak menyimpan progres, setelah masuk tersimpan', (t) async {
    final store = LiuliStore.instance;
    await t.runAsync(() async {
      await LiuliData.load();
      await store.ensureLoaded();
    });
    final prefs = await t.runAsync(SharedPreferences.getInstance);

    LiuliSync.stop(); // tidak ada sesi login → mode tamu
    expect(store.saving, isFalse);
    store.grade(LiuliData.vocab[0], 'good');
    expect(store.srs.containsKey(LiuliData.vocab[0].h), isTrue, reason: 'tetap bisa belajar');
    expect(prefs!.getString('liuli_srs_v1'), isNull, reason: 'tamu: tidak ditulis ke perangkat');
    expect(prefs.getString('liuli_prog_v1'), isNull);

    // Pengaturan (mis. mode gelap) tetap disimpan untuk tamu.
    store.updateSetting(() => store.dark = true);
    expect(prefs.getString('liuli_set_v1'), contains('"dark":true'));
    store.updateSetting(() => store.dark = false);

    store.saving = true; // seperti setelah LiuliSync.start (sudah masuk)
    store.grade(LiuliData.vocab[1], 'good');
    expect(prefs.getString('liuli_srs_v1'), contains(LiuliData.vocab[1].h));
    expect(prefs.getString('liuli_srs_v1'), contains(LiuliData.vocab[0].h),
        reason: 'progres sesi tamu ikut tersimpan setelah masuk');
  });

  testWidgets('Beranda Belajar menampilkan ajakan masuk untuk tamu', (t) async {
    t.view.physicalSize = const Size(800, 2400);
    t.view.devicePixelRatio = 1.0;
    addTearDown(t.view.reset);
    await t.runAsync(() async {
      await LiuliData.load();
      await LiuliStore.instance.ensureLoaded();
    });
    LiuliStore.instance.auto = false;
    await t.pumpWidget(MaterialApp(home: Scaffold(body: LiuliHome(onGoTab: (_) {}))));
    expect(find.text('Mode tamu — progres tidak disimpan'), findsOneWidget);
    expect(find.text('Masuk dengan email'), findsOneWidget);
  });

  testWidgets('Sehat: tamu tidak mencatat riwayat pencarian & tidak menyimpan', (t) async {
    final store = SehatStore.instance;
    await t.runAsync(() async {
      await SehatData.loadManifest();
      await store.ensureLoaded();
    });
    final prefs = await t.runAsync(SharedPreferences.getInstance);
    SehatSync.stop();
    expect(SehatSync.signedIn, isFalse);
    store.pushHistory('demam', SehatData.counties.first.key, 10);
    expect(store.history, isEmpty, reason: 'riwayat pencarian khusus yang sudah masuk');

    store.saving = true;
    store.pushHistory('demam', SehatData.counties.first.key, 10);
    expect(store.history.length, 1);
    expect(prefs!.getString('sehatrantau.v2.history'), contains('demam'));
    expect(store.snapshot()['history'], hasLength(1));
  });

  test('mergeSehat: sinkron pertama digabung, setelahnya yang terbaru menang', () {
    Map<String, dynamic> snap(String at, List<String> ids) => {
          'at': at,
          'saved': [for (final i in ids) {'id': i}],
          'visits': const [],
          'history': const [],
        };
    final local = snap('2026-10-24T01:00:00Z', ['a', 'b']);
    final remote = snap('2026-10-23T01:00:00Z', ['b', 'c']);
    final first = mergeSehat(local, remote, union: true);
    expect((first['saved'] as List).map((e) => e['id']), ['a', 'b', 'c']);
    final later = mergeSehat(local, remote);
    expect((later['saved'] as List).map((e) => e['id']), ['a', 'b']);
  });
}
