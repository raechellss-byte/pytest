import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:nihao_interpreter/features/liuli/liuli_data.dart';
import 'package:nihao_interpreter/features/sehat/sehat_translate.dart';
import 'package:nihao_interpreter/features/sehat/sehat_translate_service.dart';
import 'package:nihao_interpreter/features/sehat/sehat_ui.dart';
import 'package:nihao_interpreter/services/tts_voice.dart';
import 'package:nihao_interpreter/theme.dart';

import 'support/ui_helpers.dart';

// Tab "Terjemah" Sehat Rantau (pengganti daftar frasa).

http.Response _mm(http.Request req, Map<String, dynamic> body) => http.Response(
  jsonEncode(body),
  200,
  request: req,
  headers: {'content-type': 'application/json; charset=utf-8'},
);

final calls = <(String, String, String)>[];
final spoken = <(String, String)>[];
Object? failWith;

Future<String> fakeTranslate(String text, TrLang from, TrLang to) async {
  calls.add((text, from.code, to.code));
  if (failWith != null) throw failWith!;
  return switch (to.code) {
    'zh-TW' => '我發燒三天了。',
    'en' => 'I have had a fever for three days.',
    _ => 'Saya demam tiga hari.',
  };
}

Future<void> fakeSpeak(String text, TrLang lang) async =>
    spoken.add((text, lang.code));

/// Jeda nyata (memuat kamus pinyin) sambil memajukan frame & debounce.
Future<void> settle(WidgetTester t) async {
  for (var i = 0; i < 10; i++) {
    await t.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 30)));
    await t.pump(const Duration(milliseconds: 100));
  }
}

Future<void> boot(WidgetTester t) async {
  t.view.physicalSize = const Size(390, 1800); // lebar HP
  t.view.devicePixelRatio = 1.0;
  addTearDown(t.view.reset);
  // Tema app asli: tombolnya lebar penuh (Size.fromHeight) — harus tetap tampil.
  await t.pumpWidget(
    MaterialApp(
      theme: buildAppTheme(),
      home: const SehatThemed(
        child: Scaffold(
          body: TranslateTab(translator: fakeTranslate, speaker: fakeSpeak),
        ),
      ),
    ),
  );
  await t.pump();
}

Future<void> type(WidgetTester t, String text) async {
  await t.enterText(find.byType(TextField), text);
  await settle(t);
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Map<String, String> lookup;

  setUpAll(() async {
    lookup = buildPinyinLookup(await LiuliData.dict());
  });

  setUp(() {
    SharedPreferences.setMockInitialValues({});
    calls.clear();
    spoken.clear();
    failWith = null;
  });

  group('layanan MyMemory', () {
    test('berhasil: kirim pasangan bahasa, rapikan entitas, simpan di cache', () async {
      var n = 0;
      final client = MockClient((req) async {
        n++;
        expect(req.url.host, 'api.mymemory.translated.net');
        expect(req.url.queryParameters['langpair'], 'id|en');
        expect(req.url.queryParameters['q'], 'Saya sakit kepala');
        return _mm(req, {
          'responseData': {'translatedText': 'I&#39;ve a headache &amp; fever'},
          'responseStatus': 200,
        });
      });
      final out = await translateText(' Saya sakit kepala ', trIndonesia, trEnglish,
          client: client);
      expect(out, "I've a headache & fever");
      await translateText('Saya sakit kepala', trIndonesia, trEnglish, client: client);
      expect(n, 1, reason: 'teks sama tidak memakan kuota lagi');
    });

    test('kuota harian habis → pesan jelas', () async {
      final client = MockClient((req) async => _mm(req, {
        'responseData': {
          'translatedText': 'MYMEMORY WARNING: YOU USED ALL AVAILABLE FREE TRANSLATIONS FOR TODAY.',
        },
        'quotaFinished': true,
        'responseStatus': 429,
      }));
      expect(
        () => translateText('kuota habis', trIndonesia, trMandarin, client: client),
        throwsA(isA<TranslateException>()
            .having((e) => e.message, 'message', contains('Kuota'))),
      );
    });

    test('galat server / tanpa internet / terlalu panjang / kosong', () async {
      final err = MockClient((req) async => _mm(req, {
        'responseData': {'translatedText': 'QUERY LENGTH LIMIT EXCEEDED'},
        'responseStatus': '403',
      }));
      expect(() => translateText('galat', trIndonesia, trMandarin, client: err),
          throwsA(isA<TranslateException>()
              .having((e) => e.message, 'message', contains('gangguan'))));

      final offline = MockClient((_) async => throw http.ClientException('offline'));
      expect(() => translateText('offline', trIndonesia, trMandarin, client: offline),
          throwsA(isA<TranslateException>()
              .having((e) => e.message, 'message', contains('koneksi'))));

      var n = 0;
      final counting = MockClient((req) async {
        n++;
        return _mm(req, {'responseData': {'translatedText': 'x'}, 'responseStatus': 200});
      });
      expect(() => translateText('a' * 501, trIndonesia, trMandarin, client: counting),
          throwsA(isA<TranslateException>()));
      expect(await translateText('   ', trIndonesia, trMandarin, client: counting), '');
      expect(n, 0, reason: 'tidak ada permintaan sia-sia');
    });
  });

  group('pinyin dari kamus Liúlì', () {
    test('kata dicocokkan, tanda baca latin', () {
      expect(pinyinFor('我對青黴素過敏。', lookup), 'wǒ duì qīng méi sù guò mǐn.');
    });

    test('huruf berbunyi ganda memakai bacaan umum, angka dipertahankan', () {
      expect(pinyinFor('請您先到一樓掛號，再到三樓。', lookup), contains('guà hào,'));
      expect(pinyinFor('我吃完飯肚子疼得厲害', lookup), contains('téng de'));
      expect(pinyinFor('可以撥打1955申訴', lookup), contains('1955'));
    });
  });

  group('pilih suara TTS', () {
    Map<String, String> v(String name, String locale) => {'name': name, 'locale': locale};
    final pc = [v('David', 'en-US'), v('Huihui', 'zh-CN'), v('Tracy', 'zh-HK')];

    test('locale persis dipakai bila ada', () {
      expect(bestVoice([...pc, v('Hanhan', 'zh-TW')], 'zh-TW')!['name'], 'Hanhan');
      expect(bestVoice(pc, 'en-US')!['name'], 'David');
    });

    test('tanpa zh-TW → suara Mandarin zh-CN, bukan Kanton (zh-HK) atau Inggris', () {
      expect(bestVoice(pc, 'zh-TW')!['name'], 'Huihui');
      expect(bestVoice([v('David', 'en-US'), v('Tracy', 'zh-HK')], 'zh-TW'), isNull);
    });

    test('bahasa sama varian lain; kode Android lama in_ID untuk Indonesia', () {
      expect(bestVoice([v('Hazel', 'en-GB')], 'en-US')!['name'], 'Hazel');
      expect(bestVoice([v('Andika', 'in_ID')], 'id-ID')!['name'], 'Andika');
      expect(bestVoice([v('David', 'en-US')], 'id-ID'), isNull);
    });
  });

  group('tab Terjemah', () {
    uiTest('ketik → terjemah otomatis ke Mandarin + pinyin → suarakan', (t) async {
      await boot(t);
      expect(find.text('Terjemahkan'), findsOneWidget);
      expect(find.text('Terjemahan muncul di sini'), findsOneWidget);

      await t.enterText(find.byType(TextField), 'Saya demam tiga hari');
      await t.pump(const Duration(milliseconds: 300));
      expect(calls, isEmpty, reason: 'menunggu jeda mengetik');
      await settle(t);
      expect(calls, [('Saya demam tiga hari', 'id', 'zh-TW')]);
      expect(find.text('我發燒三天了。'), findsOneWidget);
      expect(find.textContaining('fā shāo'), findsOneWidget);

      await t.tap(find.text('Suarakan'));
      await t.pump();
      expect(spoken, [('我發燒三天了。', 'zh-TW')]);
    });

    uiTest('pilih English: terjemah ulang, tanpa pinyin, pilihan diingat', (t) async {
      await boot(t);
      await type(t, 'Saya demam tiga hari');
      await t.tap(find.text('中文 (Taiwan)').first);
      await settle(t);
      await t.tap(find.widgetWithText(CheckedPopupMenuItem<TrLang>, 'English'));
      await settle(t);
      expect(calls.last, ('Saya demam tiga hari', 'id', 'en'));
      expect(find.text('I have had a fever for three days.'), findsOneWidget);
      expect(find.textContaining('fā shāo'), findsNothing);
      final prefs = await SharedPreferences.getInstance();
      expect(prefs.getString('sehat_tr_other'), 'en');

      await t.tap(find.text('Suarakan'));
      await t.pump();
      expect(spoken.last.$2, 'en');
    });

    uiTest('tukar arah ⇄: balasan petugas diterjemahkan ke Indonesia', (t) async {
      await boot(t);
      await type(t, 'Saya demam tiga hari');
      await t.tap(find.byTooltip('Tukar arah'));
      await settle(t);
      expect(calls.last, ('我發燒三天了。', 'zh-TW', 'id'));
      expect(find.text('Saya demam tiga hari.'), findsOneWidget);
      expect(t.widget<TextField>(find.byType(TextField)).controller!.text,
          '我發燒三天了。', reason: 'kolom terisi hasil tadi');
      final left = t.getTopLeft(find.text('中文 (Taiwan)').first).dx;
      final right = t.getTopLeft(find.text('Indonesia').first).dx;
      expect(left, lessThan(right), reason: 'Mandarin kini di kiri (sumber)');
    });

    uiTest('tunjukkan tulisan besar ke petugas', (t) async {
      await boot(t);
      await type(t, 'Saya demam tiga hari');
      await t.tap(find.text('Tunjukkan'));
      await settle(t);
      expect(find.text('Tunjukkan layar ini ke petugas 👇'), findsOneWidget);
      expect(find.text('我發燒三天了。'), findsNWidgets(2));
      await t.tap(find.text('Selesai'));
      await settle(t);
      expect(find.text('Tunjukkan layar ini ke petugas 👇'), findsNothing);
    });

    uiTest('galat ditampilkan; hapus mengosongkan hasil', (t) async {
      failWith = TranslateException('Kuota terjemahan gratis hari ini habis. Coba lagi besok.');
      await boot(t);
      await type(t, 'halo dokter');
      expect(find.textContaining('Kuota terjemahan gratis'), findsOneWidget);
      expect(find.text('Suarakan'), findsNothing);

      failWith = null;
      await t.tap(find.byTooltip('Hapus'));
      await settle(t);
      expect(find.text('Terjemahan muncul di sini'), findsOneWidget);
    });

    uiTest('mikrofon tidak tersedia → saran mengetik', (t) async {
      await boot(t);
      await t.tap(find.text('Bicara'));
      await settle(t);
      expect(find.textContaining('Mikrofon tidak'), findsOneWidget);
    });
  });
}
