import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:nihao_interpreter/features/liuli/liuli_common.dart';
import 'package:nihao_interpreter/theme.dart';

import 'support/ui_helpers.dart';

// Font hanzi bawaan Belajar Mandarin (pengganti unduhan potongan font CJK
// CanvasKit yang membuat layar tersendat saat menggulir).

List<String> fallbackOf(TextStyle? s) => s?.fontFamilyFallback ?? const [];

void main() {
  uiTest('font belum dimuat → tema tidak diubah (cegah hanzi jadi kotak)', (t) async {
    final base = buildAppTheme();
    expect(hanziFontReady, isFalse);
    expect(identical(liuliTheme(base, dark: false), base), isTrue);
  });

  uiTest('font dimuat → semua gaya teks tema punya cadangan hanzi', (t) async {
    final regular = await t.runAsync(() => rootBundle.load('assets/fonts/LiuliHanzi-Regular.ttf'));
    expect(regular!.lengthInBytes, greaterThan(300 * 1024), reason: 'aset font ikut dibundel');
    await t.runAsync(loadHanziFont);
    expect(hanziFontReady, isTrue);

    final base = buildAppTheme();
    for (final dark in [false, true]) {
      final th = liuliTheme(base, dark: dark);
      final body = fallbackOf(th.textTheme.bodyMedium);
      expect(body.last, kHanziFont);
      expect(body, containsAll(fallbackOf(base.textTheme.bodyMedium)),
          reason: 'cadangan google_fonts tetap ada');
      expect(fallbackOf(th.textTheme.headlineSmall), contains(kHanziFont));
      expect(fallbackOf(th.chipTheme.labelStyle), contains(kHanziFont));
      expect(fallbackOf(th.snackBarTheme.contentTextStyle), contains(kHanziFont));
      expect(fallbackOf(th.filledButtonTheme.style!.textStyle!.resolve({})), contains(kHanziFont));
      expect(fallbackOf(th.outlinedButtonTheme.style!.textStyle!.resolve({})), contains(kHanziFont));
    }

    final once = liuliTheme(base, dark: false);
    expect(identical(liuliTheme(base, dark: false), once), isTrue, reason: 'tidak dibuat ulang tiap rebuild');
    final twice = withHanziFont(once);
    expect(fallbackOf(twice.textTheme.bodyMedium).where((f) => f == kHanziFont), hasLength(1));
  });

  uiTest('teks di halaman Belajar Mandarin mewarisi font hanzi', (t) async {
    await t.runAsync(loadHanziFont);
    late TextStyle inherited;
    await t.pumpWidget(MaterialApp(
      theme: buildAppTheme(),
      home: LiuliThemed(
        child: Scaffold(
          body: Builder(builder: (context) {
            inherited = DefaultTextStyle.of(context).style.merge(hanziStyle());
            return Text('你好', style: hanziStyle());
          }),
        ),
      ),
    ));
    expect(fallbackOf(inherited), contains(kHanziFont));
    expect(inherited.fontWeight, FontWeight.w700);
  });
}
