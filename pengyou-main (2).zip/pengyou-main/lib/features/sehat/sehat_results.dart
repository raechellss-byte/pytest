import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import 'sehat_app.dart';
import 'sehat_data.dart';
import 'sehat_detail.dart';
import 'sehat_store.dart';
import 'sehat_ui.dart';

class SehatResultsScreen extends StatefulWidget {
  const SehatResultsScreen({
    super.key,
    required this.query,
    required this.county,
  });
  final String query;
  final String county;

  @override
  State<SehatResultsScreen> createState() => _SehatResultsScreenState();
}

class _SehatResultsScreenState extends State<SehatResultsScreen> {
  bool _loading = true;
  String? _error;
  List<Clinic> _results = [];
  Set<String>? _matched;

  String _sort = 'dist';
  String? _distFilter;
  bool _map = false;
  int _shown = 50;
  Clinic? _selected; // pin klinik yang sedang dipilih di peta
  bool _locating = false;
  bool _tilesFailed = false; // tile peta gagal dimuat (mis. offline)

  final _mapController = MapController();

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    try {
      final list = await SehatData.loadCounty(widget.county);
      final specs = matchSpecs(widget.query);
      final county = SehatData.countyByKey(widget.county);
      final store = SehatStore.instance;
      final origin = store.userLoc ?? [county?.lat ?? 0, county?.lng ?? 0];
      final res = list
          .where((c) => specs == null || c.spec.any((s) => specs.contains(s)))
          .toList();
      for (final c in res) {
        c.dist = haversine(origin[0], origin[1], c.lat, c.lng);
      }
      store.pushHistory(widget.query, widget.county, res.length);
      setState(() {
        _matched = specs;
        _results = res;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = '$e';
        _loading = false;
      });
    }
  }

  List<Clinic> get _filtered {
    var r = _results;
    if (_distFilter != null) {
      r = r.where((c) => c.district == _distFilter).toList();
    }
    final arr = [...r];
    switch (_sort) {
      case 'open':
        arr.sort((a, b) {
          final o = (isOpenNow(b.hours) ? 1 : 0) - (isOpenNow(a.hours) ? 1 : 0);
          return o != 0 ? o : (a.dist ?? 0).compareTo(b.dist ?? 0);
        });
        break;
      case 'name':
        arr.sort((a, b) => a.name.compareTo(b.name));
        break;
      default:
        arr.sort((a, b) => (a.dist ?? 0).compareTo(b.dist ?? 0));
    }
    return arr;
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.query.trim();
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Hasil', style: TextStyle(fontSize: 18)),
            Text(
              '${q.isEmpty ? 'Semua klinik' : q} · ${SehatData.countyLabel(widget.county)}',
              style: const TextStyle(fontSize: 11.5, color: Colors.grey),
            ),
          ],
        ),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: SehatColors.brand),
            )
          : _error != null
          ? Center(child: Text('Gagal memuat: $_error'))
          : _buildBody(),
    );
  }

  Widget _stat(String big, String small) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        big,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 26,
          fontWeight: FontWeight.w900,
          height: 1,
        ),
      ),
      const SizedBox(height: 2),
      Text(
        small,
        style: TextStyle(
          color: Colors.white.withValues(alpha: 0.85),
          fontSize: 11.5,
          fontWeight: FontWeight.w600,
        ),
      ),
    ],
  );

  Widget _buildBody() {
    final all = _filtered;
    final districts = {
      for (final c in _results) c.district,
    }.where((d) => d.isNotEmpty).toList()..sort();

    final open = all.where((c) => isOpenNow(c.hours)).length;
    final header = <Widget>[
      // Ringkasan hasil: jumlah, yang buka sekarang, poliklinik yang dicari.
      Container(
        margin: const EdgeInsets.fromLTRB(16, 4, 16, 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF0E8A7E), SehatColors.brandDeep],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _stat('${all.length}', 'klinik ditemukan'),
                Container(
                  width: 1,
                  height: 34,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  color: Colors.white24,
                ),
                _stat('$open', 'buka sekarang'),
              ],
            ),
            const SizedBox(height: 10),
            if (_matched != null)
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final s in _matched!)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.18),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        specLabel(s),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                ],
              )
            else
              Text(
                'Keluhan tidak dikenali — menampilkan semua klinik & RS. Coba kata lain.',
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.88),
                  fontSize: 12,
                  height: 1.4,
                ),
              ),
          ],
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
        child: Row(
          children: [
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    for (final s in const [
                      ['dist', 'Terdekat'],
                      ['open', 'Buka sekarang'],
                      ['name', 'Nama A–Z'],
                    ])
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: ChoiceChip(
                          label: Text(s[1]),
                          selected: _sort == s[0],
                          showCheckmark: false,
                          onSelected: (_) => setState(() => _sort = s[0]),
                          selectedColor: SehatColors.brand,
                          labelStyle: TextStyle(
                            color: _sort == s[0]
                                ? Colors.white
                                : SehatColors.brandDeep,
                            fontWeight: FontWeight.w700,
                            fontSize: 12.5,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, icon: Icon(Icons.list, size: 18)),
                ButtonSegment(
                  value: true,
                  icon: Icon(Icons.map_outlined, size: 18),
                ),
              ],
              selected: {_map},
              showSelectedIcon: false,
              onSelectionChanged: (s) => setState(() => _map = s.first),
            ),
          ],
        ),
      ),
      if (districts.isNotEmpty)
        SizedBox(
          height: 42,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: FilterChip(
                  label: const Text('Semua distrik'),
                  selected: _distFilter == null,
                  showCheckmark: false,
                  labelStyle: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: _distFilter == null
                        ? Colors.white
                        : SehatColors.brandDeep,
                  ),
                  onSelected: (_) => setState(() => _distFilter = null),
                ),
              ),
              for (final d in districts)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: FilterChip(
                    label: Text(d),
                    selected: _distFilter == d,
                    showCheckmark: false,
                    labelStyle: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: _distFilter == d
                          ? Colors.white
                          : SehatColors.brandDeep,
                    ),
                    onSelected: (_) => setState(
                      () => _distFilter = _distFilter == d ? null : d,
                    ),
                  ),
                ),
            ],
          ),
        ),
    ];

    if (_map) {
      return Column(
        children: [
          ...header,
          Expanded(child: _buildMap(all)),
        ],
      );
    }

    if (all.isEmpty) {
      return ListView(
        children: [
          ...header,
          const Padding(
            padding: EdgeInsets.all(40),
            child: Column(
              children: [
                Icon(Icons.search_off, size: 54, color: Colors.grey),
                SizedBox(height: 12),
                Text(
                  'Tidak ada klinik',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 4),
                Text(
                  'Coba ganti kata keluhan, kota lain, atau hapus filter distrik.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      );
    }

    final shown = all.take(_shown).toList();
    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        ...header,
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            children: [
              for (final c in shown)
                ClinicCard(
                  clinic: c,
                  matchedSpecs: _matched,
                  onTap: () => Navigator.of(context)
                      .push(sehatRoute(SehatDetailScreen(clinic: c)))
                      .then((_) => setState(() {})),
                ),
              if (all.length > _shown)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: OutlinedButton(
                    onPressed: () => setState(() => _shown += 50),
                    child: Text(
                      'Tampilkan ${(all.length - _shown).clamp(0, 50)} klinik lagi '
                      '(${all.length - _shown} tersisa)',
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  /// Ambil lokasi GPS pengguna, simpan, hitung ulang jarak, lalu pusatkan peta.
  Future<void> _locate() async {
    setState(() => _locating = true);
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        _toast('Izin lokasi ditolak');
        return;
      }
      final pos = await Geolocator.getCurrentPosition();
      final loc = [pos.latitude, pos.longitude];
      SehatStore.instance.setUserLoc(loc, on: true);
      for (final c in _results) {
        c.dist = haversine(loc[0], loc[1], c.lat, c.lng);
      }
      if (mounted) setState(() {});
      try {
        _mapController.move(LatLng(loc[0], loc[1]), 14);
      } catch (_) {}
    } catch (_) {
      _toast('Gagal mengambil lokasi');
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Widget _buildMap(List<Clinic> all) {
    final pts = all.take(300).toList();
    final store = SehatStore.instance;
    final county = SehatData.countyByKey(widget.county);
    final hasLoc = store.userLoc != null;
    final center = hasLoc
        ? LatLng(store.userLoc![0], store.userLoc![1])
        : LatLng(county?.lat ?? 23.7, county?.lng ?? 120.9);
    return Stack(
      children: [
        FlutterMap(
          mapController: _mapController,
          options: MapOptions(
            initialCenter: center,
            initialZoom: 12,
            onTap: (_, __) => setState(() => _selected = null),
            onMapReady: () {
              if (pts.isNotEmpty) {
                final lls = pts.map((c) => LatLng(c.lat, c.lng)).toList();
                if (hasLoc) {
                  lls.add(LatLng(store.userLoc![0], store.userLoc![1]));
                }
                try {
                  _mapController.fitCamera(
                    CameraFit.coordinates(
                      coordinates: lls,
                      padding: const EdgeInsets.all(48),
                      maxZoom: 15,
                    ),
                  );
                } catch (_) {}
              }
            },
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.pengyou.app',
              errorTileCallback: (tile, error, stackTrace) {
                if (!_tilesFailed && mounted) {
                  setState(() => _tilesFailed = true);
                }
              },
            ),
            MarkerLayer(
              markers: [
                for (final c in pts)
                  Marker(
                    point: LatLng(c.lat, c.lng),
                    width: 32,
                    height: 32,
                    child: GestureDetector(
                      onTap: () => setState(() => _selected = c),
                      child: Container(
                        decoration: BoxDecoration(
                          color: clinicColor(c),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: _selected?.id == c.id
                                ? SehatColors.brandDeep
                                : Colors.white,
                            width: _selected?.id == c.id ? 4 : 2.5,
                          ),
                          boxShadow: const [
                            BoxShadow(color: Colors.black26, blurRadius: 3),
                          ],
                        ),
                        child: Icon(
                          clinicIcon(c),
                          color: Colors.white,
                          size: 17,
                        ),
                      ),
                    ),
                  ),
                // Titik "lokasimu" — halo biru + titik putih agar menonjol.
                if (hasLoc)
                  Marker(
                    point: LatLng(store.userLoc![0], store.userLoc![1]),
                    width: 30,
                    height: 30,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: SehatColors.nhi.withValues(alpha: 0.25),
                      ),
                      child: Center(
                        child: Container(
                          width: 16,
                          height: 16,
                          decoration: BoxDecoration(
                            color: SehatColors.nhi,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 3),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
        // Keterangan di atas peta (+ peringatan bila tile gagal dimuat).
        Positioned(
          top: 8,
          left: 12,
          right: 12,
          child: Column(
            children: [
              _mapNote(hasLoc),
              if (_tilesFailed) ...[
                const SizedBox(height: 8),
                _tileFailBanner(),
              ],
            ],
          ),
        ),
        // Tombol "Lokasiku".
        Positioned(
          right: 12,
          bottom: _selected != null ? 158 : 16,
          child: FloatingActionButton.small(
            heroTag: 'loc',
            backgroundColor: Colors.white,
            foregroundColor: SehatColors.brandDeep,
            onPressed: _locating ? null : _locate,
            child: _locating
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.my_location),
          ),
        ),
        // Kartu klinik terpilih.
        if (_selected != null)
          Positioned(
            left: 12,
            right: 12,
            bottom: 12,
            child: _selectedCard(_selected!),
          ),
      ],
    );
  }

  /// Pita keterangan: jelaskan titik biru & dasar urutan "Terdekat".
  Widget _mapNote(bool hasLoc) {
    return Material(
      elevation: 2,
      borderRadius: BorderRadius.circular(12),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        child: hasLoc
            ? Row(
                children: [
                  Container(
                    width: 14,
                    height: 14,
                    decoration: BoxDecoration(
                      color: SehatColors.nhi,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text(
                      'Titik biru = lokasimu. "Terdekat" dihitung dari sini. '
                      'Ketuk pin untuk lihat kliniknya.',
                      style: TextStyle(fontSize: 11.5, height: 1.3),
                    ),
                  ),
                ],
              )
            : Row(
                children: [
                  const Icon(
                    Icons.location_off,
                    size: 16,
                    color: SehatColors.alert,
                  ),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text(
                      'Lokasimu belum aktif — urutan "Terdekat" dihitung dari pusat kota.',
                      style: TextStyle(fontSize: 11.5, height: 1.3),
                    ),
                  ),
                  const SizedBox(width: 6),
                  TextButton(
                    onPressed: _locating ? null : _locate,
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      minimumSize: const Size(0, 32),
                      foregroundColor: SehatColors.brandDeep,
                    ),
                    child: const Text(
                      'Aktifkan',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  /// Peringatan bila tile peta gagal dimuat (offline / jaringan).
  Widget _tileFailBanner() {
    return Material(
      elevation: 2,
      borderRadius: BorderRadius.circular(12),
      color: const Color(0xFFFCEFEA),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        child: Row(
          children: [
            const Icon(Icons.wifi_off, size: 16, color: SehatColors.alert),
            const SizedBox(width: 8),
            const Expanded(
              child: Text(
                'Peta gagal dimuat (cek internet). Daftar klinik tetap bisa dipakai.',
                style: TextStyle(fontSize: 11.5, height: 1.3),
              ),
            ),
            const SizedBox(width: 6),
            TextButton(
              onPressed: () => setState(() => _map = false),
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                minimumSize: const Size(0, 32),
                foregroundColor: SehatColors.brandDeep,
              ),
              child: const Text(
                'Lihat daftar',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Kartu info klinik yang dipilih dari pin peta.
  Widget _selectedCard(Clinic c) {
    final ob = openBadge(c.hours);
    final dist = c.dist != null ? ' · ${c.dist!.toStringAsFixed(1)} km' : '';
    return Material(
      elevation: 6,
      borderRadius: BorderRadius.circular(18),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: clinicColor(c),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(clinicIcon(c), color: Colors.white, size: 21),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        c.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          height: 1.2,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        [c.district, c.type].where((x) => x.isNotEmpty).join(' · ') + dist,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        ob.text,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: ob.open ? SehatColors.ok : SehatColors.alert,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, size: 20),
                  onPressed: () => setState(() => _selected = null),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => Navigator.of(context)
                        .push(sehatRoute(SehatDetailScreen(clinic: c)))
                        .then((_) => setState(() {})),
                    icon: const Icon(Icons.info_outline, size: 18),
                    label: const Text('Lihat detail'),
                    style: FilledButton.styleFrom(
                      backgroundColor: SehatColors.brand,
                      minimumSize: const Size(0, 44),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
