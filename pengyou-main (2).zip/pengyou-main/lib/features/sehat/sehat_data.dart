import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

/// ===== Model =====

class County {
  County({
    required this.key,
    required this.zh,
    required this.en,
    required this.count,
    required this.lat,
    required this.lng,
    required this.districts,
  });

  final String key;
  final String zh;
  final String en;
  final int count;
  final double lat;
  final double lng;
  final List<String> districts;

  factory County.fromJson(Map<String, dynamic> j) => County(
        key: j['key'] as String,
        zh: j['zh'] as String,
        en: j['en'] as String,
        count: (j['count'] as num).toInt(),
        lat: (j['lat'] as num).toDouble(),
        lng: (j['lng'] as num).toDouble(),
        districts:
            (j['districts'] as List?)?.map((e) => e.toString()).toList() ?? [],
      );
}

class Clinic {
  Clinic({
    required this.id,
    required this.name,
    required this.kind,
    required this.type,
    required this.phone,
    required this.addr,
    required this.district,
    required this.spec,
    required this.hours,
    required this.hosp,
    required this.lat,
    required this.lng,
    this.county,
  });

  final String id;
  final String name;
  final String kind;
  final String type;
  final String phone;
  final String addr;
  final String district;
  final List<String> spec;
  final String hours; // 21 chars: 7 days x 3 sessions ("1"/"0")
  final bool hosp;
  final double lat;
  final double lng;
  String? county; // stored on saved snapshots
  double? dist; // computed distance (km)

  factory Clinic.fromJson(Map<String, dynamic> j) => Clinic(
        id: j['id'].toString(),
        name: (j['name'] ?? '').toString(),
        kind: (j['kind'] ?? 'western').toString(),
        type: (j['type'] ?? '').toString(),
        phone: (j['phone'] ?? '').toString(),
        addr: (j['addr'] ?? '').toString(),
        district: (j['district'] ?? '').toString(),
        spec: (j['spec'] as List?)?.map((e) => e.toString()).toList() ?? [],
        hours: (j['hours'] ?? '').toString(),
        hosp: j['hosp'] == true,
        lat: (j['lat'] as num?)?.toDouble() ?? 0,
        lng: (j['lng'] as num?)?.toDouble() ?? 0,
        county: j['_county']?.toString(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'kind': kind,
        'type': type,
        'phone': phone,
        'addr': addr,
        'district': district,
        'spec': spec,
        'hours': hours,
        'hosp': hosp,
        'lat': lat,
        'lng': lng,
        '_county': county,
      };
}

/// ===== Konstanta (port dari Sehat Rantau) =====

class SpecInfo {
  const SpecInfo(this.id, this.icon);
  final String id;
  final IconData icon;
}

const Map<String, SpecInfo> kSpec = {
  '牙科': SpecInfo('Gigi', Icons.masks_outlined),
  '家庭牙醫科': SpecInfo('Gigi Keluarga', Icons.masks_outlined),
  '口腔顎面外科': SpecInfo('Bedah Mulut', Icons.masks_outlined),
  '兒童牙科': SpecInfo('Gigi Anak', Icons.masks_outlined),
  '齒顎矯正科': SpecInfo('Ortodonti (behel)', Icons.masks_outlined),
  '牙周病科': SpecInfo('Gusi', Icons.masks_outlined),
  '內科': SpecInfo('Penyakit Dalam', Icons.favorite_outline),
  '家醫科': SpecInfo('Kedokteran Keluarga', Icons.family_restroom),
  '不分科': SpecInfo('Umum', Icons.medical_services_outlined),
  '兒科': SpecInfo('Anak', Icons.child_care),
  '耳鼻喉科(耳鼻喉頭頸外科)':
      SpecInfo('THT (Telinga-Hidung-Tenggorokan)', Icons.hearing),
  '眼科': SpecInfo('Mata', Icons.visibility_outlined),
  '婦產科': SpecInfo('Kandungan & Kebidanan', Icons.pregnant_woman),
  '外科': SpecInfo('Bedah Umum', Icons.healing),
  '復健科': SpecInfo('Rehabilitasi', Icons.accessibility_new),
  '骨科': SpecInfo('Ortopedi (tulang)', Icons.accessibility_new),
  '皮膚科': SpecInfo('Kulit', Icons.spa_outlined),
  '精神科': SpecInfo('Kejiwaan', Icons.psychology_outlined),
  '神經科': SpecInfo('Saraf', Icons.psychology_alt_outlined),
  '神經外科': SpecInfo('Bedah Saraf', Icons.psychology_alt_outlined),
  '泌尿科': SpecInfo('Urologi', Icons.water_drop_outlined),
  '整形外科': SpecInfo('Bedah Plastik', Icons.face_retouching_natural),
  '中醫一般科': SpecInfo('Pengobatan Tradisional (中醫)', Icons.eco_outlined),
  '急診醫學科': SpecInfo('Gawat Darurat', Icons.local_hospital_outlined),
  '麻醉科': SpecInfo('Anestesi', Icons.bedtime_outlined),
  '放射診斷科': SpecInfo('Radiologi', Icons.radio_button_checked),
};

String specLabel(String zh) => kSpec[zh]?.id ?? zh;
IconData specIconOf(String zh) => kSpec[zh]?.icon ?? Icons.medical_services;

const Color kWesternColor = Color(0xFF0F766E);
const Color kDentalColor = Color(0xFF2C8C9A);
const Color kTcmColor = Color(0xFF8A8A2B);
const Color kHospitalColor = Color(0xFF4B6E85);

Color clinicColor(Clinic c) {
  if (c.hosp) return kHospitalColor;
  switch (c.kind) {
    case 'dental':
      return kDentalColor;
    case 'tcm':
      return kTcmColor;
    default:
      return kWesternColor;
  }
}

IconData clinicIcon(Clinic c) {
  for (final s in c.spec) {
    if (kSpec.containsKey(s)) return kSpec[s]!.icon;
  }
  return c.hosp ? Icons.local_hospital : Icons.medical_services_outlined;
}

/// Peta kata keluhan (Indonesia) → daftar 科別.
const List<(List<String>, List<String>)> kKeymap = [
  (
    ['sakit perut', 'perut', 'mual', 'muntah', 'diare', 'mencret', 'maag',
      'lambung', 'masuk angin', 'keracunan', 'sembelit', 'mag'],
    ['內科', '家醫科', '不分科']
  ),
  (
    ['demam', 'panas', 'batuk', 'pilek', 'flu', 'meriang', 'radang',
      'badan pegal', 'lemas', 'tenggorokan gatal'],
    ['家醫科', '內科', '不分科']
  ),
  (
    ['keseleo', 'terkilir', 'bahu', 'nyeri sendi', 'sendi', 'sakit punggung',
      'pinggang', 'patah', 'tulang', 'cedera', 'encok', 'lutut', 'pergelangan'],
    ['骨科', '復健科']
  ),
  (
    ['rehabilitasi', 'fisioterapi', 'pemulihan', 'stroke', 'otot kaku',
      'saraf kejepit', 'terapi'],
    ['復健科', '骨科']
  ),
  (
    ['sakit gigi', 'gigi', 'gusi', 'berlubang', 'behel', 'ompong',
      'karang gigi', 'bengkak gusi'],
    ['牙科', '家庭牙醫科', '口腔顎面外科']
  ),
  (
    ['mata', 'mata merah', 'mata gatal', 'penglihatan', 'bintitan', 'minus',
      'silinder', 'katarak', 'belek'],
    ['眼科']
  ),
  (
    ['kulit', 'gatal', 'alergi', 'jerawat', 'ruam', 'biduran', 'kutil',
      'panu', 'eksim', 'bisul', 'kurap'],
    ['皮膚科']
  ),
  (
    ['telinga', 'hidung', 'tenggorokan', 'radang tenggorokan', 'sinus',
      'mimisan', 'vertigo', 'amandel', 'serak', 'budek'],
    ['耳鼻喉科(耳鼻喉頭頸外科)']
  ),
  (
    ['hamil', 'kandungan', 'haid', 'menstruasi', 'keputihan', 'kb',
      'melahirkan', 'kista', 'pap smear', 'janin'],
    ['婦產科']
  ),
  (['anak', 'bayi', 'balita', 'imunisasi', 'vaksin anak', 'demam anak'], ['兒科']),
  (
    ['kencing', 'buang air kecil', 'prostat', 'batu ginjal', 'saluran kemih',
      'isk', 'ereksi', 'ginjal'],
    ['泌尿科']
  ),
  (
    ['cemas', 'depresi', 'susah tidur', 'insomnia', 'stres', 'stress',
      'mental', 'panik', 'kejiwaan', 'trauma'],
    ['精神科']
  ),
  (
    ['sakit kepala', 'pusing', 'migrain', 'kejang', 'kesemutan', 'saraf',
      'tremor', 'lumpuh'],
    ['神經科', '內科']
  ),
  (
    ['benjolan', 'operasi', 'luka', 'usus buntu', 'hernia', 'wasir',
      'ambeien', 'tumor'],
    ['外科']
  ),
  (
    ['luka bakar', 'operasi plastik', 'rekonstruksi', 'sedot lemak', 'jahit luka'],
    ['整形外科']
  ),
  (
    ['akupunktur', 'herbal', 'pengobatan tradisional', 'tradisional china',
      'tuina', 'pijat medis', 'tusuk jarum'],
    ['中醫一般科']
  ),
  (['gawat darurat', 'darurat', 'ugd', 'igd', 'emergency'], ['急診醫學科', '外科', '內科']),
];

const List<(String label, String q)> kChips = [
  ('sakit perut', 'sakit perut'),
  ('muntah / mual', 'muntah'),
  ('demam', 'demam'),
  ('batuk & pilek', 'batuk'),
  ('bahu keseleo', 'keseleo'),
  ('nyeri sendi', 'nyeri sendi'),
  ('sakit gigi', 'sakit gigi'),
  ('kulit gatal', 'gatal'),
  ('mata merah', 'mata merah'),
  ('THT', 'tenggorokan'),
  ('sakit kepala', 'sakit kepala'),
  ('kandungan', 'kandungan'),
];

class Phrase {
  const Phrase(this.zh, this.pin, this.id);
  final String zh;
  final String pin;
  final String id;
}

const Map<String, Phrase> kPhrase = {
  '內科': Phrase('我肚子痛、想吐。', 'Wǒ dùzi tòng, xiǎng tù.',
      '"Perut saya sakit dan mual/mau muntah."'),
  '家醫科': Phrase('我發燒、咳嗽、流鼻水。', 'Wǒ fāshāo, késòu, liú bíshuǐ.',
      '"Saya demam, batuk, dan pilek."'),
  '骨科': Phrase('我這裡扭傷了，很痛。', 'Wǒ zhèlǐ niǔshāng le, hěn tòng.',
      '"Bagian ini keseleo dan sangat sakit."'),
  '復健科':
      Phrase('我需要復健治療。', 'Wǒ xūyào fùjiàn zhìliáo.', '"Saya perlu terapi rehabilitasi."'),
  '牙科': Phrase('我牙齒很痛。', 'Wǒ yáchǐ hěn tòng.', '"Gigi saya sangat sakit."'),
  '眼科': Phrase('我的眼睛紅、很癢。', 'Wǒ de yǎnjīng hóng, hěn yǎng.',
      '"Mata saya merah dan gatal."'),
  '皮膚科': Phrase('我的皮膚很癢、起疹子。', 'Wǒ de pífū hěn yǎng, qǐ zhěnzi.',
      '"Kulit saya gatal dan muncul ruam."'),
  '耳鼻喉科(耳鼻喉頭頸外科)': Phrase('我喉嚨痛、鼻塞。', 'Wǒ hóulóng tòng, bísāi.',
      '"Tenggorokan saya sakit dan hidung tersumbat."'),
  '婦產科': Phrase('我月經不順／懷孕了。', 'Wǒ yuèjīng bú shùn / huáiyùn le.',
      '"Haid saya tidak lancar / saya hamil."'),
  '泌尿科':
      Phrase('我小便會痛。', 'Wǒ xiǎobiàn huì tòng.', '"Saya sakit saat buang air kecil."'),
  '神經科': Phrase('我常常頭痛、頭暈。', 'Wǒ chángcháng tóutòng, tóuyūn.',
      '"Saya sering sakit kepala dan pusing."'),
  '兒科': Phrase('我的小孩發燒了。', 'Wǒ de xiǎohái fāshāo le.', '"Anak saya demam."'),
};

const Phrase kPhraseDefault = Phrase('我不舒服，想看醫生。', 'Wǒ bù shūfú, xiǎng kàn yīshēng.',
    '"Saya kurang enak badan, ingin periksa ke dokter."');
const Phrase kPhraseNhi =
    Phrase('我要用健保。', 'Wǒ yào yòng jiànbǎo.', '"Saya mau pakai asuransi NHI (健保)."');
const Phrase kPhraseEn = Phrase('有會說英文的醫生嗎？', 'Yǒu huì shuō yīngwén de yīshēng ma?',
    '"Ada dokter yang bisa bahasa Inggris?"');

const kDayNames = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
const kSessNames = ['Pagi', 'Siang', 'Malam'];

/// ===== Helper =====

double haversine(double aLat, double aLng, double bLat, double bLng) {
  const r = 6371.0;
  const rad = math.pi / 180.0;
  final dLat = (bLat - aLat) * rad;
  final dLng = (bLng - aLng) * rad;
  final x = math.pow(math.sin(dLat / 2), 2) +
      math.cos(aLat * rad) * math.cos(bLat * rad) * math.pow(math.sin(dLng / 2), 2);
  return 2 * r * math.asin(math.sqrt(x.toDouble()));
}

int sessionNow([DateTime? now]) {
  final h = (now ?? DateTime.now()).hour;
  return h < 12 ? 0 : (h < 18 ? 1 : 2);
}

int dayIdx([DateTime? now]) {
  final d = (now ?? DateTime.now()).weekday; // Mon=1..Sun=7
  return d - 1; // data index Mon..Sun = 0..6
}

bool isOpenNow(String hours) {
  if (hours.length < 21) return false;
  return hours[dayIdx() * 3 + sessionNow()] == '1';
}

class OpenBadge {
  const OpenBadge(this.open, this.text);
  final bool open;
  final String text;
}

OpenBadge openBadge(String hours) {
  if (isOpenNow(hours)) return const OpenBadge(true, 'Buka sekarang');
  const names = ['pagi', 'siang', 'malam'];
  final di = dayIdx();
  for (var s = sessionNow() + 1; s < 3; s++) {
    if (hours.length >= 21 && hours[di * 3 + s] == '1') {
      return OpenBadge(false, 'Buka nanti ${names[s]}');
    }
  }
  return const OpenBadge(false, 'Tutup sekarang');
}

/// Cocokkan keluhan ke daftar 科別 (null jika tak dikenali).
Set<String>? matchSpecs(String query) {
  final q = query.trim().toLowerCase();
  if (q.isEmpty) return null;
  final set = <String>{};
  for (final (terms, specs) in kKeymap) {
    if (terms.any((t) => q.contains(t) || t.contains(q))) {
      set.addAll(specs);
    }
  }
  return set.isEmpty ? null : set;
}

/// ===== Data service (aset lokal) =====

class SehatData {
  static Map<String, dynamic>? _manifest;
  static List<County>? _counties;
  static final Map<String, List<Clinic>> _cache = {};

  static Future<void> loadManifest() async {
    if (_manifest != null) return;
    final raw = await rootBundle.loadString('assets/sehat/manifest.json');
    _manifest = jsonDecode(raw) as Map<String, dynamic>;
    _counties = (_manifest!['counties'] as List)
        .map((e) => County.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  static int get total => (_manifest?['total'] as num?)?.toInt() ?? 0;
  static List<County> get counties => _counties ?? const [];

  static County? countyByKey(String? key) {
    for (final c in counties) {
      if (c.key == key) return c;
    }
    return null;
  }

  static String countyLabel(String? key) => countyByKey(key)?.zh ?? (key ?? '');

  static Future<List<Clinic>> loadCounty(String key) async {
    if (_cache.containsKey(key)) return _cache[key]!;
    final raw = await rootBundle.loadString('assets/sehat/clinics_$key.json');
    final list = (jsonDecode(raw) as List)
        .map((e) => Clinic.fromJson(e as Map<String, dynamic>))
        .toList();
    _cache[key] = list;
    return list;
  }
}
