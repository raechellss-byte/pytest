import 'package:flutter/material.dart';

import '../../screens/auth/login_prompt.dart';
import 'sehat_app.dart' show SehatColors;
import 'sehat_sync.dart';

/// ============================================================
/// Komponen tampilan bersama Sehat Rantau: tema teal, header bergradasi,
/// judul bagian, pil status. Dipakai semua tab & halaman Sehat.
/// ============================================================

/// Riwayat Sehat (klinik tersimpan, catatan, pencarian) hanya disimpan untuk
/// pengguna yang sudah masuk. true = boleh lanjut; false = tampil ajakan masuk.
bool sehatCanSave(BuildContext context, String reason) {
  if (SehatSync.signedIn) return true;
  showLoginRequired(context, reason: reason, next: '/sehat', color: SehatColors.brand);
  return false;
}

/// Latar halaman Sehat (mint sangat lembut).
const kSehatBg = Color(0xFFF3F8F6);

/// Tema Sehat: tema app + aksen teal (tombol, chip, navigasi, input).
ThemeData sehatTheme(ThemeData base) {
  const brand = SehatColors.brand;
  final scheme = base.colorScheme.copyWith(
    primary: brand,
    onPrimary: Colors.white,
    secondary: SehatColors.brandDeep,
    primaryContainer: SehatColors.brandSoft,
    onPrimaryContainer: SehatColors.brandDeep,
    surfaceTint: Colors.transparent,
  );
  final label = base.navigationBarTheme.labelTextStyle?.resolve({});
  return base.copyWith(
    colorScheme: scheme,
    scaffoldBackgroundColor: kSehatBg,
    progressIndicatorTheme: const ProgressIndicatorThemeData(color: brand),
    appBarTheme: base.appBarTheme.copyWith(
      backgroundColor: kSehatBg,
      surfaceTintColor: Colors.transparent,
      foregroundColor: SehatColors.brandDeep,
    ),
    cardTheme: base.cardTheme.copyWith(
      color: Colors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: brand.withValues(alpha: 0.08)),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: (base.filledButtonTheme.style ?? const ButtonStyle()).copyWith(
        backgroundColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.disabled)
              ? brand.withValues(alpha: 0.35)
              : brand,
        ),
        foregroundColor: const WidgetStatePropertyAll(Colors.white),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: (base.outlinedButtonTheme.style ?? const ButtonStyle()).copyWith(
        foregroundColor: const WidgetStatePropertyAll(SehatColors.brandDeep),
        side: WidgetStatePropertyAll(
          BorderSide(color: brand.withValues(alpha: 0.35), width: 1.5),
        ),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: (base.textButtonTheme.style ?? const ButtonStyle()).copyWith(
        foregroundColor: const WidgetStatePropertyAll(SehatColors.brandDeep),
      ),
    ),
    chipTheme: base.chipTheme.copyWith(
      backgroundColor: Colors.white,
      selectedColor: brand,
      checkmarkColor: Colors.white,
      side: BorderSide(color: brand.withValues(alpha: 0.18)),
      labelStyle: base.chipTheme.labelStyle?.copyWith(
        color: SehatColors.brandDeep,
      ),
      secondaryLabelStyle: base.chipTheme.labelStyle?.copyWith(
        color: Colors.white,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
    ),
    inputDecorationTheme: base.inputDecorationTheme.copyWith(
      fillColor: Colors.white,
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: brand, width: 2),
      ),
    ),
    segmentedButtonTheme: SegmentedButtonThemeData(
      style: SegmentedButton.styleFrom(
        selectedBackgroundColor: brand,
        selectedForegroundColor: Colors.white,
        foregroundColor: SehatColors.brandDeep,
        side: BorderSide(color: brand.withValues(alpha: 0.3)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
    navigationBarTheme: base.navigationBarTheme.copyWith(
      backgroundColor: Colors.white,
      indicatorColor: brand.withValues(alpha: 0.14),
      labelTextStyle: WidgetStateProperty.resolveWith(
        (s) => (label ?? const TextStyle()).copyWith(
          color: s.contains(WidgetState.selected)
              ? SehatColors.brandDeep
              : Colors.blueGrey.shade400,
        ),
      ),
      iconTheme: WidgetStateProperty.resolveWith(
        (s) => IconThemeData(
          color: s.contains(WidgetState.selected)
              ? brand
              : Colors.blueGrey.shade300,
        ),
      ),
    ),
    floatingActionButtonTheme: base.floatingActionButtonTheme.copyWith(
      backgroundColor: brand,
      foregroundColor: Colors.white,
    ),
  );
}

/// Bungkus halaman Sehat dengan tema teal.
class SehatThemed extends StatelessWidget {
  const SehatThemed({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) =>
      Theme(data: sehatTheme(Theme.of(context)), child: child);
}

/// Route halaman Sehat (ikut tema teal).
Route<T> sehatRoute<T>(Widget page) =>
    MaterialPageRoute<T>(builder: (_) => SehatThemed(child: page));

/// Header bergradasi teal dengan sudut bawah membulat + ikon hiasan besar.
class SehatHero extends StatelessWidget {
  const SehatHero({
    super.key,
    required this.title,
    this.eyebrow,
    this.subtitle,
    this.icon = Icons.health_and_safety_rounded,
    this.child,
    this.onBack,
    this.colors = const [Color(0xFF0E8A7E), SehatColors.brandDeep],
    this.trailing,
  });

  final String title;
  final String? eyebrow; // teks kecil di atas judul
  final String? subtitle;
  final IconData icon; // ikon hiasan transparan di kanan
  final Widget? child; // mis. kolom pencarian
  final VoidCallback? onBack; // null = tanpa tombol kembali
  final List<Color> colors;
  final Widget? trailing; // aksi di kanan atas

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(28)),
        boxShadow: [
          BoxShadow(
            color: colors.last.withValues(alpha: 0.28),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: -24,
            top: -10,
            child: Icon(
              icon,
              size: 150,
              color: Colors.white.withValues(alpha: 0.09),
            ),
          ),
          Positioned(
            left: -40,
            bottom: -60,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.06),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(16, top + 10, 16, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    if (onBack != null) ...[
                      Material(
                        color: Colors.white.withValues(alpha: 0.16),
                        shape: const CircleBorder(),
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onTap: onBack,
                          child: const Padding(
                            padding: EdgeInsets.all(8),
                            child: Icon(
                              Icons.arrow_back_rounded,
                              color: Colors.white,
                              size: 20,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                    ],
                    if (eyebrow != null)
                      Expanded(
                        child: Text(
                          eyebrow!.toUpperCase(),
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.85),
                            fontSize: 11,
                            letterSpacing: 1.1,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      )
                    else
                      const Spacer(),
                    if (trailing != null) trailing!,
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.w900,
                    height: 1.1,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    subtitle!,
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.88),
                      fontSize: 13.5,
                      height: 1.4,
                    ),
                  ),
                ],
                if (child != null) ...[const SizedBox(height: 16), child!],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Judul bagian: teks tebal + keterangan kecil di kanan.
class SehatSection extends StatelessWidget {
  const SehatSection(this.title, {super.key, this.trailing, this.icon, this.onTrailing});
  final String title;
  final String? trailing;
  final IconData? icon;

  /// Bila diisi, [trailing] menjadi tombol (mis. "Hapus semua").
  final VoidCallback? onTrailing;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(2, 20, 2, 10),
    child: Row(
      children: [
        if (icon != null) ...[
          Icon(icon, size: 18, color: SehatColors.brand),
          const SizedBox(width: 8),
        ],
        Expanded(
          child: Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
          ),
        ),
        if (trailing != null && onTrailing != null)
          Semantics(
            button: true,
            child: InkWell(
              onTap: onTrailing,
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                child: Text(
                  trailing!,
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: SehatColors.brand,
                  ),
                ),
              ),
            ),
          )
        else if (trailing != null)
          Text(
            trailing!,
            style: TextStyle(fontSize: 12, color: Colors.blueGrey.shade400),
          ),
      ],
    ),
  );
}

/// Pil kecil berikon (status buka, NHI, jarak, dll.).
class SehatPill extends StatelessWidget {
  const SehatPill(
    this.text, {
    super.key,
    this.icon,
    required this.fg,
    required this.bg,
  });
  final String text;
  final IconData? icon;
  final Color fg, bg;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(
      color: bg,
      borderRadius: BorderRadius.circular(999),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (icon != null) ...[
          Icon(icon, size: 13, color: fg),
          const SizedBox(width: 4),
        ],
        Text(
          text,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w800,
            color: fg,
          ),
        ),
      ],
    ),
  );
}

/// Kartu putih membulat dengan bayangan lembut (blok konten).
class SehatCard extends StatelessWidget {
  const SehatCard({super.key, required this.child, this.padding, this.onTap});
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      boxShadow: [
        BoxShadow(
          color: SehatColors.brandDeep.withValues(alpha: 0.06),
          blurRadius: 16,
          offset: const Offset(0, 6),
        ),
      ],
    ),
    child: Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: padding ?? const EdgeInsets.all(16),
          child: child,
        ),
      ),
    ),
  );
}

/// Kotak ikon bergradasi (untuk ikon klinik / kategori).
class SehatIconTile extends StatelessWidget {
  const SehatIconTile({
    super.key,
    required this.icon,
    required this.color,
    this.size = 48,
  });
  final IconData icon;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      gradient: LinearGradient(
        colors: [
          Color.lerp(color, Colors.white, 0.12)!,
          Color.lerp(color, Colors.black, 0.18)!,
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      borderRadius: BorderRadius.circular(size * 0.3),
      boxShadow: [
        BoxShadow(
          color: color.withValues(alpha: 0.3),
          blurRadius: 8,
          offset: const Offset(0, 3),
        ),
      ],
    ),
    child: Icon(icon, color: Colors.white, size: size * 0.5),
  );
}
