import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

import 'sehat_app.dart';
import 'sehat_data.dart';
import 'sehat_store.dart';
import 'sehat_ui.dart';

class SehatDetailScreen extends StatefulWidget {
  const SehatDetailScreen({super.key, required this.clinic});
  final Clinic clinic;

  @override
  State<SehatDetailScreen> createState() => _SehatDetailScreenState();
}

class _SehatDetailScreenState extends State<SehatDetailScreen> {
  Clinic get c => widget.clinic;

  void _copy(String t) {
    Clipboard.setData(ClipboardData(text: t));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Disalin — tinggal tunjukkan ke staf')),
    );
  }

  Future<void> _launch(Uri uri) async {
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final store = SehatStore.instance;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final ob = openBadge(c.hours);
        final saved = store.isSaved(c.id);
        Phrase ph = kPhraseDefault;
        for (final s in c.spec) {
          if (kPhrase.containsKey(s)) {
            ph = kPhrase[s]!;
            break;
          }
        }
        final di = dayIdx();
        final color = clinicColor(c);
        final route = Uri.parse(
          'https://www.google.com/maps/dir/?api=1&destination=${Uri.encodeComponent('${c.name} ${c.addr}')}',
        );
        return Scaffold(
          // Tombol utama selalu terlihat di bawah.
          bottomNavigationBar: SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.06),
                    blurRadius: 12,
                    offset: const Offset(0, -4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  if (c.phone.isNotEmpty) ...[
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _launch(
                          Uri.parse(
                            'tel:${c.phone.replaceAll(RegExp(r'[^0-9+]'), '')}',
                          ),
                        ),
                        icon: const Icon(Icons.call_rounded),
                        label: const Text('Telepon'),
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size(0, 50),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                  ],
                  Expanded(
                    flex: 2,
                    child: FilledButton.icon(
                      onPressed: () => _launch(route),
                      icon: const Icon(Icons.directions_rounded),
                      label: const Text('Rute ke sini'),
                      style: FilledButton.styleFrom(
                        minimumSize: const Size(0, 50),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          body: ListView(
            padding: const EdgeInsets.only(bottom: 24),
            children: [
              _hero(color, ob, saved, store),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Aksi cepat bulat.
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        if (c.phone.isNotEmpty)
                          _action(
                            Icons.call_rounded,
                            'Telepon',
                            () => _launch(
                              Uri.parse(
                                'tel:${c.phone.replaceAll(RegExp(r'[^0-9+]'), '')}',
                              ),
                            ),
                          ),
                        _action(
                          Icons.directions_rounded,
                          'Rute',
                          () => _launch(route),
                        ),
                        _action(
                          saved
                              ? Icons.bookmark_rounded
                              : Icons.bookmark_border_rounded,
                          saved ? 'Tersimpan' : 'Simpan',
                          () {
                            if (sehatCanSave(context,
                                'Simpan klinik ini ke akunmu supaya mudah dibuka lagi.')) {
                              store.toggleSave(c);
                            }
                          },
                          active: saved,
                        ),
                        _action(
                          Icons.content_copy_rounded,
                          'Salin alamat',
                          () => _copy(c.addr),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    _block(
                      'Bisa menangani (poliklinik)',
                      Icons.medical_services_outlined,
                      Wrap(
                        spacing: 7,
                        runSpacing: 7,
                        children: [
                          for (final s in c.spec)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 11,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: SehatColors.brandSoft.withValues(
                                  alpha: 0.5,
                                ),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(
                                  color: SehatColors.brand.withValues(
                                    alpha: 0.2,
                                  ),
                                ),
                              ),
                              child: Text.rich(
                                TextSpan(
                                  children: [
                                    TextSpan(
                                      text: specLabel(s),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        color: SehatColors.brandDeep,
                                        fontSize: 12.5,
                                      ),
                                    ),
                                    if (specLabel(s) != s)
                                      TextSpan(
                                        text: '  $s',
                                        style: TextStyle(
                                          color: Colors.grey.shade600,
                                          fontSize: 12,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    _block(
                      'Terima asuransi NHI (健保)',
                      Icons.verified_user,
                      Text(
                        'Klinik ini terikat kontrak NHI. Tunjukkan kartu NHI (健保卡); '
                        'biaya kunjungan umumnya sekitar NT\$150–NT\$400. Kalau belum '
                        'punya NHI, tetap bisa berobat tapi bayar sendiri.',
                        style: TextStyle(
                          color: Colors.grey.shade700,
                          height: 1.45,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    _block(
                      'Kalimat untuk ke dokter',
                      Icons.volume_up_outlined,
                      Column(
                        children: [
                          _phrase(ph),
                          const Divider(height: 18),
                          _phrase(kPhraseNhi),
                          const Divider(height: 18),
                          _phrase(kPhraseEn),
                        ],
                      ),
                    ),
                    _block(
                      'Jam praktik',
                      Icons.schedule,
                      Column(
                        children: [
                          for (var d = 0; d < 7; d++) _hoursRow(d, di),
                        ],
                      ),
                    ),
                    _block(
                      'Lokasi',
                      Icons.map_outlined,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: SizedBox(
                              height: 160,
                              child: FlutterMap(
                                options: MapOptions(
                                  initialCenter: LatLng(c.lat, c.lng),
                                  initialZoom: 15,
                                  interactionOptions: const InteractionOptions(
                                    flags: InteractiveFlag.none,
                                  ),
                                ),
                                children: [
                                  TileLayer(
                                    urlTemplate:
                                        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                                    userAgentPackageName: 'com.pengyou.app',
                                  ),
                                  MarkerLayer(
                                    markers: [
                                      Marker(
                                        point: LatLng(c.lat, c.lng),
                                        width: 22,
                                        height: 22,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: clinicColor(c),
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color: Colors.white,
                                              width: 3,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Titik perkiraan berdasarkan distrik. Untuk arah tepat, pakai tombol Rute.',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _block(
                      'Catatan berobat',
                      Icons.description_outlined,
                      OutlinedButton.icon(
                        onPressed: () async {
                          if (!sehatCanSave(context,
                              'Catatan berobat (keluhan, obat, biaya) disimpan di akunmu — pribadi, hanya kamu yang bisa lihat.')) {
                            return;
                          }
                          await Navigator.of(context).push(
                            sehatRoute(SehatVisitForm(prefillClinic: c.name)),
                          );
                          if (mounted) setState(() {});
                        },
                        icon: const Icon(Icons.add),
                        label: const Text('Catat kunjungan ke klinik ini'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  /// Header bergradasi warna jenis klinik: nama, jenis, alamat, status.
  Widget _hero(Color color, OpenBadge ob, bool saved, SehatStore store) {
    final top = MediaQuery.of(context).padding.top;
    final dark = Color.lerp(color, Colors.black, 0.35)!;
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color, dark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -20,
            top: 10,
            child: Icon(
              clinicIcon(c),
              size: 150,
              color: Colors.white.withValues(alpha: 0.1),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(16, top + 10, 16, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _circleBtn(
                      Icons.arrow_back_rounded,
                      () => Navigator.of(context).maybePop(),
                    ),
                    const Spacer(),
                    _circleBtn(
                      saved
                          ? Icons.bookmark_rounded
                          : Icons.bookmark_border_rounded,
                      () {
                        if (sehatCanSave(context,
                            'Simpan klinik ini ke akunmu supaya mudah dibuka lagi.')) {
                          store.toggleSave(c);
                        }
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    '${c.type} · ${c.hosp ? 'Rumah sakit' : 'Klinik'}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  c.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    height: 1.15,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.location_on_rounded,
                      size: 16,
                      color: Colors.white.withValues(alpha: 0.85),
                    ),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        c.addr,
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.9),
                          fontSize: 13,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ],
                ),
                if (c.phone.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Row(children: [
                    Icon(Icons.call_rounded,
                        size: 15, color: Colors.white.withValues(alpha: 0.85)),
                    const SizedBox(width: 7),
                    Text(c.phone,
                        style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.9),
                            fontSize: 13,
                            fontWeight: FontWeight.w600)),
                  ]),
                ],
                const SizedBox(height: 12),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    SehatPill(
                      ob.text,
                      icon: ob.open ? Icons.circle : Icons.circle_outlined,
                      fg: ob.open ? SehatColors.ok : SehatColors.alert,
                      bg: Colors.white,
                    ),
                    const SehatPill(
                      'Terima NHI 健保',
                      icon: Icons.verified_user_rounded,
                      fg: SehatColors.nhi,
                      bg: Colors.white,
                    ),
                    if (c.dist != null)
                      SehatPill(
                        '${c.dist!.toStringAsFixed(1)} km',
                        icon: Icons.near_me_rounded,
                        fg: SehatColors.brandDeep,
                        bg: Colors.white,
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _circleBtn(IconData ic, VoidCallback onTap) => Material(
    color: Colors.white.withValues(alpha: 0.18),
    shape: const CircleBorder(),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(9),
        child: Icon(ic, color: Colors.white, size: 21),
      ),
    ),
  );

  /// Tombol aksi bulat dengan label (Telepon / Rute / Simpan / Salin).
  Widget _action(
    IconData ic,
    String label,
    VoidCallback onTap, {
    bool active = false,
  }) => InkWell(
    borderRadius: BorderRadius.circular(16),
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: active ? SehatColors.brand : Colors.white,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: SehatColors.brandDeep.withValues(alpha: 0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Icon(
              ic,
              color: active ? Colors.white : SehatColors.brand,
              size: 23,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: const TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
              color: SehatColors.brandDeep,
            ),
          ),
        ],
      ),
    ),
  );

  Widget _block(String title, IconData ic, Widget child) => SehatCard(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: SehatColors.brandSoft.withValues(alpha: 0.7),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(ic, size: 17, color: SehatColors.brand),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14.5,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        child,
      ],
    ),
  );

  Widget _phrase(Phrase p) => Row(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              p.zh,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w600,
                height: 1.35,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              p.pin,
              style: const TextStyle(
                fontSize: 12,
                fontStyle: FontStyle.italic,
                color: SehatColors.brandDeep,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              p.id,
              style: TextStyle(fontSize: 12.5, color: Colors.grey.shade700),
            ),
          ],
        ),
      ),
      const SizedBox(width: 8),
      IconButton.filled(
        onPressed: () => _copy(p.zh),
        icon: const Icon(Icons.copy, size: 18),
        style: IconButton.styleFrom(
          backgroundColor: SehatColors.brand,
          foregroundColor: Colors.white,
        ),
      ),
    ],
  );

  Widget _hoursRow(int d, int di) {
    final today = d == di;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
      decoration: BoxDecoration(
        color: today ? SehatColors.brandSoft.withValues(alpha: 0.4) : null,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '${kDayNames[d]}${today ? ' · hari ini' : ''}',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 13,
                color: today ? SehatColors.brandDeep : Colors.grey.shade700,
              ),
            ),
          ),
          Row(
            children: [
              for (var s = 0; s < 3; s++)
                Padding(
                  padding: const EdgeInsets.only(left: 6),
                  child: _sessDot(
                    kSessNames[s],
                    c.hours.length >= 21 && c.hours[d * 3 + s] == '1',
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _sessDot(String label, bool on) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
    decoration: BoxDecoration(
      color: on ? SehatColors.okSoft : Colors.grey.withValues(alpha: 0.12),
      borderRadius: BorderRadius.circular(6),
    ),
    child: Text(
      label,
      style: TextStyle(
        fontSize: 10.5,
        fontWeight: FontWeight.w800,
        color: on ? SehatColors.ok : Colors.grey.shade600,
      ),
    ),
  );
}

/// Form catat / ubah kunjungan.
class SehatVisitForm extends StatefulWidget {
  const SehatVisitForm({super.key, this.existing, this.prefillClinic});
  final Visit? existing;
  final String? prefillClinic;

  @override
  State<SehatVisitForm> createState() => _SehatVisitFormState();
}

class _SehatVisitFormState extends State<SehatVisitForm> {
  late final TextEditingController _clinic;
  late final TextEditingController _sym;
  late final TextEditingController _meds;
  late final TextEditingController _cost;
  late final TextEditingController _notes;
  late String _date;
  String _followup = '';

  @override
  void initState() {
    super.initState();
    final v = widget.existing;
    _clinic = TextEditingController(
      text: v?.clinicName ?? widget.prefillClinic ?? '',
    );
    _sym = TextEditingController(text: v?.symptom ?? '');
    _meds = TextEditingController(text: v?.meds ?? '');
    _cost = TextEditingController(text: v?.cost ?? '');
    _notes = TextEditingController(text: v?.notes ?? '');
    _date = (v?.date.isNotEmpty ?? false)
        ? v!.date
        : DateTime.now().toIso8601String().substring(0, 10);
    _followup = v?.followup ?? '';
  }

  @override
  void dispose() {
    _clinic.dispose();
    _sym.dispose();
    _meds.dispose();
    _cost.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickDate(bool followup) async {
    final init =
        DateTime.tryParse(followup ? _followup : _date) ?? DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: init,
      firstDate: DateTime(2015),
      lastDate: DateTime(2035),
    );
    if (d != null) {
      setState(() {
        final iso = d.toIso8601String().substring(0, 10);
        if (followup) {
          _followup = iso;
        } else {
          _date = iso;
        }
      });
    }
  }

  void _save() {
    final v =
        widget.existing ??
        Visit(id: 'v${DateTime.now().millisecondsSinceEpoch}');
    v
      ..date = _date
      ..clinicName = _clinic.text.trim()
      ..symptom = _sym.text.trim()
      ..meds = _meds.text.trim()
      ..cost = _cost.text.replaceAll(RegExp(r'[^0-9]'), '')
      ..followup = _followup
      ..notes = _notes.text.trim();
    if (v.date.isEmpty && v.clinicName.isEmpty && v.symptom.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Isi minimal tanggal atau klinik')),
      );
      return;
    }
    SehatStore.instance.upsertVisit(v);
    Navigator.of(context).pop();
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Catatan tersimpan')));
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.existing != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          editing ? 'Ubah catatan' : 'Catat kunjungan',
          style: const TextStyle(fontSize: 18),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _dateField('Tanggal kunjungan', _date, () => _pickDate(false)),
          const SizedBox(height: 12),
          _field('Klinik / RS', _clinic, hint: 'Nama klinik'),
          const SizedBox(height: 12),
          _field('Keluhan / diagnosis', _sym, hint: 'mis. demam, sakit gigi'),
          const SizedBox(height: 12),
          _field(
            'Obat',
            _meds,
            hint: 'obat yang diberikan / cara pakai',
            lines: 2,
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _field(
                  'Biaya (NT\$)',
                  _cost,
                  hint: 'mis. 150',
                  number: true,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _dateField(
                  'Kontrol berikutnya',
                  _followup.isEmpty ? '—' : _followup,
                  () => _pickDate(true),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _field('Catatan lain', _notes, hint: 'opsional', lines: 2),
          const SizedBox(height: 18),
          Row(
            children: [
              if (editing)
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      SehatStore.instance.deleteVisit(widget.existing!.id);
                      Navigator.of(context).pop();
                    },
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Hapus'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: SehatColors.alert,
                    ),
                  ),
                ),
              if (editing) const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.check),
                  label: const Text('Simpan catatan'),
                  style: FilledButton.styleFrom(
                    backgroundColor: SehatColors.brand,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _field(
    String label,
    TextEditingController c, {
    String? hint,
    int lines = 1,
    bool number = false,
  }) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        label.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
          color: Colors.grey.shade600,
        ),
      ),
      const SizedBox(height: 6),
      TextField(
        controller: c,
        maxLines: lines,
        keyboardType: number ? TextInputType.number : null,
        decoration: InputDecoration(hintText: hint),
      ),
    ],
  );

  Widget _dateField(String label, String value, VoidCallback onTap) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        label.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
          color: Colors.grey.shade600,
        ),
      ),
      const SizedBox(height: 6),
      InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: InputDecorator(
          decoration: const InputDecoration(
            suffixIcon: Icon(Icons.calendar_today_outlined, size: 18),
          ),
          child: Text(value == '—' ? 'Pilih tanggal' : fmtDate(value)),
        ),
      ),
    ],
  );
}
