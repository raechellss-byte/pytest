import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';

import 'sehat_data.dart';
import 'sehat_detail.dart';
import 'sehat_guide_me.dart';
import 'sehat_results.dart';
import 'sehat_translate.dart';
import '../../screens/auth/login_prompt.dart';
import '../../theme.dart';
import 'sehat_store.dart';
import 'sehat_sync.dart';
import 'sehat_ui.dart';

/// Palet aksen Sehat Rantau (teal) — tetap serasi dalam PENGYOU.
class SehatColors {
  static const brand = Color(0xFF0F766E);
  static const brandDeep = Color(0xFF0B5A53);
  static const brandSoft = Color(0xFFD8ECE7);
  static const nhi = Color(0xFF1E6FB8);
  static const nhiSoft = Color(0xFFE1EDF8);
  static const ok = Color(0xFF1C934F);
  static const okSoft = Color(0xFFDBF1E2);
  static const alert = Color(0xFFCF5138);
  static const alertSoft = Color(0xFFF9E4DD);
}

/// Kembali ke aplikasi utama (PENGYOU).
void sehatExit(BuildContext context) {
  final nav = Navigator.of(context);
  if (nav.canPop()) {
    nav.pop();
  } else {
    GoRouter.maybeOf(context)?.go('/beranda');
  }
}

class SehatApp extends StatefulWidget {
  const SehatApp({super.key});

  @override
  State<SehatApp> createState() => _SehatAppState();
}

class _SehatAppState extends State<SehatApp> {
  int _tab = 0;
  late Future<void> _boot;

  @override
  void initState() {
    super.initState();
    _boot = _init();
  }

  Future<void> _init() async {
    await SehatData.loadManifest();
    await SehatStore.instance.ensureLoaded();
  }

  static const _navItems = <(IconData, IconData, String)>[
    (Icons.search_rounded, Icons.search_rounded, 'Cari Klinik'),
    (Icons.bookmark_border_rounded, Icons.bookmark_rounded, 'Tersimpan'),
    (Icons.translate_rounded, Icons.translate_rounded, 'Terjemah Medis'),
    (Icons.menu_book_outlined, Icons.menu_book_rounded, 'Panduan NHI'),
    (Icons.person_outline_rounded, Icons.person_rounded, 'Data Saya'),
  ];

  void _goTab(int i) => setState(() => _tab = i);

  @override
  Widget build(BuildContext context) {
    return SehatThemed(
      child: FutureBuilder(
        future: _boot,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          if (snap.hasError) {
            return Scaffold(
              appBar: AppBar(title: const Text('Sehat Rantau')),
              body: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    'Gagal memuat data klinik.\n${snap.error}',
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            );
          }
          final tabs = [
            _SearchTab(onGoTab: _goTab),
            const _SavedTab(),
            const TranslateTab(),
            const GuideTab(),
            const MeTab(),
          ];

          final isDesktop = AppBreakpoints.isDesktop(context);
          if (isDesktop) {
            return Scaffold(
              body: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildDesktopSidebar(context),
                  Expanded(
                    child: Align(
                      alignment: Alignment.topCenter,
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 960),
                        child: tabs[_tab],
                      ),
                    ),
                  ),
                ],
              ),
            );
          }

          return Scaffold(
            body: tabs[_tab],
            bottomNavigationBar: Container(
              decoration: const BoxDecoration(
                border: Border(top: BorderSide(color: AppColors.line, width: 2)),
              ),
              child: NavigationBar(
                selectedIndex: _tab,
                onDestinationSelected: _goTab,
                destinations: const [
                  NavigationDestination(
                    icon: Icon(Icons.search_rounded),
                    label: 'Cari',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.bookmark_border_rounded),
                    selectedIcon: Icon(Icons.bookmark_rounded),
                    label: 'Tersimpan',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.translate_rounded),
                    label: 'Terjemah',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.menu_book_outlined),
                    selectedIcon: Icon(Icons.menu_book),
                    label: 'Panduan',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.person_outline_rounded),
                    selectedIcon: Icon(Icons.person_rounded),
                    label: 'Saya',
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildDesktopSidebar(BuildContext context) {
    return Container(
      width: 260,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(right: BorderSide(color: AppColors.line, width: 2)),
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 20, 18, 16),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: SehatColors.brand,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: const [
                        BoxShadow(
                          color: SehatColors.brandDeep,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.local_hospital_rounded,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 11),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Sehat Rantau',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: AppColors.ink,
                          ),
                        ),
                        Text(
                          'Klinik NHI · PENGYOU',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: AppColors.muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(14),
                children: [
                  for (var i = 0; i < _navItems.length; i++)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Material(
                        color: _tab == i
                            ? SehatColors.brandSoft
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(16),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => _goTab(i),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 12,
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: _tab == i
                                    ? SehatColors.brand.withValues(alpha: 0.45)
                                    : Colors.transparent,
                                width: 2,
                              ),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  _tab == i
                                      ? _navItems[i].$2
                                      : _navItems[i].$1,
                                  color: _tab == i
                                      ? SehatColors.brandDeep
                                      : AppColors.muted,
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  _navItems[i].$3,
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: _tab == i
                                        ? FontWeight.w900
                                        : FontWeight.w700,
                                    color: _tab == i
                                        ? SehatColors.brandDeep
                                        : AppColors.ink,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: DuoButton(
                label: '← Beranda PENGYOU',
                backgroundColor: Colors.white,
                foregroundColor: SehatColors.brandDeep,
                borderColor: AppColors.line,
                lipColor: AppColors.line,
                compact: true,
                expanded: true,
                onPressed: () => sehatExit(context),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ============ Tab: Cari ============

/// Emoji untuk tiap keluhan umum (urutan sama dengan [kChips]).
const _chipEmoji = <String, String>{
  'sakit perut': '😖',
  'muntah / mual': '🤢',
  'demam': '🤒',
  'batuk & pilek': '🤧',
  'bahu keseleo': '💪',
  'nyeri sendi': '🦵',
  'sakit gigi': '🦷',
  'kulit gatal': '🧴',
  'mata merah': '👁️',
  'THT': '👂',
  'sakit kepala': '🤕',
  'kandungan': '🤰',
};

class _SearchTab extends StatefulWidget {
  const _SearchTab({required this.onGoTab});
  final void Function(int) onGoTab;
  @override
  State<_SearchTab> createState() => _SearchTabState();
}

class _SearchTabState extends State<_SearchTab> {
  final _qCtrl = TextEditingController();
  String? _county;
  bool _locating = false;

  @override
  void initState() {
    super.initState();
    _county = SehatData.counties.isNotEmpty
        ? SehatData.counties.first.key
        : null;
  }

  @override
  void dispose() {
    _qCtrl.dispose();
    super.dispose();
  }

  void _search([String? q]) {
    if (q != null) _qCtrl.text = q;
    final county =
        _county ??
        (SehatData.counties.isNotEmpty ? SehatData.counties.first.key : null);
    if (county == null) return;
    Navigator.of(
      context,
    ).push(sehatRoute(SehatResultsScreen(query: _qCtrl.text, county: county)));
  }

  Future<void> _useGps() async {
    setState(() => _locating = true);
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        _toast('Izin lokasi ditolak');
        return;
      }
      final pos = await Geolocator.getCurrentPosition();
      final loc = [pos.latitude, pos.longitude];
      // Kota terdekat.
      County? best;
      var bd = 1e9;
      for (final c in SehatData.counties) {
        final d = haversine(loc[0], loc[1], c.lat, c.lng);
        if (d < bd) {
          bd = d;
          best = c;
        }
      }
      SehatStore.instance.setUserLoc(loc, on: true);
      if (best != null) setState(() => _county = best!.key);
      _toast('Lokasi aktif · kota: ${SehatData.countyLabel(_county)}');
    } catch (_) {
      _toast('Gagal mengambil lokasi');
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  void _removeRecent(HistItem h) {
    SehatStore.instance.removeHistory(h);
    _undoToast(
      '"${h.query.isEmpty ? 'Semua klinik' : h.query}" dihapus dari riwayat',
      [h],
    );
  }

  void _clearRecent() =>
      _undoToast('Riwayat pencarian dihapus', SehatStore.instance.clearHistory());

  /// Hapus langsung tanpa tanya; salah pencet bisa dibatalkan.
  void _undoToast(String m, List<HistItem> removed) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(m),
          duration: const Duration(seconds: 6),
          action: SnackBarAction(
            label: 'Urungkan',
            onPressed: () => SehatStore.instance.restoreHistory(removed),
          ),
        ),
      );
  }

  /// Lembar pilih kota (dengan kolom cari).
  Future<void> _pickCounty() async {
    final picked = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: Colors.white,
      builder: (_) => _CountySheet(selected: _county),
    );
    if (picked != null) setState(() => _county = picked);
  }

  @override
  Widget build(BuildContext context) {
    final store = SehatStore.instance;
    final county = SehatData.countyByKey(_county ?? '');
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        return ListView(
          padding: const EdgeInsets.only(bottom: 28),
          children: [
            SehatHero(
              eyebrow: 'Sehat Rantau · 健康',
              title: 'Lagi sakit apa?',
              subtitle:
                  'Tulis keluhanmu — kami carikan klinik NHI yang tepat, '
                  'lengkap dengan jam buka & peta.',
              icon: Icons.medical_services_rounded,
              onBack: () => sehatExit(context),
              child: Column(
                children: [
                  _searchField(),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: _glassButton(
                          icon: Icons.location_on_rounded,
                          label: county == null
                              ? 'Pilih kota'
                              : '${county.zh} · ${county.en} · ${county.count} klinik',
                          onTap: _pickCounty,
                          trailing: Icons.expand_more_rounded,
                        ),
                      ),
                      const SizedBox(width: 8),
                      _glassButton(
                        icon: store.gpsOn
                            ? Icons.my_location_rounded
                            : Icons.location_searching_rounded,
                        label: _locating
                            ? '…'
                            : (store.gpsOn ? 'Aktif' : 'GPS'),
                        onTap: _locating ? null : _useGps,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SehatSection(
                    'Keluhan umum',
                    trailing: 'ketuk untuk cari',
                  ),
                  GridView.count(
                    crossAxisCount: AppBreakpoints.isDesktop(context) ? 6 : 4,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio:
                        AppBreakpoints.isDesktop(context) ? 1.1 : 0.92,
                    children: [
                      for (final (label, q) in kChips) _symptomTile(label, q),
                    ],
                  ),
                  const SehatSection('Akses cepat'),
                  Row(
                    children: [
                      _quickTile('🚑', 'Darurat', '119 · 1955', const [
                        Color(0xFFE0533C),
                        Color(0xFFB23F2C),
                      ], () => context.push('/darurat')),
                      const SizedBox(width: 10),
                      _quickTile('🗣️', 'Terjemah', 'ke dokter', const [
                        Color(0xFF0E8A7E),
                        SehatColors.brandDeep,
                      ], () => widget.onGoTab(2)),
                      const SizedBox(width: 10),
                      _quickTile('💳', 'Pakai NHI', 'panduan', const [
                        Color(0xFF2B7CC4),
                        Color(0xFF155A97),
                      ], () => widget.onGoTab(3)),
                    ],
                  ),
                  SehatSection(
                    'Pencarian terakhir',
                    trailing: store.history.isEmpty ? null : 'Hapus semua',
                    onTrailing: store.history.isEmpty ? null : _clearRecent,
                  ),
                  if (!SehatSync.signedIn && store.history.isEmpty)
                    const LoginNudgeCard(
                      title: 'Riwayat pencarian tidak disimpan',
                      text: 'Kamu belum masuk. Masuk dengan email supaya pencarian, '
                          'klinik favorit & catatan berobat tersimpan di akunmu.',
                      next: '/sehat',
                      color: SehatColors.brand,
                      compact: true,
                    )
                  else if (store.history.isEmpty)
                    SehatCard(
                      child: Row(
                        children: [
                          _roundIcon(Icons.history_rounded, Colors.blueGrey),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Text(
                              'Belum ada pencarian — coba ketuk salah satu keluhan di atas.',
                              style: TextStyle(fontSize: 13, height: 1.4),
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    for (int i = 0; i < store.history.length && i < 3; i++)
                      _recentItem(store.history[i]),
                  const SizedBox(height: 4),
                  _nhiBanner(),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _searchField() => Container(
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.12),
          blurRadius: 14,
          offset: const Offset(0, 6),
        ),
      ],
    ),
    padding: const EdgeInsets.only(left: 6, right: 6),
    child: Row(
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 8),
          child: Icon(Icons.search_rounded, color: SehatColors.brand),
        ),
        Expanded(
          child: TextField(
            controller: _qCtrl,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _search(),
            decoration: const InputDecoration(
              hintText: 'mis. demam, sakit gigi, bahu keseleo…',
              filled: false,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(vertical: 16),
            ),
          ),
        ),
        Material(
          color: SehatColors.brand,
          borderRadius: BorderRadius.circular(13),
          child: InkWell(
            borderRadius: BorderRadius.circular(13),
            onTap: () => _search(),
            child: const Padding(
              padding: EdgeInsets.all(10),
              child: Icon(
                Icons.arrow_forward_rounded,
                color: Colors.white,
                size: 22,
              ),
            ),
          ),
        ),
      ],
    ),
  );

  /// Tombol "kaca" transparan di atas header.
  Widget _glassButton({
    required IconData icon,
    required String label,
    VoidCallback? onTap,
    IconData? trailing,
  }) => Material(
    color: Colors.white.withValues(alpha: 0.16),
    borderRadius: BorderRadius.circular(14),
    child: InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 7),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            ),
            if (trailing != null) ...[
              const SizedBox(width: 2),
              Icon(trailing, color: Colors.white, size: 18),
            ],
          ],
        ),
      ),
    ),
  );

  Widget _symptomTile(String label, String q) => Material(
    color: Colors.white,
    borderRadius: BorderRadius.circular(18),
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => _search(q),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: SehatColors.brand.withValues(alpha: 0.1)),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: SehatColors.brandSoft.withValues(alpha: 0.6),
                shape: BoxShape.circle,
              ),
              child: Text(
                _chipEmoji[label] ?? '🩺',
                style: const TextStyle(fontSize: 21),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                height: 1.15,
              ),
            ),
          ],
        ),
      ),
    ),
  );

  Widget _quickTile(
    String emoji,
    String title,
    String sub,
    List<Color> colors,
    VoidCallback onTap,
  ) => Expanded(
    child: Material(
      borderRadius: BorderRadius.circular(18),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: colors,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 10, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(emoji, style: const TextStyle(fontSize: 22)),
                const SizedBox(height: 8),
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                  ),
                ),
                Text(
                  sub,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.85),
                    fontSize: 11.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );

  Widget _roundIcon(IconData ic, Color c) => Container(
    width: 40,
    height: 40,
    decoration: BoxDecoration(
      color: c.withValues(alpha: 0.12),
      shape: BoxShape.circle,
    ),
    child: Icon(ic, color: c, size: 20),
  );

  Widget _recentItem(HistItem h) => SehatCard(
    padding: const EdgeInsets.fromLTRB(14, 12, 4, 12),
    onTap: () {
      setState(() => _county = h.county);
      _search(h.query);
    },
    child: Row(
      children: [
        _roundIcon(Icons.history_rounded, SehatColors.brand),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                h.query.isEmpty ? 'Semua klinik' : h.query,
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                '${h.countyLabel} · ${h.count} klinik · ${agoLabel(h.ts)}',
                style: TextStyle(fontSize: 12, color: Colors.blueGrey.shade400),
              ),
            ],
          ),
        ),
        IconButton(
          tooltip: 'Hapus dari riwayat',
          onPressed: () => _removeRecent(h),
          icon: Icon(Icons.close_rounded, size: 20, color: Colors.blueGrey.shade300),
        ),
      ],
    ),
  );

  Widget _nhiBanner() => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        colors: [
          SehatColors.nhiSoft,
          SehatColors.brandSoft.withValues(alpha: 0.7),
        ],
      ),
      borderRadius: BorderRadius.circular(18),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Icon(
          Icons.verified_user_rounded,
          color: SehatColors.nhi,
          size: 22,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text.rich(
            TextSpan(
              children: [
                TextSpan(
                  text: '${SehatData.total} klinik & RS ',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
                const TextSpan(
                  text:
                      'di aplikasi ini terikat kontrak NHI (健保) — bisa pakai '
                      'kartu asuransimu. Data resmi NHIA.',
                ),
              ],
            ),
            style: const TextStyle(
              fontSize: 12.5,
              color: Color(0xFF1B4E7A),
              height: 1.45,
            ),
          ),
        ),
      ],
    ),
  );
}

/// Lembar pilih kota/kabupaten dengan kolom cari.
class _CountySheet extends StatefulWidget {
  const _CountySheet({required this.selected});
  final String? selected;
  @override
  State<_CountySheet> createState() => _CountySheetState();
}

class _CountySheetState extends State<_CountySheet> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final all = [...SehatData.counties]..sort((a, b) => a.en.compareTo(b.en));
    final q = _q.toLowerCase();
    final list = all
        .where(
          (c) =>
              q.isEmpty || c.en.toLowerCase().contains(q) || c.zh.contains(_q),
        )
        .toList();
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.75,
      child: Column(
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 10),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Pilih kota / kabupaten',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              autofocus: false,
              onChanged: (v) => setState(() => _q = v.trim()),
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search_rounded),
                hintText: 'Cari kota (mis. Taipei, 台中)…',
                fillColor: kSehatBg,
              ),
            ),
          ),
          const SizedBox(height: 6),
          Expanded(
            child: ListView.builder(
              itemCount: list.length,
              itemBuilder: (_, i) {
                final c = list[i];
                final sel = c.key == widget.selected;
                return ListTile(
                  onTap: () => Navigator.pop(context, c.key),
                  leading: CircleAvatar(
                    backgroundColor: sel
                        ? SehatColors.brand
                        : SehatColors.brandSoft.withValues(alpha: 0.6),
                    child: Icon(
                      Icons.location_city_rounded,
                      color: sel ? Colors.white : SehatColors.brandDeep,
                      size: 20,
                    ),
                  ),
                  title: Text(
                    '${c.zh} · ${c.en}',
                    style: TextStyle(
                      fontWeight: sel ? FontWeight.w800 : FontWeight.w600,
                    ),
                  ),
                  subtitle: Text('${c.count} klinik'),
                  trailing: sel
                      ? const Icon(
                          Icons.check_circle_rounded,
                          color: SehatColors.brand,
                        )
                      : null,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// ============ Tab: Tersimpan ============

class _SavedTab extends StatelessWidget {
  const _SavedTab();

  @override
  Widget build(BuildContext context) {
    final store = SehatStore.instance;
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final origin = store.userLoc;
        for (final c in store.saved) {
          c.dist = origin != null
              ? haversine(origin[0], origin[1], c.lat, c.lng)
              : null;
        }
        return ListView(
          padding: const EdgeInsets.only(bottom: 28),
          children: [
            SehatHero(
              eyebrow: 'Tersimpan',
              title: 'Klinik Saya',
              subtitle:
                  'Klinik yang kamu simpan — biar cepat dibuka lagi saat butuh.',
              icon: Icons.bookmark_rounded,
              onBack: () => sehatExit(context),
              trailing: store.saved.isEmpty
                  ? null
                  : SehatPill(
                      '${store.saved.length} klinik',
                      fg: SehatColors.brandDeep,
                      bg: Colors.white,
                    ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: !SehatSync.signedIn && store.saved.isEmpty
                  ? const LoginNudgeCard(
                      title: 'Masuk untuk menyimpan klinik',
                      text: 'Klinik favoritmu akan tersimpan di akun — tidak hilang '
                          'walau ganti HP. Ketuk 🔖 di klinik mana pun setelah masuk.',
                      next: '/sehat',
                      color: SehatColors.brand,
                    )
                  : store.saved.isEmpty
                  ? _empty()
                  : Column(
                      children: [
                        if (!SehatSync.signedIn)
                          const LoginNudgeCard(
                            title: 'Belum tersimpan di akun',
                            text: 'Klinik di bawah hanya ada di HP ini. Masuk supaya '
                                'tersimpan di akunmu.',
                            next: '/sehat',
                            color: SehatColors.brand,
                            compact: true,
                          ),
                        for (final c in store.saved)
                          ClinicCard(
                            clinic: c,
                            onTap: () => Navigator.of(
                              context,
                            ).push(sehatRoute(SehatDetailScreen(clinic: c))),
                          ),
                      ],
                    ),
            ),
          ],
        );
      },
    );
  }

  Widget _empty() => Padding(
    padding: const EdgeInsets.only(top: 30),
    child: Column(
      children: [
        Container(
          width: 96,
          height: 96,
          decoration: BoxDecoration(
            color: SehatColors.brandSoft.withValues(alpha: 0.7),
            shape: BoxShape.circle,
          ),
          child: const Icon(
            Icons.bookmark_add_outlined,
            size: 44,
            color: SehatColors.brandDeep,
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'Belum ada klinik tersimpan',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
        ),
        const SizedBox(height: 6),
        Text(
          'Ketuk ikon 🔖 di klinik mana pun untuk menyimpannya di sini.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.blueGrey.shade400, height: 1.4),
        ),
      ],
    ),
  );
}

/// ============ Kartu klinik (dipakai di Hasil & Tersimpan) ============

class ClinicCard extends StatelessWidget {
  const ClinicCard({
    super.key,
    required this.clinic,
    required this.onTap,
    this.matchedSpecs,
  });

  final Clinic clinic;
  final VoidCallback onTap;
  final Set<String>? matchedSpecs;

  @override
  Widget build(BuildContext context) {
    final c = clinic;
    final ob = openBadge(c.hours);
    final store = SehatStore.instance;
    final saved = store.isSaved(c.id);
    return SehatCard(
      onTap: onTap,
      padding: const EdgeInsets.fromLTRB(14, 14, 6, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SehatIconTile(icon: clinicIcon(c), color: clinicColor(c)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      c.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 15.5,
                        fontWeight: FontWeight.w800,
                        height: 1.2,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      [c.district, c.type].where((x) => x.isNotEmpty).join(' · '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.blueGrey.shade400,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: saved ? 'Hapus dari Klinik Saya' : 'Simpan',
                icon: Icon(
                  saved
                      ? Icons.bookmark_rounded
                      : Icons.bookmark_border_rounded,
                  color: saved ? SehatColors.brand : Colors.blueGrey.shade300,
                ),
                onPressed: () {
                  if (sehatCanSave(
                      context,
                      'Klinik yang kamu simpan akan tersimpan di akunmu — '
                      'bisa dibuka lagi dari HP mana pun.',
                  )) {
                    store.toggleSave(c);
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                SehatPill(
                  ob.text,
                  icon: ob.open ? Icons.circle : Icons.circle_outlined,
                  fg: ob.open ? SehatColors.ok : SehatColors.alert,
                  bg: ob.open ? SehatColors.okSoft : SehatColors.alertSoft,
                ),
                if (c.dist != null)
                  SehatPill(
                    '${c.dist!.toStringAsFixed(1)} km',
                    icon: Icons.near_me_rounded,
                    fg: SehatColors.brandDeep,
                    bg: SehatColors.brandSoft.withValues(alpha: 0.7),
                  ),
                const SehatPill(
                  'NHI 健保',
                  icon: Icons.verified_user_rounded,
                  fg: SehatColors.nhi,
                  bg: SehatColors.nhiSoft,
                ),
                if (c.hosp)
                  SehatPill(
                    'Rumah sakit',
                    icon: Icons.local_hospital_rounded,
                    fg: Colors.blueGrey.shade700,
                    bg: Colors.blueGrey.withValues(alpha: 0.12),
                  ),
              ],
            ),
          ),
          if (c.spec.isNotEmpty) ...[
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final s in c.spec.take(4))
                    _tag(specLabel(s), matchedSpecs?.contains(s) ?? false),
                  if (c.spec.length > 4) _tag('+${c.spec.length - 4}', false),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _tag(String text, bool hit) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
    decoration: BoxDecoration(
      color: hit ? SehatColors.brand : kSehatBg,
      borderRadius: BorderRadius.circular(8),
      border: Border.all(
        color: hit
            ? SehatColors.brand
            : Colors.blueGrey.withValues(alpha: 0.15),
      ),
    ),
    child: Text(
      text,
      style: TextStyle(
        fontSize: 11.5,
        fontWeight: FontWeight.w700,
        color: hit ? Colors.white : Colors.blueGrey.shade600,
      ),
    ),
  );
}
