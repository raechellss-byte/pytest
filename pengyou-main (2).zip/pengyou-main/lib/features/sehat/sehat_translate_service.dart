import 'dart:convert';
import 'dart:math';

import 'package:http/http.dart' as http;

import '../liuli/liuli_data.dart' show DictRow;

/// ============================================================
/// Terjemahan untuk tab "Terjemah" Sehat Rantau.
/// Memakai MyMemory (api.mymemory.translated.net): gratis tanpa kunci,
/// maks. 500 karakter per permintaan, ±5.000 karakter/hari per jaringan.
/// ============================================================

/// Bahasa yang didukung + locale suara (TTS) & mikrofon (speech-to-text).
class TrLang {
  const TrLang(this.code, this.label, this.tts, this.stt, this.hint);
  final String code; // kode bahasa MyMemory
  final String label;
  final String tts;
  final String stt;
  final String hint; // contoh di kolom ketik
}

const trIndonesia = TrLang(
  'id',
  'Indonesia',
  'id-ID',
  'id_ID',
  'Ketik di sini… mis. Saya demam sejak 3 hari',
);
const trMandarin = TrLang('zh-TW', '中文 (Taiwan)', 'zh-TW', 'zh_TW', '請在這裡輸入…');
const trEnglish = TrLang('en', 'English', 'en-US', 'en_US', 'Type here…');

/// Pilihan bahasa lawan bicara (sisi selain Indonesia).
const trOthers = [trMandarin, trEnglish];

const kTrMaxChars = 500;

class TranslateException implements Exception {
  TranslateException(this.message);
  final String message;
  @override
  String toString() => message;
}

final _cache = <String, String>{};

/// Terjemahkan [text]. Hasil disimpan di memori supaya teks yang sama tidak
/// memakan kuota harian dua kali.
Future<String> translateText(
  String text,
  TrLang from,
  TrLang to, {
  http.Client? client,
}) async {
  final q = text.trim();
  if (q.isEmpty) return '';
  if (q.length > kTrMaxChars) {
    throw TranslateException('Maksimal $kTrMaxChars karakter sekali terjemah.');
  }
  final key = '${from.code}|${to.code}|$q';
  final hit = _cache[key];
  if (hit != null) return hit;

  final uri = Uri.https('api.mymemory.translated.net', '/get', {
    'q': q,
    'langpair': '${from.code}|${to.code}',
  });
  final http.Response res;
  try {
    res = await (client?.get(uri) ?? http.get(uri)).timeout(
      const Duration(seconds: 15),
    );
  } catch (_) {
    throw TranslateException('Tidak bisa terhubung. Periksa koneksi internet.');
  }
  Map<String, dynamic>? data;
  try {
    data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
  } catch (_) {}
  final status = int.tryParse('${data?['responseStatus']}') ?? res.statusCode;
  final out = '${(data?['responseData'] as Map?)?['translatedText'] ?? ''}'
      .trim();
  if (data?['quotaFinished'] == true ||
      status == 429 ||
      out.startsWith('MYMEMORY WARNING')) {
    throw TranslateException(
      'Kuota terjemahan gratis hari ini habis. Coba lagi besok.',
    );
  }
  if (status != 200 || out.isEmpty) {
    throw TranslateException('Layanan terjemahan sedang gangguan. Coba lagi.');
  }
  return _cache[key] = decodeEntities(out);
}

/// MyMemory kadang mengirim entitas HTML (mis. &#39; untuk apostrof).
String decodeEntities(String s) => s
    .replaceAll('&#39;', "'")
    .replaceAll('&quot;', '"')
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&amp;', '&');

// ---------------- Pinyin (bantuan membaca hasil Mandarin) ----------------

/// Bacaan paling umum untuk huruf berbunyi ganda bila tidak menjadi bagian
/// kata di kamus (kamus menyimpan bacaan pertama, belum tentu yang umum).
const _commonReading = {
  '得': 'de', '的': 'de', '了': 'le', '著': 'zhe', '着': 'zhe', //
  '號': 'hào', '号': 'hào', '還': 'hái', '还': 'hái', '都': 'dōu',
  '長': 'cháng', '长': 'cháng', '覺': 'jué', '觉': 'jué', '重': 'zhòng',
  '量': 'liàng', '血': 'xuè', '少': 'shǎo', '便': 'biàn', '只': 'zhǐ',
  '給': 'gěi', '给': 'gěi', '個': 'gè', '个': 'gè', '吧': 'ba',
  '嗎': 'ma', '吗': 'ma', '呢': 'ne', '一': 'yī', '要': 'yào',
};

const _punct = {
  '，': ',', '。': '.', '？': '?', '！': '!', '：': ':', '；': ';', //
  '、': ',', '（': '(', '）': ')', '「': '"', '」': '"',
};

final _han = RegExp(r'[㐀-鿿豈-﫿]');
final _alnum = RegExp(r'[A-Za-z0-9]');
final _closing = RegExp(r'^[,.?!:;)"]$');

/// Kamus kata → pinyin (tradisional & sederhana) dari data Liúlì.
Map<String, String> buildPinyinLookup(List<DictRow> dict) {
  final m = <String, String>{};
  for (final r in dict) {
    for (final k in [r.trad, r.simp]) {
      if (k.isNotEmpty) m.putIfAbsent(k, () => r.pin);
    }
  }
  return m..addAll(_commonReading);
}

/// Pinyin untuk teks Mandarin: cocokkan kata terpanjang (≤4 huruf) di kamus.
/// Angka/huruf latin dipertahankan, tanda baca diubah ke versi latin.
String pinyinFor(String zh, Map<String, String> lookup) {
  final c = zh.runes.map(String.fromCharCode).toList();
  final out = <String>[];
  var i = 0;
  while (i < c.length) {
    final ch = c[i];
    if (_alnum.hasMatch(ch)) {
      final b = StringBuffer();
      while (i < c.length && _alnum.hasMatch(c[i])) {
        b.write(c[i++]);
      }
      out.add(b.toString());
      continue;
    }
    if (!_han.hasMatch(ch)) {
      final p = _punct[ch] ?? ch;
      if (p.trim().isNotEmpty) {
        if (out.isNotEmpty && _closing.hasMatch(p)) {
          out[out.length - 1] += p;
        } else {
          out.add(p);
        }
      }
      i++;
      continue;
    }
    var len = min(4, c.length - i);
    while (len > 0 && lookup[c.sublist(i, i + len).join()] == null) {
      len--;
    }
    if (len > 0) out.add(lookup[c.sublist(i, i + len).join()]!);
    i += max(len, 1); // huruf yang tak ada di kamus dilewati
  }
  return out.join(' ');
}
