import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'sehat_store.dart';

/// Gabungkan riwayat Sehat di perangkat ([local]) dengan yang di akun
/// ([remote]). Snapshot yang lebih baru menang — kecuali [union] (sinkron
/// pertama perangkat ini): klinik tersimpan, catatan & pencarian digabung.
Map<String, dynamic> mergeSehat(Map<String, dynamic> local, Map<String, dynamic> remote,
    {bool union = false}) {
  String s(Object? x) => x is String ? x : '';
  final remoteNewer = s(remote['at']).compareTo(s(local['at'])) > 0;
  final newer = remoteNewer ? remote : local;
  final older = remoteNewer ? local : remote;
  if (!union) return {...newer, 'at': newer['at'] ?? older['at']};

  List<Map<String, dynamic>> list(Map<String, dynamic> m, String k) =>
      ((m[k] as List?) ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  List<Map<String, dynamic>> byKey(String k, String Function(Map<String, dynamic>) key) {
    final seen = <String>{};
    return [
      for (final e in [...list(newer, k), ...list(older, k)])
        if (seen.add(key(e))) e,
    ];
  }

  final history = byKey('history', (h) => '${h['query']}|${h['county']}')
    ..sort((a, b) => ((b['ts'] as num?) ?? 0).compareTo((a['ts'] as num?) ?? 0));
  return {
    'at': newer['at'] ?? older['at'],
    'saved': byKey('saved', (c) => '${c['id']}'),
    'visits': byKey('visits', (v) => '${v['id']}'),
    'history': history.take(20).toList(),
  };
}

/// Sinkron riwayat Sehat Rantau ke akun (tabel Supabase `sehat_data`).
/// Tanpa login → mode tamu: tidak ada riwayat yang disimpan.
class SehatSync {
  static String? _uid;
  static Timer? _debounce;
  static bool _hooked = false;
  static const _kUid = 'sehat_sync_uid';

  static SupabaseClient? get _db {
    try {
      return Supabase.instance.client;
    } catch (_) {
      return null; // mis. di widget test
    }
  }

  /// Sudah masuk akun? (Menyimpan klinik & catatan butuh ini.)
  static bool get signedIn => _db?.auth.currentUser != null;

  static Future<void> start() async {
    final db = _db;
    final user = db?.auth.currentUser;
    if (db == null || user == null) {
      stop();
      return;
    }
    _uid = user.id;
    final store = SehatStore.instance;
    try {
      await store.ensureLoaded();
      store.saving = true;
      final prefs = await SharedPreferences.getInstance();
      final prevUid = prefs.getString(_kUid);
      final row = await db
          .from('sehat_data')
          .select('data')
          .eq('user_id', user.id)
          .maybeSingle();
      final remote = row?['data'];
      if (prevUid != null && prevUid != user.id) {
        // Perangkat ini sebelumnya dipakai akun lain → jangan campur riwayat.
        store.clearAll();
        if (remote is Map) store.applySnapshot(Map<String, dynamic>.from(remote));
      } else if (remote is Map) {
        store.applySnapshot(mergeSehat(store.snapshot(), Map<String, dynamic>.from(remote),
            union: prevUid == null));
      }
      await prefs.setString(_kUid, user.id);
      if (!_hooked) {
        _hooked = true;
        store.addListener(_schedule);
      }
      if (remote is Map || !store.isBlank) await push();
    } catch (e) {
      debugPrint('SehatSync start gagal: $e');
    }
  }

  /// Mode tamu: berhenti mengirim & menyimpan riwayat.
  static void stop() {
    _uid = null;
    _debounce?.cancel();
    SehatStore.instance.saving = false;
  }

  /// Keluar akun: mode tamu + hapus riwayat di perangkat (tetap aman di akun).
  static Future<void> signOut() async {
    stop();
    final store = SehatStore.instance;
    await store.ensureLoaded();
    store.clearAll();
  }

  static void _schedule() {
    if (_uid == null) return;
    _debounce?.cancel();
    _debounce = Timer(const Duration(seconds: 3), push);
  }

  static Future<void> push() async {
    final db = _db;
    final uid = _uid;
    if (db == null || uid == null) return;
    _debounce?.cancel();
    try {
      await db.from('sehat_data').upsert({
        'user_id': uid,
        'data': SehatStore.instance.snapshot(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id');
    } catch (e) {
      debugPrint('SehatSync push gagal: $e');
    }
  }
}
