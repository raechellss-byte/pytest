import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'sehat_data.dart';

class Visit {
  Visit({
    required this.id,
    this.date = '',
    this.clinicName = '',
    this.symptom = '',
    this.meds = '',
    this.cost = '',
    this.followup = '',
    this.notes = '',
  });

  String id;
  String date;
  String clinicName;
  String symptom;
  String meds;
  String cost;
  String followup;
  String notes;

  factory Visit.fromJson(Map<String, dynamic> j) => Visit(
        id: j['id'].toString(),
        date: (j['date'] ?? '').toString(),
        clinicName: (j['clinicName'] ?? '').toString(),
        symptom: (j['symptom'] ?? '').toString(),
        meds: (j['meds'] ?? '').toString(),
        cost: (j['cost'] ?? '').toString(),
        followup: (j['followup'] ?? '').toString(),
        notes: (j['notes'] ?? '').toString(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date,
        'clinicName': clinicName,
        'symptom': symptom,
        'meds': meds,
        'cost': cost,
        'followup': followup,
        'notes': notes,
      };
}

class HistItem {
  HistItem(this.query, this.county, this.countyLabel, this.count, this.ts);
  final String query;
  final String? county;
  final String countyLabel;
  final int count;
  final int ts;

  Map<String, dynamic> toJson() => {
        'query': query,
        'county': county,
        'countyLabel': countyLabel,
        'count': count,
        'ts': ts,
      };
  factory HistItem.fromJson(Map<String, dynamic> j) => HistItem(
        (j['query'] ?? '').toString(),
        j['county']?.toString(),
        (j['countyLabel'] ?? '').toString(),
        (j['count'] as num?)?.toInt() ?? 0,
        (j['ts'] as num?)?.toInt() ?? 0,
      );
}

const _kSaved = 'sehatrantau.v2.saved';
const _kVisits = 'sehatrantau.v2.visits';
const _kProfile = 'sehatrantau.v2.profile';
const _kHistory = 'sehatrantau.v2.history';
const _kMeta = 'sehatrantau.v2.meta'; // {changedAt}

/// State bersama Sehat Rantau (persisten di perangkat).
class SehatStore extends ChangeNotifier {
  SehatStore._();
  static final SehatStore instance = SehatStore._();

  bool _loaded = false;
  SharedPreferences? _prefs;

  /// Simpan riwayat (klinik tersimpan, catatan, pencarian) di perangkat?
  /// Hanya bila sudah masuk akun — diatur SehatSync.
  bool saving = true;

  /// Kapan data terakhir berubah (UTC ISO) — penentu saat sinkron akun.
  String? changedAt;

  final List<Clinic> saved = [];
  final List<Visit> visits = [];
  Map<String, String> profile = {};
  final List<HistItem> history = [];

  List<double>? userLoc; // [lat, lng]
  bool gpsOn = false;

  Future<void> ensureLoaded() async {
    if (_loaded) return;
    _prefs = await SharedPreferences.getInstance();
    final p = _prefs!;
    _decodeList(p.getString(_kSaved), (m) => saved.add(Clinic.fromJson(m)));
    _decodeList(p.getString(_kVisits), (m) => visits.add(Visit.fromJson(m)));
    _decodeList(p.getString(_kHistory), (m) => history.add(HistItem.fromJson(m)));
    try {
      changedAt = (jsonDecode(p.getString(_kMeta) ?? '{}') as Map)['changedAt'] as String?;
    } catch (_) {}
    final pr = p.getString(_kProfile);
    if (pr != null) {
      try {
        profile = Map<String, String>.from(
            (jsonDecode(pr) as Map).map((k, v) => MapEntry(k.toString(), '$v')));
      } catch (_) {}
    }
    _sortVisits();
    _loaded = true;
  }

  void _decodeList(String? raw, void Function(Map<String, dynamic>) add) {
    if (raw == null) return;
    try {
      for (final e in (jsonDecode(raw) as List)) {
        add(Map<String, dynamic>.from(e as Map));
      }
    } catch (_) {}
  }

  void _persist(String key, Object value) {
    if (!saving) return; // tamu: tidak disimpan
    _prefs?.setString(key, jsonEncode(value));
    changedAt = DateTime.now().toUtc().toIso8601String();
    _prefs?.setString(_kMeta, jsonEncode({'changedAt': changedAt}));
  }

  bool isSaved(String id) => saved.any((c) => c.id == id);

  void toggleSave(Clinic c, {String? county}) {
    if (isSaved(c.id)) {
      saved.removeWhere((x) => x.id == c.id);
    } else {
      final snap = Clinic.fromJson(c.toJson())..county = county ?? c.county;
      saved.insert(0, snap);
    }
    _persist(_kSaved, saved.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  void _sortVisits() =>
      visits.sort((a, b) => b.date.compareTo(a.date));

  void upsertVisit(Visit v) {
    final i = visits.indexWhere((x) => x.id == v.id);
    if (i >= 0) {
      visits[i] = v;
    } else {
      visits.insert(0, v);
    }
    _sortVisits();
    _persist(_kVisits, visits.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  void deleteVisit(String id) {
    visits.removeWhere((x) => x.id == id);
    _persist(_kVisits, visits.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  void saveProfile(Map<String, String> p) {
    profile = p;
    _persist(_kProfile, profile);
    notifyListeners();
  }

  void pushHistory(String query, String? county, int count) {
    if (!saving) return; // riwayat pencarian hanya untuk yang sudah masuk
    final q = query.trim();
    final key = '$q|$county';
    history.removeWhere((h) => '${h.query}|${h.county}' == key);
    history.insert(0, HistItem(q, county, SehatData.countyLabel(county), count,
        DateTime.now().millisecondsSinceEpoch));
    if (history.length > 20) history.removeRange(20, history.length);
    _saveHistory();
  }

  /// Hapus satu pencarian dari riwayat.
  void removeHistory(HistItem h) {
    history.removeWhere((x) => x.query == h.query && x.county == h.county);
    _saveHistory();
  }

  /// Kosongkan riwayat pencarian saja (klinik tersimpan & catatan tetap).
  /// Mengembalikan yang dihapus, untuk tombol "Urungkan".
  List<HistItem> clearHistory() {
    final removed = List<HistItem>.of(history);
    history.clear();
    _saveHistory();
    return removed;
  }

  /// Kembalikan pencarian yang baru dihapus ("Urungkan"); pencarian yang
  /// sempat dibuat sesudahnya tetap ada, urutan tetap yang terbaru di atas.
  void restoreHistory(List<HistItem> items) {
    final have = {for (final h in history) '${h.query}|${h.county}'};
    history
      ..addAll(items.where((h) => have.add('${h.query}|${h.county}')))
      ..sort((a, b) => b.ts.compareTo(a.ts));
    if (history.length > 20) history.removeRange(20, history.length);
    _saveHistory();
  }

  void _saveHistory() {
    _persist(_kHistory, history.map((e) => e.toJson()).toList());
    notifyListeners();
  }

  void clearAll() {
    saved.clear();
    visits.clear();
    history.clear();
    profile = {};
    _prefs?.remove(_kSaved);
    _prefs?.remove(_kVisits);
    _prefs?.remove(_kHistory);
    _prefs?.remove(_kProfile);
    _prefs?.remove(_kMeta);
    // Saat masuk akun, hapus-semua juga dicatat waktunya supaya ikut tersinkron.
    changedAt = saving ? DateTime.now().toUtc().toIso8601String() : null;
    notifyListeners();
  }

  /// true bila tidak ada data apa pun (tak perlu disimpan ke akun).
  bool get isBlank => saved.isEmpty && visits.isEmpty && history.isEmpty;

  /// Semua riwayat dalam satu objek (untuk sinkron akun).
  Map<String, dynamic> snapshot() => {
        'at': changedAt,
        'saved': saved.map((e) => e.toJson()).toList(),
        'visits': visits.map((e) => e.toJson()).toList(),
        'history': history.map((e) => e.toJson()).toList(),
      };

  /// Terapkan [snap] (dari akun) dan simpan di perangkat.
  void applySnapshot(Map<String, dynamic> snap) {
    List<Map<String, dynamic>> list(String k) => ((snap[k] as List?) ?? const [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
    saved
      ..clear()
      ..addAll(list('saved').map(Clinic.fromJson));
    visits
      ..clear()
      ..addAll(list('visits').map(Visit.fromJson));
    history
      ..clear()
      ..addAll(list('history').map(HistItem.fromJson));
    _sortVisits();
    _persist(_kSaved, saved.map((e) => e.toJson()).toList());
    _persist(_kVisits, visits.map((e) => e.toJson()).toList());
    _persist(_kHistory, history.map((e) => e.toJson()).toList());
    if (snap['at'] is String) {
      changedAt = snap['at'] as String;
      if (saving) _prefs?.setString(_kMeta, jsonEncode({'changedAt': changedAt}));
    }
    notifyListeners();
  }

  void setUserLoc(List<double>? loc, {bool on = false}) {
    userLoc = loc;
    gpsOn = on;
    notifyListeners();
  }
}

String agoLabel(int ts) {
  final s = (DateTime.now().millisecondsSinceEpoch - ts) / 1000;
  if (s < 60) return 'baru saja';
  if (s < 3600) return '${(s / 60).floor()} menit lalu';
  if (s < 86400) return '${(s / 3600).floor()} jam lalu';
  return '${(s / 86400).floor()} hari lalu';
}

const _monShort = [
  'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
  'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
];

String fmtDate(String iso) {
  if (iso.isEmpty) return '';
  final p = iso.split('-');
  if (p.length < 3) return iso;
  final m = int.tryParse(p[1]) ?? 0;
  final d = int.tryParse(p[2]) ?? 0;
  return '$d ${m >= 1 && m <= 12 ? _monShort[m - 1] : ''} ${p[0]}';
}
