import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'sehat_app.dart';
import 'sehat_detail.dart';
import '../../screens/auth/login_prompt.dart';
import 'sehat_store.dart';
import 'sehat_sync.dart';
import 'sehat_ui.dart';

/// ============ Tab: Panduan ============

class GuideTab extends StatelessWidget {
  const GuideTab({super.key});

  Future<void> _call(String num) async {
    try {
      await launchUrl(
        Uri.parse('tel:$num'),
        mode: LaunchMode.externalApplication,
      );
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        SehatHero(
          eyebrow: 'Panduan berobat',
          title: 'Berobat tanpa bingung',
          subtitle:
              'Cara pakai NHI, perkiraan biaya, apa yang dibawa, '
              'dan kapan harus ke UGD.',
          icon: Icons.menu_book_rounded,
          onBack: () => sehatExit(context),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SehatSection(
                'Nomor darurat',
                icon: Icons.emergency_rounded,
              ),
              // Dua kartu sama tinggi walau panjang teksnya beda.
              IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      child: _emergency('119', 'Ambulans & darurat medis', const [
                        Color(0xFFE0533C),
                        Color(0xFFB23F2C),
                      ], () => _call('119')),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _emergency(
                        '1955',
                        'Hotline pekerja migran · ada Bahasa Indonesia',
                        const [Color(0xFF2B7CC4), Color(0xFF155A97)],
                        () => _call('1955'),
                      ),
                    ),
                  ],
                ),
              ),
              const SehatSection(
                'Panduan singkat',
                icon: Icons.lightbulb_outline_rounded,
              ),
              ..._articles(),
              const SizedBox(height: 14),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.info_outline,
                    size: 15,
                    color: Colors.grey.shade500,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Informasi umum untuk membantu — bukan pengganti nasihat dokter. '
                      'Kalau ragu soal NHI, telepon 1955 atau 健保署.',
                      style: TextStyle(
                        fontSize: 11.5,
                        color: Colors.grey.shade600,
                        height: 1.45,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _emergency(
    String num,
    String label,
    List<Color> colors,
    VoidCallback onTap,
  ) => Material(
    borderRadius: BorderRadius.circular(20),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: onTap,
      child: Ink(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: colors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.22),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.call_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 9),
                Text(
                  num,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.92),
                fontSize: 12,
                height: 1.3,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Ketuk untuk menelepon',
              style: TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    ),
  );

  List<Widget> _articles() {
    return [
      _Accordion(
        icon: Icons.credit_card,
        title: 'Cara pakai kartu NHI (健保) di klinik',
        initiallyExpanded: true,
        body: const [
          _P(
            'Kalau kamu bekerja resmi di Taiwan, kamu otomatis punya NHI (健保). Langkahnya:',
          ),
          _Li('Datang ke klinik, ke loket pendaftaran (掛號).'),
          _Li(
            'Tunjukkan kartu NHI (健保卡). Bilang: "我要用健保" (Wǒ yào yòng jiànbǎo) = "saya mau pakai NHI".',
          ),
          _Li('Tunggu dipanggil, lalu diperiksa dokter.'),
          _Li('Bayar copay (部分負擔) di kasir, ambil obat di apotek klinik.'),
          _P(
            'Dengan NHI kamu cuma bayar sebagian kecil — sisanya ditanggung asuransi.',
          ),
        ],
      ),
      _Accordion(
        icon: Icons.account_balance_wallet_outlined,
        title: 'Perkiraan biaya (copay NHI)',
        body: const [
          _P(
            'Ini perkiraan copay (yang kamu bayar sendiri). Angka pastinya diatur pemerintah & bisa berubah:',
          ),
          _Li(
            'Klinik (診所): sekitar NT\$150–200 sekali kunjungan (biasanya sudah termasuk obat).',
          ),
          _Li(
            'Rumah sakit + rujukan: ± NT\$170–300. Tanpa rujukan lebih mahal (± NT\$300–550).',
          ),
          _Li('UGD (急診): ± NT\$150–550, tergantung tingkat RS.'),
          _Warn(
            'Klinik paling murah & cepat. Untuk sakit ringan (flu, demam), ke klinik dulu — bukan UGD.',
          ),
          _P('Mau tanya harga? "多少錢？" (duōshǎo qián) = "berapa?"'),
        ],
      ),
      _Accordion(
        icon: Icons.description_outlined,
        title: 'Yang harus dibawa saat berobat',
        body: const [
          _Li('Kartu NHI (健保卡) — paling penting.'),
          _Li('ARC / izin tinggal (居留證).'),
          _Li(
            'Uang tunai untuk copay — bawa NT\$300–600 sudah cukup untuk klinik.',
          ),
          _Li('Catatan obat/alergi yang sedang kamu minum (kalau ada).'),
          _Li('Nomor 1955 (hotline Bahasa Indonesia) & nomor teman/majikan.'),
        ],
      ),
      _Accordion(
        icon: Icons.verified_user_outlined,
        title: 'Belum / tidak punya kartu NHI?',
        body: const [
          _P(
            'Tetap bisa berobat, tapi bayar penuh (lebih mahal). Beberapa hal:',
          ),
          _Li(
            'Kartu hilang? Klinik sering masih bisa cek datamu; atau minta majikan/agensi urus kartu ganti.',
          ),
          _Li(
            'Baru datang & belum dapat kartu? Pendaftaran NHI jadi tanggung jawab majikan/agensi — tanyakan ke mereka.',
          ),
          _Li('Ada masalah? Telepon 1955 (gratis, ada Bahasa Indonesia).'),
        ],
      ),
      _Accordion(
        icon: Icons.warning_amber_rounded,
        title: 'Kapan harus ke UGD (急診)?',
        body: const [
          _P('Segera ke UGD / telepon 119 kalau ada tanda bahaya:'),
          _Li('Nyeri dada hebat atau sesak napas berat.'),
          _Li('Pendarahan hebat, luka besar, atau patah tulang parah.'),
          _Li('Pingsan, kejang, atau tidak sadar.'),
          _Li('Kecelakaan serius atau keracunan.'),
          _Warn(
            'Darurat: 119 ambulans · 110 polisi · 1955 hotline Bahasa Indonesia.',
          ),
          _P(
            'Untuk sakit ringan (flu, demam, batuk) cukup ke klinik — jauh lebih cepat & murah.',
          ),
        ],
      ),
    ];
  }
}

class _Accordion extends StatelessWidget {
  const _Accordion({
    required this.icon,
    required this.title,
    required this.body,
    this.initiallyExpanded = false,
  });
  final IconData icon;
  final String title;
  final List<Widget> body;
  final bool initiallyExpanded;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          initiallyExpanded: initiallyExpanded,
          leading: Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: SehatColors.brandSoft.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 18, color: SehatColors.brand),
          ),
          title: Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
          ),
          childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
          expandedCrossAxisAlignment: CrossAxisAlignment.start,
          children: body,
        ),
      ),
    );
  }
}

class _P extends StatelessWidget {
  const _P(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: Text(
      text,
      style: TextStyle(
        fontSize: 13.5,
        color: Colors.grey.shade800,
        height: 1.55,
      ),
    ),
  );
}

class _Li extends StatelessWidget {
  const _Li(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 7),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: const EdgeInsets.only(top: 7, right: 10),
          width: 6,
          height: 6,
          decoration: const BoxDecoration(
            color: SehatColors.brand,
            shape: BoxShape.circle,
          ),
        ),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 13.5,
              color: Colors.grey.shade800,
              height: 1.5,
            ),
          ),
        ),
      ],
    ),
  );
}

class _Warn extends StatelessWidget {
  const _Warn(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 9, top: 2),
    padding: const EdgeInsets.all(11),
    decoration: BoxDecoration(
      color: SehatColors.alertSoft,
      borderRadius: BorderRadius.circular(10),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Icon(Icons.info_outline, size: 15, color: SehatColors.alert),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(
              fontSize: 12.5,
              color: SehatColors.alert,
              fontWeight: FontWeight.w600,
              height: 1.4,
            ),
          ),
        ),
      ],
    ),
  );
}

/// ============ Tab: Saya ============

class MeTab extends StatefulWidget {
  const MeTab({super.key});
  @override
  State<MeTab> createState() => _MeTabState();
}

class _MeTabState extends State<MeTab> {
  Map<String, dynamic>? _account;

  bool get _loggedIn {
    try {
      return Supabase.instance.client.auth.currentSession != null;
    } catch (_) {
      return false; // Supabase belum siap (mis. offline / tes) → tampil ajakan masuk
    }
  }

  @override
  void initState() {
    super.initState();
    if (_loggedIn) _loadAccount();
  }

  /// Ambil profil dari akun PENGYOU (tabel users di database zhuanti).
  Future<void> _loadAccount() async {
    try {
      final uid = Supabase.instance.client.auth.currentUser!.id;
      // select() semua kolom: aman walau kolom arc_no/nhi_no belum dibuat.
      final row = await Supabase.instance.client
          .from('users')
          .select()
          .eq('id', uid)
          .maybeSingle();
      if (mounted) setState(() => _account = row ?? {});
    } catch (_) {
      if (mounted) setState(() => _account = {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = SehatStore.instance;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            SehatHero(
              eyebrow: 'Saya',
              title: 'Profil & riwayat',
              subtitle:
                  'Identitas dari akun PENGYOU-mu; catatan berobat tersimpan '
                  'di perangkat ini.',
              icon: Icons.person_rounded,
              onBack: () => sehatExit(context),
              trailing: store.visits.isEmpty
                  ? null
                  : SehatPill(
                      '${store.visits.length} catatan',
                      fg: SehatColors.brandDeep,
                      bg: Colors.white,
                    ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _profileSection(),
                  SehatSection(
                    'Catatan berobat',
                    icon: Icons.description_outlined,
                    trailing: store.visits.isEmpty ? null : 'terbaru di atas',
                  ),
                  if (!SehatSync.signedIn)
                    const LoginNudgeCard(
                      title: 'Masuk untuk mencatat',
                      text: 'Catatan berobat (keluhan, obat, biaya, jadwal kontrol) '
                          'disimpan di akunmu — pribadi, hanya kamu yang bisa lihat.',
                      next: '/sehat',
                      color: SehatColors.brand,
                      compact: true,
                    )
                  else
                  FilledButton.icon(
                    onPressed: () async {
                      await Navigator.of(
                        context,
                      ).push(sehatRoute(const SehatVisitForm()));
                      if (mounted) setState(() {});
                    },
                    icon: const Icon(Icons.add_rounded),
                    label: const Text('Tambah catatan kunjungan'),
                    style: FilledButton.styleFrom(
                      minimumSize: const Size(0, 48),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const SizedBox(height: 8),
                  if (store.visits.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 26),
                      child: Column(
                        children: [
                          Icon(
                            Icons.description_outlined,
                            size: 46,
                            color: Colors.grey.shade400,
                          ),
                          const SizedBox(height: 10),
                          const Text(
                            'Belum ada catatan',
                            style: TextStyle(fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Catat kunjungan & obat biar tidak lupa riwayat berobatmu.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                        ],
                      ),
                    )
                  else
                    for (final v in store.visits) _visitCard(v),
                  if (store.visits.isNotEmpty)
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton.icon(
                        onPressed: () async {
                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text('Hapus semua data?'),
                              content: const Text(
                                'Hapus SEMUA riwayat Sehat (klinik tersimpan, catatan berobat, pencarian) dari akun & perangkat ini? Profil akun PENGYOU tidak terhapus.',
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () =>
                                      Navigator.pop(context, false),
                                  child: const Text('Batal'),
                                ),
                                FilledButton(
                                  onPressed: () => Navigator.pop(context, true),
                                  style: FilledButton.styleFrom(
                                    backgroundColor: SehatColors.alert,
                                  ),
                                  child: const Text('Hapus'),
                                ),
                              ],
                            ),
                          );
                          if (ok == true) {
                            store.clearAll();
                          }
                        },
                        icon: const Icon(Icons.delete_outline, size: 16),
                        label: const Text('Hapus semua data saya'),
                        style: TextButton.styleFrom(
                          foregroundColor: SehatColors.alert,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _visitCard(Visit v) {
    final rows = <Widget>[];
    void row(IconData ic, String text) => rows.add(
      Padding(
        padding: const EdgeInsets.only(top: 5),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(ic, size: 14, color: Colors.grey.shade500),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                text,
                style: TextStyle(
                  fontSize: 12.5,
                  color: Colors.grey.shade800,
                  height: 1.4,
                ),
              ),
            ),
          ],
        ),
      ),
    );
    if (v.symptom.isNotEmpty) row(Icons.medical_services_outlined, v.symptom);
    if (v.meds.isNotEmpty) row(Icons.medication_outlined, v.meds);
    if (v.cost.isNotEmpty) {
      row(Icons.account_balance_wallet_outlined, 'NT\$${v.cost}');
    }
    if (v.followup.isNotEmpty) {
      row(Icons.event_outlined, 'Kontrol: ${fmtDate(v.followup)}');
    }
    if (v.notes.isNotEmpty) row(Icons.notes_outlined, v.notes);
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: () async {
          await Navigator.of(
            context,
          ).push(sehatRoute(SehatVisitForm(existing: v)));
          if (mounted) setState(() {});
        },
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: SehatColors.brandSoft,
                      borderRadius: BorderRadius.circular(7),
                    ),
                    child: Text(
                      fmtDate(v.date),
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: SehatColors.brandDeep,
                      ),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      v.clinicName.isEmpty ? 'Kunjungan' : v.clinicName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                      ),
                    ),
                  ),
                  Icon(
                    Icons.edit_outlined,
                    size: 15,
                    color: Colors.grey.shade500,
                  ),
                ],
              ),
              ...rows,
            ],
          ),
        ),
      ),
    );
  }

  Widget _profileSection() {
    if (!_loggedIn) return _loginPrompt();
    if (_account == null) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(28),
          child: Center(
            child: CircularProgressIndicator(color: SehatColors.brand),
          ),
        ),
      );
    }
    final name = (_account!['full_name'] ?? '').toString();
    final arc = (_account!['arc_no'] ?? '').toString();
    final nhi = (_account!['nhi_no'] ?? '').toString();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: SehatColors.brand,
                  child: Text(
                    name.trim().isEmpty ? '?' : name.trim()[0].toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 22,
                    ),
                  ),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name.isEmpty ? 'Akun PENGYOU' : name,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        'Dari akun PENGYOU-mu',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            _idRow('No. ARC / 居留證', arc),
            const Divider(height: 18),
            _idRow('No. NHI / 健保卡', nhi),
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: () => context.go('/akun'),
              icon: const Icon(Icons.manage_accounts_outlined),
              label: const Text('Kelola di Akun PENGYOU'),
              style: OutlinedButton.styleFrom(
                foregroundColor: SehatColors.brandDeep,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.info_outline, size: 15, color: Colors.grey.shade500),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Identitas ini tersimpan di akunmu (database PENGYOU), bukan hanya di perangkat.',
                    style: TextStyle(
                      fontSize: 11.5,
                      color: Colors.grey.shade600,
                      height: 1.45,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _idRow(String label, String value) => Row(
    children: [
      Expanded(
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12.5,
            color: Colors.grey.shade600,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      Text(
        value.isEmpty ? 'Belum diisi' : value,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w700,
          color: value.isEmpty ? Colors.grey.shade400 : SehatColors.brandDeep,
        ),
      ),
    ],
  );

  Widget _loginPrompt() => Card(
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const CircleAvatar(
            radius: 30,
            backgroundColor: SehatColors.brandSoft,
            child: Icon(
              Icons.person_outline,
              size: 34,
              color: SehatColors.brandDeep,
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Masuk untuk menampilkan profil',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
          ),
          const SizedBox(height: 6),
          Text(
            'Nama, No. ARC & No. NHI diambil dari akun PENGYOU-mu — jadi tak perlu isi ulang di sini.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey.shade600, height: 1.45),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => context.go('/login'),
            icon: const Icon(Icons.login),
            label: const Text('Masuk'),
            style: FilledButton.styleFrom(
              backgroundColor: SehatColors.brand,
              minimumSize: const Size.fromHeight(48),
            ),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => context.go('/daftar'),
            icon: const Icon(Icons.person_add_alt),
            label: const Text('Daftar akun baru'),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(48),
            ),
          ),
        ],
      ),
    ),
  );
}
