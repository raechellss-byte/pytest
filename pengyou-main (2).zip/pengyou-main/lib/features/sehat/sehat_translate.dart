import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart';

import '../../services/tts_voice.dart';
import '../liuli/liuli_data.dart';
import 'sehat_app.dart' show SehatColors, sehatExit;
import 'sehat_translate_service.dart';
import 'sehat_ui.dart';

typedef Translator = Future<String> Function(String text, TrLang from, TrLang to);
typedef Speaker = Future<void> Function(String text, TrLang lang);

/// Tema app memberi tombol lebar penuh (Size.fromHeight); di Row/Wrap tombol
/// harus berukuran sendiri.
const _kButton = Size(0, 44);

/// Tab "Terjemah": ketik atau ucapkan bahasa Indonesia → Mandarin Taiwan /
/// Inggris, lalu suarakan 🔊 atau tunjukkan tulisan besar ke petugas.
/// Tombol ⇄ membalik arah supaya petugas bisa membalas.
class TranslateTab extends StatefulWidget {
  const TranslateTab({
    super.key,
    this.translator = translateText,
    this.speaker,
  });

  final Translator translator;
  final Speaker? speaker; // null = TTS perangkat (diganti saat tes)

  @override
  State<TranslateTab> createState() => _TranslateTabState();
}

class _TranslateTabState extends State<TranslateTab> {
  static const _kOther = 'sehat_tr_other';

  final _input = TextEditingController();
  final _tts = FlutterTts();
  final _stt = SpeechToText();
  Timer? _debounce;
  TrLang _other = trMandarin; // bahasa lawan bicara
  bool _reversed = false; // true = lawan bicara → Indonesia
  String _result = '';
  String? _pinyin;
  String? _error;
  bool _loading = false;
  bool _sttReady = false;
  bool _listening = false;
  int _seq = 0; // abaikan hasil terjemahan yang sudah usang
  Map<String, String>? _pyLookup;

  TrLang get _from => _reversed ? _other : trIndonesia;
  TrLang get _to => _reversed ? trIndonesia : _other;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      final code = p.getString(_kOther);
      final saved = trOthers.where((l) => l.code == code);
      if (saved.isNotEmpty && mounted) setState(() => _other = saved.first);
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _input.dispose();
    if (_listening) _stt.stop();
    _tts.stop().catchError((_) => null);
    super.dispose();
  }

  void _onChanged(String _) {
    setState(() {});
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 800), _translate);
  }

  Future<void> _translate() async {
    _debounce?.cancel();
    final text = _input.text.trim();
    final seq = ++_seq;
    if (text.isEmpty) {
      setState(() {
        _result = '';
        _pinyin = null;
        _error = null;
        _loading = false;
      });
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    final to = _to;
    try {
      final out = await widget.translator(text, _from, to);
      final py = to == trMandarin ? await _pinyinOf(out) : null;
      if (seq != _seq || !mounted) return;
      setState(() {
        _result = out;
        _pinyin = py;
        _loading = false;
      });
    } catch (e) {
      if (seq != _seq || !mounted) return;
      setState(() {
        _error = e is TranslateException
            ? e.message
            : 'Gagal menerjemahkan. Coba lagi.';
        _loading = false;
      });
    }
  }

  Future<String?> _pinyinOf(String zh) async {
    try {
      _pyLookup ??= buildPinyinLookup(await LiuliData.dict());
      final py = pinyinFor(zh, _pyLookup!);
      return py.isEmpty ? null : py;
    } catch (_) {
      return null;
    }
  }

  void _swap() {
    setState(() {
      _reversed = !_reversed;
      if (_result.isNotEmpty && _error == null) _input.text = _result;
      _result = '';
      _pinyin = null;
      _error = null;
    });
    _translate();
  }

  void _setOther(TrLang lang) {
    if (lang == _other) return;
    setState(() {
      _other = lang;
      _result = '';
      _pinyin = null;
    });
    SharedPreferences.getInstance()
        .then((p) => p.setString(_kOther, lang.code))
        .catchError((_) => false);
    _translate();
  }

  void _clear() {
    _input.clear();
    _translate();
  }

  Future<void> _speak(String text, TrLang lang) async {
    if (text.isEmpty) return;
    if (widget.speaker != null) return widget.speaker!(text, lang);
    try {
      await _tts.stop();
      await useVoiceFor(_tts, lang.tts);
      await _tts.setSpeechRate(lang == trMandarin ? 0.45 : 0.5);
      await _tts.speak(text);
    } catch (_) {}
  }

  Future<void> _toggleMic() async {
    if (_listening) {
      await _stt.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }
    if (!_sttReady) {
      try {
        _sttReady = await _stt.initialize(
          onStatus: (s) {
            if ((s == 'done' || s == 'notListening') && mounted) {
              setState(() => _listening = false);
            }
          },
          onError: (_) {
            if (mounted) setState(() => _listening = false);
          },
        );
      } catch (_) {
        _sttReady = false;
      }
    }
    if (!_sttReady) {
      _snack('Mikrofon tidak tersedia di perangkat/browser ini. Silakan ketik.');
      return;
    }
    setState(() => _listening = true);
    try {
      await _stt.listen(
        listenOptions: SpeechListenOptions(
          partialResults: true,
          localeId: _from.stt,
        ),
        onResult: (r) {
          if (!mounted) return;
          _input.value = TextEditingValue(
            text: r.recognizedWords,
            selection: TextSelection.collapsed(
              offset: r.recognizedWords.length,
            ),
          );
          setState(() {});
          if (r.finalResult) {
            setState(() => _listening = false);
            _translate();
          }
        },
      );
    } catch (_) {
      if (mounted) setState(() => _listening = false);
      _snack('Mikrofon tidak bisa dipakai. Silakan ketik.');
    }
  }

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: _result));
    _snack('Terjemahan disalin.');
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.only(bottom: 28),
      children: [
        SehatHero(
          eyebrow: 'Terjemah ke dokter',
          title: 'Terjemahkan',
          subtitle:
              'Ketik atau ucapkan, lalu ketuk 🔊 Suarakan atau tunjukkan '
              'tulisan besar ke petugas.',
          icon: Icons.translate_rounded,
          onBack: () => sehatExit(context),
          child: _langBar(),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _inputCard(),
              _resultCard(),
              const SizedBox(height: 12),
              Text(
                'Terjemahan mesin gratis (MyMemory) — periksa ulang hal penting '
                'seperti dosis obat. Jangan ketik nomor identitas atau data '
                'pribadi.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11.5,
                  height: 1.4,
                  color: Colors.blueGrey.shade400,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _langBar() {
    Widget side(TrLang lang) {
      final pickable = lang != trIndonesia;
      final label = Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Flexible(
            child: Text(
              lang.label,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                color: SehatColors.brandDeep,
              ),
            ),
          ),
          if (pickable)
            const Icon(
              Icons.arrow_drop_down_rounded,
              color: SehatColors.brandDeep,
            ),
        ],
      );
      if (!pickable) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: label,
        );
      }
      return PopupMenuButton<TrLang>(
        tooltip: 'Pilih bahasa',
        onSelected: _setOther,
        itemBuilder: (_) => [
          for (final l in trOthers)
            CheckedPopupMenuItem(
              value: l,
              checked: l == _other,
              child: Text(l.label),
            ),
        ],
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: label,
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.12),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(child: side(_from)),
          IconButton.filled(
            tooltip: 'Tukar arah',
            onPressed: _swap,
            style: IconButton.styleFrom(
              backgroundColor: SehatColors.brandSoft,
              foregroundColor: SehatColors.brandDeep,
            ),
            icon: const Icon(Icons.swap_horiz_rounded),
          ),
          Expanded(child: side(_to)),
        ],
      ),
    );
  }

  Widget _inputCard() {
    final len = _input.text.characters.length;
    return SehatCard(
      padding: const EdgeInsets.fromLTRB(16, 12, 8, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                _from.label,
                style: const TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: SehatColors.brand,
                ),
              ),
              const Spacer(),
              if (len > 0)
                IconButton(
                  tooltip: 'Hapus',
                  visualDensity: VisualDensity.compact,
                  onPressed: _clear,
                  icon: const Icon(Icons.close_rounded),
                ),
            ],
          ),
          TextField(
            controller: _input,
            onChanged: _onChanged,
            onSubmitted: (_) => _translate(),
            minLines: 3,
            maxLines: 8,
            maxLength: kTrMaxChars,
            style: const TextStyle(fontSize: 19, height: 1.35),
            decoration: InputDecoration(
              hintText: _from.hint,
              hintStyle: TextStyle(color: Colors.blueGrey.shade200),
              filled: false,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              counterText: '',
              contentPadding: const EdgeInsets.only(right: 8, bottom: 6),
            ),
          ),
          Row(
            children: [
              FilledButton.tonalIcon(
                onPressed: _toggleMic,
                icon: Icon(
                  _listening ? Icons.stop_rounded : Icons.mic_rounded,
                ),
                label: Text(_listening ? 'Berhenti' : 'Bicara'),
                style: FilledButton.styleFrom(
                  minimumSize: _kButton,
                  backgroundColor: _listening
                      ? SehatColors.alertSoft
                      : SehatColors.brandSoft,
                  foregroundColor: _listening
                      ? SehatColors.alert
                      : SehatColors.brandDeep,
                ),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Text(
                  '$len / $kTrMaxChars',
                  style: TextStyle(
                    fontSize: 11.5,
                    color: Colors.blueGrey.shade300,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _resultCard() {
    final zh = _to == trMandarin;
    final has = _result.isNotEmpty && _error == null;
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0E8A7E), SehatColors.brandDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: SehatColors.brandDeep.withValues(alpha: 0.22),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                _to.label,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: Colors.white.withValues(alpha: 0.8),
                ),
              ),
              const Spacer(),
              if (_loading)
                const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          if (_error != null)
            Row(
              children: [
                const Icon(Icons.error_outline_rounded, color: Colors.white),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.white, height: 1.35),
                  ),
                ),
              ],
            )
          else if (!has)
            Text(
              _loading ? 'Menerjemahkan…' : 'Terjemahan muncul di sini',
              style: TextStyle(
                fontSize: 17,
                color: Colors.white.withValues(alpha: 0.55),
              ),
            )
          else ...[
            SelectableText(
              _result,
              style: TextStyle(
                fontSize: zh ? 28 : 21,
                fontWeight: FontWeight.w800,
                height: 1.3,
                color: Colors.white,
              ),
            ),
            if (_pinyin != null) ...[
              const SizedBox(height: 6),
              Text(
                _pinyin!,
                style: TextStyle(
                  fontSize: 14.5,
                  fontStyle: FontStyle.italic,
                  color: Colors.white.withValues(alpha: 0.85),
                ),
              ),
            ],
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.icon(
                  onPressed: () => _speak(_result, _to),
                  icon: const Icon(Icons.volume_up_rounded),
                  label: const Text('Suarakan'),
                  style: FilledButton.styleFrom(
                    minimumSize: _kButton,
                    backgroundColor: Colors.white,
                    foregroundColor: SehatColors.brandDeep,
                  ),
                ),
                _ghostButton(Icons.fullscreen_rounded, 'Tunjukkan', _showBig),
                _ghostButton(Icons.copy_rounded, 'Salin', _copy),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _ghostButton(IconData icon, String label, VoidCallback onTap) =>
      OutlinedButton.icon(
        onPressed: onTap,
        icon: Icon(icon),
        label: Text(label),
        style: OutlinedButton.styleFrom(
          minimumSize: _kButton,
          foregroundColor: Colors.white,
          side: BorderSide(color: Colors.white.withValues(alpha: 0.6)),
        ),
      );

  /// Tulisan besar untuk ditunjukkan (atau dibaca sendiri bila arah dibalik).
  void _showBig() {
    final to = _to;
    final text = _result;
    final source = _input.text.trim();
    final pinyin = _pinyin;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(24, 4, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _reversed
                  ? 'Terjemahan untuk Anda'
                  : 'Tunjukkan layar ini ke petugas 👇',
              style: const TextStyle(
                color: Colors.grey,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: to == trMandarin ? 40 : 30,
                fontWeight: FontWeight.w800,
                height: 1.3,
                color: SehatColors.brandDeep,
              ),
            ),
            if (pinyin != null) ...[
              const SizedBox(height: 10),
              Text(
                pinyin,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 15, color: Colors.grey.shade600),
              ),
            ],
            const SizedBox(height: 10),
            Text(
              source,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 22),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _speak(text, to),
                    icon: const Icon(Icons.volume_up_rounded),
                    label: const Text('Suarakan'),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 48),
                      foregroundColor: SehatColors.brandDeep,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => Navigator.pop(ctx),
                    icon: const Icon(Icons.check),
                    label: const Text('Selesai'),
                    style: FilledButton.styleFrom(
                      backgroundColor: SehatColors.brand,
                      minimumSize: const Size(0, 48),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
