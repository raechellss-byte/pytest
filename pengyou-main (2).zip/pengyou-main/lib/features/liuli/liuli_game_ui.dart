import 'package:flutter/material.dart';

import 'liuli_common.dart';
import 'liuli_game.dart';
import 'liuli_practice.dart' show startGrammarPractice;
import 'liuli_speech.dart' show SpeakQuizScreen;
import 'liuli_stats.dart';
import 'liuli_store.dart';
import 'liuli_study.dart' show startLiuliStudy;
import 'liuli_typing.dart' show ZhuyinTypingScreen;

const _gold = Color(0xFFCA8A04);

/// Kartu Beranda: level + XP, lalu 3 misi hari ini (ketuk → langsung latihan).
class LiuliQuestCard extends StatelessWidget {
  const LiuliQuestCard({super.key, required this.onGoTab});
  final void Function(int) onGoTab;

  @override
  Widget build(BuildContext context) {
    final s = LiuliStore.instance;
    final lv = s.level;
    final base = xpForLevel(lv), next = xpForLevel(lv + 1);
    final today = s.xpDaily[liuliToday()] ?? 0;
    final quests = s.todayQuests;
    final allDone = quests.every(s.questDone);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [Color(0xFFE0A526), Color(0xFFB7791F)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Text('Lv',
                    style: TextStyle(
                        color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700, height: 1)),
                Text('$lv',
                    style: const TextStyle(
                        color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900, height: 1.05)),
              ]),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(levelTitle(lv),
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5)),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: (s.xp - base) / (next - base),
                    minHeight: 7,
                    backgroundColor: LiuliColors.surface2,
                    color: _gold,
                  ),
                ),
                const SizedBox(height: 4),
                Text('${s.xp - base} / ${next - base} XP ke level ${lv + 1}'
                    '${today > 0 ? ' · +$today hari ini' : ''}',
                    style: TextStyle(fontSize: 11.5, color: LiuliColors.text2)),
              ]),
            ),
            const SizedBox(width: 8),
            InkWell(
              borderRadius: BorderRadius.circular(999),
              onTap: () => Navigator.of(context).push(liuliRoute(const LiuliStatsScreen())),
              child: Pill('🏅 ${s.badgesEarned.length}/${liuliBadges.length}', color: _gold),
            ),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            const Text('Misi hari ini', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            const Spacer(),
            Text('berganti tiap hari', style: TextStyle(fontSize: 11.5, color: LiuliColors.text3)),
          ]),
          const SizedBox(height: 6),
          for (final q in quests) _questRow(context, s, q),
          const SizedBox(height: 4),
          Text(
              allDone
                  ? '🏆 Semua misi selesai — bonus +$kQuestAllBonus XP sudah masuk!'
                  : 'Tuntaskan ketiganya untuk bonus +$kQuestAllBonus XP.',
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: allDone ? FontWeight.w700 : FontWeight.w500,
                  color: allDone ? LiuliColors.jadeDeep : LiuliColors.text2)),
        ]),
      ),
    );
  }

  Widget _questRow(BuildContext context, LiuliStore s, Quest q) {
    final done = s.questDone(q);
    final p = s.questProgress(q).clamp(0, q.target);
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: done ? null : () => _go(context, q.kind),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          Container(
            width: 36,
            height: 36,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: done ? LiuliColors.jadeTint : LiuliColors.surface2,
              shape: BoxShape.circle,
            ),
            child: Text(q.icon, style: const TextStyle(fontSize: 17)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(q.title,
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      decoration: done ? TextDecoration.lineThrough : null,
                      color: done ? LiuliColors.text3 : LiuliColors.ink)),
              const SizedBox(height: 4),
              ClipRRect(
                borderRadius: BorderRadius.circular(3),
                child: LinearProgressIndicator(
                  value: p / q.target,
                  minHeight: 5,
                  backgroundColor: LiuliColors.surface2,
                  color: done ? LiuliColors.good : LiuliColors.jade,
                ),
              ),
            ]),
          ),
          const SizedBox(width: 10),
          done
              ? Pill('✓ Selesai', color: LiuliColors.good)
              : Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('$p/${q.target}',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
                  Text('+${q.reward} XP', style: const TextStyle(fontSize: 11, color: _gold)),
                ]),
        ]),
      ),
    );
  }

  /// Ketuk misi → buka latihan yang sesuai.
  void _go(BuildContext context, String kind) {
    final nav = Navigator.of(context);
    switch (kind) {
      case 'review':
      case 'new':
        startLiuliStudy(context);
      case 'quiz':
        onGoTab(4);
      case 'type':
        nav.push(liuliRoute(const ZhuyinTypingScreen(initialMode: 'word')));
      case 'gram':
        startGrammarPractice(context);
      case 'talk':
        onGoTab(2);
      case 'speak':
        nav.push(liuliRoute(const SpeakQuizScreen()));
    }
  }
}

/// Kisi lencana: yang sudah didapat berwarna, yang belum redup + syaratnya.
class LiuliBadgeGrid extends StatelessWidget {
  const LiuliBadgeGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final s = LiuliStore.instance;
    return LayoutBuilder(builder: (context, c) {
      final w = (c.maxWidth - 16) / 3;
      return Wrap(spacing: 8, runSpacing: 8, children: [
        for (final b in liuliBadges)
          () {
            final got = s.badgesEarned[b.id];
            return Container(
              width: w,
              height: 136, // seragam supaya kisi rapi
              padding: const EdgeInsets.fromLTRB(8, 10, 8, 8),
              decoration: BoxDecoration(
                color: got != null ? _gold.withValues(alpha: 0.12) : LiuliColors.surface2,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                    color: got != null ? _gold.withValues(alpha: 0.45) : Colors.transparent),
              ),
              child: Column(children: [
                Opacity(
                  opacity: got != null ? 1 : 0.3,
                  child: Text(b.icon, style: const TextStyle(fontSize: 26)),
                ),
                const SizedBox(height: 4),
                Text(b.title,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w800,
                        color: got != null ? LiuliColors.ink : LiuliColors.text3)),
                const SizedBox(height: 2),
                Text(got != null ? 'Didapat $got' : b.desc,
                    textAlign: TextAlign.center,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 10, height: 1.25, color: LiuliColors.text3)),
              ]),
            );
          }(),
      ]);
    });
  }
}
