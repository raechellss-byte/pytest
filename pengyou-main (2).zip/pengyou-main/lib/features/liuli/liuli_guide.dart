import 'package:flutter/material.dart';

import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_practice.dart' show startGrammarPractice;
import 'liuli_store.dart';

/// Buang tag HTML sederhana (<b>, <span>, <i>) dari string konten.
String _stripHtml(String s) => s.replaceAll(RegExp(r'<[^>]+>'), '');

class LiuliGuide extends StatelessWidget {
  const LiuliGuide({super.key});

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        Text('CARA PAKAI & STRATEGI',
            style: TextStyle(
                fontSize: 11,
                letterSpacing: 1,
                fontWeight: FontWeight.w700,
                color: LiuliColors.jade)),
        const SizedBox(height: 4),
        Text('Cara keluar dari plateau',
            style: hanziStyle(size: 24, color: LiuliColors.ink)),
        const SizedBox(height: 12),
        LiuliBanner(
          stats: [
            ('${LiuliData.steps.length}', 'langkah strategi'),
            ('${LiuliData.grammar.length}', 'pola tata bahasa'),
          ],
          mark: '道',
          color: levelColor(6),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: LiuliColors.jadeTint,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Text(
              'Paham pasif tapi belum lancar itu normal — bukan karena kurang '
              'kosakata, tapi jarang memproduksi bahasa secara aktif. Aplikasi ini '
              'memaksa recall & bicara, bukan cuma mengenali.',
              style: TextStyle(color: LiuliColors.jadeDeep, height: 1.5)),
        ),
        const SizedBox(height: 12),
        for (var i = 0; i < LiuliData.steps.length; i++)
          _step(i + 1, LiuliData.steps[i]),
        const SectionHead('Empat nada (聲調)', trailing: 'latihan di Kuis'),
        Text('Nada mengubah arti total: mā (媽 ibu) vs mà (罵 memarahi). '
            'Dengar & tirukan keempatnya.',
            style: TextStyle(color: LiuliColors.text2, height: 1.4)),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(children: [
              for (final r in LiuliData.toneRef) _toneRow(store, r),
            ]),
          ),
        ),
        SectionHead('Tata bahasa penting',
            trailing: '${LiuliData.grammar.fold<int>(0, (n, g) => n + g.q.length)} soal latihan'),
        FilledButton.icon(
          onPressed: () => startGrammarPractice(context),
          icon: const Icon(Icons.shuffle_rounded),
          label: const Text('Latihan campuran (10 soal acak)'),
          style: FilledButton.styleFrom(
              backgroundColor: LiuliColors.jade, minimumSize: const Size(0, 46)),
        ),
        const SizedBox(height: 8),
        for (final g in LiuliData.grammar) _grammar(context, store, g),
        const SectionHead('Tentang level TOCFL'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(children: [
              _tocflRow('Level', 'CEFR', 'Perkiraan', header: true),
              for (final r in LiuliData.tocflInfo)
                _tocflRow('Level ${r[0]}', '${r[1]}', '${r[2]}'),
            ]),
          ),
        ),
        const SectionHead('Kenapa metode ini bekerja'),
        Text(
            'Flashcard di sini pakai spaced repetition (SRS): kata "Susah" muncul '
            'lagi lebih cepat, yang "Mudah" makin jarang. Mode Produksi (ID → 中文) '
            'memaksa otak mengeluarkan bahasa — jauh lebih ampuh untuk kelancaran.',
            style: TextStyle(color: LiuliColors.text2, height: 1.55)),
      ],
    );
  }

  Widget _step(int n, GuideStep s) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 30,
            height: 30,
            alignment: Alignment.center,
            decoration: const BoxDecoration(
                color: LiuliColors.jade, shape: BoxShape.circle),
            child: Text('$n',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_stripHtml(s.t),
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
              const SizedBox(height: 2),
              Text(_stripHtml(s.d),
                  style: TextStyle(
                      fontSize: 13, color: LiuliColors.text2, height: 1.45)),
            ]),
          ),
        ]),
      );

  Widget _toneRow(LiuliStore store, ToneItem r) => ListTile(
        leading: Row(mainAxisSize: MainAxisSize.min, children: [
          ToneIcon(r.tone, size: 20),
          const SizedBox(width: 6),
          Text('${r.tone}',
              style: const TextStyle(fontWeight: FontWeight.w800)),
        ]),
        title: Row(children: [
          Text(r.h, style: hanziStyle(size: 24)),
          const SizedBox(width: 12),
          Text(r.p,
              style: TextStyle(
                  fontWeight: FontWeight.w700, color: LiuliColors.jadeDeep)),
          const SizedBox(width: 8),
          Expanded(
              child: Text(r.id,
                  style: TextStyle(color: LiuliColors.text2, fontSize: 12))),
        ]),
        trailing: IconButton(
          icon: const Icon(Icons.volume_up_rounded, color: LiuliColors.jade),
          onPressed: () => store.speak(r.h),
        ),
      );

  Widget _grammar(BuildContext context, LiuliStore store, Grammar g) => Card(
        clipBehavior: Clip.antiAlias,
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            title: Text(store.zh(_stripHtml(g.t)),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            subtitle: Text(store.zh(g.pat),
                style: TextStyle(fontSize: 12, color: LiuliColors.jadeDeep)),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
            expandedCrossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(_stripHtml(g.d),
                  style: TextStyle(color: LiuliColors.text2, height: 1.5)),
              const SizedBox(height: 10),
              for (final e in g.ex)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(store.zh(e.h), style: hanziStyle(size: 18)),
                          Text(e.p,
                              style: TextStyle(
                                  fontSize: 12, color: LiuliColors.jadeDeep)),
                          Text(e.id,
                              style: TextStyle(
                                  fontSize: 12, color: LiuliColors.text2)),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.volume_up_rounded,
                          size: 20, color: LiuliColors.jade),
                      onPressed: () => store.speak(e.h),
                    ),
                  ]),
                ),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: LiuliColors.gold.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text('💡 ${_stripHtml(g.tip)}',
                    style: const TextStyle(fontSize: 12.5, height: 1.4)),
              ),
              if (g.q.isNotEmpty) ...[
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () => startGrammarPractice(context, g: g),
                  icon: const Icon(Icons.edit_note_rounded),
                  label: Text('Latihan pola ini (${g.q.length} soal)'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(0, 42),
                    foregroundColor: LiuliColors.jadeDeep,
                    side: BorderSide(color: LiuliColors.jade.withValues(alpha: 0.4)),
                  ),
                ),
              ],
            ],
          ),
        ),
      );

  Widget _tocflRow(String a, String b, String c, {bool header = false}) {
    final style = TextStyle(
        fontWeight: header ? FontWeight.w800 : FontWeight.w600,
        fontSize: header ? 12 : 13,
        color: header ? LiuliColors.text2 : null);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(children: [
        SizedBox(width: 70, child: Text(a, style: style)),
        SizedBox(
            width: 44,
            child: Text(b,
                style: style.copyWith(
                    color: header ? LiuliColors.text2 : LiuliColors.jade))),
        Expanded(child: Text(c, style: style)),
      ]),
    );
  }
}
