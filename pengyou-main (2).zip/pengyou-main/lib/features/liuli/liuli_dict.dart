import 'package:flutter/material.dart';

import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_store.dart';
import 'liuli_study.dart';
import 'liuli_write.dart';

String _noTone(String s) => s
    .toLowerCase()
    .replaceAll(RegExp(r'[āáǎà]'), 'a')
    .replaceAll(RegExp(r'[ēéěè]'), 'e')
    .replaceAll(RegExp(r'[īíǐì]'), 'i')
    .replaceAll(RegExp(r'[ōóǒò]'), 'o')
    .replaceAll(RegExp(r'[ūúǔùǖǘǚǜ]'), 'u')
    .replaceAll('ü', 'u')
    .replaceAll(RegExp(r'[^a-z]'), '');

class DictEntry {
  DictEntry(this.h, this.p, this.gloss, {this.vocab});
  final String h, p, gloss;
  final Vocab? vocab;
}

class LiuliDict extends StatefulWidget {
  const LiuliDict({super.key});
  @override
  State<LiuliDict> createState() => _LiuliDictState();
}

class _LiuliDictState extends State<LiuliDict> {
  final _ctrl = TextEditingController();
  final store = LiuliStore.instance;
  int _view = 0; // 0 = cari, 1 = koleksi
  List<DictEntry> _results = [];
  List<DictRow>? _dict;
  bool _dictLoading = false;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _search(String q) async {
    q = q.trim();
    if (q.isEmpty) {
      setState(() => _results = []);
      return;
    }
    final qLower = q.toLowerCase();
    final qNoTone = _noTone(q);
    final out = <DictEntry>[];
    final seen = <String>{};
    // 1) VOCAB dulu.
    for (final v in LiuliData.vocab) {
      if (v.h.contains(q) ||
          _noTone(v.p).contains(qNoTone) ||
          v.id.toLowerCase().contains(qLower)) {
        if (seen.add(v.h)) out.add(DictEntry(v.h, v.p, v.id, vocab: v));
      }
      if (out.length >= 40) break;
    }
    // 2) DICT (dimuat lazy).
    if (_dict == null && !_dictLoading) {
      setState(() => _dictLoading = true);
      _dict = await LiuliData.dict();
      if (mounted) setState(() => _dictLoading = false);
    }
    for (final r in _dict ?? const <DictRow>[]) {
      if (out.length >= 60) break;
      if (r.trad.contains(q) ||
          r.simp.contains(q) ||
          _noTone(r.pin).contains(qNoTone) ||
          r.gloss.toLowerCase().contains(qLower)) {
        if (seen.add(r.trad)) out.add(DictEntry(r.trad, r.pin, r.gloss));
      }
    }
    if (mounted) setState(() => _results = out);
    store.addHist(q);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(
            title: TextField(
              controller: _ctrl,
              autofocus: true,
              onChanged: _search,
              decoration: InputDecoration(
                hintText: 'Cari hanzi, pinyin, atau arti…',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _ctrl.text.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          _ctrl.clear();
                          _search('');
                        }),
              ),
            ),
          ),
          body: Column(children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('Cari')),
                  ButtonSegment(value: 1, label: Text('📚 Koleksi')),
                ],
                selected: {_view},
                showSelectedIcon: false,
                onSelectionChanged: (s) => setState(() => _view = s.first),
              ),
            ),
            Expanded(child: _view == 0 ? _searchView() : _collView()),
          ]),
        );
      },
    );
  }

  Widget _searchView() {
    if (_ctrl.text.trim().isEmpty) {
      return _hintList();
    }
    if (_dictLoading && _results.isEmpty) {
      return const Center(child: CircularProgressIndicator(color: LiuliColors.jade));
    }
    if (_results.isEmpty) {
      return Center(
          child: Text('Tidak ada hasil untuk "${_ctrl.text.trim()}".',
              style: TextStyle(color: LiuliColors.text2)));
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      itemCount: _results.length,
      itemBuilder: (_, i) => _entryCard(_results[i]),
    );
  }

  Widget _hintList() {
    if (store.dictHist.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
              'Cari kata Mandarin apa pun — dari 25.000+ entri kamus & kosakata aplikasi.',
              textAlign: TextAlign.center,
              style: TextStyle(color: LiuliColors.text2, height: 1.5)),
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Pencarian terakhir',
            style: TextStyle(fontWeight: FontWeight.w800, color: LiuliColors.text2)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final h in store.dictHist)
              ActionChip(
                label: Text(h),
                onPressed: () {
                  _ctrl.text = h;
                  _search(h);
                },
              ),
          ],
        ),
      ],
    );
  }

  Widget _entryCard(DictEntry e) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(store.zh(e.h), style: hanziStyle(size: 30)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(e.p,
                      style: TextStyle(
                          fontWeight: FontWeight.w700, color: LiuliColors.jadeDeep)),
                  const SizedBox(height: 2),
                  Text(e.gloss,
                      style: TextStyle(color: LiuliColors.text2, height: 1.35)),
                ],
              ),
            ),
          ]),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 6, children: [
            SayButton(text: e.h, compact: true),
            OutlinedButton.icon(
              onPressed: () => openWriterDialog(context, e.h, e.p, e.gloss),
              icon: const Text('✍'),
              label: const Text('Tulis'),
              style: OutlinedButton.styleFrom(
                  minimumSize: const Size(0, 36),
                  foregroundColor: LiuliColors.jadeDeep),
            ),
            OutlinedButton.icon(
              onPressed: () => _showCollPicker(e.h),
              icon: Icon(store.saved.contains(e.h) ? Icons.star : Icons.star_border,
                  size: 17),
              label: const Text('Simpan'),
              style: OutlinedButton.styleFrom(
                  minimumSize: const Size(0, 36),
                  foregroundColor: LiuliColors.gold),
            ),
          ]),
        ]),
      ),
    );
  }

  Widget _collView() {
    final colls = store.allColls();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      children: [
        for (final c in colls) _collCard(c),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: _newCollDialog,
          icon: const Icon(Icons.add),
          label: const Text('Buat koleksi baru'),
        ),
      ],
    );
  }

  Widget _collCard(Collection c) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${c.words.length} kata'),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final w in c.words)
                Chip(
                  label: Text(store.zh(w), style: hanziStyle(size: 18)),
                  onDeleted: () => store.collToggle(c.id, w),
                ),
              if (c.words.isEmpty)
                Text('Kosong — simpan kata dari tab Cari.',
                    style: TextStyle(color: LiuliColors.text2)),
            ],
          ),
          const SizedBox(height: 10),
          Row(children: [
            FilledButton.icon(
              onPressed: c.words.isEmpty
                  ? null
                  : () {
                      final vocabs = c.words
                          .map((h) => LiuliData.vocab.where((v) => v.h == h).firstOrNull)
                          .whereType<Vocab>()
                          .toList();
                      if (vocabs.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                            content: Text('Kata koleksi ini di luar kosakata inti.')));
                        return;
                      }
                      startLiuliStudy(context, explicit: vocabs, label: c.name);
                    },
              icon: const Icon(Icons.play_arrow),
              label: const Text('Belajar'),
              style: FilledButton.styleFrom(
                  backgroundColor: LiuliColors.jade,
                  minimumSize: const Size(0, 40)),
            ),
            const Spacer(),
            if (c.id != 'fav')
              TextButton.icon(
                onPressed: () => store.collDelete(c.id),
                icon: const Icon(Icons.delete_outline, size: 16),
                label: const Text('Hapus'),
                style: TextButton.styleFrom(foregroundColor: LiuliColors.seal),
              ),
          ]),
        ],
      ),
    );
  }

  void _showCollPicker(String h) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => StatefulBuilder(
        builder: (context, setSheet) {
          final colls = store.allColls();
          final nameCtrl = TextEditingController();
          return Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('Simpan ke koleksi',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(store.zh(h), style: hanziStyle(size: 28)),
              const SizedBox(height: 12),
              for (final c in colls)
                CheckboxListTile(
                  value: store.collHas(c.id, h),
                  activeColor: LiuliColors.jade,
                  title: Text(c.name),
                  subtitle: Text('${c.words.length} kata'),
                  onChanged: (_) {
                    store.collToggle(c.id, h);
                    setSheet(() {});
                  },
                ),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: nameCtrl,
                    decoration: const InputDecoration(hintText: 'Nama koleksi baru…'),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () {
                    if (nameCtrl.text.trim().isEmpty) return;
                    final id = store.collCreate(nameCtrl.text.trim());
                    store.collToggle(id, h);
                    nameCtrl.clear();
                    setSheet(() {});
                  },
                  style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
                  child: const Text('Buat'),
                ),
              ]),
            ]),
          );
        },
      ),
    );
  }

  void _newCollDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Koleksi baru'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Nama koleksi'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          FilledButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) store.collCreate(ctrl.text.trim());
              Navigator.pop(context);
            },
            style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
            child: const Text('Buat'),
          ),
        ],
      ),
    );
  }
}
