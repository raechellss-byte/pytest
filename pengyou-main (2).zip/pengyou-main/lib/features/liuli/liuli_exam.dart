import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_store.dart';

/// ============================================================
/// Simulasi mini ujian TOCFL: 10 soal mendengar + 10 soal membaca,
/// 20 menit, audio boleh diputar 2×. Nilai baru terlihat di akhir.
/// ============================================================

const kExamMinutes = 20;
const kExamPlays = 2;

/// Band → rentang level kosakata yang dipakai.
const examBands = <String, (int, int, String)>{
  'A': (1, 2, 'Band A · Level 1–2 (A1–A2)'),
  'B': (3, 4, 'Band B · Level 3–4 (B1–B2)'),
};

class ExamQ {
  ExamQ({
    required this.section,
    required this.ask,
    required this.options,
    required this.answer,
    required this.explain,
    this.audio,
    this.prompt,
  });
  final String section; // 'listen' | 'read'
  final String ask; // instruksi soal
  final String? audio; // teks yang dibacakan (soal mendengar)
  final String? prompt; // teks Mandarin yang ditampilkan (soal membaca)
  final List<String> options;
  final int answer; // indeks opsi benar
  final String explain; // pembahasan
}

ExamQ _mc({
  required Random rng,
  required String section,
  required String ask,
  required String right,
  required Iterable<String> wrongPool,
  required String explain,
  String? audio,
  String? prompt,
}) {
  final wrong = wrongPool.where((w) => w != right).toSet().toList()..shuffle(rng);
  final opts = [right, ...wrong.take(3)]..shuffle(rng);
  return ExamQ(
    section: section,
    ask: ask,
    audio: audio,
    prompt: prompt,
    options: opts,
    answer: opts.indexOf(right),
    explain: explain,
  );
}

/// Susun 20 soal untuk [band] ('A' atau 'B').
List<ExamQ> buildExam(String band, Random rng) {
  final (lo, hi, _) = examBands[band]!;
  final words = LiuliData.vocab
      .where((v) => v.lv >= lo && v.lv <= hi && v.ex.contains(v.h) && v.exid.isNotEmpty)
      .toList()
    ..shuffle(rng);
  final pick = words.iterator;
  Vocab next() => (pick..moveNext()).current;
  final allMeanings = words.map((v) => v.exid);
  String ex(Vocab v) => '${v.ex}\n${v.exp}\n${v.exid}';

  // Pasangan tanya-jawab dari dialog (A lalu B).
  final pairs = <(TalkLine, TalkLine)>[
    for (final d in LiuliData.dialogs)
      for (var i = 0; i + 1 < d.lines.length; i++)
        if (!d.lines[i].mine && d.lines[i + 1].mine) (d.lines[i], d.lines[i + 1]),
  ]..shuffle(rng);
  final replies = [
    for (final d in LiuliData.dialogs) ...d.lines.where((l) => l.mine).map((l) => l.h)
  ];
  final gram = [
    for (final g in LiuliData.grammar) ...g.q.where((q) => q.k == 'fill')
  ]..shuffle(rng);

  final listen = <ExamQ>[
    for (var k = 0; k < 5; k++)
      () {
        final v = next();
        return _mc(
            rng: rng,
            section: 'listen',
            ask: 'Dengarkan kalimatnya, lalu pilih artinya.',
            audio: v.ex,
            right: v.exid,
            wrongPool: allMeanings,
            explain: ex(v));
      }(),
    for (final (a, b) in pairs.take(5))
      _mc(
          rng: rng,
          section: 'listen',
          ask: 'Dengarkan, lalu pilih jawaban yang paling cocok.',
          audio: a.h,
          right: b.h,
          wrongPool: replies..shuffle(rng),
          explain: '${a.h}  (${a.id})\n→ ${b.h}\n${b.p}\n${b.id}'),
  ];

  final read = <ExamQ>[
    for (var k = 0; k < 4; k++)
      () {
        final v = next();
        return _mc(
            rng: rng,
            section: 'read',
            ask: 'Pilih kata yang tepat untuk bagian kosong.',
            prompt: v.ex.replaceFirst(v.h, '＿＿'),
            right: v.h,
            wrongPool: words.where((w) => w.h.length == v.h.length).map((w) => w.h),
            explain: ex(v));
      }(),
    for (final q in gram.take(3))
      () {
        final opts = [...q.o]..shuffle(rng);
        return ExamQ(
            section: 'read',
            ask: 'Pilih yang tepat untuk bagian kosong.',
            prompt: q.q.replaceFirst('___', '＿＿'),
            options: opts,
            answer: opts.indexOf(q.a),
            explain: '${q.full}\n${q.p}\n${q.id}');
      }(),
    for (var k = 0; k < 3; k++)
      () {
        final v = next();
        return _mc(
            rng: rng,
            section: 'read',
            ask: 'Baca kalimatnya, lalu pilih artinya.',
            prompt: v.ex,
            right: v.exid,
            wrongPool: allMeanings,
            explain: ex(v));
      }(),
  ];
  return [...listen, ...read];
}

// ============================================================
// Pembuka: pilih band.
// ============================================================

class LiuliExamIntro extends StatelessWidget {
  const LiuliExamIntro({super.key});

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('Simulasi ujian TOCFL', style: TextStyle(fontSize: 17))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          LiuliBanner(
            stats: const [('20', 'soal'), ('$kExamMinutes', 'menit')],
            mark: '考',
            color: const Color(0xFF6A45B8),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Format', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                for (final line in const [
                  '🎧 Bagian 1 · Mendengar — 10 soal (audio boleh diputar 2×)',
                  '📖 Bagian 2 · Membaca — 10 soal',
                  '⏱ Waktu $kExamMinutes menit · jawaban baru dinilai di akhir',
                  '🀄 Tanpa pinyin, seperti ujian asli',
                ])
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text(line, style: TextStyle(fontSize: 13, color: LiuliColors.text2)),
                  ),
              ]),
            ),
          ),
          const SectionHead('Pilih tingkat'),
          for (final e in examBands.entries)
            Card(
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => Navigator.of(context).push(liuliRoute(ExamScreen(band: e.key))),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(children: [
                    Container(
                      width: 48,
                      height: 48,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: levelColor(e.value.$1),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text(e.key,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(e.value.$3,
                            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                        Text(
                            store.examBest[e.key] == null
                                ? 'Belum pernah dicoba'
                                : 'Skor terbaik: ${store.examBest[e.key]}%',
                            style: TextStyle(fontSize: 12, color: LiuliColors.text2)),
                      ]),
                    ),
                    const Icon(Icons.chevron_right, color: Colors.grey),
                  ]),
                ),
              ),
            ),
          const SizedBox(height: 10),
          Text(
              'Ini simulasi mini untuk mengukur kesiapan, bukan ujian resmi. Ujian TOCFL '
              'asli jauh lebih panjang (puluhan soal mendengar dan membaca).',
              style: TextStyle(fontSize: 11.5, color: LiuliColors.text3, height: 1.4)),
        ],
      ),
    );
  }
}

// ============================================================
// Ujian.
// ============================================================

class ExamScreen extends StatefulWidget {
  const ExamScreen({super.key, required this.band, this.questions});
  final String band;
  final List<ExamQ>? questions; // untuk tes; null = acak baru
  @override
  State<ExamScreen> createState() => _ExamScreenState();
}

class _ExamScreenState extends State<ExamScreen> {
  final store = LiuliStore.instance;
  late List<ExamQ> qs;
  late List<int?> picks;
  late List<int> plays;
  int i = 0;
  int left = kExamMinutes * 60;
  Timer? _timer;
  bool done = false;

  @override
  void initState() {
    super.initState();
    _start(widget.questions);
  }

  void _start([List<ExamQ>? given]) {
    qs = given ?? buildExam(widget.band, Random());
    picks = List.filled(qs.length, null);
    plays = List.filled(qs.length, 0);
    i = 0;
    left = kExamMinutes * 60;
    done = false;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || done) return;
      setState(() => left--);
      if (left <= 0) _finish(timeUp: true);
    });
    _autoPlay();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _autoPlay() {
    if (qs[i].audio != null && plays[i] == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _play());
    }
  }

  void _play() {
    if (!mounted || plays[i] >= kExamPlays) return;
    setState(() => plays[i]++);
    store.speak(qs[i].audio!);
  }

  void _go(int to) {
    setState(() => i = to);
    _autoPlay();
  }

  Future<void> _confirmFinish() async {
    final empty = picks.where((p) => p == null).length;
    if (empty > 0) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('Selesaikan ujian?'),
          content: Text('Masih ada $empty soal yang belum dijawab.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Kembali')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Selesai')),
          ],
        ),
      );
      if (ok != true) return;
    }
    _finish();
  }

  void _finish({bool timeUp = false}) {
    if (done) return;
    _timer?.cancel();
    for (var k = 0; k < qs.length; k++) {
      store.logAnswer(picks[k] == qs[k].answer);
    }
    store.recordExam(widget.band, _pct);
    setState(() => done = true);
    if (timeUp && mounted) {
      ScaffoldMessenger.maybeOf(context)
          ?.showSnackBar(const SnackBar(content: Text('⏱ Waktu habis — jawabanmu dinilai.')));
    }
  }

  int _right(String section) => [
        for (var k = 0; k < qs.length; k++)
          if (qs[k].section == section && picks[k] == qs[k].answer) 1
      ].length;
  int get _pct => (100 * (_right('listen') + _right('read')) / qs.length).round();

  String get _clock =>
      '${(left ~/ 60).toString().padLeft(2, '0')}:${(left % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Simulasi TOCFL · Band ${widget.band}', style: const TextStyle(fontSize: 16)),
        actions: [
          if (!done)
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Center(
                child: Pill('⏱ $_clock', color: left < 120 ? LiuliColors.seal : LiuliColors.jade),
              ),
            ),
        ],
        bottom: done
            ? null
            : PreferredSize(
                preferredSize: const Size.fromHeight(4),
                child: LinearProgressIndicator(
                  value: picks.where((p) => p != null).length / qs.length,
                  minHeight: 4,
                  backgroundColor: LiuliColors.surface2,
                  color: LiuliColors.jade,
                ),
              ),
      ),
      body: done ? _result() : _question(),
    );
  }

  Widget _question() {
    final q = qs[i];
    final listen = q.section == 'listen';
    final nInSection = qs.where((x) => x.section == q.section).length;
    final idxInSection = qs.take(i + 1).where((x) => x.section == q.section).length;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(
            '${listen ? 'Bagian 1 · Mendengar 聽力' : 'Bagian 2 · Membaca 閱讀'} — soal $idxInSection/$nInSection',
            style: TextStyle(fontWeight: FontWeight.w800, color: LiuliColors.text2)),
        const SizedBox(height: 4),
        Text(q.ask, style: TextStyle(color: LiuliColors.text2)),
        const SizedBox(height: 16),
        if (q.audio != null)
          Center(
            child: FilledButton.icon(
              onPressed: plays[i] < kExamPlays ? _play : null,
              icon: const Icon(Icons.volume_up_rounded),
              label: Text(plays[i] < kExamPlays
                  ? 'Putar audio (sisa ${kExamPlays - plays[i]}×)'
                  : 'Audio sudah diputar $kExamPlays×'),
              style: FilledButton.styleFrom(
                  backgroundColor: LiuliColors.jade, minimumSize: const Size(0, 48)),
            ),
          ),
        if (q.prompt != null)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: LiuliColors.surface2,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(store.zh(q.prompt!),
                textAlign: TextAlign.center, style: hanziStyle(size: 23, weight: FontWeight.w500)),
          ),
        const SizedBox(height: 18),
        for (var k = 0; k < q.options.length; k++) _opt(k),
        const SizedBox(height: 10),
        Row(children: [
          if (i > 0)
            Expanded(
              child: OutlinedButton(
                  onPressed: () => _go(i - 1), child: const Text('← Sebelumnya')),
            ),
          if (i > 0) const SizedBox(width: 10),
          Expanded(
            child: FilledButton(
              onPressed: i + 1 < qs.length ? () => _go(i + 1) : _confirmFinish,
              style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
              child: Text(i + 1 < qs.length ? 'Berikutnya →' : 'Selesai & lihat nilai'),
            ),
          ),
        ]),
      ],
    );
  }

  Widget _opt(int k) {
    final q = qs[i];
    final sel = picks[i] == k;
    final zhText = q.options[k].contains(RegExp(r'[㐀-鿿]'));
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => setState(() => picks[i] = k),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 14),
          decoration: BoxDecoration(
            color: sel ? LiuliColors.jadeTint : LiuliColors.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: sel ? LiuliColors.jade : LiuliColors.text3.withValues(alpha: 0.3),
                width: sel ? 2 : 1.2),
          ),
          child: Row(children: [
            Text('${String.fromCharCode(65 + k)}.',
                style: TextStyle(fontWeight: FontWeight.w800, color: LiuliColors.text3)),
            const SizedBox(width: 10),
            Expanded(
              child: Text(zhText ? store.zh(q.options[k]) : q.options[k],
                  style: zhText
                      ? hanziStyle(size: 18, weight: FontWeight.w500)
                      : const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _result() {
    final pct = _pct;
    final band = examBands[widget.band]!;
    final verdict = pct >= 80
        ? 'Bagus! Kemampuanmu sudah mendekati target ${band.$3.split(' · ').first}. Pertimbangkan mendaftar TOCFL.'
        : pct >= 60
            ? 'Hampir! Pelajari pembahasan soal yang salah, lalu coba lagi.'
            : 'Belum cukup. Perbanyak latihan kosakata Level ${band.$1}–${band.$2} dulu, lalu ulangi.';
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
      children: [
        Center(
          child: Text('$pct%',
              style: TextStyle(
                  fontSize: 52,
                  fontWeight: FontWeight.w900,
                  color: pct >= 80
                      ? LiuliColors.good
                      : (pct >= 60 ? LiuliColors.hard : LiuliColors.again))),
        ),
        Center(
          child: Text('Mendengar ${_right('listen')}/10 · Membaca ${_right('read')}/10',
              style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
        const SizedBox(height: 8),
        Text(verdict, textAlign: TextAlign.center, style: TextStyle(color: LiuliColors.text2)),
        const SizedBox(height: 4),
        Center(
          child: Text('+${20 + pct ~/ 2} XP',
              style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFFCA8A04))),
        ),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(
            child: OutlinedButton(
                onPressed: () => Navigator.pop(context), child: const Text('Selesai')),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: FilledButton(
              onPressed: () => setState(() => _start()),
              style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
              child: const Text('Ujian baru'),
            ),
          ),
        ]),
        const SectionHead('Pembahasan'),
        for (var k = 0; k < qs.length; k++) _review(k),
      ],
    );
  }

  Widget _review(int k) {
    final q = qs[k];
    final ok = picks[k] == q.answer;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Pill(ok ? '✓ Benar' : (picks[k] == null ? '— Kosong' : '✗ Salah'),
                color: ok ? LiuliColors.good : LiuliColors.again),
            const SizedBox(width: 8),
            Text('${q.section == 'listen' ? 'Mendengar' : 'Membaca'} · soal ${k + 1}',
                style: TextStyle(fontSize: 12, color: LiuliColors.text3)),
            const Spacer(),
            if (q.audio != null)
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: Icon(Icons.volume_up_rounded, color: LiuliColors.jade, size: 20),
                onPressed: () => store.speak(q.audio!),
              ),
          ]),
          if (!ok && picks[k] != null)
            Text('Jawabanmu: ${q.options[picks[k]!]}',
                style: const TextStyle(color: LiuliColors.again, fontSize: 13)),
          Text('Jawaban benar: ${q.options[q.answer]}',
              style: const TextStyle(
                  color: LiuliColors.good, fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 4),
          Text(store.zh(q.explain),
              style: TextStyle(fontSize: 12.5, color: LiuliColors.text2, height: 1.4)),
        ]),
      ),
    );
  }
}
