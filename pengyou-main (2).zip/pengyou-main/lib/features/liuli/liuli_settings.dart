import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

import '../../services/push_service.dart';
import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_store.dart';
import 'liuli_sync.dart';

void showLiuliSettings(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    // Latar digambar sendiri oleh sheet supaya langsung berganti saat
    // mode gelap dinyalakan/dimatikan dari sini.
    backgroundColor: Colors.transparent,
    builder: (_) => const _SettingsSheet(),
  );
}

class _SettingsSheet extends StatefulWidget {
  const _SettingsSheet();
  @override
  State<_SettingsSheet> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends State<_SettingsSheet> {
  LiuliStore get store => LiuliStore.instance;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: store,
    builder: (context, _) {
      LiuliColors.isDark = store.dark;
      return Theme(
        data: liuliTheme(liuliBaseTheme(context), dark: store.dark),
        child: _sheet(),
      );
    },
  );

  Widget _sheet() {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.85,
      maxChildSize: 0.95,
      minChildSize: 0.5,
      builder: (_, controller) => Container(
        decoration: BoxDecoration(
          color: LiuliColors.card,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 32),
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                margin: const EdgeInsets.only(bottom: 14),
                decoration: BoxDecoration(
                  color: LiuliColors.text3.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const Text(
              'Pengaturan',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 12),
            _switchRow(
              'Tampilkan Zhuyin (注音)',
              'Fonetik cara Taiwan (ㄅㄆㄇㄈ)',
              store.zhuyin,
              (v) => store.updateSetting(() => store.zhuyin = v),
            ),
            _switchRow(
              'Tampilkan Pinyin',
              'Fonetik latin (nǐ hǎo)',
              store.pinyin,
              (v) => store.updateSetting(() => store.pinyin = v),
            ),
            _switchRow(
              'Suara otomatis',
              'Bunyikan kartu saat dibuka',
              store.auto,
              (v) => store.updateSetting(() => store.auto = v),
            ),
            _switchRow(
              'Mode gelap 🌙',
              'Nyaman untuk belajar malam hari',
              store.dark,
              (v) => store.updateSetting(() => store.dark = v),
            ),
            _seg<String>(
              'Arah belajar',
              'Produksi melatih bicara lebih kuat',
              const {'recog': '中→ID', 'prod': 'ID→中', 'mix': 'Campur'},
              store.dir,
              (v) => store.updateSetting(() => store.dir = v),
            ),
            _seg<int>(
              'Kata baru / hari',
              'Jumlah kartu baru per sesi',
              const {5: '5', 10: '10', 15: '15', 20: '20'},
              store.newPerDay,
              (v) => store.updateSetting(() => store.newPerDay = v),
            ),
            _seg<int>(
              'Target harian',
              'Jumlah ulasan target per hari',
              const {10: '10', 20: '20', 30: '30', 50: '50'},
              store.dailyGoal,
              (v) => store.updateSetting(() => store.dailyGoal = v),
            ),
            _seg<String>(
              'Ukuran huruf',
              'Besar-kecil teks & karakter',
              const {'small': 'Kecil', 'normal': 'Sedang', 'large': 'Besar'},
              store.fs,
              (v) => store.updateSetting(() => store.fs = v),
            ),
            _seg<String>(
              'Tampilan karakter',
              '繁體 (Taiwan) atau 简体',
              const {'trad': '繁體', 'simp': '简体'},
              store.script,
              (v) async {
                store.updateSetting(() => store.script = v);
                if (v == 'simp') await LiuliData.t2s();
                if (mounted) setState(() {});
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Pelindung rentetan ❄️',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                        Text(
                          'Otomatis menyelamatkan streak saat bolos',
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    '❄️ ${store.freezes}',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
            const Divider(),
            _remindSection(),
            const Divider(),
            _syncSection(),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Salin progres manual',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                        Text(
                          'Simpan / pulihkan progres belajar',
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  OutlinedButton(
                    onPressed: _export,
                    child: const Text('Ekspor'),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton(
                    onPressed: _import,
                    child: const Text('Impor'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _reset,
              icon: const Icon(Icons.restart_alt),
              label: const Text('Reset semua progres'),
              style: OutlinedButton.styleFrom(
                foregroundColor: LiuliColors.seal,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Belajar Mandarin · alat belajar mandiri. Audio memakai suara bawaan '
              'perangkat (pilih suara 中文 台灣 bila ada). Goresan: HanziWriter + '
              'Make Me a Hanzi.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 11,
                color: LiuliColors.text3,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Pengingat belajar (push) bila belum belajar hari itu.
  Widget _remindSection() {
    final signedIn = LiuliSync.signedIn;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _switchRow(
          'Pengingat belajar 🔔',
          signedIn
              ? 'Notifikasi kalau hari itu kamu belum belajar'
              : 'Masuk akun dulu supaya pengingat bisa dikirim',
          store.remind && signedIn,
          signedIn ? _toggleRemind : null,
        ),
        if (store.remind && signedIn)
          _seg<int>(
            'Jam pengingat',
            'Waktu setempat di HP-mu',
            const {
              7: '07.00',
              12: '12.00',
              18: '18.00',
              20: '20.00',
              21: '21.00',
            },
            store.remindHour,
            (v) => store.updateSetting(() => store.remindHour = v),
          ),
      ],
    );
  }

  Future<void> _toggleRemind(bool v) async {
    store.updateSetting(() => store.remind = v);
    if (!v) return;
    // Notifikasi butuh izin browser; minta sekarang bila belum diberikan.
    if (await PushService.needsEnable()) {
      final ok = await PushService.enable();
      if (!ok && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Izin notifikasi belum diberikan — aktifkan di pengaturan browser.',
            ),
          ),
        );
      }
    }
  }

  /// Status penyimpanan progres ke akun.
  Widget _syncSection() => ValueListenableBuilder(
    valueListenable: LiuliSync.state,
    builder: (context, st, _) {
      final (icon, color, title, sub) = switch (st) {
        LiuliSyncState.off => (
          Icons.cloud_off_rounded,
          LiuliColors.text3,
          'Belum masuk — progres tidak disimpan',
          'Masuk dengan email supaya progres, rentetan & lencana tersimpan di akun',
        ),
        LiuliSyncState.syncing => (
          Icons.cloud_sync_rounded,
          LiuliColors.jade,
          'Menyimpan ke akun…',
          'Sebentar',
        ),
        LiuliSyncState.ok => (
          Icons.cloud_done_rounded,
          LiuliColors.jade,
          'Tersimpan di akun ✓',
          'Terakhir: ${_hhmm(LiuliSync.lastOk)} · otomatis tiap ada perubahan',
        ),
        LiuliSyncState.error => (
          Icons.cloud_off_rounded,
          LiuliColors.seal,
          'Belum bisa menyimpan ke akun',
          'Progres aman di perangkat ini. Coba lagi nanti.',
        ),
      };
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            Icon(icon, color: color, size: 26),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  Text(
                    sub,
                    style: TextStyle(fontSize: 12, color: LiuliColors.text2),
                  ),
                ],
              ),
            ),
            if (st == LiuliSyncState.error ||
                (st == LiuliSyncState.ok && LiuliSync.signedIn))
              TextButton(
                onPressed: LiuliSync.start,
                child: const Text('Sinkron'),
              ),
            if (st == LiuliSyncState.off && !LiuliSync.signedIn)
              FilledButton(
                onPressed: () {
                  Navigator.pop(context);
                  context.go('/login?next=%2Fbelajar');
                },
                style: FilledButton.styleFrom(
                  backgroundColor: LiuliColors.jade,
                  minimumSize: const Size(0, 38),
                ),
                child: const Text('Masuk'),
              ),
          ],
        ),
      );
    },
  );

  String _hhmm(DateTime? t) => t == null
      ? '-'
      : '${t.hour.toString().padLeft(2, '0')}.${t.minute.toString().padLeft(2, '0')}';

  Widget _switchRow(
    String t,
    String s,
    bool v,
    ValueChanged<bool>? onCh,
  ) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(t, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(s, style: const TextStyle(fontSize: 12, color: Colors.grey)),
            ],
          ),
        ),
        Switch(value: v, activeThumbColor: LiuliColors.jade, onChanged: onCh),
      ],
    ),
  );

  Widget _seg<T>(
    String t,
    String s,
    Map<T, String> opts,
    T value,
    ValueChanged<T> onCh,
  ) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(t, style: const TextStyle(fontWeight: FontWeight.w700)),
        Text(s, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            for (final e in opts.entries)
              ChoiceChip(
                label: Text(e.value),
                selected: value == e.key,
                selectedColor: LiuliColors.jade,
                labelStyle: TextStyle(
                  color: value == e.key ? Colors.white : null,
                  fontWeight: FontWeight.w700,
                ),
                onSelected: (_) => onCh(e.key),
              ),
          ],
        ),
      ],
    ),
  );

  void _reset() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Reset progres?'),
        content: const Text(
          'Yakin reset semua progres belajar? Tindakan ini tidak bisa dibatalkan.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: LiuliColors.seal),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
    if (ok == true) {
      store.resetProgress();
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Progres direset.')));
      }
    }
  }

  void _export() {
    final data = store.exportData();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Ekspor progres'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Salin teks ini & simpan. Di perangkat lain, buka Impor lalu tempel.',
                style: TextStyle(fontSize: 13),
              ),
              const SizedBox(height: 10),
              Container(
                constraints: const BoxConstraints(maxHeight: 160),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: LiuliColors.surface2,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: SingleChildScrollView(
                  child: SelectableText(
                    data,
                    style: const TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 11,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
          FilledButton.icon(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: data));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Tersalin ke clipboard ✓')),
              );
            },
            icon: const Icon(Icons.copy),
            label: const Text('Salin'),
            style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
          ),
        ],
      ),
    );
  }

  void _import() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Impor progres'),
        content: TextField(
          controller: ctrl,
          maxLines: 6,
          decoration: const InputDecoration(
            hintText: 'Tempel data progres di sini…',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () {
              final ok = store.importData(ctrl.text);
              Navigator.pop(context);
              if (mounted) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      ok
                          ? 'Progres berhasil diimpor ✓'
                          : 'Data tidak dikenali / format salah.',
                    ),
                  ),
                );
              }
            },
            style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
            child: const Text('Impor'),
          ),
        ],
      ),
    );
  }
}
