import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../theme.dart';
import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_dict.dart';
import 'liuli_guide.dart';
import 'liuli_home.dart';
import 'liuli_quiz.dart';
import 'liuli_sentences.dart';
import 'liuli_settings.dart';
import 'liuli_store.dart';
import 'liuli_study.dart';
import 'liuli_write.dart';

/// Keluar dari Belajar Mandarin kembali ke Beranda PENGYOU.
void liuliExit(BuildContext context) {
  final nav = Navigator.of(context);
  if (nav.canPop()) {
    nav.pop();
  } else {
    GoRouter.maybeOf(context)?.go('/beranda');
  }
}

/// Entry point Liúlì (流利) — 6 tab: Beranda · Belajar · Kalimat · Tulis · Kuis · Panduan.
/// Mendukung tampilan Mobile (Bottom Nav) & Desktop (Sidebar ala Duolingo/Brilliant).
class LiuliApp extends StatefulWidget {
  const LiuliApp({super.key});
  @override
  State<LiuliApp> createState() => _LiuliAppState();
}

class _LiuliAppState extends State<LiuliApp> {
  int _tab = 0;
  late Future<void> _boot;
  StreamSubscription<String>? _toasts;

  static const _navItems = <(IconData, IconData, String)>[
    (Icons.home_outlined, Icons.home_rounded, 'Beranda'),
    (Icons.style_outlined, Icons.style_rounded, 'Belajar'),
    (Icons.chat_bubble_outline_rounded, Icons.chat_bubble_rounded, 'Kalimat'),
    (Icons.brush_outlined, Icons.brush_rounded, 'Tulis'),
    (Icons.quiz_outlined, Icons.quiz_rounded, 'Kuis'),
    (Icons.menu_book_outlined, Icons.menu_book_rounded, 'Panduan'),
  ];

  @override
  void initState() {
    super.initState();
    _boot = _init();
    // Misi selesai / naik level / lencana baru → toast singkat.
    _toasts = LiuliStore.instance.events.listen((msg) {
      if (!mounted) return;
      ScaffoldMessenger.maybeOf(context)
        ?..hideCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: Text(msg),
            duration: const Duration(milliseconds: 2600),
          ),
        );
    });
  }

  @override
  void dispose() {
    _toasts?.cancel();
    super.dispose();
  }

  Future<void> _init() async {
    await Future.wait([LiuliData.load(), loadHanziFont()]);
    await LiuliStore.instance.ensureLoaded();
    // Muat T2S di latar bila mode simplified aktif.
    if (LiuliStore.instance.script == 'simp') {
      await LiuliData.t2s();
    }
  }

  void _goTab(int i) => setState(() => _tab = i);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _boot,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(color: LiuliColors.jade),
            ),
          );
        }
        if (snap.hasError) {
          return Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_rounded),
                onPressed: () => liuliExit(context),
              ),
              title: const Text('Belajar Mandarin'),
            ),
            body: Center(child: Text('Gagal memuat data.\n${snap.error}')),
          );
        }
        final store = LiuliStore.instance;
        return LiuliThemed(
          child: ListenableBuilder(
            listenable: store,
            builder: (context, _) {
              final tabs = [
                LiuliHome(onGoTab: _goTab),
                LiuliStudyEntry(onGoTab: _goTab),
                const LiuliSentences(),
                const LiuliWrite(),
                LiuliQuizHome(onGoTab: _goTab),
                const LiuliGuide(),
              ];

              final isDesktop = AppBreakpoints.isDesktop(context);

              if (isDesktop) {
                return Scaffold(
                  body: Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _buildDesktopSidebar(context, store),
                      Expanded(
                        child: Column(
                          children: [
                            _buildDesktopTopBar(context, store),
                            Expanded(
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: ConstrainedBox(
                                  constraints:
                                      const BoxConstraints(maxWidth: 960),
                                  child: tabs[_tab],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }

              // Tampilan Mobile (< 840px)
              return Scaffold(
                appBar: AppBar(
                  leading: IconButton(
                    tooltip: 'Kembali ke PENGYOU',
                    icon: const Icon(Icons.arrow_back_rounded),
                    onPressed: () => liuliExit(context),
                  ),
                  titleSpacing: 4,
                  title: Row(
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [LiuliColors.jade, LiuliColors.jadeShade],
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.translate_rounded,
                          color: Colors.white,
                          size: 19,
                        ),
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Belajar Mandarin',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                color: LiuliColors.ink,
                              ),
                            ),
                            Text(
                              'Liúlì 流利 · Mandarin Taiwan',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w700,
                                color: LiuliColors.text3,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  actions: [
                    _streakChip(store),
                    IconButton(
                      tooltip: 'Kamus',
                      icon: const Icon(Icons.search_rounded),
                      onPressed: () => Navigator.of(context)
                          .push(liuliRoute(const LiuliDict())),
                    ),
                    IconButton(
                      tooltip: 'Pengaturan',
                      icon: const Icon(Icons.settings_outlined),
                      onPressed: () => showLiuliSettings(context),
                    ),
                    const SizedBox(width: 4),
                  ],
                ),
                body: SafeArea(top: false, bottom: false, child: tabs[_tab]),
                bottomNavigationBar: Container(
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(
                        color: LiuliColors.isDark
                            ? Colors.white12
                            : AppColors.line,
                        width: 2,
                      ),
                    ),
                  ),
                  child: NavigationBar(
                    selectedIndex: _tab,
                    onDestinationSelected: _goTab,
                    destinations: [
                      for (final item in _navItems)
                        NavigationDestination(
                          icon: Icon(item.$1),
                          selectedIcon: Icon(item.$2),
                          label: item.$3,
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildDesktopSidebar(BuildContext context, LiuliStore store) {
    final dark = LiuliColors.isDark;
    final borderCol = dark ? Colors.white12 : AppColors.line;
    return Container(
      width: 260,
      decoration: BoxDecoration(
        color: LiuliColors.card,
        border: Border(right: BorderSide(color: borderCol, width: 2)),
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 20, 18, 16),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [LiuliColors.jade, LiuliColors.jadeShade],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: const [
                        BoxShadow(
                          color: LiuliColors.jadeShade,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: const Text(
                      '學',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 21,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Liúlì 流利',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: LiuliColors.ink,
                          ),
                        ),
                        Text(
                          'Mandarin Taiwan · PENGYOU',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: LiuliColors.text3,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Divider(height: 1, color: borderCol),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(14),
                children: [
                  for (var i = 0; i < _navItems.length; i++)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Material(
                        color: _tab == i
                            ? LiuliColors.jadeTint
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(16),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => _goTab(i),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 12,
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: _tab == i
                                    ? LiuliColors.jade.withValues(alpha: 0.45)
                                    : Colors.transparent,
                                width: 2,
                              ),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  _tab == i
                                      ? _navItems[i].$2
                                      : _navItems[i].$1,
                                  color: _tab == i
                                      ? LiuliColors.jadeDeep
                                      : LiuliColors.text2,
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  _navItems[i].$3,
                                  style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: _tab == i
                                        ? FontWeight.w900
                                        : FontWeight.w700,
                                    color: _tab == i
                                        ? LiuliColors.jadeDeep
                                        : LiuliColors.ink,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  const SizedBox(height: 12),
                  Divider(color: borderCol),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context)
                        .push(liuliRoute(const LiuliDict())),
                    icon: const Icon(Icons.search_rounded, size: 19),
                    label: const Text('Buka Kamus Lengkap'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () => showLiuliSettings(context),
                    icon: const Icon(Icons.settings_outlined, size: 19),
                    label: const Text('Pengaturan Belajar'),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: DuoButton(
                label: '← Beranda PENGYOU',
                backgroundColor: LiuliColors.card,
                foregroundColor: LiuliColors.jadeDeep,
                borderColor: borderCol,
                lipColor: borderCol,
                compact: true,
                expanded: true,
                onPressed: () => liuliExit(context),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDesktopTopBar(BuildContext context, LiuliStore store) {
    final borderCol = LiuliColors.isDark ? Colors.white12 : AppColors.line;
    return Container(
      height: 64,
      padding: const EdgeInsets.symmetric(horizontal: 28),
      decoration: BoxDecoration(
        color: LiuliColors.card,
        border: Border(bottom: BorderSide(color: borderCol, width: 2)),
      ),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 960),
          child: Row(
            children: [
              Text(
                _navItems[_tab].$3,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: LiuliColors.ink,
                ),
              ),
              const Spacer(),
              _streakChip(store),
              const SizedBox(width: 8),
              IconButton(
                tooltip: 'Kamus',
                icon: const Icon(Icons.search_rounded),
                onPressed: () =>
                    Navigator.of(context).push(liuliRoute(const LiuliDict())),
              ),
              IconButton(
                tooltip: 'Pengaturan',
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => showLiuliSettings(context),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _streakChip(LiuliStore store) {
    final hot = store.streak >= 2;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: hot
              ? LiuliColors.seal.withValues(alpha: 0.12)
              : Colors.grey.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.local_fire_department_rounded,
              size: 17,
              color: hot ? LiuliColors.seal : Colors.grey,
            ),
            const SizedBox(width: 4),
            Text(
              '${store.streak}',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                color: hot ? LiuliColors.seal : LiuliColors.text2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
