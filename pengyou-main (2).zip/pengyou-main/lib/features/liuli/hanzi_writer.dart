import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'liuli_common.dart';

/// Data goresan satu karakter (format Make Me a Hanzi / HanziWriter).
class HanziChar {
  HanziChar(this.strokes, this.medians);
  final List<String> strokes; // SVG path (ruang 1024, y ke atas)
  final List<List<Offset>> medians; // titik median (ruang 1024, y ke atas)

  static HanziChar? from(Map<String, dynamic>? j) {
    if (j == null) return null;
    final strokes = (j['strokes'] as List?)?.map((e) => '$e').toList() ?? [];
    final medians = (j['medians'] as List?)
            ?.map((m) => (m as List)
                .map((p) => Offset(
                    (p[0] as num).toDouble(), (p[1] as num).toDouble()))
                .toList())
            .toList() ??
        [];
    return HanziChar(strokes, medians);
  }
}

/// Transform ruang-1024 (y ke atas) → ruang kanvas (y ke bawah).
class HzTransform {
  HzTransform(this.size, {double? padding})
      : padding = padding ?? size * 0.045,
        scale = (size - 2 * (padding ?? size * 0.045)) / 1024.0;
  final double size;
  final double padding;
  final double scale;

  Offset pt(Offset p) =>
      Offset(padding + p.dx * scale, (size - padding) - p.dy * scale);

  Matrix4 get matrix => Matrix4.identity()
    ..translate(padding, size - padding)
    ..scale(scale, -scale);
}

/// ===== Parser SVG path → ui.Path =====
class _PathParser {
  _PathParser(this.d);
  final String d;
  int _i = 0;
  final _tok = RegExp(r'[a-zA-Z]|-?\d*\.?\d+(?:e-?\d+)?');

  List<String> _tokens() =>
      _tok.allMatches(d).map((m) => m.group(0)!).toList();

  ui.Path parse() {
    final t = _tokens();
    final path = ui.Path();
    double cx = 0, cy = 0, sx = 0, sy = 0;
    double lastC1x = 0, lastC1y = 0;
    String cmd = '';
    _i = 0;
    double num() => double.parse(t[_i++]);
    bool isCmd(String s) => RegExp(r'^[a-zA-Z]$').hasMatch(s);
    while (_i < t.length) {
      if (isCmd(t[_i])) {
        cmd = t[_i++];
      }
      final rel = cmd == cmd.toLowerCase();
      switch (cmd.toUpperCase()) {
        case 'M':
          var x = num(), y = num();
          if (rel) {
            x += cx;
            y += cy;
          }
          path.moveTo(x, y);
          cx = x;
          cy = y;
          sx = x;
          sy = y;
          cmd = rel ? 'l' : 'L';
          break;
        case 'L':
          var x = num(), y = num();
          if (rel) {
            x += cx;
            y += cy;
          }
          path.lineTo(x, y);
          cx = x;
          cy = y;
          break;
        case 'H':
          var x = num();
          if (rel) x += cx;
          path.lineTo(x, cy);
          cx = x;
          break;
        case 'V':
          var y = num();
          if (rel) y += cy;
          path.lineTo(cx, y);
          cy = y;
          break;
        case 'C':
          var x1 = num(), y1 = num(), x2 = num(), y2 = num(), x = num(), y = num();
          if (rel) {
            x1 += cx; y1 += cy; x2 += cx; y2 += cy; x += cx; y += cy;
          }
          path.cubicTo(x1, y1, x2, y2, x, y);
          lastC1x = x2; lastC1y = y2;
          cx = x; cy = y;
          break;
        case 'S':
          var x2 = num(), y2 = num(), x = num(), y = num();
          if (rel) { x2 += cx; y2 += cy; x += cx; y += cy; }
          final x1 = 2 * cx - lastC1x, y1 = 2 * cy - lastC1y;
          path.cubicTo(x1, y1, x2, y2, x, y);
          lastC1x = x2; lastC1y = y2;
          cx = x; cy = y;
          break;
        case 'Q':
          var x1 = num(), y1 = num(), x = num(), y = num();
          if (rel) { x1 += cx; y1 += cy; x += cx; y += cy; }
          path.quadraticBezierTo(x1, y1, x, y);
          lastC1x = x1; lastC1y = y1;
          cx = x; cy = y;
          break;
        case 'T':
          var x = num(), y = num();
          if (rel) { x += cx; y += cy; }
          final x1 = 2 * cx - lastC1x, y1 = 2 * cy - lastC1y;
          path.quadraticBezierTo(x1, y1, x, y);
          lastC1x = x1; lastC1y = y1;
          cx = x; cy = y;
          break;
        case 'Z':
          path.close();
          cx = sx; cy = sy;
          break;
        default:
          _i++; // lewati token tak dikenal
      }
    }
    return path;
  }
}

List<ui.Path> strokePaths(HanziChar c, HzTransform t) {
  return c.strokes.map((d) {
    final p = _PathParser(d).parse();
    return p.transform(t.matrix.storage);
  }).toList();
}

List<List<Offset>> medianPoints(HanziChar c, HzTransform t) =>
    c.medians.map((m) => m.map(t.pt).toList()).toList();

/// ===== Widget animasi urutan goresan =====
class AnimatedHanzi extends StatefulWidget {
  const AnimatedHanzi({
    super.key,
    required this.data,
    required this.size,
    this.showOutline = true,
    this.autoStart = true,
    this.loop = false,
    this.speed = 1.0,
  });
  final HanziChar data;
  final double size;
  final bool showOutline;
  final bool autoStart;
  final bool loop;
  final double speed;

  @override
  State<AnimatedHanzi> createState() => AnimatedHanziState();
}

class AnimatedHanziState extends State<AnimatedHanzi>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late List<ui.Path> _paths;
  late List<List<Offset>> _medians;
  late HzTransform _t;
  int _n = 0;

  @override
  void initState() {
    super.initState();
    _prepare();
    _c = AnimationController(vsync: this)..addListener(() => setState(() {}));
    if (widget.autoStart) WidgetsBinding.instance.addPostFrameCallback((_) => play());
  }

  void _prepare() {
    _t = HzTransform(widget.size);
    _paths = strokePaths(widget.data, _t);
    _medians = medianPoints(widget.data, _t);
    _n = _paths.length;
  }

  @override
  void didUpdateWidget(covariant AnimatedHanzi oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.data != widget.data || oldWidget.size != widget.size) {
      _prepare();
      play();
    }
  }

  Future<void> play() async {
    if (_n == 0) return;
    for (var i = 0; i < _n; i++) {
      _current = i;
      final dur = Duration(
          milliseconds:
              (max(300, _medians[i].length * 90) / widget.speed).round());
      _c.duration = dur;
      try {
        await _c.forward(from: 0);
      } catch (_) {
        return;
      }
      if (!mounted) return;
      await Future.delayed(const Duration(milliseconds: 220));
      if (!mounted) return;
    }
    _current = _n; // semua tampil
    if (mounted) setState(() {});
    if (widget.loop && mounted) {
      await Future.delayed(const Duration(milliseconds: 600));
      if (mounted) play();
    }
  }

  int _current = -1;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(widget.size, widget.size),
      painter: _HanziPainter(
        paths: _paths,
        medians: _medians,
        transform: _t,
        current: _current,
        progress: _c.value,
        showOutline: widget.showOutline,
      ),
    );
  }
}

class _HanziPainter extends CustomPainter {
  _HanziPainter({
    required this.paths,
    required this.medians,
    required this.transform,
    required this.current,
    required this.progress,
    required this.showOutline,
  });
  final List<ui.Path> paths;
  final List<List<Offset>> medians;
  final HzTransform transform;
  final int current;
  final double progress;
  final bool showOutline;

  @override
  void paint(Canvas canvas, Size size) {
    final outline = Paint()
      ..color = Colors.grey.withValues(alpha: 0.16)
      ..style = PaintingStyle.fill;
    final ink = Paint()
      ..color = LiuliColors.jade
      ..style = PaintingStyle.fill;

    if (showOutline) {
      for (final p in paths) {
        canvas.drawPath(p, outline);
      }
    }
    for (var i = 0; i < paths.length; i++) {
      if (i < current) {
        canvas.drawPath(paths[i], ink);
      } else if (i == current) {
        // Reveal "ditulis" sepanjang median.
        canvas.save();
        canvas.clipPath(_revealClip(i));
        canvas.drawPath(paths[i], ink);
        canvas.restore();
      }
    }
  }

  ui.Path _revealClip(int i) {
    final med = medians[i];
    final clip = ui.Path();
    if (med.isEmpty) return clip..addRect(Rect.largest);
    // Panjang kumulatif.
    final segLen = <double>[0];
    var total = 0.0;
    for (var k = 1; k < med.length; k++) {
      total += (med[k] - med[k - 1]).distance;
      segLen.add(total);
    }
    final target = total * progress.clamp(0, 1);
    final r = transform.scale * 128; // radius kuas ~ 128 unit 1024
    for (var k = 0; k < med.length; k++) {
      if (segLen[k] <= target || k == 0) {
        clip.addOval(Rect.fromCircle(center: med[k], radius: r));
      } else {
        // titik interpolasi terakhir
        final prev = med[k - 1];
        final frac = (target - segLen[k - 1]) /
            max(1e-6, segLen[k] - segLen[k - 1]);
        final p = Offset.lerp(prev, med[k], frac.clamp(0, 1))!;
        clip.addOval(Rect.fromCircle(center: p, radius: r));
        break;
      }
    }
    return clip;
  }

  @override
  bool shouldRepaint(covariant _HanziPainter old) =>
      old.current != current ||
      old.progress != progress ||
      old.showOutline != showOutline ||
      old.paths != paths;
}

/// ===== Widget latihan menulis (trace) =====
class HanziQuiz extends StatefulWidget {
  const HanziQuiz({
    super.key,
    required this.data,
    required this.size,
    this.onComplete,
  });
  final HanziChar data;
  final double size;
  final void Function(int mistakes)? onComplete;

  @override
  State<HanziQuiz> createState() => HanziQuizState();
}

class HanziQuizState extends State<HanziQuiz> {
  late List<ui.Path> _paths;
  late List<List<Offset>> _medians;
  late HzTransform _t;
  int _stroke = 0;
  int _mistakes = 0;
  int _mistakesOnStroke = 0;
  bool _showHint = false;
  final List<Offset> _current = [];
  String _status = 'Tulis goresan sesuai urutan ✍';
  Color _statusColor = LiuliColors.inkSoft;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  void _prepare() {
    _t = HzTransform(widget.size);
    _paths = strokePaths(widget.data, _t);
    _medians = medianPoints(widget.data, _t);
  }

  @override
  void didUpdateWidget(covariant HanziQuiz oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.data != widget.data || oldWidget.size != widget.size) {
      setState(() {
        _prepare();
        _stroke = 0;
        _mistakes = 0;
        _mistakesOnStroke = 0;
        _current.clear();
        _status = 'Tulis goresan sesuai urutan ✍';
        _statusColor = LiuliColors.inkSoft;
      });
    }
  }

  void restart() => setState(() {
        _stroke = 0;
        _mistakes = 0;
        _mistakesOnStroke = 0;
        _showHint = false;
        _current.clear();
        _status = 'Tulis goresan sesuai urutan ✍';
        _statusColor = LiuliColors.inkSoft;
      });

  void hint() => setState(() => _showHint = true);

  void _onEnd() {
    if (_stroke >= _medians.length) return;
    final ok = _matches(_current, _medians[_stroke]);
    if (ok) {
      _stroke++;
      _mistakesOnStroke = 0;
      _showHint = false;
      if (_stroke >= _medians.length) {
        _status = _mistakes == 0
            ? '完美！Sempurna, tanpa salah 🎉'
            : '完成！Selesai — total salah: $_mistakes';
        _statusColor = LiuliColors.good;
        widget.onComplete?.call(_mistakes);
      } else {
        _status = 'Bagus! Sisa ${_medians.length - _stroke} goresan';
        _statusColor = LiuliColors.good;
      }
    } else {
      _mistakes++;
      _mistakesOnStroke++;
      _status =
          'Bukan goresan ini — coba lagi ($_mistakesOnStroke×). Tekan 💡 untuk petunjuk.';
      _statusColor = LiuliColors.again;
      if (_mistakesOnStroke >= 3) _showHint = true;
    }
    _current.clear();
    setState(() {});
  }

  /// Cocokkan goresan pengguna dengan median target (heuristik).
  bool _matches(List<Offset> user, List<Offset> median) {
    if (user.length < 2 || median.length < 2) return false;
    final u = _resample(user, 16);
    final m = _resample(median, 16);
    final tol = widget.size; // ~ ukuran kotak
    final startD = (u.first - m.first).distance;
    final endD = (u.last - m.last).distance;
    if (startD > tol * 0.33 || endD > tol * 0.33) return false;
    var sum = 0.0;
    for (var k = 0; k < u.length; k++) {
      sum += (u[k] - m[k]).distance;
    }
    final avg = sum / u.length;
    return avg < tol * 0.30;
  }

  List<Offset> _resample(List<Offset> pts, int n) {
    if (pts.length <= 1) return List.filled(n, pts.isEmpty ? Offset.zero : pts.first);
    final lens = <double>[0];
    var total = 0.0;
    for (var i = 1; i < pts.length; i++) {
      total += (pts[i] - pts[i - 1]).distance;
      lens.add(total);
    }
    if (total == 0) return List.filled(n, pts.first);
    final out = <Offset>[];
    for (var i = 0; i < n; i++) {
      final d = total * i / (n - 1);
      var k = 1;
      while (k < lens.length && lens[k] < d) {
        k++;
      }
      if (k >= pts.length) {
        out.add(pts.last);
      } else {
        final frac = (d - lens[k - 1]) / max(1e-6, lens[k] - lens[k - 1]);
        out.add(Offset.lerp(pts[k - 1], pts[k], frac.clamp(0, 1))!);
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      GestureDetector(
        onPanStart: (d) {
          _current
            ..clear()
            ..add(d.localPosition);
          setState(() {});
        },
        onPanUpdate: (d) => setState(() => _current.add(d.localPosition)),
        onPanEnd: (_) => _onEnd(),
        child: CustomPaint(
          size: Size(widget.size, widget.size),
          painter: _QuizPainter(
            paths: _paths,
            medians: _medians,
            stroke: _stroke,
            userStroke: _current,
            hintStroke: _showHint && _stroke < _paths.length ? _stroke : -1,
          ),
        ),
      ),
      const SizedBox(height: 10),
      Text(_status,
          textAlign: TextAlign.center,
          style: TextStyle(fontWeight: FontWeight.w700, color: _statusColor)),
    ]);
  }
}

class _QuizPainter extends CustomPainter {
  _QuizPainter({
    required this.paths,
    required this.medians,
    required this.stroke,
    required this.userStroke,
    required this.hintStroke,
  });
  final List<ui.Path> paths;
  final List<List<Offset>> medians;
  final int stroke;
  final List<Offset> userStroke;
  final int hintStroke;

  @override
  void paint(Canvas canvas, Size size) {
    final outline = Paint()
      ..color = Colors.grey.withValues(alpha: 0.14)
      ..style = PaintingStyle.fill;
    final done = Paint()
      ..color = LiuliColors.jade
      ..style = PaintingStyle.fill;
    // Kotak bantu
    for (var i = 0; i < paths.length; i++) {
      canvas.drawPath(paths[i], i < stroke ? done : outline);
    }
    // Petunjuk median goresan aktif.
    if (hintStroke >= 0 && hintStroke < medians.length) {
      final hint = Paint()
        ..color = LiuliColors.seal.withValues(alpha: 0.7)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..strokeCap = StrokeCap.round;
      final med = medians[hintStroke];
      final p = ui.Path()..moveTo(med.first.dx, med.first.dy);
      for (final pt in med.skip(1)) {
        p.lineTo(pt.dx, pt.dy);
      }
      canvas.drawPath(p, hint);
      canvas.drawCircle(med.first, 6, Paint()..color = LiuliColors.seal);
    }
    // Coretan pengguna.
    if (userStroke.length > 1) {
      final up = Paint()
        ..color = LiuliColors.inkOnPaper
        ..style = PaintingStyle.stroke
        ..strokeWidth = 10
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;
      final p = ui.Path()..moveTo(userStroke.first.dx, userStroke.first.dy);
      for (final pt in userStroke.skip(1)) {
        p.lineTo(pt.dx, pt.dy);
      }
      canvas.drawPath(p, up);
    }
  }

  @override
  bool shouldRepaint(covariant _QuizPainter old) => true;
}
