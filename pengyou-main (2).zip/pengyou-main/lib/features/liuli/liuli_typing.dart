import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_store.dart';

/// ============================================================
/// Latihan Ketik Zhuyin (注音打字) — layout keyboard 大千 (Dachen),
/// standar keyboard Taiwan.
///
/// App memetakan tombol FISIK (posisi QWERTY) → simbol zhuyin sendiri,
/// jadi tidak perlu memasang IME Zhuyin. Posisinya sama dengan label
/// zhuyin yang tercetak di keyboard Taiwan.
///
/// Urutan ketik satu suku kata (sama seperti IME Microsoft Bopomofo):
///   huruf zhuyin dulu, lalu tombol nada →
///   Spasi = nada 1 · 6 = ˊ · 3 = ˇ · 4 = ˋ · 7 = ˙ (ringan)
/// Catatan: di notasi, ˙ ditulis di depan (˙ㄒㄧㄝ), tapi diketik TERAKHIR.
///
/// Tiga mode:
///  • Ketik kata  — hanzi tampil, ketik zhuyin + nadanya (字/menit).
///  • Dikte       — dengar kata (TTS), ketik zhuyin-nya; hanzi baru muncul
///                  setelah suku katanya benar.
///  • Kenal tombol — tekan tombol untuk satu simbol (hafalkan layout).
/// ============================================================

/// Nada 1 tidak bertanda di zhuyin; diketik dengan Spasi. Diwakili makron.
const kTone1 = 'ˉ';

class DKey {
  const DKey(this.label, this.sym, this.key);
  final String label; // huruf/angka yang tercetak di keyboard
  final String sym; // simbol zhuyin / tanda nada
  final PhysicalKeyboardKey key;
}

const dachenRows = <List<DKey>>[
  [
    DKey('1', 'ㄅ', PhysicalKeyboardKey.digit1),
    DKey('2', 'ㄉ', PhysicalKeyboardKey.digit2),
    DKey('3', 'ˇ', PhysicalKeyboardKey.digit3),
    DKey('4', 'ˋ', PhysicalKeyboardKey.digit4),
    DKey('5', 'ㄓ', PhysicalKeyboardKey.digit5),
    DKey('6', 'ˊ', PhysicalKeyboardKey.digit6),
    DKey('7', '˙', PhysicalKeyboardKey.digit7),
    DKey('8', 'ㄚ', PhysicalKeyboardKey.digit8),
    DKey('9', 'ㄞ', PhysicalKeyboardKey.digit9),
    DKey('0', 'ㄢ', PhysicalKeyboardKey.digit0),
    DKey('-', 'ㄦ', PhysicalKeyboardKey.minus),
  ],
  [
    DKey('Q', 'ㄆ', PhysicalKeyboardKey.keyQ),
    DKey('W', 'ㄊ', PhysicalKeyboardKey.keyW),
    DKey('E', 'ㄍ', PhysicalKeyboardKey.keyE),
    DKey('R', 'ㄐ', PhysicalKeyboardKey.keyR),
    DKey('T', 'ㄔ', PhysicalKeyboardKey.keyT),
    DKey('Y', 'ㄗ', PhysicalKeyboardKey.keyY),
    DKey('U', 'ㄧ', PhysicalKeyboardKey.keyU),
    DKey('I', 'ㄛ', PhysicalKeyboardKey.keyI),
    DKey('O', 'ㄟ', PhysicalKeyboardKey.keyO),
    DKey('P', 'ㄣ', PhysicalKeyboardKey.keyP),
  ],
  [
    DKey('A', 'ㄇ', PhysicalKeyboardKey.keyA),
    DKey('S', 'ㄋ', PhysicalKeyboardKey.keyS),
    DKey('D', 'ㄎ', PhysicalKeyboardKey.keyD),
    DKey('F', 'ㄑ', PhysicalKeyboardKey.keyF),
    DKey('G', 'ㄕ', PhysicalKeyboardKey.keyG),
    DKey('H', 'ㄘ', PhysicalKeyboardKey.keyH),
    DKey('J', 'ㄨ', PhysicalKeyboardKey.keyJ),
    DKey('K', 'ㄜ', PhysicalKeyboardKey.keyK),
    DKey('L', 'ㄠ', PhysicalKeyboardKey.keyL),
    DKey(';', 'ㄤ', PhysicalKeyboardKey.semicolon),
  ],
  [
    DKey('Z', 'ㄈ', PhysicalKeyboardKey.keyZ),
    DKey('X', 'ㄌ', PhysicalKeyboardKey.keyX),
    DKey('C', 'ㄏ', PhysicalKeyboardKey.keyC),
    DKey('V', 'ㄒ', PhysicalKeyboardKey.keyV),
    DKey('B', 'ㄖ', PhysicalKeyboardKey.keyB),
    DKey('N', 'ㄙ', PhysicalKeyboardKey.keyN),
    DKey('M', 'ㄩ', PhysicalKeyboardKey.keyM),
    DKey(',', 'ㄝ', PhysicalKeyboardKey.comma),
    DKey('.', 'ㄡ', PhysicalKeyboardKey.period),
    DKey('/', 'ㄥ', PhysicalKeyboardKey.slash),
  ],
];
const dachenSpace = DKey('Spasi', kTone1, PhysicalKeyboardKey.space);

final Map<PhysicalKeyboardKey, String> _keyToSym = {
  for (final r in dachenRows)
    for (final k in r) k.key: k.sym,
  dachenSpace.key: kTone1,
};
final Map<String, String> _symToLabel = {
  for (final r in dachenRows)
    for (final k in r) k.sym: k.label,
  kTone1: 'Spasi',
};

// ---- Kategori simbol (untuk warna keyboard & edukasi) ----
const _initials = 'ㄅㄆㄇㄈㄉㄊㄋㄌㄍㄎㄏㄐㄑㄒㄓㄔㄕㄖㄗㄘㄙ';
const _medials = 'ㄧㄨㄩ';
const _toneMarks = 'ˉˊˇˋ˙';

enum ZyCat { initial, medial, finalV, tone }

ZyCat catOf(String s) => _toneMarks.contains(s)
    ? ZyCat.tone
    : _initials.contains(s)
        ? ZyCat.initial
        : _medials.contains(s)
            ? ZyCat.medial
            : ZyCat.finalV;

Color catTint(ZyCat c) => switch (c) {
      ZyCat.initial => const Color(0xFFE3EEF9),
      ZyCat.medial => const Color(0xFFE2F2E7),
      ZyCat.finalV => const Color(0xFFFCEEDD),
      ZyCat.tone => const Color(0xFFF1E6F7),
    };

Color catInk(ZyCat c) => switch (c) {
      ZyCat.initial => const Color(0xFF1E5A96),
      ZyCat.medial => const Color(0xFF1F7A4D),
      ZyCat.finalV => const Color(0xFFA35A12),
      ZyCat.tone => const Color(0xFF7B3FA0),
    };

String catName(ZyCat c) => switch (c) {
      ZyCat.initial => 'Huruf awal 聲母',
      ZyCat.medial => 'Bunyi tengah 介音',
      ZyCat.finalV => 'Bunyi akhir 韻母',
      ZyCat.tone => 'Tanda nada 聲調',
    };

/// Urutan ketik satu suku kata: badan zhuyin lalu tombol nada.
/// "ㄋㄧˇ" → [ㄋ,ㄧ,ˇ] · "ㄢ" → [ㄢ,ˉ] · "˙ㄒㄧㄝ" → [ㄒ,ㄧ,ㄝ,˙]
List<String> typingSeq(String syl) {
  var body = syl.trim();
  var tone = kTone1;
  if (body.startsWith('˙')) {
    tone = '˙';
    body = body.substring(1);
  } else if (body.isNotEmpty && 'ˊˇˋ'.contains(body[body.length - 1])) {
    tone = body[body.length - 1];
    body = body.substring(0, body.length - 1);
  }
  return [...body.split(''), tone];
}

final _han = RegExp(r'[㐀-鿿]');

class _Word {
  _Word(this.v)
      : chars = v.h.split('').where((c) => _han.hasMatch(c)).toList(),
        syls = v.z.trim().split(RegExp(r'\s+')).map(typingSeq).toList();
  final Vocab v;
  final List<String> chars;
  final List<List<String>> syls;
  late final List<String> flat = [for (final s in syls) ...s];
  int get hanziCount => chars.isEmpty ? syls.length : chars.length;
}

class ZhuyinTypingScreen extends StatefulWidget {
  const ZhuyinTypingScreen({super.key, this.initialMode});

  /// Mode awal: 'word' | 'dict' | 'drill'. null = pakai pilihan terakhir.
  final String? initialMode;
  @override
  State<ZhuyinTypingScreen> createState() => _ZhuyinTypingScreenState();
}

class _ZhuyinTypingScreenState extends State<ZhuyinTypingScreen> {
  final _rng = Random();
  final _focus = FocusNode();
  final store = LiuliStore.instance;

  String _mode = 'word'; // word | dict | drill
  String _level = 'p'; // p (lv1-2) | m (lv3-4) | h (lv5-6) | all
  String _row = 'all'; // all | r1 | r2 | r3 | r4
  bool _showZy = true; // tampilkan zhuyin target (mode kata)
  bool _hint = true; // sorot tombol berikutnya
  bool _dictMeaning = false; // dikte: tampilkan arti sebagai petunjuk

  static const _wordsPerRound = 10;
  static const _drillPerRound = 30;

  // ---- sesi ----
  List<_Word> _words = [];
  List<String> _drill = [];
  int _idx = 0; // item ke-
  int _pos = 0; // posisi dalam urutan ketik kata
  int _correct = 0, _wrong = 0, _hanziDone = 0;
  DateTime? _startAt, _endAt;
  bool _pause = false; // jeda singkat setelah satu kata selesai
  bool _done = false;
  bool _wordMissed = false; // kata ini sudah dicatat salah?
  final Map<String, int> _miss = {}; // item → jumlah salah
  String? _lastErr;
  double _best = 0;
  bool _newBest = false;

  // ---- kilatan tombol ----
  String? _flashSym;
  bool _flashOk = true;
  Timer? _flashTimer, _nextTimer;

  @override
  void initState() {
    super.initState();
    _focus.addListener(() {
      if (mounted) setState(() {});
    });
    if (widget.initialMode != null) _mode = widget.initialMode!;
    _newRound();
    _loadBest();
    _loadPrefs();
  }

  @override
  void dispose() {
    _flashTimer?.cancel();
    _nextTimer?.cancel();
    _focus.dispose();
    super.dispose();
  }

  // ---------------- rekor ----------------
  String get _bestKey => 'liuli_typing_best_$_mode';

  Future<void> _loadBest() async {
    try {
      final p = await SharedPreferences.getInstance();
      if (mounted) setState(() => _best = p.getDouble(_bestKey) ?? 0);
    } catch (_) {}
  }

  Future<void> _saveBest(double v) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setDouble(_bestKey, v);
    } catch (_) {}
  }

  // ---------------- preferensi latihan (diingat antar-sesi) ----------------
  static const _kMode = 'liuli_typing_mode',
      _kLevel = 'liuli_typing_level',
      _kRow = 'liuli_typing_row',
      _kShowZy = 'liuli_typing_showzy',
      _kHint = 'liuli_typing_hint',
      _kDictMeaning = 'liuli_typing_dictmeaning';

  Future<void> _loadPrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      if (!mounted) return;
      // Mode awal dari pemanggil (mis. ubin "Dikte") mengalahkan pilihan tersimpan.
      final m = widget.initialMode ?? p.getString(_kMode) ?? _mode;
      final l = p.getString(_kLevel) ?? _level;
      final r = p.getString(_kRow) ?? _row;
      // Ronde hanya dibuat ulang bila setelan yang memengaruhi soal berubah.
      final roundChanged = m != _mode || l != _level || r != _row;
      final modeChanged = m != _mode;
      setState(() {
        _mode = m;
        _level = l;
        _row = r;
        _showZy = p.getBool(_kShowZy) ?? _showZy;
        _hint = p.getBool(_kHint) ?? _hint;
        _dictMeaning = p.getBool(_kDictMeaning) ?? _dictMeaning;
        if (roundChanged) _newRound();
      });
      if (modeChanged) _loadBest();
    } catch (_) {}
  }

  Future<void> _savePrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_kMode, _mode);
      await p.setString(_kLevel, _level);
      await p.setString(_kRow, _row);
      await p.setBool(_kShowZy, _showZy);
      await p.setBool(_kHint, _hint);
      await p.setBool(_kDictMeaning, _dictMeaning);
    } catch (_) {}
  }

  // ---------------- ronde ----------------
  List<Vocab> get _levelPool {
    bool ok(int lv) => switch (_level) {
          'p' => lv <= 2,
          'm' => lv == 3 || lv == 4,
          'h' => lv >= 5,
          _ => true,
        };
    final r = LiuliData.vocab
        .where((v) => v.z.trim().isNotEmpty && ok(v.lv))
        .toList();
    return r.isEmpty ? LiuliData.vocab : r;
  }

  List<String> get _rowSyms {
    List<String> of(int i) => dachenRows[i].map((k) => k.sym).toList();
    return switch (_row) {
      'r1' => of(0),
      'r2' => of(1),
      'r3' => of(2),
      'r4' => of(3),
      _ => [for (final r in dachenRows) ...r.map((k) => k.sym), kTone1],
    };
  }

  /// Mode berbasis kata (ketik kata & dikte) berbagi logika yang sama.
  bool get _wordLike => _mode != 'drill';

  void _newRound() {
    _flashTimer?.cancel();
    _nextTimer?.cancel();
    if (_wordLike) {
      final pool = [..._levelPool]..shuffle(_rng);
      _words = pool.take(_wordsPerRound).map(_Word.new).toList();
    } else {
      final syms = _rowSyms;
      final list = <String>[];
      while (list.length < _drillPerRound) {
        final s = syms[_rng.nextInt(syms.length)];
        if (list.isNotEmpty && list.last == s && syms.length > 1) continue;
        list.add(s);
      }
      _drill = list;
    }
    _idx = 0;
    _pos = 0;
    _correct = 0;
    _wrong = 0;
    _hanziDone = 0;
    _startAt = null;
    _endAt = null;
    _pause = false;
    _done = false;
    _wordMissed = false;
    _miss.clear();
    _lastErr = null;
    _newBest = false;
    _flashSym = null;
    if (_mode == 'dict') {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _speakCur();
      });
    }
  }

  /// Dikte: putar kata yang sedang ditanyakan.
  void _speakCur() {
    if (_mode != 'dict') return;
    final w = _curWord;
    if (w != null) store.speak(w.v.h);
  }

  void _restart() => setState(_newRound);

  void _setMode(String m) {
    setState(() {
      _mode = m;
      _newRound();
    });
    _loadBest();
    _savePrefs();
    _focus.requestFocus();
  }

  void _changeOpt(VoidCallback fn) {
    setState(() {
      fn();
      _newRound();
    });
    _savePrefs();
    _focus.requestFocus();
  }

  // ---------------- logika ketik ----------------
  _Word? get _curWord =>
      _wordLike && _idx < _words.length ? _words[_idx] : null;

  String? get _expected {
    if (_done || _pause) return null;
    if (_mode == 'drill') return _idx < _drill.length ? _drill[_idx] : null;
    final w = _curWord;
    if (w == null || _pos >= w.flat.length) return null;
    return w.flat[_pos];
  }

  String _symShow(String s) => s == kTone1 ? 'nada 1 (ˉ)' : s;

  void _input(String s) {
    final exp = _expected;
    if (exp == null) return;
    _startAt ??= DateTime.now();
    final ok = s == exp;
    _flash(s, ok);
    setState(() {
      if (ok) {
        _correct++;
        _lastErr = null;
        if (_mode == 'drill') {
          _idx++;
          if (_idx >= _drill.length) _finish();
        } else {
          _pos++;
          final w = _curWord!;
          if (_pos >= w.flat.length) _wordComplete(w);
        }
      } else {
        _wrong++;
        final item = _mode == 'drill' ? exp : _curWord!.v.h;
        _miss[item] = (_miss[item] ?? 0) + 1;
        // Catat ke deck otomatis "Baru salah / Kata lemah" (sekali per kata).
        if (_wordLike && !_wordMissed) {
          _wordMissed = true;
          store.recordMiss(_curWord!.v.h);
        }
        _lastErr = 'Tombol ${_symToLabel[s] ?? '?'} = ${_symShow(s)} · '
            'yang dicari ${_symShow(exp)} (tombol ${_symToLabel[exp]})';
      }
    });
  }

  void _wordComplete(_Word w) {
    _hanziDone += w.hanziCount;
    if (_wordLike) {
      store.logAnswer(!_wordMissed);
      store.award('type');
    }
    store.registerActivity(); // ikut menghitung target harian & rentetan
    if (_mode == 'word' && store.auto) store.speak(w.v.h);
    _pause = true;
    // Dikte: jeda lebih lama supaya jawaban (hanzi + arti) sempat terbaca.
    _nextTimer =
        Timer(Duration(milliseconds: _mode == 'dict' ? 1100 : 380), () {
      if (!mounted) return;
      setState(() {
        _pause = false;
        _idx++;
        _pos = 0;
        _wordMissed = false;
        if (_idx >= _words.length) _finish();
      });
      if (!_done) _speakCur();
    });
  }

  void _finish() {
    _done = true;
    _endAt = DateTime.now();
    final sp = _speed;
    if (sp > _best) {
      _best = sp;
      _newBest = true;
      _saveBest(sp);
    }
  }

  void _flash(String s, bool ok) {
    _flashTimer?.cancel();
    setState(() {
      _flashSym = s;
      _flashOk = ok;
    });
    _flashTimer = Timer(const Duration(milliseconds: 180), () {
      if (mounted) setState(() => _flashSym = null);
    });
  }

  KeyEventResult _onKey(FocusNode node, KeyEvent e) {
    final hk = HardwareKeyboard.instance;
    if (hk.isControlPressed || hk.isMetaPressed || hk.isAltPressed) {
      return KeyEventResult.ignored; // biarkan shortcut browser (Ctrl+R dsb.)
    }
    final pk = e.physicalKey;
    if (pk == PhysicalKeyboardKey.tab) return KeyEventResult.handled;
    if (pk == PhysicalKeyboardKey.enter || pk == PhysicalKeyboardKey.numpadEnter) {
      if (_done) {
        if (e is KeyDownEvent) _restart();
        return KeyEventResult.handled;
      }
      if (_mode == 'dict') {
        if (e is KeyDownEvent) _speakCur(); // Enter = putar lagi
        return KeyEventResult.handled;
      }
      return KeyEventResult.ignored;
    }
    final s = _keyToSym[pk];
    if (s == null) return KeyEventResult.ignored;
    if (e is KeyDownEvent) _input(s);
    // Telan juga repeat/up (mis. Spasi tidak menggulir halaman).
    return KeyEventResult.handled;
  }

  // ---------------- metrik ----------------
  double get _minutes {
    if (_startAt == null) return 0;
    final end = _endAt ?? DateTime.now();
    return end.difference(_startAt!).inMilliseconds / 60000.0;
  }

  /// Mode kata: 字/menit (standar ukur ketik di Taiwan); mode tombol: tombol/menit.
  double get _speed {
    final m = _minutes;
    if (m <= 0.0001) return 0;
    return (_wordLike ? _hanziDone : _correct) / m;
  }

  String get _unit => _wordLike ? '字/menit' : 'tombol/menit';

  int get _acc {
    final t = _correct + _wrong;
    return t == 0 ? 100 : (_correct * 100 / t).round();
  }

  double get _progress {
    if (_done) return 1;
    if (_mode == 'drill') return _drill.isEmpty ? 0 : _idx / _drill.length;
    return _words.isEmpty ? 0 : _idx / _words.length;
  }

  // ---------------- UI ----------------
  @override
  Widget build(BuildContext context) {
    final exp = _expected;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ketik Zhuyin 注音', style: TextStyle(fontSize: 17)),
        actions: [
          ExcludeFocus(
            child: IconButton(
              tooltip: 'Cara mengetik',
              icon: const Icon(Icons.help_outline),
              onPressed: _showGuide,
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: LinearProgressIndicator(
            value: _progress,
            minHeight: 4,
            backgroundColor: LiuliColors.surface2,
            color: LiuliColors.jade,
          ),
        ),
      ),
      body: Focus(
        focusNode: _focus,
        autofocus: true,
        onKeyEvent: _onKey,
        child: Listener(
          behavior: HitTestBehavior.translucent,
          onPointerDown: (_) {
            if (!_focus.hasFocus) _focus.requestFocus();
          },
          // ExcludeFocus: tombol/chip tidak "mencuri" fokus keyboard,
          // jadi Spasi tidak memicu tombol yang terakhir diklik.
          child: ExcludeFocus(
            child: Column(children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                  children: [
                    _modeBar(),
                    const SizedBox(height: 8),
                    _options(),
                    if (!_focus.hasFocus) _focusHint(),
                    const SizedBox(height: 12),
                    _done
                        ? _summary()
                        : (_mode == 'drill' ? _drillCard(exp) : _wordCard()),
                    if (!_done) ...[
                      const SizedBox(height: 10),
                      _statsRow(),
                    ],
                    if (_lastErr != null && !_done) _errLine(),
                  ],
                ),
              ),
              _DachenKeyboard(
                highlight: _hint ? exp : null,
                flashSym: _flashSym,
                flashOk: _flashOk,
                onTap: _input,
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _modeBar() => SegmentedButton<String>(
        segments: const [
          ButtonSegment(value: 'word', label: Text('Ketik kata')),
          ButtonSegment(value: 'dict', label: Text('Dikte 🔊')),
          ButtonSegment(value: 'drill', label: Text('Kenal tombol')),
        ],
        selected: {_mode},
        showSelectedIcon: false,
        // Gaya teks diambil dari tema (font aplikasi), cuma diperkecil supaya
        // tiga label muat di layar HP.
        style: ButtonStyle(
          visualDensity: VisualDensity.compact,
          textStyle: WidgetStatePropertyAll(Theme.of(context)
              .textTheme
              .labelLarge
              ?.copyWith(fontSize: 12.5, fontWeight: FontWeight.w700)),
        ),
        onSelectionChanged: (s) => _setMode(s.first),
      );

  Widget _chip(String label, bool sel, VoidCallback onTap) => ChoiceChip(
        label: Text(label),
        selected: sel,
        onSelected: (_) => onTap(),
        selectedColor: LiuliColors.jade,
        labelStyle: TextStyle(
            color: sel ? Colors.white : null,
            fontWeight: FontWeight.w700,
            fontSize: 12.5),
        visualDensity: VisualDensity.compact,
      );

  Widget _toggle(String label, bool v, ValueChanged<bool> on) => FilterChip(
        label: Text(label),
        selected: v,
        onSelected: (x) {
          on(x);
          _savePrefs();
          _focus.requestFocus();
        },
        visualDensity: VisualDensity.compact,
        labelStyle: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
      );

  Widget _options() {
    final chips = _wordLike
        ? [
            for (final o in const [
              ['p', 'Pemula'],
              ['m', 'Menengah'],
              ['h', 'Mahir'],
              ['all', 'Semua'],
            ])
              _chip(o[1], _level == o[0], () => _changeOpt(() => _level = o[0])),
          ]
        : [
            for (final o in const [
              ['all', 'Semua'],
              ['r1', 'Baris angka'],
              ['r2', 'Atas'],
              ['r3', 'Tengah'],
              ['r4', 'Bawah'],
            ])
              _chip(o[1], _row == o[0], () => _changeOpt(() => _row = o[0])),
          ];
    return Wrap(spacing: 6, runSpacing: 6, children: [
      ...chips,
      if (_mode == 'word')
        _toggle('Lihat zhuyin', _showZy, (x) => setState(() => _showZy = x)),
      if (_mode == 'dict')
        _toggle('Tampilkan arti', _dictMeaning,
            (x) => setState(() => _dictMeaning = x)),
      _toggle('Sorot tombol', _hint, (x) => setState(() => _hint = x)),
    ]);
  }

  Widget _focusHint() => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: LiuliColors.gold.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Row(children: [
            Icon(Icons.touch_app, size: 18, color: LiuliColors.gold),
            SizedBox(width: 8),
            Expanded(
              child: Text(
                'Klik area ini dulu, lalu ketik pakai keyboard. Gunakan mode '
                'keyboard English — app ini yang mengubah tombol jadi zhuyin.',
                style: TextStyle(fontSize: 12, height: 1.35),
              ),
            ),
          ]),
        ),
      );

  // ---- kartu mode kata ----
  Widget _wordCard() {
    final w = _curWord;
    if (w == null) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(children: [
          Text('Kata ${_idx + 1} / ${_words.length}',
              style: TextStyle(
                  fontSize: 12,
                  color: LiuliColors.text2,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          if (_mode == 'dict') ...[
            FilledButton.tonalIcon(
              onPressed: _speakCur,
              icon: const Icon(Icons.volume_up_rounded),
              label: const Text('Putar lagi (Enter)'),
            ),
            const SizedBox(height: 12),
          ],
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 14,
            runSpacing: 12,
            children: [
              for (var si = 0; si < w.syls.length; si++) _sylColumn(w, si),
            ],
          ),
          const SizedBox(height: 12),
          if (store.pinyin && (_mode == 'word' || _pause))
            Text(w.v.p,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: LiuliColors.jadeDeep, fontWeight: FontWeight.w700)),
          if (_mode == 'word' || _pause || _dictMeaning)
            Text(w.v.id,
                textAlign: TextAlign.center,
                style: TextStyle(color: LiuliColors.text2))
          else
            Text('Dengar, lalu ketik zhuyin-nya',
                style: TextStyle(fontSize: 12, color: LiuliColors.text3)),
        ]),
      ),
    );
  }

  Widget _sylColumn(_Word w, int si) {
    var g0 = 0;
    for (var k = 0; k < si; k++) {
      g0 += w.syls[k].length;
    }
    final syl = w.syls[si];
    final allDone = _pos >= g0 + syl.length;
    // Dikte: hanzi disembunyikan sampai suku katanya benar diketik.
    final hidden = _mode == 'dict' && !allDone;
    final ch =
        hidden ? '？' : (si < w.chars.length ? store.zh(w.chars[si]) : '');
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Text(ch,
          style: hanziStyle(
              size: 38,
              color: allDone
                  ? LiuliColors.jadeDeep
                  : (hidden ? LiuliColors.text3 : LiuliColors.ink))),
      const SizedBox(height: 6),
      Row(mainAxisSize: MainAxisSize.min, children: [
        for (var j = 0; j < syl.length; j++) _slot(syl[j], g0 + j),
      ]),
    ]);
  }

  Widget _slot(String sym, int g) {
    final typed = g < _pos;
    final cur = g == _pos && !_pause;
    final cat = catOf(sym);
    final wrongNow = cur && _flashSym != null && !_flashOk;
    final show = typed || (_mode == 'word' && _showZy);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 120),
      margin: const EdgeInsets.symmetric(horizontal: 1.5),
      width: 26,
      height: 32,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: typed
            ? catTint(cat)
            : (wrongNow
                ? LiuliColors.seal.withValues(alpha: 0.15)
                : Colors.transparent),
        borderRadius: BorderRadius.circular(7),
        border: Border.all(
          color: cur
              ? (wrongNow ? LiuliColors.seal : LiuliColors.jade)
              : (typed
                  ? catInk(cat).withValues(alpha: 0.35)
                  : Colors.grey.shade300),
          width: cur ? 2 : 1,
        ),
      ),
      child: Text(show ? sym : '·',
          style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              height: 1.1,
              color: typed ? catInk(cat) : LiuliColors.text3)),
    );
  }

  // ---- kartu mode kenal tombol ----
  Widget _drillCard(String? exp) {
    if (exp == null) return const SizedBox.shrink();
    final cat = catOf(exp);
    final next = _drill.skip(_idx + 1).take(5).toList();
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(children: [
          Text('Simbol ${_idx + 1} / ${_drill.length}',
              style: TextStyle(
                  fontSize: 12,
                  color: LiuliColors.text2,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 120),
              width: 96,
              height: 96,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: _flashSym != null && !_flashOk
                    ? LiuliColors.seal.withValues(alpha: 0.18)
                    : catTint(cat),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: catInk(cat).withValues(alpha: 0.4), width: 2),
              ),
              child: Text(exp,
                  style: TextStyle(
                      fontSize: 52,
                      fontWeight: FontWeight.w800,
                      height: 1,
                      color: catInk(cat))),
            ),
            const SizedBox(width: 18),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Berikutnya',
                  style: TextStyle(fontSize: 11, color: LiuliColors.text2)),
              const SizedBox(height: 4),
              Row(children: [
                for (final s in next)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: Text(s,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: LiuliColors.text3)),
                  ),
              ]),
            ]),
          ]),
          const SizedBox(height: 10),
          Text(catName(cat),
              style: TextStyle(
                  fontSize: 12, color: catInk(cat), fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(
              exp == kTone1
                  ? 'Nada 1 tidak bertanda → tekan Spasi'
                  : 'Tekan tombol untuk “$exp”',
              style: TextStyle(color: LiuliColors.text2)),
          if (_hint)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('Tombol: ${_symToLabel[exp]}',
                  style: TextStyle(
                      color: LiuliColors.jadeDeep, fontWeight: FontWeight.w800)),
            ),
        ]),
      ),
    );
  }

  Widget _stat(String v, String l) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            color: LiuliColors.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.brown.withValues(alpha: 0.08)),
          ),
          child: Column(children: [
            Text(v,
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            Text(l, style: TextStyle(fontSize: 11, color: LiuliColors.text2)),
          ]),
        ),
      );

  Widget _statsRow() => Row(children: [
        _stat(_startAt == null ? '–' : '${_speed.round()}', _unit),
        _stat('$_acc%', 'akurasi'),
        _stat(_best > 0 ? '${_best.round()}' : '–', 'rekor'),
      ]);

  Widget _errLine() => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: Row(children: [
          const Icon(Icons.close_rounded, size: 16, color: LiuliColors.seal),
          const SizedBox(width: 6),
          Expanded(
            child: Text(_lastErr!,
                style: const TextStyle(
                    fontSize: 12.5,
                    color: LiuliColors.seal,
                    fontWeight: FontWeight.w600)),
          ),
        ]),
      );

  // ---- ringkasan ----
  Widget _summary() {
    final secs = (_minutes * 60).round();
    final time = '${secs ~/ 60}:${(secs % 60).toString().padLeft(2, '0')}';
    final zyOf = {for (final w in _words) w.v.h: w.v.z};
    final hard = _miss.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
        child: Column(children: [
          Text(_newBest ? '🏆 Rekor baru!' : '🎉 Selesai!',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Text('${_speed.round()}',
              style: const TextStyle(
                  fontSize: 48, fontWeight: FontWeight.w900, color: LiuliColors.jade)),
          Text(_unit, style: TextStyle(color: LiuliColors.text2)),
          const SizedBox(height: 14),
          Row(children: [
            _stat('$_acc%', 'akurasi'),
            _stat(time, 'waktu'),
            _stat('$_wrong', 'salah'),
          ]),
          if (hard.isNotEmpty) ...[
            const SizedBox(height: 14),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Perlu dilatih lagi',
                  style: TextStyle(fontWeight: FontWeight.w800)),
            ),
            const SizedBox(height: 6),
            Wrap(spacing: 6, runSpacing: 6, children: [
              for (final e in hard.take(8))
                Chip(
                  visualDensity: VisualDensity.compact,
                  label: Text(
                    _mode == 'drill'
                        ? '${_symShow(e.key)} → ${_symToLabel[e.key]}  ×${e.value}'
                        : '${store.zh(e.key)}  ${zyOf[e.key] ?? ''}  ×${e.value}',
                    style: const TextStyle(fontSize: 12.5),
                  ),
                ),
            ]),
          ],
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _restart,
            icon: const Icon(Icons.replay),
            label: const Text('Ulangi (Enter)'),
            style: FilledButton.styleFrom(
                backgroundColor: LiuliColors.jade,
                minimumSize: const Size(double.infinity, 46)),
          ),
        ]),
      ),
    );
  }

  void _showGuide() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Cara mengetik Zhuyin (大千)',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            _guideLine('1', 'Ketik huruf zhuyin satu suku kata dulu, lalu tombol nada.'),
            _guideLine('2',
                'Tombol nada: Spasi = nada 1 · 6 = ˊ · 3 = ˇ · 4 = ˋ · 7 = ˙ (ringan).'),
            _guideLine('3',
                'Nada ringan ˙ ditulis di depan (˙ㄒㄧㄝ), tapi diketik paling akhir.'),
            _guideLine('4', 'Contoh: 你好 = ㄋㄧˇ ㄏㄠˇ → S U 3 C L 3.'),
            _guideLine('5',
                'Posisi tombolnya sama dengan label zhuyin di keyboard Taiwan. '
                'Pakai mode keyboard English saat latihan di sini.'),
            _guideLine('6',
                'Mode Dikte: dengar katanya (Enter = putar lagi), lalu ketik '
                'zhuyin-nya. Hanzi muncul setelah suku katanya benar.'),
          ],
        ),
      ),
    ).then((_) => _focus.requestFocus());
  }

  Widget _guideLine(String n, String t) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 22,
            height: 22,
            alignment: Alignment.center,
            decoration: BoxDecoration(
                color: LiuliColors.jadeTint, shape: BoxShape.circle),
            child: Text(n,
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: LiuliColors.jadeDeep)),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(t, style: const TextStyle(height: 1.4))),
        ]),
      );
}

/// ============ Keyboard on-screen layout 大千 ============
class _DachenKeyboard extends StatelessWidget {
  const _DachenKeyboard({
    required this.highlight,
    required this.flashSym,
    required this.flashOk,
    required this.onTap,
  });
  final String? highlight;
  final String? flashSym;
  final bool flashOk;
  final ValueChanged<String> onTap;

  // Geser tiap baris seperti keyboard asli (bantu ingatan posisi jari).
  static const _indent = [0.0, 0.5, 0.8, 1.2];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF3F1EC),
        border: Border(
            top: BorderSide(color: Colors.brown.withValues(alpha: 0.12))),
      ),
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
      child: SafeArea(
        top: false,
        child: LayoutBuilder(builder: (context, c) {
          final unit = c.maxWidth / 11.2;
          final h = (unit * 1.12).clamp(34.0, 52.0);
          Widget cap(DKey k, double w) => _KeyCap(
                k: k,
                width: w,
                height: h,
                unit: unit,
                highlight: highlight == k.sym,
                flash: flashSym == k.sym ? (flashOk ? 1 : -1) : 0,
                onTap: () => onTap(k.sym),
              );
          return Column(mainAxisSize: MainAxisSize.min, children: [
            for (var r = 0; r < dachenRows.length; r++)
              Padding(
                padding: EdgeInsets.only(bottom: 3, left: unit * _indent[r]),
                child: Row(children: [
                  for (final k in dachenRows[r]) cap(k, unit),
                ]),
              ),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              cap(dachenSpace, unit * 6),
            ]),
            const SizedBox(height: 6),
            const _Legend(),
          ]);
        }),
      ),
    );
  }
}

class _KeyCap extends StatelessWidget {
  const _KeyCap({
    required this.k,
    required this.width,
    required this.height,
    required this.unit,
    required this.highlight,
    required this.flash,
    required this.onTap,
  });
  final DKey k;
  final double width, height, unit;
  final bool highlight;
  final int flash; // 1 benar · -1 salah · 0 tidak
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cat = catOf(k.sym);
    final isSpace = identical(k, dachenSpace);
    var bg = catTint(cat);
    var border = Colors.brown.withValues(alpha: 0.14);
    var bw = 1.0;
    if (highlight) {
      bg = Color.lerp(bg, LiuliColors.jade, 0.22)!;
      border = LiuliColors.jade;
      bw = 2.2;
    }
    if (flash == 1) bg = LiuliColors.good.withValues(alpha: 0.6);
    if (flash == -1) bg = LiuliColors.again.withValues(alpha: 0.6);
    return SizedBox(
      width: width,
      height: height,
      child: Padding(
        padding: const EdgeInsets.all(1.5),
        child: Material(
          color: bg,
          borderRadius: BorderRadius.circular(8),
          child: InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: onTap,
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: border, width: bw),
              ),
              child: isSpace
                  ? Center(
                      child: Text('Spasi · nada 1 (ˉ)',
                          style: TextStyle(
                              fontSize: (unit * 0.3).clamp(10.0, 13.0),
                              fontWeight: FontWeight.w700,
                              color: catInk(cat))),
                    )
                  : Stack(children: [
                      Positioned(
                        left: 4,
                        top: 2,
                        child: Text(k.label,
                            style: TextStyle(
                                fontSize: (unit * 0.25).clamp(8.0, 11.0),
                                fontWeight: FontWeight.w600,
                                color: LiuliColors.text2)),
                      ),
                      Center(
                        child: Padding(
                          padding: EdgeInsets.only(top: unit * 0.12),
                          child: Text(k.sym,
                              style: TextStyle(
                                  fontSize: (unit * 0.5).clamp(13.0, 22.0),
                                  fontWeight: FontWeight.w700,
                                  height: 1,
                                  color: catInk(cat))),
                        ),
                      ),
                    ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  const _Legend();

  @override
  Widget build(BuildContext context) {
    Widget item(ZyCat c, String t) => Row(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: catTint(c),
              border: Border.all(color: catInk(c).withValues(alpha: 0.5)),
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 4),
          Text(t, style: TextStyle(fontSize: 10.5, color: LiuliColors.text2)),
        ]);
    return Wrap(
      alignment: WrapAlignment.center,
      spacing: 12,
      runSpacing: 4,
      children: [
        item(ZyCat.initial, 'Awal 聲母'),
        item(ZyCat.medial, 'Tengah 介音'),
        item(ZyCat.finalV, 'Akhir 韻母'),
        item(ZyCat.tone, 'Nada 聲調'),
      ],
    );
  }
}
