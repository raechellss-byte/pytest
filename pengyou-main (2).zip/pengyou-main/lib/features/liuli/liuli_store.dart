import 'dart:async';
import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../services/tts_voice.dart';
import 'liuli_data.dart';
import 'liuli_game.dart';

class SrsCard {
  SrsCard({this.due, this.iv = 0, this.ease = 2.3, this.reps = 0, this.lapses = 0, this.at});
  String? due;
  int iv;
  double ease;
  int reps;
  int lapses;
  String? at; // waktu terakhir dinilai (UTC ISO) — penentu saat sinkron

  Map<String, dynamic> toJson() => {
        'due': due,
        'iv': iv,
        'ease': ease,
        'reps': reps,
        'lapses': lapses,
        if (at != null) 'at': at,
      };
  factory SrsCard.fromJson(Map<String, dynamic> j) => SrsCard(
        due: j['due'] as String?,
        iv: (j['iv'] as num?)?.toInt() ?? 0,
        ease: (j['ease'] as num?)?.toDouble() ?? 2.3,
        reps: (j['reps'] as num?)?.toInt() ?? 0,
        lapses: (j['lapses'] as num?)?.toInt() ?? 0,
        at: j['at'] as String?,
      );
}

class Collection {
  Collection(this.id, this.name, this.words);
  final String id;
  String name;
  List<String> words;
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'words': words};
  factory Collection.fromJson(Map<String, dynamic> j) => Collection(
        '${j['id']}',
        '${j['name']}',
        (j['words'] as List?)?.map((e) => '$e').toList() ?? [],
      );
}

String liuliToday() => DateTime.now().toIso8601String().substring(0, 10);
String liuliDay(int offset) =>
    DateTime.now().add(Duration(days: offset)).toIso8601String().substring(0, 10);
int _daysBetween(String a, String b) =>
    (DateTime.parse(b).difference(DateTime.parse(a)).inHours / 24).round();
String _nowUtc() => DateTime.now().toUtc().toIso8601String();

Map<String, int> _intMap(Object? m) => m is Map
    ? m.map((k, v) => MapEntry('$k', (v as num).toInt()))
    : <String, int>{};

const _kSrs = 'liuli_srs_v1';
const _kProg = 'liuli_prog_v1';
const _kSet = 'liuli_set_v1';
const _kSaved = 'liuli_saved_v1';
const _kLists = 'liuli_lists_v1';
const _kHist = 'liuli_dicthist_v1';
const _kMiss = 'liuli_miss_v1';
const _kMeta = 'liuli_meta_v1'; // {changedAt, resetAt}
const _kGame = 'liuli_game_v1'; // XP, misi, lencana, ujian

class LiuliStore extends ChangeNotifier {
  LiuliStore._();
  static final LiuliStore instance = LiuliStore._();

  bool _loaded = false;
  SharedPreferences? _prefs;

  /// Simpan riwayat belajar ke perangkat? Hanya bila sudah masuk akun
  /// (diatur LiuliSync). Tamu tetap bisa belajar, tapi progresnya hanya
  /// bertahan selama halaman terbuka. Pengaturan (_kSet) selalu disimpan.
  bool saving = true;
  SharedPreferences? get _w => saving ? _prefs : null;
  final FlutterTts _tts = FlutterTts();
  bool _ttsReady = false;
  bool _voiced = false; // suara Mandarin sudah terpasang (web: daftar suara bisa telat)

  // Settings (default).
  bool zhuyin = true;
  bool pinyin = true;
  bool auto = true;
  String dir = 'mix'; // recog | prod | mix
  int newPerDay = 10;
  int dailyGoal = 20;
  String fs = 'normal'; // small | normal | large
  String script = 'trad'; // trad | simp
  bool dark = false; // mode gelap Belajar Mandarin
  bool remind = true; // pengingat belajar (push) bila belum belajar hari itu
  int remindHour = 20; // jam lokal pengingat

  // SRS + progress.
  Map<String, SrsCard> srs = {};
  int streak = 0, best = 0, todayCount = 0, total = 0, freezes = 2;
  String? last, todayDate;
  Map<String, int> daily = {};
  final Set<String> dates = {};
  // Akurasi harian: jumlah jawaban & jawaban salah per tanggal.
  Map<String, int> dailyTry = {};
  Map<String, int> dailyMiss = {};

  // Collections.
  final Set<String> saved = {}; // favorites
  List<Collection> lists = [];
  List<String> dictHist = [];

  // Catatan jawaban salah (study/kuis/ketik) → deck otomatis.
  List<String> misses = []; // terbaru di depan, unik
  Map<String, int> missCount = {}; // berapa kali tiap kata salah

  // Kapan data terakhir berubah / direset (UTC ISO) — untuk sinkron akun.
  String? changedAt, resetAt;

  // Gamifikasi (lihat liuli_game.dart).
  int xp = 0;
  Map<String, int> xpDaily = {};
  String? questDate; // tanggal progres misi di bawah
  Map<String, int> questCount = {}; // progres misi hari ini per jenis
  Set<String> questsDone = {}; // misi yang bonusnya sudah diberikan hari ini
  Map<String, int> kindTotal = {}; // jumlah seumur hidup per jenis aksi
  Map<String, String> badgesEarned = {}; // id lencana → tanggal didapat
  Set<String> talksDone = {}; // id dialog yang pernah diselesaikan
  Map<String, int> examBest = {}; // band ujian → skor terbaik (%)

  // Latihan menulis: berapa kali tiap karakter berhasil ditulis, dan set
  // latihan hari ini (dipilih sekali per hari supaya tidak berubah-ubah).
  Map<String, int> writeCount = {};
  String? writeDay;
  List<String> writeSet = [];
  Set<String> writeToday = {};

  /// Kabar untuk ditampilkan sebagai toast (misi selesai, naik level, lencana).
  final _events = StreamController<String>.broadcast();
  Stream<String> get events => _events.stream;

  double get textScale => fs == 'small' ? 0.9 : (fs == 'large' ? 1.18 : 1.0);

  Future<void> ensureLoaded() async {
    if (_loaded) return;
    _prefs = await SharedPreferences.getInstance();
    final p = _prefs!;

    final s = _decodeMap(p.getString(_kSet));
    if (s != null) _applySet(s);

    final srsRaw = _decodeMap(p.getString(_kSrs));
    if (srsRaw != null) _applySrs(srsRaw);

    final pr = _decodeMap(p.getString(_kProg));
    if (pr != null) _applyProg(pr);

    saved.addAll(
        (_decodeList(p.getString(_kSaved)) ?? const []).map((e) => '$e'));
    lists = (_decodeList(p.getString(_kLists)) ?? const [])
        .map((e) => Collection.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    dictHist =
        (_decodeList(p.getString(_kHist)) ?? const []).map((e) => '$e').toList();
    final mi = _decodeMap(p.getString(_kMiss));
    if (mi != null) _applyMiss(mi);
    final game = _decodeMap(p.getString(_kGame));
    if (game != null) _applyGame(game);
    final meta = _decodeMap(p.getString(_kMeta));
    if (meta != null) {
      changedAt = meta['changedAt'] as String?;
      resetAt = meta['resetAt'] as String?;
    }

    _loaded = true;
    _initTts();
  }

  Future<void> _initTts() async {
    if (_ttsReady) return;
    try {
      _voiced = await useVoiceFor(_tts, 'zh-TW');
      await _tts.setSpeechRate(0.45);
      await _tts.setPitch(1.0);
      _ttsReady = true;
    } catch (_) {}
  }

  Map<String, dynamic>? _decodeMap(String? raw) {
    if (raw == null) return null;
    try {
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return null;
    }
  }

  List? _decodeList(String? raw) {
    if (raw == null) return null;
    try {
      return jsonDecode(raw) as List;
    } catch (_) {
      return null;
    }
  }

  // ---- TTS ----
  Future<void> speak(String text) async {
    if (text.isEmpty) return;
    await _initTts();
    if (!_voiced) _voiced = await useVoiceFor(_tts, 'zh-TW');
    try {
      await _tts.stop();
      await _tts.speak(text);
    } catch (_) {}
  }

  // ---- Script conversion (繁→简) ----
  String zh(String s) {
    if (s.isEmpty || script != 'simp') return s;
    final t2s = LiuliData.t2sSync;
    if (t2s == null) return s; // belum termuat; tampilkan apa adanya
    final b = StringBuffer();
    for (final ch in s.characters) {
      b.write(t2s[ch] ?? ch);
    }
    return b.toString();
  }

  // ---- (De)serialisasi per bagian ----
  Map<String, dynamic> _setJson() => {
        'zhuyin': zhuyin,
        'pinyin': pinyin,
        'auto': auto,
        'dir': dir,
        'newPerDay': newPerDay,
        'dailyGoal': dailyGoal,
        'fs': fs,
        'script': script,
        'dark': dark,
        'remind': remind,
        'remindHour': remindHour,
      };

  void _applySet(Map<String, dynamic> s) {
    zhuyin = s['zhuyin'] ?? zhuyin;
    pinyin = s['pinyin'] ?? pinyin;
    auto = s['auto'] ?? auto;
    dir = s['dir'] ?? dir;
    newPerDay = (s['newPerDay'] as num?)?.toInt() ?? newPerDay;
    dailyGoal = (s['dailyGoal'] as num?)?.toInt() ?? dailyGoal;
    fs = s['fs'] ?? fs;
    script = s['script'] ?? script;
    dark = s['dark'] ?? dark;
    remind = s['remind'] ?? remind;
    remindHour = (s['remindHour'] as num?)?.toInt() ?? remindHour;
  }

  void _applySrs(Map<String, dynamic> m) => srs = m.map((k, v) =>
      MapEntry(k, SrsCard.fromJson(Map<String, dynamic>.from(v as Map))));

  Map<String, dynamic> _progJson() => {
        'streak': streak,
        'best': best,
        'last': last,
        'todayDate': todayDate,
        'todayCount': todayCount,
        'total': total,
        'freezes': freezes,
        'daily': daily,
        'dates': dates.toList()..sort(),
        'try': dailyTry,
        'miss': dailyMiss,
      };

  void _applyProg(Map<String, dynamic> pr) {
    streak = (pr['streak'] as num?)?.toInt() ?? 0;
    best = (pr['best'] as num?)?.toInt() ?? streak;
    last = pr['last'] as String?;
    todayDate = pr['todayDate'] as String?;
    todayCount = (pr['todayCount'] as num?)?.toInt() ?? 0;
    total = (pr['total'] as num?)?.toInt() ?? 0;
    freezes = (pr['freezes'] as num?)?.toInt() ?? 2;
    daily = _intMap(pr['daily']);
    dates
      ..clear()
      ..addAll(((pr['dates'] as List?) ?? const []).map((e) => '$e'));
    dailyTry = _intMap(pr['try']);
    dailyMiss = _intMap(pr['miss']);
  }

  void _applyMiss(Map<String, dynamic> mi) {
    misses = ((mi['recent'] as List?) ?? const []).map((e) => '$e').toList();
    missCount = _intMap(mi['count']);
  }

  Map<String, dynamic> _gameJson() => {
        'xp': xp,
        'xpDaily': xpDaily,
        'questDate': questDate,
        'questCount': questCount,
        'questsDone': questsDone.toList(),
        'kindTotal': kindTotal,
        'badges': badgesEarned,
        'talksDone': talksDone.toList(),
        'examBest': examBest,
        'write': writeCount,
        'writeDay': writeDay,
        'writeSet': writeSet,
        'writeToday': writeToday.toList(),
      };

  void _applyGame(Map<String, dynamic> g) {
    xp = (g['xp'] as num?)?.toInt() ?? 0;
    xpDaily = _intMap(g['xpDaily']);
    questDate = g['questDate'] as String?;
    questCount = _intMap(g['questCount']);
    questsDone = ((g['questsDone'] as List?) ?? const []).map((e) => '$e').toSet();
    kindTotal = _intMap(g['kindTotal']);
    badgesEarned = g['badges'] is Map
        ? (g['badges'] as Map).map((k, v) => MapEntry('$k', '$v'))
        : {};
    talksDone = ((g['talksDone'] as List?) ?? const []).map((e) => '$e').toSet();
    examBest = _intMap(g['examBest']);
    writeCount = _intMap(g['write']);
    writeDay = g['writeDay'] as String?;
    writeSet = ((g['writeSet'] as List?) ?? const []).map((e) => '$e').toList();
    writeToday = ((g['writeToday'] as List?) ?? const []).map((e) => '$e').toSet();
  }

  // ---- Latihan menulis ----
  static final _han = RegExp(r'[㐀-鿿]');

  /// 6 karakter latihan hari ini: dulu dari kata yang sedang dipelajari
  /// (terakhir diulas dulu, belum lancar ditulis), lalu karakter level
  /// terendah yang belum pernah ditulis. Dipilih sekali per hari.
  List<String> todayWriteSet([int n = 6]) {
    final t = liuliToday();
    if (writeDay == t && writeSet.isNotEmpty) return writeSet;
    final picked = <String>[];
    void take(Iterable<Vocab> words, bool Function(String c) ok) {
      for (final v in words) {
        for (final m in _han.allMatches(v.h)) {
          final c = m[0]!;
          if (picked.length < n && !picked.contains(c) && ok(c)) picked.add(c);
        }
        if (picked.length >= n) return;
      }
    }

    final learning = LiuliData.vocab
        .where((v) => !isNew(v.h) && !isMastered(v.h))
        .toList()
      ..sort((a, b) => (srs[b.h]?.at ?? '').compareTo(srs[a.h]?.at ?? ''));
    take(learning, (c) => (writeCount[c] ?? 0) < 3);
    final byLevel = [...LiuliData.vocab]..sort((a, b) => a.lv.compareTo(b.lv));
    take(byLevel, (c) => (writeCount[c] ?? 0) == 0);
    writeDay = t;
    writeSet = picked;
    writeToday = {};
    _saveGame();
    return picked;
  }

  /// Karakter [c] berhasil ditulis (kuis goresan selesai).
  void recordWrite(String c) {
    if (writeDay != liuliToday()) todayWriteSet();
    writeCount[c] = (writeCount[c] ?? 0) + 1;
    writeToday.add(c);
    _award('write');
    notifyListeners();
  }

  // ---- Gamifikasi ----
  int get level => levelForXp(xp);

  /// Misi hari ini + progresnya.
  List<Quest> get todayQuests => questsFor(liuliToday());
  int questProgress(Quest q) => questDate == liuliToday() ? (questCount[q.kind] ?? 0) : 0;
  bool questDone(Quest q) => questDate == liuliToday() && questsDone.contains(q.id);

  /// Catat [n] aksi jenis [kind] → XP, misi harian, lencana.
  void award(String kind, {int n = 1, int? xpGain}) {
    _award(kind, n: n, xpGain: xpGain);
    notifyListeners();
  }

  void _award(String kind, {int n = 1, int? xpGain}) {
    final t = liuliToday();
    if (questDate != t) {
      questDate = t;
      questCount = {};
      questsDone = {};
    }
    questCount[kind] = (questCount[kind] ?? 0) + n;
    kindTotal[kind] = (kindTotal[kind] ?? 0) + n;
    _addXp(xpGain ?? (kXp[kind] ?? 0) * n);
    final qs = questsFor(t);
    for (final q in qs) {
      if (!questsDone.contains(q.id) && (questCount[q.kind] ?? 0) >= q.target) {
        questsDone.add(q.id);
        _addXp(q.reward);
        _emit('🎯 Misi selesai: ${q.title} · +${q.reward} XP');
      }
    }
    if (!questsDone.contains('all') && qs.every((q) => questsDone.contains(q.id))) {
      questsDone.add('all');
      kindTotal['questall'] = (kindTotal['questall'] ?? 0) + 1;
      _addXp(kQuestAllBonus);
      _emit('🏆 Semua misi hari ini selesai! +$kQuestAllBonus XP');
    }
    _checkBadges();
    _saveGame();
  }

  void _addXp(int n) {
    if (n <= 0) return;
    final before = level;
    xp += n;
    final t = liuliToday();
    xpDaily[t] = (xpDaily[t] ?? 0) + n;
    if (level > before) _emit('⬆️ Naik ke Level $level · ${levelTitle(level)}');
  }

  void _checkBadges() {
    for (final b in liuliBadges) {
      if (badgesEarned.containsKey(b.id)) continue;
      if (b.check(this)) {
        badgesEarned[b.id] = liuliToday();
        _emit('🏅 Lencana baru: ${b.icon} ${b.title}');
      }
    }
  }

  void _emit(String msg) {
    if (_events.hasListener) _events.add(msg);
  }

  /// Dialog latihan peran [id] selesai.
  void finishTalk(String id) {
    talksDone.add(id);
    _award('talk');
    notifyListeners();
  }

  /// Simulasi ujian selesai dengan skor [pct] (0–100).
  void recordExam(String band, int pct) {
    if (pct > (examBest[band] ?? -1)) examBest[band] = pct;
    _award('exam', xpGain: 20 + pct ~/ 2);
    notifyListeners();
  }

  void _saveGame() {
    _w?.setString(_kGame, jsonEncode(_gameJson()));
    _touch();
  }

  // ---- Persist ----
  void _touch() {
    changedAt = _nowUtc();
    _saveMeta();
  }

  void _saveMeta() => _w?.setString(
      _kMeta, jsonEncode({'changedAt': changedAt, 'resetAt': resetAt}));

  void _saveSet() {
    _prefs?.setString(_kSet, jsonEncode(_setJson()));
    _touch();
  }

  void updateSetting(void Function() mutate) {
    mutate();
    _saveSet();
    notifyListeners();
  }

  // ---- SRS status ----
  bool isDue(String h) {
    final s = srs[h];
    return s != null && s.due != null && s.due!.compareTo(liuliToday()) <= 0;
  }

  bool isNew(String h) => !srs.containsKey(h);
  bool isMastered(String h) => (srs[h]?.iv ?? 0) >= 21;
  bool isLearning(String h) {
    final s = srs[h];
    return s != null && s.reps > 0 && s.iv < 21;
  }

  List<Vocab> dueList([bool Function(Vocab)? pred]) => LiuliData.vocab
      .where((v) => (pred == null || pred(v)) && isDue(v.h))
      .toList();
  List<Vocab> newList([bool Function(Vocab)? pred]) => LiuliData.vocab
      .where((v) => (pred == null || pred(v)) && isNew(v.h))
      .toList();

  int get dueCount => dueList().length;
  int get newCount => newList().length;
  int get masteredCount =>
      LiuliData.vocab.where((v) => isMastered(v.h)).length;
  int get seenCount => LiuliData.vocab.where((v) => !isNew(v.h)).length;

  /// Tingkat penguasaan: Baru (belum pernah) · Belajar (interval <7 hari) ·
  /// Akrab (7–20 hari) · Dikuasai (≥21 hari, sama dengan [isMastered]).
  bool isFamiliar(String h) {
    final iv = srs[h]?.iv ?? -1;
    return iv >= 7 && iv < 21;
  }

  int get learningCount => LiuliData.vocab
      .where((v) => !isNew(v.h) && (srs[v.h]?.iv ?? 0) < 7)
      .length;
  int get familiarCount =>
      LiuliData.vocab.where((v) => isFamiliar(v.h)).length;

  /// Prakiraan ulasan: jumlah kartu jatuh tempo per hari untuk [days] hari
  /// ke depan. Indeks 0 = hari ini (termasuk yang sudah lewat tempo).
  List<int> dueForecast([int days = 7]) {
    final out = List.filled(days, 0);
    final keys = [for (var i = 0; i < days; i++) liuliDay(i)];
    for (final v in LiuliData.vocab) {
      final due = srs[v.h]?.due;
      if (due == null) continue;
      if (due.compareTo(keys[0]) <= 0) {
        out[0]++;
      } else {
        final i = keys.indexOf(due);
        if (i > 0) out[i]++;
      }
    }
    return out;
  }

  /// Akurasi jawaban (0–1) dalam [days] hari, mundur dari [from] hari lalu
  /// (0 = mulai hari ini); null bila belum ada jawaban.
  double? accuracy([int days = 7, int from = 0]) {
    var tries = 0, miss = 0;
    for (var i = from; i < from + days; i++) {
      final d = liuliDay(-i);
      tries += dailyTry[d] ?? 0;
      miss += dailyMiss[d] ?? 0;
    }
    if (tries == 0) return null;
    return ((tries - miss) / tries).clamp(0.0, 1.0);
  }

  /// Kata lemah: sering salah di kuis/ketik atau sering lupa di SRS
  /// (skor ≥ 2) dan belum dikuasai — paling lemah di depan.
  List<Vocab> weakList() {
    int score(Vocab v) => (missCount[v.h] ?? 0) + (srs[v.h]?.lapses ?? 0);
    final list = LiuliData.vocab
        .where((v) => score(v) >= 2 && !isMastered(v.h))
        .toList()
      ..sort((a, b) => score(b).compareTo(score(a)));
    return list.take(50).toList();
  }

  /// Kata yang terakhir dijawab salah (terbaru di depan).
  List<Vocab> recentMissList() {
    final byH = {for (final v in LiuliData.vocab) v.h: v};
    return misses.map((h) => byH[h]).whereType<Vocab>().take(30).toList();
  }

  List<Vocab> favoriteList() =>
      LiuliData.vocab.where((v) => saved.contains(v.h)).toList();

  /// Catat jawaban salah untuk kata [h] (dipakai deck otomatis).
  void recordMiss(String h) {
    _addMiss(h);
    notifyListeners();
  }

  void _addMiss(String h) {
    if (h.isEmpty) return;
    misses.remove(h);
    misses.insert(0, h);
    if (misses.length > 60) misses = misses.sublist(0, 60);
    missCount[h] = (missCount[h] ?? 0) + 1;
    _w?.setString(_kMiss, jsonEncode({'recent': misses, 'count': missCount}));
    _touch();
  }

  /// Catat satu jawaban (benar/salah) untuk statistik akurasi harian.
  void logAnswer(bool ok) {
    _logAnswer(ok);
    _saveProg();
    notifyListeners();
  }

  void _logAnswer(bool ok) {
    final t = liuliToday();
    dailyTry[t] = (dailyTry[t] ?? 0) + 1;
    if (!ok) dailyMiss[t] = (dailyMiss[t] ?? 0) + 1;
  }

  void _saveSrs() {
    _w?.setString(
        _kSrs, jsonEncode(srs.map((k, v) => MapEntry(k, v.toJson()))));
    _touch();
  }

  void _saveProg() {
    _w?.setString(_kProg, jsonEncode(_progJson()));
    _touch();
  }

  /// Nilai kartu (again/hard/good/easy). Mengembalikan pesan opsional (freeze).
  String? grade(Vocab v, String g) {
    final wasNew = isNew(v.h);
    final s = srs[v.h] ?? SrsCard();
    if (g == 'again') {
      _addMiss(v.h);
      s.lapses++;
      s.reps = 0;
      s.ease = (s.ease - 0.2).clamp(1.3, 2.8);
      s.iv = 0;
      s.due = liuliToday();
    } else if (g == 'hard') {
      s.ease = (s.ease - 0.15).clamp(1.3, 2.8);
      s.iv = s.iv < 1 ? 1 : (s.iv * 1.2).round().clamp(1, 100000);
      s.reps++;
      s.due = liuliDay(s.iv);
    } else if (g == 'good') {
      s.iv = s.reps == 0 ? 1 : (s.reps == 1 ? 3 : (s.iv * s.ease).round());
      s.reps++;
      s.due = liuliDay(s.iv);
    } else if (g == 'easy') {
      s.ease = (s.ease + 0.12).clamp(1.3, 2.8);
      s.iv = s.reps == 0 ? 4 : (s.iv * s.ease * 1.35).round();
      if (s.iv < 4) s.iv = 4;
      s.reps++;
      s.due = liuliDay(s.iv);
    }
    s.at = _nowUtc();
    srs[v.h] = s;
    _saveSrs();
    _logAnswer(g != 'again');
    final msg = _bumpProgress();
    _award('review', xpGain: g == 'again' ? 1 : null);
    if (wasNew) _award('new');
    notifyListeners();
    return msg;
  }

  /// Catat 1 aktivitas (mis. jawaban kuis benar) ke progres harian.
  void registerActivity() {
    _bumpProgress();
    notifyListeners();
  }

  String? _bumpProgress() {
    final t = liuliToday();
    String? msg;
    if (todayDate != t) {
      todayDate = t;
      todayCount = 0;
    }
    todayCount++;
    total++;
    daily[t] = (daily[t] ?? 0) + 1;
    if (last != t) {
      if (last == null) {
        streak = 1;
      } else {
        final gap = _daysBetween(last!, t);
        if (gap == 1) {
          streak++;
        } else if (gap > 1) {
          final missed = gap - 1;
          if (freezes >= missed && missed <= 3) {
            freezes -= missed;
            streak++;
            msg = '❄️ Pelindung rentetan dipakai — rentetanmu aman!';
          } else {
            streak = 1;
          }
        }
      }
      last = t;
      dates.add(t);
      if (streak > 0 && streak % 7 == 0 && freezes < 3) freezes++;
    }
    best = best > streak ? best : streak;
    _saveProg();
    return msg;
  }

  // ---- Collections ----
  List<Collection> allColls() =>
      [Collection('fav', 'Favorit ⭐', saved.toList()), ...lists];
  Collection? collById(String id) {
    if (id == 'fav') return Collection('fav', 'Favorit ⭐', saved.toList());
    return lists.where((l) => l.id == id).firstOrNull;
  }

  bool collHas(String id, String h) {
    if (id == 'fav') return saved.contains(h);
    return lists.where((l) => l.id == id).firstOrNull?.words.contains(h) ?? false;
  }

  void collToggle(String id, String h) {
    if (id == 'fav') {
      saved.contains(h) ? saved.remove(h) : saved.add(h);
      _saveSaved();
    } else {
      final l = lists.where((x) => x.id == id).firstOrNull;
      if (l == null) return;
      l.words.contains(h) ? l.words.remove(h) : l.words.add(h);
      _saveLists();
    }
    notifyListeners();
  }

  String collCreate(String name) {
    final id = 'l${DateTime.now().millisecondsSinceEpoch.toRadixString(36)}';
    lists.add(Collection(id, name.isEmpty ? 'Koleksi baru' : name, []));
    _saveLists();
    notifyListeners();
    return id;
  }

  void collDelete(String id) {
    lists.removeWhere((l) => l.id == id);
    _saveLists();
    notifyListeners();
  }

  void _saveSaved() {
    _w?.setString(_kSaved, jsonEncode(saved.toList()));
    _touch();
  }

  void _saveLists() {
    _w?.setString(_kLists, jsonEncode(lists.map((e) => e.toJson()).toList()));
    _touch();
  }

  void addHist(String q) {
    q = q.trim();
    if (q.isEmpty || q.length > 40) return;
    dictHist.remove(q);
    dictHist.insert(0, q);
    if (dictHist.length > 12) dictHist = dictHist.sublist(0, 12);
    _w?.setString(_kHist, jsonEncode(dictHist));
  }

  // ---- Reset / snapshot / export / import ----
  void resetProgress() {
    _clearProgress();
    resetAt = _nowUtc();
    _saveSrs();
    _saveProg();
    notifyListeners();
  }

  void _clearProgress() {
    srs = {};
    streak = 0;
    best = 0;
    last = null;
    todayDate = null;
    todayCount = 0;
    total = 0;
    freezes = 2;
    daily = {};
    dates.clear();
    dailyTry = {};
    dailyMiss = {};
    misses = [];
    missCount = {};
    _prefs?.remove(_kMiss);
    _applyGame(const {});
    _prefs?.remove(_kGame);
  }

  /// Hapus semua data belajar di perangkat ini (dipakai saat akun lain masuk).
  void clearLocal() {
    _clearProgress();
    saved.clear();
    lists = [];
    dictHist = [];
    changedAt = null;
    resetAt = null;
    for (final k in [_kSrs, _kProg, _kSaved, _kLists, _kHist, _kMeta]) {
      _prefs?.remove(k);
    }
    notifyListeners();
  }

  /// true bila belum ada progres sama sekali (tak perlu disimpan ke akun).
  bool get isBlank => srs.isEmpty && total == 0 && saved.isEmpty && lists.isEmpty;

  /// Seluruh data belajar dalam satu objek (sinkron akun & ekspor).
  Map<String, dynamic> snapshot() => {
        'app': 'liuli',
        'v': 2,
        'at': changedAt,
        if (resetAt != null) 'resetAt': resetAt,
        'srs': srs.map((k, v) => MapEntry(k, v.toJson())),
        'prog': _progJson(),
        'set': _setJson(),
        'saved': saved.toList(),
        'lists': lists.map((e) => e.toJson()).toList(),
        'miss': {'recent': misses, 'count': missCount},
        'hist': dictHist,
        'game': _gameJson(),
      };

  /// Terapkan [snapshot]; bagian yang tidak ada dibiarkan seperti sekarang.
  void applySnapshot(Map<String, dynamic> obj) {
    Map<String, dynamic> m(Object? x) => Map<String, dynamic>.from(x as Map);
    if (obj['srs'] is Map) _applySrs(m(obj['srs']));
    if (obj['prog'] is Map) _applyProg(m(obj['prog']));
    if (obj['set'] is Map) _applySet(m(obj['set']));
    if (obj['saved'] is List) {
      saved
        ..clear()
        ..addAll((obj['saved'] as List).map((e) => '$e'));
    }
    if (obj['lists'] is List) {
      lists = (obj['lists'] as List)
          .map((e) => Collection.fromJson(m(e)))
          .toList();
    }
    if (obj['miss'] is Map) _applyMiss(m(obj['miss']));
    if (obj['hist'] is List) {
      dictHist = (obj['hist'] as List).map((e) => '$e').toList();
    }
    if (obj['game'] is Map) _applyGame(m(obj['game']));
    if (obj['resetAt'] is String) resetAt = obj['resetAt'] as String;
    final p = _w;
    if (p != null) {
      p.setString(_kSrs, jsonEncode(srs.map((k, v) => MapEntry(k, v.toJson()))));
      p.setString(_kProg, jsonEncode(_progJson()));
      p.setString(_kSet, jsonEncode(_setJson()));
      p.setString(_kSaved, jsonEncode(saved.toList()));
      p.setString(_kLists, jsonEncode(lists.map((e) => e.toJson()).toList()));
      p.setString(_kMiss, jsonEncode({'recent': misses, 'count': missCount}));
      p.setString(_kHist, jsonEncode(dictHist));
      p.setString(_kGame, jsonEncode(_gameJson()));
    }
    changedAt = (obj['at'] as String?) ?? _nowUtc();
    _saveMeta();
    notifyListeners();
  }

  String exportData() => jsonEncode(
      {...snapshot(), 'exportedAt': DateTime.now().toIso8601String()});

  bool importData(String text) {
    Map<String, dynamic> obj;
    try {
      obj = Map<String, dynamic>.from(jsonDecode(text.trim()) as Map);
    } catch (_) {
      return false;
    }
    if (obj['app'] != 'liuli' || obj['srs'] == null || obj['prog'] == null) {
      return false;
    }
    applySnapshot({...obj, 'at': _nowUtc()});
    return true;
  }
}
