import 'package:flutter/material.dart';

import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_practice.dart';
import 'liuli_store.dart';

class LiuliSentences extends StatefulWidget {
  const LiuliSentences({super.key});
  @override
  State<LiuliSentences> createState() => _LiuliSentencesState();
}

class _LiuliSentencesState extends State<LiuliSentences> {
  String _scene = 'order';

  @override
  void initState() {
    super.initState();
    if (LiuliData.scenes.isNotEmpty) _scene = LiuliData.scenes.first.id;
  }

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    final list = LiuliData.sentences.where((s) => s.scene == _scene).toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        Text('LATIHAN BICARA',
            style: TextStyle(
                fontSize: 11,
                letterSpacing: 1,
                fontWeight: FontWeight.w700,
                color: LiuliColors.jade)),
        const SizedBox(height: 4),
        Text('Kalimat & Shadowing', style: hanziStyle(size: 24, color: LiuliColors.ink)),
        const SizedBox(height: 4),
        Text(
            'Dengar, tirukan keras-keras, ulangi sampai lancar. Ini kunci dari '
            '"ngerti tapi nggak bisa ngomong".',
            style: TextStyle(color: LiuliColors.text2, height: 1.4)),
        const SizedBox(height: 12),
        LiuliBanner(
          stats: [
            ('${LiuliData.dialogs.length}', 'dialog'),
            ('${LiuliData.sentences.length}', 'kalimat'),
            ('${LiuliData.scenes.length}', 'situasi'),
          ],
          mark: '說',
          color: const Color(0xFF14878A),
        ),
        SectionHead('Dialog situasi PMI', trailing: '${LiuliData.dialogs.length} dialog'),
        for (final t in LiuliData.dialogs) _talkTile(context, t),
        const SectionHead('Kalimat per situasi'),
        SizedBox(
          height: 40,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              for (final s in LiuliData.scenes)
                Padding(
                  padding: const EdgeInsets.only(right: 7),
                  child: ChoiceChip(
                    label: Text(store.zh(s.name)),
                    selected: _scene == s.id,
                    onSelected: (_) => setState(() => _scene = s.id),
                    selectedColor: LiuliColors.jade,
                    labelStyle: TextStyle(
                        color: _scene == s.id ? Colors.white : null,
                        fontWeight: FontWeight.w700),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        for (final s in list) _SentenceCard(sentence: s),
      ],
    );
  }

  Widget _talkTile(BuildContext context, Talk t) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Navigator.of(context).push(liuliRoute(TalkScreen(talk: t))),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 6, 10),
            child: Row(children: [
              Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: LiuliColors.jadeTint,
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Text(t.icon, style: const TextStyle(fontSize: 21)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(t.title,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                  Text('${LiuliStore.instance.zh(t.zh)} · ${t.lines.length} baris · ${t.a}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 11.5, color: LiuliColors.text2)),
                ]),
              ),
              IconButton(
                tooltip: 'Latihan peran',
                icon: Icon(Icons.theater_comedy_rounded, color: LiuliColors.jade),
                onPressed: () => Navigator.of(context)
                    .push(liuliRoute(TalkScreen(talk: t, practice: true))),
              ),
            ]),
          ),
        ),
      );
}

class _SentenceCard extends StatefulWidget {
  const _SentenceCard({required this.sentence});
  final Sentence sentence;
  @override
  State<_SentenceCard> createState() => _SentenceCardState();
}

class _SentenceCardState extends State<_SentenceCard> {
  bool _py = true;
  bool _id = false;

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    final s = widget.sentence;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(store.zh(s.h), style: hanziStyle(size: 22, weight: FontWeight.w500)),
          if (_py) ...[
            const SizedBox(height: 4),
            Text(s.p,
                style: TextStyle(
                    color: LiuliColors.jadeDeep,
                    fontStyle: FontStyle.italic,
                    fontWeight: FontWeight.w600)),
          ],
          if (_id) ...[
            const SizedBox(height: 4),
            Text(s.id, style: TextStyle(color: LiuliColors.text2)),
          ],
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            SayButton(text: s.h, label: 'Putar', compact: true),
            _toggle('Aa Pinyin', _py, () => setState(() => _py = !_py)),
            _toggle('🇮🇩 Arti', _id, () => setState(() => _id = !_id)),
          ]),
        ]),
      ),
    );
  }

  Widget _toggle(String label, bool on, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: on ? LiuliColors.jadeTint : LiuliColors.surface2,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
                color: on ? LiuliColors.jade.withValues(alpha: 0.4) : Colors.transparent),
          ),
          child: Text(label,
              style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                  color: on ? LiuliColors.jadeDeep : LiuliColors.text2)),
        ),
      );
}
