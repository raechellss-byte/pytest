import 'package:flutter/material.dart';

import 'hanzi_writer.dart';
import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_store.dart';
import 'liuli_typing.dart' show ZhuyinTypingScreen;

final _hanRe = RegExp(r'[一-鿿]');

/// Kata contoh pertama (level terendah) yang memuat tiap karakter + level
/// saat karakter itu pertama muncul. Dihitung sekali.
Map<String, Vocab>? _charIndex;
Map<String, Vocab> charIndex() {
  if (_charIndex != null && _charIndex!.isNotEmpty) return _charIndex!;
  final byLv = [...LiuliData.vocab]..sort((a, b) => a.lv.compareTo(b.lv));
  final m = <String, Vocab>{};
  for (final v in byLv) {
    for (final c in _hanRe.allMatches(v.h)) {
      m.putIfAbsent(c[0]!, () => v);
    }
  }
  return _charIndex = m;
}

void openWriterDialog(BuildContext context, String h, String p, String id) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (_) => _WriterSheet(word: h, pinyin: p, meaning: id),
  );
}

/// Papan goresan satu karakter: animasi urutan goresan ⇄ latihan menulis.
/// Dipakai di lembar kata & sesi latihan harian.
class HanziPad extends StatefulWidget {
  const HanziPad({
    super.key,
    required this.char,
    required this.size,
    this.initialMode = 'anim',
    this.onComplete,
  });
  final String char;
  final double size;
  final String initialMode; // anim | quiz
  final void Function(int mistakes)? onComplete;

  @override
  State<HanziPad> createState() => HanziPadState();
}

class HanziPadState extends State<HanziPad> {
  late String _mode = widget.initialMode;
  bool _slow = false;
  bool _outline = true;
  Map<String, dynamic>? _hz;
  // Kunci baru tiap ganti karakter → animasi & kuis mulai dari awal.
  var _animKey = GlobalKey<AnimatedHanziState>();
  var _quizKey = GlobalKey<HanziQuizState>();
  final Map<String, HanziChar?> _cache = {};

  String get mode => _mode;
  set mode(String m) => setState(() => _mode = m);

  @override
  void initState() {
    super.initState();
    LiuliData.hz().then((m) {
      if (mounted) setState(() => _hz = m);
    });
  }

  @override
  void didUpdateWidget(covariant HanziPad oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.char != widget.char) {
      _mode = widget.initialMode;
      _animKey = GlobalKey<AnimatedHanziState>();
      _quizKey = GlobalKey<HanziQuizState>();
    }
  }

  /// HanziChar dengan identitas stabil (mencegah animasi diputar ulang terus).
  HanziChar? _charData(String ch) {
    if (_hz == null) return null;
    return _cache.putIfAbsent(ch, () {
      final raw = _hz![ch];
      return HanziChar.from(raw == null ? null : Map<String, dynamic>.from(raw));
    });
  }

  @override
  Widget build(BuildContext context) {
    final ch = widget.char;
    final data = _charData(ch);
    final size = widget.size;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      SegmentedButton<String>(
        segments: const [
          ButtonSegment(value: 'anim', label: Text('Animasi')),
          ButtonSegment(value: 'quiz', label: Text('Latihan menulis')),
        ],
        selected: {_mode},
        showSelectedIcon: false,
        onSelectionChanged: (s) => setState(() => _mode = s.first),
      ),
      const SizedBox(height: 14),
      Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.brown.withValues(alpha: 0.15)),
        ),
        child: _hz == null
            ? const Center(child: CircularProgressIndicator(color: LiuliColors.jade))
            : data == null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text('Data goresan untuk 「$ch」 belum tersedia.',
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.black54)),
                    ),
                  )
                : Stack(children: [
                    Positioned.fill(child: CustomPaint(painter: _GridPainter())),
                    if (_mode == 'anim')
                      AnimatedHanzi(
                        key: _animKey,
                        data: data,
                        size: size,
                        showOutline: _outline,
                        speed: _slow ? 0.4 : 1.0,
                      )
                    else
                      HanziQuiz(
                        key: _quizKey,
                        data: data,
                        size: size,
                        onComplete: widget.onComplete,
                      ),
                  ]),
      ),
      const SizedBox(height: 14),
      if (data != null)
        _mode == 'anim'
            ? Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
                OutlinedButton.icon(
                    onPressed: () => _animKey.currentState?.play(),
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Putar')),
                OutlinedButton.icon(
                    onPressed: () => setState(() => _slow = !_slow),
                    icon: Text(_slow ? '🐇' : '🐢'),
                    label: Text(_slow ? 'Normal' : 'Pelan')),
                OutlinedButton.icon(
                    onPressed: () => setState(() => _outline = !_outline),
                    icon: Icon(_outline ? Icons.visibility_off : Icons.visibility),
                    label: Text(_outline ? 'Tanpa bantuan' : 'Dengan bantuan')),
                SayButton(text: ch, compact: true),
              ])
            : Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
                OutlinedButton.icon(
                    onPressed: () => _quizKey.currentState?.restart(),
                    icon: const Icon(Icons.restart_alt),
                    label: const Text('Ulang')),
                OutlinedButton.icon(
                    onPressed: () => _quizKey.currentState?.hint(),
                    icon: const Text('💡'),
                    label: const Text('Petunjuk')),
                OutlinedButton.icon(
                    onPressed: () => setState(() => _mode = 'anim'),
                    icon: const Icon(Icons.visibility),
                    label: const Text('Lihat animasi')),
              ]),
    ]);
  }
}

/// Lembar goresan untuk satu kata (dibuka dari kamus, kartu, cari).
class _WriterSheet extends StatefulWidget {
  const _WriterSheet({required this.word, required this.pinyin, required this.meaning});
  final String word, pinyin, meaning;
  @override
  State<_WriterSheet> createState() => _WriterSheetState();
}

class _WriterSheetState extends State<_WriterSheet> {
  late final List<String> _chars =
      widget.word.characters.where((c) => _hanRe.hasMatch(c)).toList();
  int _idx = 0;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size.width.clamp(240, 340).toDouble() - 40;
    final ch = _chars.isNotEmpty ? _chars[_idx] : '';
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.9,
      maxChildSize: 0.95,
      minChildSize: 0.5,
      builder: (_, controller) => ListView(
        controller: controller,
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
        children: [
          Row(children: [
            Text(widget.word, style: hanziStyle(size: 34)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.pinyin,
                    style: TextStyle(fontWeight: FontWeight.w800, color: LiuliColors.jadeDeep)),
                Text(widget.meaning, style: TextStyle(color: LiuliColors.text2, fontSize: 13)),
              ]),
            ),
          ]),
          if (_chars.length > 1) ...[
            const SizedBox(height: 12),
            Wrap(spacing: 8, children: [
              for (var i = 0; i < _chars.length; i++)
                ChoiceChip(
                  label: Text(_chars[i], style: hanziStyle(size: 20)),
                  selected: i == _idx,
                  selectedColor: LiuliColors.jade,
                  labelStyle: TextStyle(color: i == _idx ? Colors.white : null),
                  onSelected: (_) => setState(() => _idx = i),
                ),
            ]),
          ],
          const SizedBox(height: 14),
          if (ch.isNotEmpty)
            HanziPad(
              char: ch,
              size: size,
              onComplete: (_) {
                LiuliStore.instance.recordWrite(ch);
                if (_idx < _chars.length - 1) {
                  Future.delayed(const Duration(milliseconds: 1400), () {
                    if (mounted) setState(() => _idx++);
                  });
                }
              },
            ),
          const SizedBox(height: 12),
          Text('Data goresan: Make Me a Hanzi · animasi HanziWriter — berjalan offline.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: LiuliColors.text3)),
        ],
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = Colors.grey.withValues(alpha: 0.22)
      ..strokeWidth = 1;
    final dash = Paint()
      ..color = Colors.grey.withValues(alpha: 0.18)
      ..strokeWidth = 1;
    canvas.drawRect(Offset.zero & size, p..style = PaintingStyle.stroke);
    canvas.drawLine(Offset(size.width / 2, 0), Offset(size.width / 2, size.height), dash);
    canvas.drawLine(Offset(0, size.height / 2), Offset(size.width, size.height / 2), dash);
    canvas.drawLine(Offset.zero, Offset(size.width, size.height), dash);
    canvas.drawLine(Offset(size.width, 0), Offset(0, size.height), dash);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ============================================================
// Sesi latihan menulis: karakter satu per satu (lihat → tulis → lanjut).
// ============================================================

class WriteSessionScreen extends StatefulWidget {
  const WriteSessionScreen({super.key, required this.chars, this.title = 'Latihan menulis'});
  final List<String> chars;
  final String title;
  @override
  State<WriteSessionScreen> createState() => _WriteSessionScreenState();
}

class _WriteSessionScreenState extends State<WriteSessionScreen> {
  final store = LiuliStore.instance;
  int i = 0;
  int _doneCount = 0;
  bool _justDone = false;

  void _complete(int mistakes) {
    store.recordWrite(widget.chars[i]);
    setState(() {
      _doneCount++;
      _justDone = true;
    });
  }

  void _next() => setState(() {
        i++;
        _justDone = false;
      });

  @override
  Widget build(BuildContext context) {
    final done = i >= widget.chars.length;
    final size = MediaQuery.of(context).size.width.clamp(240, 360).toDouble() - 48;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title, style: const TextStyle(fontSize: 17)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: LinearProgressIndicator(
            value: done ? 1 : i / widget.chars.length,
            minHeight: 4,
            backgroundColor: LiuliColors.surface2,
            color: LiuliColors.jade,
          ),
        ),
      ),
      body: done ? _summary() : _step(size),
    );
  }

  Widget _step(double size) {
    final ch = widget.chars[i];
    final ex = charIndex()[ch];
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
      children: [
        Text('Karakter ${i + 1} / ${widget.chars.length}',
            textAlign: TextAlign.center,
            style: TextStyle(color: LiuliColors.text2, fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        if (ex != null)
          Card(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
              child: Row(children: [
                Text(store.zh(ch), style: hanziStyle(size: 40, color: LiuliColors.jadeDeep)),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('dalam kata ${store.zh(ex.h)}',
                        style: TextStyle(fontSize: 12, color: LiuliColors.text3)),
                    Text(ex.p,
                        style: TextStyle(
                            fontWeight: FontWeight.w800, color: LiuliColors.jadeDeep)),
                    Text(ex.id,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 13, color: LiuliColors.text2)),
                  ]),
                ),
                SayButton(text: ex.h, compact: true),
              ]),
            ),
          ),
        const SizedBox(height: 12),
        Center(
          child: HanziPad(
            key: ValueKey(ch),
            char: ch,
            size: size,
            onComplete: _complete,
          ),
        ),
        const SizedBox(height: 16),
        if (_justDone)
          Text('正確！Goresanmu benar 🎉',
              textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.w800, color: LiuliColors.good)),
        const SizedBox(height: 8),
        FilledButton(
          onPressed: _next,
          style: FilledButton.styleFrom(
              backgroundColor: _justDone ? LiuliColors.jade : LiuliColors.text3,
              minimumSize: const Size(0, 48)),
          child: Text(i + 1 >= widget.chars.length
              ? 'Selesai'
              : (_justDone ? 'Karakter berikutnya →' : 'Lewati')),
        ),
        const SizedBox(height: 6),
        Text('Lihat animasinya dulu, lalu pilih "Latihan menulis" dan tulis dengan jarimu.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: LiuliColors.text3)),
      ],
    );
  }

  Widget _summary() => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_doneCount == widget.chars.length ? '讚' : '加油',
                style: hanziStyle(size: 52, color: LiuliColors.jade)),
            const SizedBox(height: 10),
            Text('$_doneCount / ${widget.chars.length} karakter ditulis',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text('Tulis ulang karakter yang sama besok supaya makin lancar.',
                textAlign: TextAlign.center, style: TextStyle(color: LiuliColors.text2)),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: () => Navigator.pop(context),
              style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
              child: const Text('Selesai'),
            ),
          ]),
        ),
      );
}

// ============================================================
// Tab Tulis: latihan harian · jelajah per level · cari.
// ============================================================

class LiuliWrite extends StatefulWidget {
  const LiuliWrite({super.key});
  @override
  State<LiuliWrite> createState() => _LiuliWriteState();
}

class _LiuliWriteState extends State<LiuliWrite> {
  final _ctrl = TextEditingController();
  String _q = '';
  int _lv = 1;
  int _shown = 30;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _openChar(String c) {
    final v = charIndex()[c];
    openWriterDialog(context, c, v?.p ?? '', v == null ? '' : 'dalam ${v.h} · ${v.id}');
  }

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    final idx = charIndex();
    final today = store.todayWriteSet();
    final doneToday = today.where(store.writeToday.contains).length;
    final levels = {for (final v in idx.values) v.lv}.toList()..sort();
    final levelChars = [
      for (final e in idx.entries)
        if (e.value.lv == _lv) e.key
    ];
    final q = _q.trim().toLowerCase();
    final results = q.isEmpty
        ? const <Vocab>[]
        : LiuliData.vocab
            .where((v) =>
                v.h.contains(q) || v.p.toLowerCase().contains(q) || v.id.toLowerCase().contains(q))
            .take(30)
            .toList();
    final written = idx.keys.where((c) => (store.writeCount[c] ?? 0) > 0).length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        Text('MENULIS 寫',
            style: TextStyle(
                fontSize: 11, letterSpacing: 1, fontWeight: FontWeight.w700, color: LiuliColors.jade)),
        const SizedBox(height: 4),
        Text('Urutan Goresan', style: hanziStyle(size: 24, color: LiuliColors.ink)),
        const SizedBox(height: 12),
        LiuliBanner(
          stats: [
            ('$written', 'karakter ditulis'),
            ('${idx.length}', 'karakter total'),
          ],
          mark: '寫',
          color: const Color(0xFFB7791F),
        ),
        const SizedBox(height: 12),
        _dailyCard(today, doneToday),
        _typingCard(),
        // Cari kata / karakter.
        TextField(
          controller: _ctrl,
          onChanged: (v) => setState(() => _q = v),
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search),
            hintText: 'Cari kata (hanzi / pinyin / arti)…',
            suffixIcon: _q.isEmpty
                ? null
                : IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () => setState(() {
                      _ctrl.clear();
                      _q = '';
                    }),
                  ),
          ),
        ),
        if (q.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text(results.isEmpty ? 'Tidak ada kata cocok.' : '${results.length} kata cocok',
              style: TextStyle(fontSize: 12, color: LiuliColors.text3)),
          const SizedBox(height: 4),
          Card(
            child: Column(children: [
              for (final v in results)
                ListTile(
                  dense: true,
                  onTap: () => openWriterDialog(context, v.h, v.p, v.id),
                  title: Text(store.zh(v.h), style: hanziStyle(size: 20)),
                  subtitle: Text('${v.p} · ${v.id}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: LiuliColors.text2)),
                  trailing: Icon(Icons.draw_outlined, color: LiuliColors.jade),
                ),
            ]),
          ),
        ] else ...[
          SectionHead('Jelajahi per level', trailing: '${levelChars.length} karakter'),
          SizedBox(
            height: 40,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              for (final lv in levels)
                Padding(
                  padding: const EdgeInsets.only(right: 7),
                  child: ChoiceChip(
                    label: Text('Lv$lv'),
                    selected: _lv == lv,
                    showCheckmark: false,
                    selectedColor: levelColor(lv),
                    labelStyle: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: _lv == lv ? Colors.white : levelColor(lv)),
                    onSelected: (_) => setState(() {
                      _lv = lv;
                      _shown = 30;
                    }),
                  ),
                ),
            ]),
          ),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 6,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 6,
            crossAxisSpacing: 6,
            children: [
              for (final c in levelChars.take(_shown)) _charTile(c, store),
            ],
          ),
          if (levelChars.length > _shown)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: OutlinedButton(
                onPressed: () => setState(() => _shown += 30),
                child: Text('Tampilkan ${(levelChars.length - _shown).clamp(0, 30)} lagi '
                    '(${levelChars.length - _shown} tersisa)'),
              ),
            ),
        ],
      ],
    );
  }

  /// Kartu utama: 6 karakter latihan hari ini + tombol mulai.
  Widget _dailyCard(List<String> chars, int done) {
    final store = LiuliStore.instance;
    final all = chars.isNotEmpty && done >= chars.length;
    final rest = [for (final c in chars) if (!store.writeToday.contains(c)) c];
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Text('✍️', style: TextStyle(fontSize: 20)),
            const SizedBox(width: 8),
            const Expanded(
              child: Text('Latihan menulis hari ini',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            ),
            Pill('$done/${chars.length}', color: all ? LiuliColors.good : const Color(0xFFB7791F)),
          ]),
          const SizedBox(height: 4),
          Text('Dipilih dari kata yang sedang kamu pelajari. Lihat goresannya, lalu tulis sendiri.',
              style: TextStyle(fontSize: 12.5, color: LiuliColors.text2, height: 1.35)),
          const SizedBox(height: 12),
          Row(children: [
            for (final c in chars)
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: _charTile(c, store, today: true),
                  ),
                ),
              ),
          ]),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: chars.isEmpty
                  ? null
                  : () => Navigator.of(context).push(liuliRoute(WriteSessionScreen(
                      chars: rest.isEmpty ? chars : rest,
                      title: rest.isEmpty ? 'Ulangi latihan hari ini' : 'Latihan menulis hari ini'))),
              icon: Icon(all ? Icons.replay_rounded : Icons.play_arrow_rounded),
              label: Text(all
                  ? 'Selesai hari ini 🎉 — ulangi?'
                  : (done == 0 ? 'Mulai latihan (${chars.length} karakter)' : 'Lanjutkan (${rest.length} lagi)')),
              style: FilledButton.styleFrom(
                  backgroundColor: LiuliColors.jade, minimumSize: const Size(0, 46)),
            ),
          ),
        ]),
      ),
    );
  }

  /// Ubin karakter kecil; titik hijau = sudah pernah ditulis (centang = hari ini).
  Widget _charTile(String c, LiuliStore store, {bool today = false}) {
    final doneToday = store.writeToday.contains(c);
    final written = (store.writeCount[c] ?? 0) > 0;
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => _openChar(c),
      child: Container(
        decoration: BoxDecoration(
          color: today && doneToday ? LiuliColors.jadeTint : LiuliColors.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: today && doneToday
                  ? LiuliColors.jade.withValues(alpha: 0.5)
                  : Colors.brown.withValues(alpha: 0.1)),
        ),
        child: Stack(children: [
          Center(child: Text(store.zh(c), style: hanziStyle(size: 22))),
          if (today ? doneToday : written)
            Positioned(
              right: 3,
              top: 3,
              child: today
                  ? Icon(Icons.check_circle_rounded, size: 13, color: LiuliColors.good)
                  : Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(color: LiuliColors.good, shape: BoxShape.circle),
                    ),
            ),
        ]),
      ),
    );
  }

  Widget _typingCard() => Card(
        color: LiuliColors.jadeTint,
        margin: const EdgeInsets.only(top: 4, bottom: 12),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Navigator.of(context).push(liuliRoute(const ZhuyinTypingScreen())),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(children: [
              Icon(Icons.keyboard, color: LiuliColors.jadeDeep, size: 24),
              const SizedBox(width: 12),
              Expanded(
                child: Text('Latihan ketik Zhuyin 注音 — keyboard 大千',
                    style: TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 13.5, color: LiuliColors.ink)),
              ),
              Icon(Icons.chevron_right, color: LiuliColors.jadeDeep),
            ]),
          ),
        ),
      );
}
