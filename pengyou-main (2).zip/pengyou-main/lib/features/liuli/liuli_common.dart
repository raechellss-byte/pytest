import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'liuli_store.dart';

/// Palet 流利 Liúlì — jade (hijau) + seal (merah bata) di atas krem PENGYOU.
/// Warna teks/permukaan berupa getter: ikut [isDark] (mode gelap Belajar
/// Mandarin, diset oleh [LiuliThemed] tiap kali dibangun).
class LiuliColors {
  static bool isDark = false;

  static const jade = Color(0xFF1F7A4D);
  static const jadeShade = Color(0xFF14603A); // latar gradasi (tetap gelap)
  static const seal = Color(0xFFC0392B);
  static const gold = Color(0xFFCA8A04);
  static const inkOnPaper = Color(0xFF23271F); // goresan di kanvas putih

  static Color get jadeDeep => isDark ? const Color(0xFF8FD9AE) : jadeShade;
  static Color get jadeTint =>
      isDark ? const Color(0xFF1D3A2A) : const Color(0xFFE4F0E8);
  static Color get ink => isDark ? const Color(0xFFE6E9E3) : inkOnPaper;
  static Color get inkSoft =>
      isDark ? const Color(0xFFA9B0A4) : const Color(0xFF5B6157);
  static Color get surface2 =>
      isDark ? const Color(0xFF29302B) : const Color(0xFFF1F5F0);

  /// Latar kartu/ubin (pengganti Colors.white).
  static Color get card => isDark ? const Color(0xFF1B211D) : Colors.white;

  /// Teks sekunder (pengganti grey.shade600–800) & tersier (grey.shade400–500).
  static Color get text2 =>
      isDark ? const Color(0xFFB9C0B4) : const Color(0xFF616161);
  static Color get text3 =>
      isDark ? const Color(0xFF8C9488) : const Color(0xFF8A8A8A);

  static const again = Color(0xFFD1584B);
  static const hard = Color(0xFFDB8B2A);
  static const good = Color(0xFF2E9E5B);
  static const easy = Color(0xFF2E82C9);
}

/// Nama keluarga font hanzi bawaan (Noto Sans TC yang dipangkas ke huruf
/// materi; lihat tool/subset_hanzi_font.py).
const kHanziFont = 'LiuliHanzi';
bool _hanziFontReady = false;
bool get hanziFontReady => _hanziFontReady;

/// Muat font hanzi bawaan. Tanpa ini CanvasKit (web) mengunduh potongan font
/// CJK dari Google tiap ada huruf baru, lalu mengatur ulang semua teks, dan
/// layar tersendat saat menggulir. Gagal = tetap jalan dengan cara lama.
Future<void> loadHanziFont() async {
  if (_hanziFontReady) return;
  try {
    final loader = FontLoader(kHanziFont)
      ..addFont(rootBundle.load('assets/fonts/LiuliHanzi-Regular.ttf'))
      ..addFont(rootBundle.load('assets/fonts/LiuliHanzi-Bold.ttf'));
    await loader.load();
    _hanziFontReady = true;
  } catch (e) {
    debugPrint('Font hanzi gagal dimuat: $e');
  }
}

ThemeData? _hanziIn, _hanziOut;

/// [t] dengan [kHanziFont] sebagai font cadangan di semua gaya teks tema
/// (font Latin tetap). Hanya bila font sudah dimuat: family yang belum
/// terdaftar bisa membuat hanzi tampil sebagai kotak.
ThemeData withHanziFont(ThemeData t) {
  if (!_hanziFontReady) return t;
  if (identical(t, _hanziIn)) return _hanziOut!;
  if (t.textTheme.bodyMedium?.fontFamilyFallback?.contains(kHanziFont) ?? false) {
    return t; // sudah (mis. tema halaman Liúlì yang dipakai lagi sebagai dasar)
  }
  TextStyle? s(TextStyle? x) => x == null || (x.fontFamilyFallback?.contains(kHanziFont) ?? false)
      ? x
      : x.copyWith(fontFamilyFallback: [...?x.fontFamilyFallback, kHanziFont]);
  TextTheme tt(TextTheme x) => x.copyWith(
    displayLarge: s(x.displayLarge),
    displayMedium: s(x.displayMedium),
    displaySmall: s(x.displaySmall),
    headlineLarge: s(x.headlineLarge),
    headlineMedium: s(x.headlineMedium),
    headlineSmall: s(x.headlineSmall),
    titleLarge: s(x.titleLarge),
    titleMedium: s(x.titleMedium),
    titleSmall: s(x.titleSmall),
    bodyLarge: s(x.bodyLarge),
    bodyMedium: s(x.bodyMedium),
    bodySmall: s(x.bodySmall),
    labelLarge: s(x.labelLarge),
    labelMedium: s(x.labelMedium),
    labelSmall: s(x.labelSmall),
  );
  ButtonStyle? b(ButtonStyle? x) => x?.textStyle == null
      ? x
      : x!.copyWith(textStyle: WidgetStatePropertyAll(s(x.textStyle!.resolve({}))));
  final out = t.copyWith(
    textTheme: tt(t.textTheme),
    primaryTextTheme: tt(t.primaryTextTheme),
    appBarTheme: t.appBarTheme.copyWith(titleTextStyle: s(t.appBarTheme.titleTextStyle)),
    chipTheme: t.chipTheme.copyWith(labelStyle: s(t.chipTheme.labelStyle)),
    snackBarTheme: t.snackBarTheme.copyWith(
      contentTextStyle: s(t.snackBarTheme.contentTextStyle),
    ),
    filledButtonTheme: FilledButtonThemeData(style: b(t.filledButtonTheme.style)),
    outlinedButtonTheme: OutlinedButtonThemeData(style: b(t.outlinedButtonTheme.style)),
    textButtonTheme: TextButtonThemeData(style: b(t.textButtonTheme.style)),
    elevatedButtonTheme: ElevatedButtonThemeData(style: b(t.elevatedButtonTheme.style)),
  );
  _hanziIn = t;
  return _hanziOut = out;
}

/// Tema Belajar Mandarin: tema app apa adanya, atau versi gelap (+ font hanzi).
ThemeData liuliTheme(ThemeData base, {required bool dark}) =>
    withHanziFont(dark ? _liuliDark(base) : base);

ThemeData _liuliDark(ThemeData base) {
  const bg = Color(0xFF121613);
  const card = Color(0xFF1B211D);
  const field = Color(0xFF232A25);
  const ink = Color(0xFFE6E9E3);
  const accent = Color(0xFF6FCF97);
  final scheme = ColorScheme.fromSeed(
    seedColor: LiuliColors.jade,
    brightness: Brightness.dark,
  ).copyWith(primary: accent, surface: card, onSurface: ink);
  final label = base.navigationBarTheme.labelTextStyle?.resolve({});
  return base.copyWith(
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: bg,
    canvasColor: bg,
    cardColor: card,
    dividerColor: Colors.white12,
    textTheme: base.textTheme.apply(bodyColor: ink, displayColor: ink),
    iconTheme: const IconThemeData(color: ink),
    appBarTheme: base.appBarTheme.copyWith(
      foregroundColor: ink,
      titleTextStyle: base.appBarTheme.titleTextStyle?.copyWith(color: ink),
    ),
    cardTheme: base.cardTheme.copyWith(
      color: card,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: BorderSide(color: Colors.white.withValues(alpha: 0.06)),
      ),
    ),
    navigationBarTheme: base.navigationBarTheme.copyWith(
      backgroundColor: card,
      indicatorColor: accent.withValues(alpha: 0.18),
      labelTextStyle: WidgetStatePropertyAll(
        (label ?? const TextStyle()).copyWith(color: ink),
      ),
      iconTheme: WidgetStateProperty.resolveWith(
        (s) => IconThemeData(
          color: s.contains(WidgetState.selected) ? accent : LiuliColors.text3,
        ),
      ),
    ),
    inputDecorationTheme: base.inputDecorationTheme.copyWith(fillColor: field),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: (base.outlinedButtonTheme.style ?? const ButtonStyle()).copyWith(
        foregroundColor: const WidgetStatePropertyAll(ink),
        side: WidgetStatePropertyAll(
          BorderSide(color: Colors.white.withValues(alpha: 0.25), width: 1.5),
        ),
      ),
    ),
    // Tombol isi berwarna (hijau/merah) tetap bertulisan putih.
    filledButtonTheme: FilledButtonThemeData(
      style: (base.filledButtonTheme.style ?? const ButtonStyle()).copyWith(
        foregroundColor: WidgetStateProperty.resolveWith((s) =>
            s.contains(WidgetState.disabled) ? Colors.white38 : Colors.white),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: (base.textButtonTheme.style ?? const ButtonStyle()).copyWith(
        foregroundColor: const WidgetStatePropertyAll(accent),
      ),
    ),
    chipTheme: base.chipTheme.copyWith(
      backgroundColor: field,
      labelStyle: base.chipTheme.labelStyle?.copyWith(color: ink),
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: card,
      modalBackgroundColor: card,
    ),
    dialogTheme: const DialogThemeData(backgroundColor: card),
    listTileTheme: const ListTileThemeData(textColor: ink, iconColor: ink),
    dividerTheme: const DividerThemeData(color: Colors.white12, thickness: 1),
  );
}

ThemeData? _lightBase;

/// Tema dasar (terang) app. Di dalam halaman/modal yang sudah bertema gelap,
/// pakai tema terang yang terakhir terlihat supaya bisa kembali ke terang.
ThemeData liuliBaseTheme(BuildContext context) {
  final t = Theme.of(context);
  if (t.brightness == Brightness.light) return _lightBase = t;
  return _lightBase ?? t;
}

/// Bungkus halaman Belajar Mandarin: tema (terang/gelap) + ukuran huruf.
/// Dipakai di [LiuliApp] dan setiap halaman yang di-push lewat [liuliRoute].
class LiuliThemed extends StatelessWidget {
  const LiuliThemed({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        LiuliColors.isDark = store.dark;
        return Theme(
          data: liuliTheme(liuliBaseTheme(context), dark: store.dark),
          child: MediaQuery(
            data: MediaQuery.of(
              context,
            ).copyWith(textScaler: TextScaler.linear(store.textScale)),
            child: child,
          ),
        );
      },
    );
  }
}

/// Route halaman Belajar Mandarin (ikut tema gelap & ukuran huruf).
Route<T> liuliRoute<T>(Widget page) =>
    MaterialPageRoute<T>(builder: (_) => LiuliThemed(child: page));

/// Teks hanzi besar. JANGAN set fontFamily/fontFamilyFallback: biarkan sama
/// seperti Text biasa (mewarisi font tema, termasuk [kHanziFont] dari
/// [withHanziFont]). Menetapkan family yang tak ter-load = kotak (tofu).
TextStyle hanziStyle({
  double size = 24,
  FontWeight weight = FontWeight.w700,
  Color? color,
}) => TextStyle(fontSize: size, fontWeight: weight, color: color, height: 1.2);

/// Tombol "Dengar" (TTS).
class SayButton extends StatelessWidget {
  const SayButton({
    super.key,
    required this.text,
    this.label = 'Dengar',
    this.compact = false,
  });
  final String text;
  final String label;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final child = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.volume_up_rounded, size: 17),
        if (!compact) ...[const SizedBox(width: 6), Text(label)],
      ],
    );
    return OutlinedButton(
      onPressed: () => LiuliStore.instance.speak(text),
      style: OutlinedButton.styleFrom(
        minimumSize: compact ? const Size(0, 36) : const Size(0, 40),
        padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 16),
        foregroundColor: LiuliColors.jadeDeep,
        side: BorderSide(color: LiuliColors.jade.withValues(alpha: 0.35)),
      ),
      child: child,
    );
  }
}

class SectionHead extends StatelessWidget {
  const SectionHead(this.title, {super.key, this.trailing});
  final String title;
  final String? trailing;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(2, 18, 2, 8),
    child: Row(
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800),
        ),
        const Spacer(),
        if (trailing != null)
          Text(
            trailing!,
            style: TextStyle(fontSize: 12, color: LiuliColors.text3),
          ),
      ],
    ),
  );
}

/// SVG-like tone contour icon digambar via CustomPaint.
class ToneIcon extends StatelessWidget {
  const ToneIcon(this.tone, {super.key, this.size = 24, this.color});
  final int tone;
  final double size;
  final Color? color;
  @override
  Widget build(BuildContext context) => CustomPaint(
    size: Size(size, size * 0.9),
    painter: _TonePainter(tone, color ?? LiuliColors.jade),
  );
}

class _TonePainter extends CustomPainter {
  _TonePainter(this.tone, this.color);
  final int tone;
  final Color color;
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()
      ..color = color
      ..strokeWidth = 2.4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final w = s.width, h = s.height;
    final path = Path();
    switch (tone) {
      case 1:
        path.moveTo(w * 0.1, h * 0.3);
        path.lineTo(w * 0.9, h * 0.3);
        break;
      case 2:
        path.moveTo(w * 0.15, h * 0.85);
        path.lineTo(w * 0.85, h * 0.25);
        break;
      case 3:
        path.moveTo(w * 0.12, h * 0.3);
        path.lineTo(w * 0.42, h * 0.85);
        path.lineTo(w * 0.9, h * 0.45);
        break;
      default:
        path.moveTo(w * 0.15, h * 0.25);
        path.lineTo(w * 0.85, h * 0.85);
    }
    canvas.drawPath(path, p);
  }

  @override
  bool shouldRepaint(covariant _TonePainter old) =>
      old.tone != tone || old.color != color;
}

/// ============================================================
/// Komponen tampilan bersama (gaya "banner berangka besar", level berwarna,
/// ubin mode bergradasi). Desain sendiri: watermark hanzi seperti hero 學.
/// ============================================================

/// Warna khas tiap level TOCFL (1 → 6).
Color levelColor(int lv) => switch (lv) {
  1 => const Color(0xFF2E9E5B), // hijau
  2 => const Color(0xFF14878A), // teal
  3 => const Color(0xFFB7791F), // amber
  4 => const Color(0xFFD9692B), // oranye
  5 => const Color(0xFFC94A3F), // merah bata
  _ => const Color(0xFF7552C0), // ungu
};

/// Nama level TOCFL (Indonesia + 中文).
String levelName(int lv) => switch (lv) {
  1 => 'Pemula 入門',
  2 => 'Dasar 基礎',
  3 => 'Menengah 進階',
  4 => 'Mahir 高階',
  5 => 'Lancar 流利',
  _ => 'Fasih 精通',
};

/// Tingkat penguasaan kata (dipakai bar "Penguasaan kosakata").
class Mastery {
  static const newC = Color(0xFF94A3B8); // Baru
  static const learning = Color(0xFFE8893A); // Belajar
  static const familiar = Color(0xFFE3B341); // Akrab
  static const mastered = Color(0xFF2E9E5B); // Dikuasai
}

/// Banner lebar dengan angka besar + watermark hanzi (pembuka tiap tab).
class LiuliBanner extends StatelessWidget {
  const LiuliBanner({
    super.key,
    required this.stats,
    required this.mark,
    this.color = LiuliColors.jade,
  });

  /// (angka, keterangan), mis. ('755', 'kata').
  final List<(String, String)> stats;
  final String mark; // hanzi hiasan, mis. 學
  final Color color;

  @override
  Widget build(BuildContext context) {
    final dark = LiuliColors.isDark;
    final ink = dark
        ? Color.lerp(color, Colors.white, 0.62)!
        : Color.lerp(color, Colors.black, 0.35)!;
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: Container(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: dark
                ? [
                    Color.lerp(color, Colors.black, 0.72)!,
                    Color.lerp(color, Colors.black, 0.58)!,
                  ]
                : [
                    Color.lerp(color, Colors.white, 0.88)!,
                    Color.lerp(color, Colors.white, 0.72)!,
                  ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: color.withValues(alpha: 0.16)),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(
              right: -6,
              bottom: -34,
              child: Text(
                mark,
                style: hanziStyle(
                  size: 104,
                  color: color.withValues(alpha: 0.16),
                ),
              ),
            ),
            Row(
              children: [
                for (var i = 0; i < stats.length; i++) ...[
                  if (i > 0)
                    Container(
                      width: 1,
                      height: 40,
                      margin: const EdgeInsets.symmetric(horizontal: 16),
                      color: color.withValues(alpha: 0.28),
                    ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        stats[i].$1,
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                          height: 1.05,
                          color: ink,
                        ),
                      ),
                      Text(
                        stats[i].$2,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: ink.withValues(alpha: 0.75),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Ubin mode latihan bergradasi (grid di tab Kuis).
class ModeTile extends StatelessWidget {
  const ModeTile({
    super.key,
    required this.icon,
    required this.title,
    required this.sub,
    required this.colors,
    required this.onTap,
    this.badge,
  });
  final IconData icon;
  final String title, sub;
  final List<Color> colors;
  final VoidCallback onTap;
  final String? badge;

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: BorderRadius.circular(18),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: colors,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                right: -10,
                bottom: -12,
                child: Icon(
                  icon,
                  size: 72,
                  color: Colors.white.withValues(alpha: 0.16),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.22),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(icon, color: Colors.white, size: 20),
                    ),
                    const Spacer(),
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 13.5,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      sub,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.88),
                        fontSize: 11,
                        height: 1.25,
                      ),
                    ),
                  ],
                ),
              ),
              if (badge != null)
                Positioned(
                  top: 10,
                  right: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      badge!,
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: colors.first,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Label kecil berbentuk pil (mis. "⏰ 12", "203 kata").
class Pill extends StatelessWidget {
  const Pill(this.text, {super.key, required this.color, this.filled = false});
  final String text;
  final Color color;
  final bool filled;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
    decoration: BoxDecoration(
      color: filled ? color : color.withValues(alpha: 0.12),
      borderRadius: BorderRadius.circular(999),
    ),
    child: Text(
      text,
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w800,
        color: filled ? Colors.white : color,
      ),
    ),
  );
}
