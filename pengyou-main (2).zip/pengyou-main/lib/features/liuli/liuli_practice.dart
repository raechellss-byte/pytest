import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';

import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_speech.dart' show speechScore;
import 'liuli_store.dart';

final _rng = Random();
final _hanRe = RegExp(r'[㐀-鿿]');

/// Buka latihan tata bahasa: satu pola ([g]) atau campuran 10 soal acak.
void startGrammarPractice(BuildContext context, {Grammar? g}) {
  final qs = g != null
      ? [...g.q]
      : ([for (final x in LiuliData.grammar) ...x.q]..shuffle(_rng)).take(10).toList();
  if (qs.isEmpty) return;
  Navigator.of(context).push(liuliRoute(GrammarPracticeScreen(
    title: g == null ? 'Latihan tata bahasa' : g.t.split(' — ').first,
    questions: qs,
  )));
}

// ============================================================
// Latihan tata bahasa: isi titik-titik & susun kalimat.
// ============================================================

class GrammarPracticeScreen extends StatefulWidget {
  const GrammarPracticeScreen({super.key, required this.title, required this.questions});
  final String title;
  final List<GramQ> questions;
  @override
  State<GrammarPracticeScreen> createState() => _GrammarPracticeScreenState();
}

class _GrammarPracticeScreenState extends State<GrammarPracticeScreen> {
  final store = LiuliStore.instance;
  late List<GramQ> qs;
  int i = 0, score = 0;
  String? chosen; // fill: opsi yang dipilih
  late List<String> opts;
  // order: ubin (indeks token) yang tersedia & yang sudah disusun
  List<int> pool = [], built = [];
  bool? ok; // null = belum dijawab

  @override
  void initState() {
    super.initState();
    qs = [...widget.questions];
    _setup();
  }

  GramQ get q => qs[i];

  void _setup() {
    chosen = null;
    ok = null;
    built = [];
    if (i >= qs.length) return;
    opts = [...q.o]..shuffle(_rng);
    pool = List.generate(q.tok.length, (k) => k)..shuffle(_rng);
    // Hindari urutan acak yang kebetulan sudah benar.
    if (pool.length > 1 && List.generate(pool.length, (k) => k).join() == pool.join()) {
      pool = pool.reversed.toList();
    }
  }

  void _answer(bool right) {
    store.logAnswer(right);
    if (right) {
      score++;
      store.registerActivity();
      store.award('gram');
    }
    if (store.auto) store.speak(q.full);
  }

  void _pick(String o) {
    if (ok != null) return;
    setState(() {
      chosen = o;
      ok = o == q.a;
    });
    _answer(ok!);
  }

  void _check() {
    final s = built.map((k) => q.tok[k]).join();
    setState(() => ok = s == q.tok.join());
    _answer(ok!);
  }

  void _next() => setState(() {
        i++;
        _setup();
      });

  @override
  Widget build(BuildContext context) {
    final done = i >= qs.length;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title, style: const TextStyle(fontSize: 17)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: LinearProgressIndicator(
            value: done ? 1 : i / qs.length,
            minHeight: 4,
            backgroundColor: LiuliColors.surface2,
            color: LiuliColors.jade,
          ),
        ),
      ),
      body: done ? _result() : _question(),
    );
  }

  Widget _result() {
    final pct = (score / qs.length * 100).round();
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(pct >= 70 ? '讚' : '加油', style: hanziStyle(size: 52, color: LiuliColors.jade)),
          const SizedBox(height: 10),
          Text('$score / ${qs.length} benar',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(pct >= 70 ? 'Pola kalimatmu sudah bagus!' : 'Baca lagi penjelasannya di Panduan, lalu coba lagi.',
              textAlign: TextAlign.center, style: TextStyle(color: LiuliColors.text2)),
          const SizedBox(height: 22),
          FilledButton(
            onPressed: () => setState(() {
              qs.shuffle(_rng);
              i = 0;
              score = 0;
              _setup();
            }),
            style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
            child: const Text('Coba lagi'),
          ),
          const SizedBox(height: 8),
          OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Selesai')),
        ]),
      ),
    );
  }

  Widget _question() {
    final fill = q.k == 'fill';
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Soal ${i + 1} / ${qs.length} · ${fill ? 'Isi bagian kosong' : 'Susun jadi kalimat'}',
            textAlign: TextAlign.center,
            style: TextStyle(color: LiuliColors.text2, fontWeight: FontWeight.w700)),
        const SizedBox(height: 18),
        if (fill) ...[
          Center(child: _blankSentence()),
          const SizedBox(height: 6),
          Center(
              child: Text(q.id,
                  textAlign: TextAlign.center, style: TextStyle(color: LiuliColors.text2))),
          const SizedBox(height: 20),
          for (final o in opts) _optBtn(o),
        ] else
          ..._orderBody(),
        if (ok != null) ..._feedback(),
      ],
    );
  }

  /// Kalimat dengan bagian kosong; setelah dijawab, isinya diwarnai.
  Widget _blankSentence() {
    final parts = q.q.split('___');
    // Setelah dijawab, bagian kosong selalu berisi jawaban benar (hijau);
    // pilihan yang salah sudah ditandai merah di daftar opsi.
    final fillText = ok == null ? '＿＿' : store.zh(q.a);
    final c = ok == null ? LiuliColors.jade : LiuliColors.good;
    return Text.rich(
      TextSpan(children: [
        TextSpan(text: store.zh(parts[0])),
        TextSpan(
            text: fillText,
            style: TextStyle(color: c, fontWeight: FontWeight.w900, decoration: TextDecoration.underline)),
        TextSpan(text: store.zh(parts.length > 1 ? parts[1] : '')),
      ]),
      textAlign: TextAlign.center,
      style: hanziStyle(size: 24, weight: FontWeight.w500),
    );
  }

  Widget _optBtn(String o) {
    Color? bg, border;
    if (ok != null) {
      if (o == q.a) {
        bg = LiuliColors.good.withValues(alpha: 0.14);
        border = LiuliColors.good;
      } else if (o == chosen) {
        bg = LiuliColors.again.withValues(alpha: 0.12);
        border = LiuliColors.again;
      }
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: ok == null ? () => _pick(o) : null,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
          decoration: BoxDecoration(
            color: bg ?? LiuliColors.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: border ?? LiuliColors.text3.withValues(alpha: 0.3), width: 1.5),
          ),
          child: Text(store.zh(o), textAlign: TextAlign.center, style: hanziStyle(size: 20)),
        ),
      ),
    );
  }

  List<Widget> _orderBody() {
    final locked = ok != null;
    return [
      Text(q.id,
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w700, color: LiuliColors.ink)),
      const SizedBox(height: 14),
      Container(
        constraints: const BoxConstraints(minHeight: 58),
        width: double.infinity,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: LiuliColors.surface2,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: ok == null ? Colors.transparent : (ok! ? LiuliColors.good : LiuliColors.again),
              width: 2),
        ),
        child: Wrap(spacing: 8, runSpacing: 8, children: [
          for (final k in built)
            _tile(q.tok[k], placed: true,
                onTap: locked ? null : () => setState(() {
                      built.remove(k);
                      pool.add(k);
                    })),
        ]),
      ),
      const SizedBox(height: 14),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final k in pool)
          _tile(q.tok[k],
              onTap: locked ? null : () => setState(() {
                    pool.remove(k);
                    built.add(k);
                  })),
      ]),
      const SizedBox(height: 16),
      if (ok == null)
        FilledButton(
          onPressed: pool.isEmpty ? _check : null,
          style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
          child: Text(pool.isEmpty ? 'Cek jawaban' : 'Pakai semua kata dulu'),
        ),
    ];
  }

  Widget _tile(String t, {bool placed = false, VoidCallback? onTap}) => InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: placed ? LiuliColors.jade : LiuliColors.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: LiuliColors.jade.withValues(alpha: 0.35)),
          ),
          child: Text(store.zh(t),
              style: hanziStyle(size: 19, color: placed ? Colors.white : LiuliColors.ink)),
        ),
      );

  List<Widget> _feedback() => [
        const SizedBox(height: 10),
        Text(ok! ? '正確！Benar 🎉' : 'Belum tepat — yang benar:',
            textAlign: TextAlign.center,
            style: TextStyle(
                fontWeight: FontWeight.w800, color: ok! ? LiuliColors.good : LiuliColors.again)),
        const SizedBox(height: 6),
        Center(child: Text(store.zh(q.full), style: hanziStyle(size: 22))),
        if (store.pinyin)
          Center(
            child: Text(q.p,
                textAlign: TextAlign.center,
                style: TextStyle(color: LiuliColors.jadeDeep, fontSize: 13)),
          ),
        const SizedBox(height: 8),
        Center(child: SayButton(text: q.full, compact: true)),
        Padding(
          padding: const EdgeInsets.only(top: 16),
          child: FilledButton(
            onPressed: _next,
            style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
            child: Text(i + 1 >= qs.length ? 'Lihat hasil' : 'Soal berikutnya →'),
          ),
        ),
      ];
}

// ============================================================
// Dialog situasi PMI: baca & dengar, atau latihan peran (kamu = B).
// ============================================================

class TalkScreen extends StatefulWidget {
  const TalkScreen({super.key, required this.talk, this.practice = false});
  final Talk talk;
  final bool practice;
  @override
  State<TalkScreen> createState() => _TalkScreenState();
}

class _TalkScreenState extends State<TalkScreen> {
  final store = LiuliStore.instance;
  late bool _practice = widget.practice;
  bool _py = true, _id = true;

  // Latihan peran.
  int _shown = 0; // jumlah baris yang sudah tampil
  int _score = 0, _asked = 0;
  List<TalkLine>? _choices;
  TalkLine? _picked;

  // Putar semua.
  bool _playing = false;
  int? _playingIdx;

  // Ucapkan kembali (pengenal suara).
  final SpeechToText _stt = SpeechToText();
  bool? _sttOk;
  bool _listening = false;
  int? _sayScore;

  List<TalkLine> get lines => widget.talk.lines;

  @override
  void initState() {
    super.initState();
    if (_practice) _restart();
  }

  @override
  void dispose() {
    _playing = false;
    _stt.stop();
    super.dispose();
  }

  // ---------- latihan peran ----------
  void _restart() {
    _shown = 0;
    _score = 0;
    _asked = 0;
    _advance();
  }

  /// Tampilkan baris lawan bicara berikutnya, berhenti di giliranmu (B).
  void _advance() {
    _picked = null;
    _choices = null;
    _sayScore = null;
    while (_shown < lines.length && !lines[_shown].mine) {
      _shown++;
    }
    if (_shown > 0 && !lines[_shown - 1].mine) store.speak(lines[_shown - 1].h);
    if (_shown < lines.length) _choices = _makeChoices(lines[_shown]);
  }

  List<TalkLine> _makeChoices(TalkLine right) {
    final others = [
      for (final t in LiuliData.dialogs)
        if (t.id != widget.talk.id) ...t.lines.where((l) => l.mine && l.h != right.h),
    ]..shuffle(_rng);
    return [right, ...others.take(2)]..shuffle(_rng);
  }

  void _choose(TalkLine l) {
    if (_picked != null) return;
    final right = lines[_shown];
    final ok = l.h == right.h;
    setState(() {
      _picked = l;
      _asked++;
      if (ok) _score++;
    });
    store.logAnswer(ok);
    if (ok) {
      store.registerActivity();
      store.award('talkline');
    }
    store.speak(right.h);
  }

  void _continue() {
    setState(() {
      _shown++; // baris B yang barusan dijawab
      _advance();
    });
    if (_shown >= lines.length) store.finishTalk(widget.talk.id);
  }

  // ---------- putar semua ----------
  Future<void> _playAll() async {
    if (_playing) {
      setState(() => _playing = false);
      return;
    }
    setState(() => _playing = true);
    for (var k = 0; k < lines.length && _playing && mounted; k++) {
      setState(() => _playingIdx = k);
      store.speak(lines[k].h);
      // Perkiraan lama ucapan (TTS tidak memberi tanda selesai yang andal di web).
      final n = _hanRe.allMatches(lines[k].h).length;
      await Future.delayed(Duration(milliseconds: 700 + 360 * n));
    }
    if (mounted) {
      setState(() {
        _playing = false;
        _playingIdx = null;
      });
    }
  }

  // ---------- ucapkan kembali ----------
  Future<void> _sayIt(String target) async {
    if (_listening) return;
    _sttOk ??= await _stt.initialize().catchError((_) => false);
    if (_sttOk != true) {
      if (mounted) setState(() => _sayScore = -1);
      return;
    }
    setState(() {
      _listening = true;
      _sayScore = null;
    });
    await _stt.listen(
      listenOptions: SpeechListenOptions(partialResults: false, localeId: 'zh_TW'),
      onResult: (r) {
        if (!r.finalResult) return;
        final alts = r.alternates.isNotEmpty
            ? r.alternates.map((a) => a.recognizedWords).toList()
            : [r.recognizedWords];
        if (mounted) {
          setState(() {
            _listening = false;
            _sayScore = speechScore(target, alts).score;
          });
          if ((_sayScore ?? 0) >= 65) store.award('speak');
        }
      },
    );
    // Berhenti otomatis bila tidak ada hasil.
    Timer(const Duration(seconds: 8), () {
      if (mounted && _listening) setState(() => _listening = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.talk;
    final done = _practice && _shown >= lines.length;
    final visible = _practice ? lines.take(_shown + (_picked != null ? 1 : 0)).toList() : lines;
    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
          Text('${t.zh} · lawan bicara: ${t.a}',
              style: TextStyle(fontSize: 11, color: LiuliColors.text3)),
        ]),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          Wrap(spacing: 8, runSpacing: 8, children: [
            _chip('📖 Baca & dengar', !_practice, () => setState(() {
                  _practice = false;
                  _playing = false;
                })),
            _chip('🎭 Latihan peran', _practice, () => setState(() {
                  _practice = true;
                  _playing = false;
                  _restart();
                })),
            _chip('Aa Pinyin', _py, () => setState(() => _py = !_py)),
            _chip('🇮🇩 Arti', _id, () => setState(() => _id = !_id)),
          ]),
          const SizedBox(height: 12),
          if (!_practice)
            Align(
              alignment: Alignment.centerLeft,
              child: OutlinedButton.icon(
                onPressed: _playAll,
                icon: Icon(_playing ? Icons.stop_rounded : Icons.play_arrow_rounded),
                label: Text(_playing ? 'Berhenti' : 'Putar semua'),
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 40)),
              ),
            )
          else
            Text('Kamu berperan sebagai "Kamu" (kanan). Dengarkan, lalu pilih jawaban yang tepat.',
                style: TextStyle(fontSize: 12.5, color: LiuliColors.text2)),
          const SizedBox(height: 12),
          for (var k = 0; k < visible.length; k++) _bubble(visible[k], highlight: _playingIdx == k),
          if (_practice && !done && _choices != null) _choiceCard(),
          if (done) _summary(),
        ],
      ),
    );
  }

  Widget _chip(String label, bool on, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: on ? LiuliColors.jadeTint : LiuliColors.surface2,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
                color: on ? LiuliColors.jade.withValues(alpha: 0.4) : Colors.transparent),
          ),
          child: Text(label,
              style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                  color: on ? LiuliColors.jadeDeep : LiuliColors.text2)),
        ),
      );

  Widget _bubble(TalkLine l, {bool highlight = false}) {
    final mine = l.mine;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
        child: GestureDetector(
          onTap: () => store.speak(l.h),
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
            decoration: BoxDecoration(
              color: mine ? LiuliColors.jadeTint : LiuliColors.card,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(16),
                topRight: const Radius.circular(16),
                bottomLeft: Radius.circular(mine ? 16 : 4),
                bottomRight: Radius.circular(mine ? 4 : 16),
              ),
              border: Border.all(
                  color: highlight
                      ? LiuliColors.jade
                      : LiuliColors.text3.withValues(alpha: 0.18),
                  width: highlight ? 2 : 1),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisSize: MainAxisSize.min, children: [
                Text(mine ? 'Kamu' : widget.talk.a,
                    style: TextStyle(
                        fontSize: 11, fontWeight: FontWeight.w800, color: LiuliColors.text3)),
                const SizedBox(width: 6),
                Icon(Icons.volume_up_rounded, size: 14, color: LiuliColors.jade),
              ]),
              const SizedBox(height: 2),
              Text(store.zh(l.h), style: hanziStyle(size: 19, weight: FontWeight.w500)),
              if (_py)
                Text(l.p,
                    style: TextStyle(
                        fontSize: 12.5, color: LiuliColors.jadeDeep, fontStyle: FontStyle.italic)),
              if (_id) Text(l.id, style: TextStyle(fontSize: 12.5, color: LiuliColors.text2)),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _choiceCard() {
    final right = lines[_shown];
    final answered = _picked != null;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(answered ? (_picked!.h == right.h ? '正確！Tepat 🎉' : 'Kurang tepat — jawaban yang cocok sudah tampil di atas')
              : 'Giliranmu — apa jawabanmu?',
              style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: !answered
                      ? LiuliColors.ink
                      : (_picked!.h == right.h ? LiuliColors.good : LiuliColors.again))),
          const SizedBox(height: 10),
          if (!answered)
            for (final c in _choices!)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => _choose(c),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: LiuliColors.surface2,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(store.zh(c.h), style: hanziStyle(size: 17, weight: FontWeight.w500)),
                      if (_py)
                        Text(c.p, style: TextStyle(fontSize: 12, color: LiuliColors.text2)),
                    ]),
                  ),
                ),
              )
          else ...[
            Row(children: [
              OutlinedButton.icon(
                onPressed: _listening ? null : () => _sayIt(right.h),
                icon: Icon(_listening ? Icons.hearing_rounded : Icons.mic_rounded),
                label: Text(_listening ? 'Mendengarkan…' : 'Ucapkan'),
                style: OutlinedButton.styleFrom(minimumSize: const Size(0, 42)),
              ),
              const SizedBox(width: 10),
              if (_sayScore != null)
                Expanded(
                  child: Text(
                      _sayScore! < 0
                          ? 'Penilaian suara belum didukung di browser ini — tirukan saja.'
                          : 'Skor ucapan $_sayScore${_sayScore! >= 85 ? ' · 完美！' : _sayScore! >= 65 ? ' · 不錯！' : ' · coba lagi'}',
                      style: TextStyle(fontSize: 12.5, color: LiuliColors.text2)),
                ),
            ]),
            const SizedBox(height: 10),
            FilledButton(
              onPressed: _continue,
              style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
              child: const Text('Lanjut →'),
            ),
          ],
        ]),
      ),
    );
  }

  Widget _summary() => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Text(_score == _asked ? '讚' : '加油', style: hanziStyle(size: 40, color: LiuliColors.jade)),
            const SizedBox(height: 4),
            Text('$_score / $_asked jawaban tepat',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text('Ulangi sampai lancar, lalu coba ucapkan semua bagianmu tanpa melihat.',
                textAlign: TextAlign.center, style: TextStyle(color: LiuliColors.text2)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: OutlinedButton(
                    onPressed: () => setState(_restart), child: const Text('Ulangi')),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  onPressed: () => Navigator.pop(context),
                  style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
                  child: const Text('Selesai'),
                ),
              ),
            ]),
          ]),
        ),
      );
}
