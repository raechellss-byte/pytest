import 'dart:math';

import 'package:flutter/material.dart';

import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_store.dart';
import 'liuli_write.dart';

class _QueueItem {
  _QueueItem(this.v, this.fresh);
  final Vocab v;
  final bool fresh;
}

/// Mulai sesi belajar (dipush sebagai layar penuh).
void startLiuliStudy(BuildContext context,
    {bool Function(Vocab)? pred, String? label, List<Vocab>? explicit}) {
  Navigator.of(context)
      .push(liuliRoute(StudyScreen(pred: pred, label: label, explicit: explicit)));
}

/// Tab "Belajar" — entri sesi harian.
class LiuliStudyEntry extends StatelessWidget {
  const LiuliStudyEntry({super.key, required this.onGoTab});
  final void Function(int) onGoTab;

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    final due = store.dueCount;
    final fresh = min(store.newCount, store.newPerDay);
    final startable = due + fresh;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
      children: [
        LiuliBanner(
          stats: [
            ('${LiuliData.vocab.length}', 'kata'),
            ('${{for (final v in LiuliData.vocab) v.lv}.length}', 'level TOCFL'),
            ('${store.masteredCount}', 'dikuasai'),
          ],
          mark: '學',
        ),
        const SizedBox(height: 18),
        Center(child: Text('開始', style: hanziStyle(size: 44, color: LiuliColors.jade))),
        const SizedBox(height: 14),
        Text(
            'Pilih topik atau level di Beranda, atau mulai sesi harian gabungan '
            '(kartu jatuh tempo + kata baru).',
            textAlign: TextAlign.center,
            style: TextStyle(color: LiuliColors.text2, height: 1.5)),
        const SizedBox(height: 20),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _stat('$due', 'Jatuh tempo', LiuliColors.seal),
                  _stat('$fresh', 'Kata baru', LiuliColors.jade),
                  _stat('${store.masteredCount}', 'Dikuasai', LiuliColors.gold),
                ],
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: startable > 0
                    ? () => startLiuliStudy(context, pred: null, label: null)
                    : null,
                icon: const Icon(Icons.play_arrow),
                label: Text(startable > 0
                    ? 'Mulai sesi harian · $startable kartu'
                    : 'Semua beres hari ini 🎉'),
                style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: () => onGoTab(0),
          icon: const Icon(Icons.grid_view),
          label: const Text('Pilih topik / level di Beranda'),
        ),
      ],
    );
  }

  Widget _stat(String b, String s, Color c) => Column(children: [
        Text(b,
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: c)),
        Text(s, style: TextStyle(fontSize: 11.5, color: LiuliColors.text2)),
      ]);
}

class StudyScreen extends StatefulWidget {
  const StudyScreen({super.key, this.pred, this.label, this.explicit});
  final bool Function(Vocab)? pred;
  final String? label;
  final List<Vocab>? explicit;

  @override
  State<StudyScreen> createState() => _StudyScreenState();
}

class _StudyScreenState extends State<StudyScreen> {
  final _rng = Random();
  late List<_QueueItem> _queue;
  int _total = 0;
  int _done = 0;
  bool _revealed = false;
  String _mode = 'recog';
  bool _finished = false;

  @override
  void initState() {
    super.initState();
    final store = LiuliStore.instance;
    List<_QueueItem> q;
    if (widget.explicit != null) {
      final due = widget.explicit!.where((v) => store.isDue(v.h)).toList();
      final fresh = widget.explicit!.where((v) => store.isNew(v.h)).toList();
      final other = widget.explicit!
          .where((v) => !store.isDue(v.h) && !store.isNew(v.h))
          .toList();
      q = [
        ..._shuffle(due).map((v) => _QueueItem(v, false)),
        ..._shuffle(fresh).map((v) => _QueueItem(v, true)),
        ..._shuffle(other).map((v) => _QueueItem(v, false)),
      ];
    } else {
      final due = store.dueList(widget.pred);
      final fresh = store.newList(widget.pred).take(store.newPerDay).toList();
      q = [
        ..._shuffle(due).map((v) => _QueueItem(v, false)),
        ..._shuffle(fresh).map((v) => _QueueItem(v, true)),
      ];
      q = _shuffle(q);
    }
    _queue = q;
    _total = q.length;
    _finished = q.isEmpty;
    _pickMode();
  }

  List<T> _shuffle<T>(List<T> a) {
    final b = [...a];
    b.shuffle(_rng);
    return b;
  }

  void _pickMode() {
    final dir = LiuliStore.instance.dir;
    _mode = dir == 'mix' ? (_rng.nextBool() ? 'prod' : 'recog') : dir;
  }

  void _reveal() {
    setState(() => _revealed = true);
    final store = LiuliStore.instance;
    if (store.auto) store.speak(_queue.first.v.h);
  }

  void _grade(String g) {
    final store = LiuliStore.instance;
    final cur = _queue.first;
    final msg = store.grade(cur.v, g);
    if (msg != null && mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(msg)));
    }
    _queue.removeAt(0);
    if (g == 'again') {
      _queue.add(cur);
    } else {
      _done++;
    }
    if (_queue.isEmpty) {
      setState(() => _finished = true);
    } else {
      setState(() {
        _revealed = false;
        _pickMode();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.label ?? 'Sesi harian', style: const TextStyle(fontSize: 17)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: LinearProgressIndicator(
            value: _total == 0 ? 1 : _done / _total,
            backgroundColor: LiuliColors.surface2,
            color: LiuliColors.jade,
            minHeight: 4,
          ),
        ),
      ),
      body: _finished ? _buildDone(store) : _buildCard(store),
    );
  }

  Widget _buildDone(LiuliStore store) {
    final none = _total == 0;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(none ? '✓' : '太棒了',
              style: hanziStyle(size: none ? 60 : 46, color: LiuliColors.jade)),
          const SizedBox(height: 12),
          Text(none ? 'Tidak ada yang jatuh tempo' : 'Sesi selesai!',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(
            none
                ? '${widget.label != null ? '“${widget.label}” sudah kamu ulang. ' : ''}Coba topik/level lain, atau kembali besok saat kartunya matang.'
                : 'Kerja bagus. Balik lagi besok — kartunya akan matang tepat waktu.',
            textAlign: TextAlign.center,
            style: TextStyle(color: LiuliColors.text2, height: 1.5),
          ),
          if (!none) ...[
            const SizedBox(height: 20),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              _doneStat('$_total', 'KARTU'),
              _doneStat('${store.streak}', 'RENTETAN'),
              _doneStat('${store.masteredCount}', 'DIKUASAI'),
            ]),
          ],
          const SizedBox(height: 24),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(),
            style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
            child: const Text('Selesai'),
          ),
        ]),
      ),
    );
  }

  Widget _doneStat(String b, String s) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Column(children: [
          Text(b,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          Text(s,
              style: TextStyle(
                  fontSize: 10.5,
                  letterSpacing: 0.5,
                  color: LiuliColors.text2)),
        ]),
      );

  Widget _buildCard(LiuliStore store) {
    final v = _queue.first.v;
    final dk = LiuliData.decks.where((d) => d.id == v.deck).firstOrNull;
    final emo = LiuliData.emo[v.h];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('${(_done + 1).clamp(1, _total)} / $_total',
            textAlign: TextAlign.center,
            style: TextStyle(color: LiuliColors.text3, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: _revealed ? null : _reveal,
          child: Container(
            constraints: const BoxConstraints(minHeight: 260),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: LiuliColors.card,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.brown.withValues(alpha: 0.08)),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 16,
                    offset: const Offset(0, 6)),
              ],
            ),
            child: Column(children: [
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                _chip(dk != null ? store.zh(dk.name) : 'Koleksi',
                    LiuliColors.jadeTint, LiuliColors.jadeDeep),
                if (v.lv > 0) ...[
                  const SizedBox(width: 6),
                  _chip('TOCFL ${v.lv}', LiuliColors.surface2, LiuliColors.text2),
                ],
              ]),
              const SizedBox(height: 20),
              if (!_revealed)
                _front(store, v, emo)
              else
                _revealFace(store, v, emo),
            ]),
          ),
        ),
        const SizedBox(height: 16),
        if (!_revealed)
          Text('Ketuk kartu untuk melihat jawaban',
              textAlign: TextAlign.center,
              style: TextStyle(color: LiuliColors.text3))
        else
          _grades(),
      ],
    );
  }

  Widget _front(LiuliStore store, Vocab v, String? emo) {
    if (_mode == 'prod') {
      return Column(children: [
        if (emo != null) Text(emo, style: const TextStyle(fontSize: 44)),
        const SizedBox(height: 6),
        Text(v.id,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, height: 1.3)),
        const SizedBox(height: 14),
        Text('Ucapkan dalam 中文, lalu ketuk untuk cek',
            textAlign: TextAlign.center,
            style: TextStyle(color: LiuliColors.text3, fontSize: 13)),
      ]);
    }
    return Column(children: [
      Text(store.zh(v.h), style: hanziStyle(size: 74, color: LiuliColors.ink)),
      const SizedBox(height: 14),
      Text('Apa artinya? Ketuk untuk buka',
          textAlign: TextAlign.center,
          style: TextStyle(color: LiuliColors.text3, fontSize: 13)),
    ]);
  }

  Widget _revealFace(LiuliStore store, Vocab v, String? emo) {
    return Column(children: [
      if (emo != null) Text(emo, style: const TextStyle(fontSize: 40)),
      Text(store.zh(v.h), style: hanziStyle(size: 56, color: LiuliColors.ink)),
      if (store.zhuyin && v.z.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(v.z,
              style: TextStyle(fontSize: 16, color: LiuliColors.text2)),
        ),
      if (store.pinyin)
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Text(v.p,
              style: TextStyle(
                  fontSize: 16,
                  fontStyle: FontStyle.italic,
                  color: LiuliColors.jadeDeep,
                  fontWeight: FontWeight.w700)),
        ),
      const SizedBox(height: 6),
      if (v.pos.isNotEmpty)
        Text(v.pos, style: TextStyle(fontSize: 12, color: LiuliColors.text3)),
      const SizedBox(height: 2),
      Text(v.id,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
        SayButton(text: v.h),
        OutlinedButton.icon(
          onPressed: () => openWriterDialog(context, v.h, v.p, v.id),
          icon: const Text('✍', style: TextStyle(fontSize: 15)),
          label: const Text('Tulis'),
          style: OutlinedButton.styleFrom(
              minimumSize: const Size(0, 40),
              foregroundColor: LiuliColors.jadeDeep),
        ),
      ]),
      if (v.ex.isNotEmpty) ...[
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: LiuliColors.surface2,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(store.zh(v.ex), style: hanziStyle(size: 20, weight: FontWeight.w500)),
            if (store.pinyin && v.exp.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(v.exp,
                    style: TextStyle(
                        fontSize: 13, color: LiuliColors.jadeDeep)),
              ),
            const SizedBox(height: 3),
            Text(v.exid, style: TextStyle(fontSize: 13, color: LiuliColors.text2)),
            const SizedBox(height: 8),
            SayButton(text: v.ex, label: 'Contoh kalimat'),
          ]),
        ),
      ],
    ]);
  }

  Widget _grades() {
    Widget g(String key, String title, String sub, Color color) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => _grade(key),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: color.withValues(alpha: 0.4)),
                ),
                child: Column(children: [
                  Text(title,
                      style: TextStyle(
                          fontWeight: FontWeight.w800, color: color, fontSize: 14)),
                  const SizedBox(height: 2),
                  Text(sub,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 10.5, color: LiuliColors.text2)),
                ]),
              ),
            ),
          ),
        );
    return Column(children: [
      Text('Seberapa ingat kamu tadi? Pilihanmu menentukan kapan kartu muncul lagi:',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12, color: LiuliColors.text2)),
      const SizedBox(height: 10),
      Row(children: [
        g('again', 'Lagi', 'belum ingat', LiuliColors.again),
        g('hard', 'Susah', 'hampir lupa', LiuliColors.hard),
        g('good', 'Bagus', 'sudah ingat', LiuliColors.good),
        g('easy', 'Mudah', 'hafal betul', LiuliColors.easy),
      ]),
    ]);
  }

  Widget _chip(String t, Color bg, Color fg) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(999)),
        child: Text(t,
            style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: fg)),
      );
}
