import 'dart:math';

import 'package:flutter/material.dart';

import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_exam.dart' show LiuliExamIntro;
import 'liuli_practice.dart' show startGrammarPractice;
import 'liuli_speech.dart';
import 'liuli_store.dart';
import 'liuli_study.dart' show startLiuliStudy;
import 'liuli_typing.dart' show ZhuyinTypingScreen;

class LiuliQuizHome extends StatelessWidget {
  const LiuliQuizHome({super.key, required this.onGoTab});
  final void Function(int) onGoTab;

  /// (kode, ikon, judul, keterangan, gradasi, lencana)
  static const _modes = <(String, IconData, String, String, List<Color>, String?)>[
    ('type', Icons.keyboard_rounded, 'Ketik Zhuyin 注音', 'Hanzi tampil, ketik zhuyin-nya',
        [Color(0xFF1F7A4D), Color(0xFF34A86E)], null),
    ('dict', Icons.hearing_rounded, 'Dikte 聽寫', 'Dengar kata, ketik zhuyin-nya',
        [Color(0xFF1E5FA8), Color(0xFF4A90D9)], null),
    ('talk', Icons.forum_rounded, 'Dialog 對話', 'Latihan peran situasi PMI',
        [Color(0xFF0B6E99), Color(0xFF3A9BC4)], 'Baru'),
    ('gram', Icons.rule_rounded, 'Tata bahasa 語法', 'Isi & susun pola kalimat',
        [Color(0xFF7A4E2D), Color(0xFFA9744A)], 'Baru'),
    ('speak', Icons.mic_rounded, 'Bicara 口說', 'Ucapkan kalimat, dapat skor',
        [Color(0xFFB83227), Color(0xFFE0604C)], null),
    ('zh2id', Icons.translate_rounded, '中文 → Arti', 'Lihat karakter, pilih artinya',
        [Color(0xFF0E7C7E), Color(0xFF2FA9A0)], null),
    ('id2zh', Icons.abc_rounded, 'Arti → 中文', 'Lihat arti, pilih karakternya',
        [Color(0xFF6A45B8), Color(0xFF9473D8)], null),
    ('audio', Icons.volume_up_rounded, 'Dengar → 中文', 'Dengar audio, pilih karakter',
        [Color(0xFF2B7A64), Color(0xFF4FA88F)], null),
    ('build', Icons.view_week_rounded, 'Susun kalimat 排列', 'Rangkai kata jadi kalimat',
        [Color(0xFFA9661C), Color(0xFFD08A35)], null),
    ('cloze', Icons.short_text_rounded, 'Kalimat rumpang', 'Isi kata yang hilang',
        [Color(0xFFC0561F), Color(0xFFE07B3C)], null),
    ('tone', Icons.show_chart_rounded, 'Nada 聲調', 'Dengar, lalu tebak nadanya',
        [Color(0xFFA2346D), Color(0xFFCF5C95)], null),
    ('mw', Icons.numbers_rounded, 'Kata bantu 量詞', 'Pilih pengukur yang tepat',
        [Color(0xFF4E5D72), Color(0xFF7887A0)], null),
  ];

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    final due = store.dueCount;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        Text('UJI DIRI',
            style: TextStyle(
                fontSize: 11,
                letterSpacing: 1,
                fontWeight: FontWeight.w700,
                color: LiuliColors.jade)),
        const SizedBox(height: 4),
        Text('Kuis & Latihan', style: hanziStyle(size: 24, color: LiuliColors.ink)),
        const SizedBox(height: 12),
        LiuliBanner(
          stats: [
            ('${_modes.length}', 'mode latihan'),
            ('${store.streak}', 'hari rentetan'),
          ],
          mark: '考',
          color: LiuliColors.seal,
        ),
        const SizedBox(height: 12),
        // Ulas SRS: hanya kartu yang jatuh tempo.
        Card(
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: due > 0
                ? () => startLiuliStudy(context,
                    explicit: store.dueList(), label: 'Ulas SRS')
                : null,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: Mastery.learning.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: const Icon(Icons.event_repeat_rounded,
                      color: Mastery.learning),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Ulas SRS',
                          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                      Text(
                          due > 0
                              ? '$due kata jatuh tempo hari ini'
                              : 'Tidak ada ulasan hari ini 🎉',
                          style: TextStyle(fontSize: 12, color: LiuliColors.text2)),
                    ],
                  ),
                ),
                if (due > 0) Pill('$due', color: Mastery.learning, filled: true),
                const SizedBox(width: 4),
                Icon(Icons.chevron_right,
                    color: due > 0 ? Colors.grey : Colors.grey.shade300),
              ]),
            ),
          ),
        ),
        // Simulasi ujian TOCFL.
        Card(
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () => Navigator.of(context).push(liuliRoute(const LiuliExamIntro())),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                Container(
                  width: 44,
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: const Color(0xFF6A45B8).withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: const Icon(Icons.assignment_rounded, color: Color(0xFF6A45B8)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Simulasi ujian TOCFL 模擬考',
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                    Text(
                        store.examBest.isEmpty
                            ? '20 soal mendengar & membaca · 20 menit'
                            : 'Skor terbaik: ${store.examBest.entries.map((e) => 'Band ${e.key} ${e.value}%').join(' · ')}',
                        style: TextStyle(fontSize: 12, color: LiuliColors.text2)),
                  ]),
                ),
                const Pill('Baru', color: Color(0xFF6A45B8)),
                const SizedBox(width: 4),
                const Icon(Icons.chevron_right, color: Colors.grey),
              ]),
            ),
          ),
        ),
        const SectionHead('Mode latihan', trailing: 'soal acak dari kosakatamu'),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.32,
          children: [
            for (final m in _modes)
              ModeTile(
                icon: m.$2,
                title: m.$3,
                sub: m.$4,
                colors: m.$5,
                badge: m.$6,
                onTap: () => _open(context, m.$1),
              ),
          ],
        ),
      ],
    );
  }

  void _open(BuildContext context, String mode) {
    if (mode == 'talk') return onGoTab(2); // daftar dialog ada di tab Kalimat
    if (mode == 'gram') return startGrammarPractice(context);
    final Widget page = switch (mode) {
      'type' => const ZhuyinTypingScreen(initialMode: 'word'),
      'dict' => const ZhuyinTypingScreen(initialMode: 'dict'),
      'speak' => const SpeakQuizScreen(),
      _ => QuizScreen(mode: mode),
    };
    Navigator.of(context).push(liuliRoute(page));
  }
}

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key, required this.mode});
  final String mode;
  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  final _rng = Random();
  late List pool;
  int i = 0;
  int score = 0;
  bool answered = false;
  String? chosen; // for MC: the hanzi/id chosen or tone/mw value
  // build state
  List<_Tile> tiles = [];
  List<int> order = [];
  bool? buildCorrect;

  final store = LiuliStore.instance;

  List<T> _sh<T>(List<T> a) {
    final b = [...a];
    b.shuffle(_rng);
    return b;
  }

  @override
  void initState() {
    super.initState();
    switch (widget.mode) {
      case 'tone':
        pool = _sh(LiuliData.toneSyl).take(10).toList();
        break;
      case 'cloze':
        pool = _sh(LiuliData.vocab.where((v) => v.ex.contains(v.h)).toList())
            .take(10)
            .toList();
        break;
      case 'build':
        pool = _sh(LiuliData.build).take(8).toList();
        break;
      case 'mw':
        pool = _sh(LiuliData.mw).take(10).toList();
        break;
      default:
        pool = _sh(LiuliData.vocab).take(10).toList();
    }
    if (widget.mode == 'build') _setupBuild();
    _autoPlay();
  }

  void _autoPlay() {
    if (i >= pool.length) return;
    if (widget.mode == 'audio' || widget.mode == 'tone') {
      final it = pool[i];
      final h = widget.mode == 'tone' ? (it as ToneItem).h : (it as Vocab).h;
      Future.delayed(const Duration(milliseconds: 350), () => store.speak(h));
    }
  }

  void _next() {
    setState(() {
      i++;
      answered = false;
      chosen = null;
      buildCorrect = null;
      if (widget.mode == 'build' && i < pool.length) _setupBuild();
    });
    _autoPlay();
  }

  void _setupBuild() {
    final s = pool[i] as BuildItem;
    final decoys = _sh(LiuliData.buildTokens.where((x) => !s.tok.contains(x)).toList())
        .take(2)
        .toList();
    tiles = _sh([...s.tok, ...decoys])
        .asMap()
        .entries
        .map((e) => _Tile(e.key, e.value))
        .toList();
    order = [];
  }

  @override
  Widget build(BuildContext context) {
    final done = i >= pool.length;
    return Scaffold(
      appBar: AppBar(
        title: Text(_title, style: const TextStyle(fontSize: 17)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: LinearProgressIndicator(
            value: pool.isEmpty ? 1 : (done ? 1 : i / pool.length),
            backgroundColor: LiuliColors.surface2,
            color: LiuliColors.jade,
            minHeight: 4,
          ),
        ),
      ),
      body: done ? _buildResult() : _buildQuestion(),
    );
  }

  String get _title => switch (widget.mode) {
        'zh2id' => '中文 → Arti',
        'id2zh' => 'Arti → 中文',
        'audio' => 'Dengar → 中文',
        'cloze' => 'Kalimat rumpang',
        'build' => 'Susun kalimat',
        'tone' => 'Nada 聲調',
        'mw' => 'Kata bantu 量詞',
        _ => 'Kuis',
      };

  Widget _buildResult() {
    final pct = pool.isEmpty ? 0 : (score / pool.length * 100).round();
    final msg = pct >= 90
        ? '厲害！Nyaris sempurna.'
        : pct >= 70
            ? '不錯！Bagus, terus lanjut.'
            : pct >= 50
                ? '加油！Ulang kata yang meleset.'
                : '沒關係, pelan-pelan pasti bisa.';
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(pct >= 70 ? '讚' : '加油',
              style: hanziStyle(size: 52, color: LiuliColors.jade)),
          const SizedBox(height: 10),
          Text('$score / ${pool.length} benar',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(msg,
              textAlign: TextAlign.center,
              style: TextStyle(color: LiuliColors.text2)),
          const SizedBox(height: 22),
          FilledButton(
            onPressed: () {
              setState(() {
                i = 0;
                score = 0;
                answered = false;
                chosen = null;
                pool = _sh(pool);
                if (widget.mode == 'build') _setupBuild();
              });
              _autoPlay();
            },
            style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
            child: const Text('Coba lagi'),
          ),
          const SizedBox(height: 8),
          OutlinedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Selesai')),
        ]),
      ),
    );
  }

  Widget _buildQuestion() {
    switch (widget.mode) {
      case 'tone':
        return _toneQ();
      case 'mw':
        return _mwQ();
      case 'build':
        return _buildQ();
      case 'cloze':
        return _clozeQ();
      default:
        return _mcQ();
    }
  }

  Widget _qhead(String ask) => Text('Soal ${i + 1} / ${pool.length} · $ask',
      textAlign: TextAlign.center,
      style: TextStyle(color: LiuliColors.text2, fontWeight: FontWeight.w700));

  Widget _nextBtn() => Padding(
        padding: const EdgeInsets.only(top: 16),
        child: FilledButton(
          onPressed: _next,
          style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
          child: Text(i + 1 >= pool.length ? 'Lihat hasil' : 'Soal berikutnya →'),
        ),
      );

  // ---- Recognition / audio ----
  Widget _mcQ() {
    final v = pool[i] as Vocab;
    final distract = _sh(LiuliData.vocab.where((x) => x.h != v.h).toList()).take(3);
    final opts = _sh([v, ...distract]);
    final mode = widget.mode;
    Widget center;
    String ask;
    if (mode == 'zh2id') {
      ask = 'Apa arti kata ini?';
      center = Column(children: [
        Text(store.zh(v.h), style: hanziStyle(size: 52)),
        if (store.pinyin)
          Text(v.p,
              style: TextStyle(
                  color: LiuliColors.jadeDeep, fontStyle: FontStyle.italic)),
      ]);
    } else if (mode == 'id2zh') {
      ask = 'Mana karakter yang benar?';
      center = Text(v.id,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700));
    } else {
      ask = 'Dengar, lalu pilih karakternya';
      center = SayButton(text: v.h, label: 'Putar lagi');
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _qhead(ask),
        const SizedBox(height: 20),
        Center(child: center),
        const SizedBox(height: 24),
        for (final o in opts)
          _optBtn(
            label: mode == 'zh2id' ? o.id : store.zh(o.h),
            correct: o.h == v.h,
            selected: chosen == o.h,
            onTap: () => setState(() {
              answered = true;
              chosen = o.h;
              store.logAnswer(o.h == v.h);
              if (o.h == v.h) store.award('quiz');
              if (o.h == v.h) {
                score++;
              } else {
                store.recordMiss(v.h);
              }
            }),
          ),
        if (answered) _nextBtn(),
      ],
    );
  }

  Widget _clozeQ() {
    final v = pool[i] as Vocab;
    var distract =
        _sh(LiuliData.vocab.where((x) => x.h != v.h && x.h.length == v.h.length).toList())
            .take(3)
            .toList();
    if (distract.length < 3) {
      distract = [
        ...distract,
        ..._sh(LiuliData.vocab.where((x) => x.h != v.h && !distract.contains(x)).toList())
            .take(3 - distract.length)
      ];
    }
    final opts = _sh([v, ...distract]);
    final sentence = answered
        ? store.zh(v.ex).replaceFirst(store.zh(v.h), '【${store.zh(v.h)}】')
        : store.zh(v.ex).replaceFirst(store.zh(v.h), ' ____ ');
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _qhead('Isi kata yang hilang'),
        const SizedBox(height: 18),
        Center(child: Text(sentence, style: hanziStyle(size: 24, weight: FontWeight.w500))),
        const SizedBox(height: 6),
        Center(
            child: Text(v.exid,
                textAlign: TextAlign.center,
                style: TextStyle(color: LiuliColors.text2))),
        const SizedBox(height: 20),
        for (final o in opts)
          _optBtn(
            label: store.zh(o.h),
            correct: o.h == v.h,
            selected: chosen == o.h,
            onTap: () => setState(() {
              answered = true;
              chosen = o.h;
              store.logAnswer(o.h == v.h);
              if (o.h == v.h) store.award('quiz');
              if (o.h == v.h) {
                score++;
              } else {
                store.recordMiss(v.h);
              }
              if (store.auto) store.speak(v.ex);
            }),
          ),
        if (answered) ...[
          const SizedBox(height: 10),
          Center(child: SayButton(text: v.ex, label: 'Dengar kalimat')),
          const SizedBox(height: 6),
          Center(
              child: Text('${v.h} ${v.p} · ${v.id}',
                  style: TextStyle(fontSize: 12, color: LiuliColors.text2))),
          _nextBtn(),
        ],
      ],
    );
  }

  Widget _toneQ() {
    final it = pool[i] as ToneItem;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _qhead('Nada berapa yang kamu dengar?'),
        const SizedBox(height: 16),
        Center(child: SayButton(text: it.h, label: 'Putar lagi')),
        const SizedBox(height: 20),
        for (final t in [1, 2, 3, 4])
          _optRow(
            leading: ToneIcon(t, size: 22, color: _optColor(it.tone == t, chosen == '$t')),
            title: 'Nada $t',
            sub: LiuliData.toneEx[t] ?? '',
            correct: it.tone == t,
            selected: chosen == '$t',
            onTap: () => setState(() {
              answered = true;
              chosen = '$t';
              store.logAnswer(it.tone == t);
              if (it.tone == t) store.award('quiz');
              if (it.tone == t) score++;
            }),
          ),
        if (answered) ...[
          const SizedBox(height: 12),
          Center(
            child: Column(children: [
              Text(it.h, style: hanziStyle(size: 36)),
              Text('${it.p} · ${it.id}',
                  style: TextStyle(
                      color: LiuliColors.jadeDeep, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(LiuliData.toneDesc[it.tone] ?? '',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12.5, color: LiuliColors.text2)),
            ]),
          ),
          _nextBtn(),
        ],
      ],
    );
  }

  Widget _mwQ() {
    final it = pool[i] as List<String>; // [word, id, mw]
    final allMw = {...LiuliData.mw.map((m) => m[2]), '個'}.toList();
    final opts = _sh([it[2], ..._sh(allMw.where((m) => m != it[2]).toList()).take(3)]);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _qhead('Kata bantu bilangan yang tepat?'),
        const SizedBox(height: 18),
        Center(
            child: Text('一 ◯ ${it[0]}',
                style: hanziStyle(size: 40))),
        Center(
            child: Text('satu ___ ${it[1]}',
                style: TextStyle(color: LiuliColors.text2))),
        const SizedBox(height: 20),
        for (final m in opts)
          _optRow(
            title: m,
            sub: LiuliData.mwPy[m] ?? '',
            correct: m == it[2],
            selected: chosen == m,
            onTap: () => setState(() {
              answered = true;
              chosen = m;
              store.logAnswer(m == it[2]);
              if (m == it[2]) store.award('quiz');
              if (m == it[2]) score++;
              final phrase = '一${it[2]}${it[0]}';
              if (store.auto) store.speak(phrase);
            }),
          ),
        if (answered) ...[
          const SizedBox(height: 12),
          Center(
            child: Column(children: [
              Text('一${it[2]}${it[0]}', style: hanziStyle(size: 30)),
              const SizedBox(height: 4),
              SayButton(text: '一${it[2]}${it[0]}', compact: true),
            ]),
          ),
          _nextBtn(),
        ],
      ],
    );
  }

  Widget _buildQ() {
    final s = pool[i] as BuildItem;
    final used = order.toSet();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _qhead('Susun jadi kalimat Mandarin'),
        const SizedBox(height: 14),
        Text(s.id,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15, color: LiuliColors.text2)),
        const SizedBox(height: 16),
        Container(
          constraints: const BoxConstraints(minHeight: 56),
          width: double.infinity,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: LiuliColors.surface2,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: buildCorrect == null
                    ? Colors.transparent
                    : (buildCorrect! ? LiuliColors.good : LiuliColors.again),
                width: 2),
          ),
          child: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final oid in order)
                _tileBtn(tiles[oid].text, placed: true,
                    onTap: buildCorrect != null
                        ? null
                        : () => setState(() => order.remove(oid))),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final t in tiles.where((t) => !used.contains(t.id)))
              _tileBtn(t.text,
                  onTap: buildCorrect != null
                      ? null
                      : () => setState(() => order.add(t.id))),
          ],
        ),
        const SizedBox(height: 16),
        if (buildCorrect == null)
          FilledButton(
            onPressed: order.isEmpty ? null : _checkBuild,
            style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
            child: const Text('Cek jawaban'),
          )
        else ...[
          Text(buildCorrect! ? '正確！Benar 🎉' : 'Belum tepat — jawaban yang benar:',
              style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: buildCorrect! ? LiuliColors.good : LiuliColors.again)),
          const SizedBox(height: 6),
          Text(store.zh(s.tok.join()), style: hanziStyle(size: 22)),
          if (store.pinyin)
            Text(s.p,
                style: TextStyle(
                    color: LiuliColors.jadeDeep, fontSize: 13)),
          const SizedBox(height: 8),
          SayButton(text: s.tok.join(), compact: true),
          _nextBtn(),
        ],
      ],
    );
  }

  void _checkBuild() {
    final s = pool[i] as BuildItem;
    final built = order.map((id) => tiles[id].text).join();
    final ok = built == s.tok.join();
    store.logAnswer(ok);
    if (ok) store.award('quiz');
    setState(() {
      buildCorrect = ok;
      if (ok) score++;
    });
    if (ok) {
      store.registerActivity();
      if (store.auto) store.speak(s.tok.join());
    }
  }

  // ---- shared option widgets ----
  Color _optColor(bool correct, bool selected) {
    if (!answered) return LiuliColors.jade;
    if (correct) return LiuliColors.good;
    if (selected) return LiuliColors.again;
    return Colors.grey;
  }

  Widget _optBtn({
    required String label,
    required bool correct,
    required bool selected,
    required VoidCallback onTap,
  }) {
    Color? bg, border, fg;
    if (answered) {
      if (correct) {
        bg = LiuliColors.good.withValues(alpha: 0.14);
        border = LiuliColors.good;
        fg = LiuliColors.good;
      } else if (selected) {
        bg = LiuliColors.again.withValues(alpha: 0.14);
        border = LiuliColors.again;
        fg = LiuliColors.again;
      }
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: answered ? null : onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 16),
          decoration: BoxDecoration(
            color: bg ?? LiuliColors.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: border ?? Colors.brown.withValues(alpha: 0.12), width: 1.5),
          ),
          child: Text(label,
              style: TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w700, color: fg)),
        ),
      ),
    );
  }

  Widget _optRow({
    Widget? leading,
    required String title,
    required String sub,
    required bool correct,
    required bool selected,
    required VoidCallback onTap,
  }) {
    Color? bg, border;
    if (answered) {
      if (correct) {
        bg = LiuliColors.good.withValues(alpha: 0.14);
        border = LiuliColors.good;
      } else if (selected) {
        bg = LiuliColors.again.withValues(alpha: 0.14);
        border = LiuliColors.again;
      }
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: answered ? null : onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 16),
          decoration: BoxDecoration(
            color: bg ?? LiuliColors.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: border ?? Colors.brown.withValues(alpha: 0.12), width: 1.5),
          ),
          child: Row(children: [
            if (leading != null) ...[leading, const SizedBox(width: 12)],
            Text(title,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(width: 8),
            Text(sub, style: TextStyle(color: LiuliColors.text3, fontSize: 12)),
          ]),
        ),
      ),
    );
  }

  Widget _tileBtn(String text, {bool placed = false, VoidCallback? onTap}) => InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: placed ? LiuliColors.jade : LiuliColors.card,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
                color: placed ? LiuliColors.jade : Colors.brown.withValues(alpha: 0.2)),
          ),
          child: Text(store.zh(text),
              style: hanziStyle(
                  size: 18,
                  weight: FontWeight.w600,
                  color: placed ? Colors.white : LiuliColors.ink)),
        ),
      );
}

class _Tile {
  _Tile(this.id, this.text);
  final int id;
  final String text;
}
