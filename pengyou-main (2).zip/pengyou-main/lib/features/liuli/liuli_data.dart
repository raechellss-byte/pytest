import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

/// ===== Model =====

class Vocab {
  Vocab({
    required this.idx,
    required this.deck,
    required this.h,
    required this.p,
    required this.z,
    required this.id,
    required this.pos,
    required this.lv,
    required this.ex,
    required this.exp,
    required this.exid,
  });
  final int idx;
  final String deck, h, p, z, id, pos, ex, exp, exid;
  final int lv;

  factory Vocab.fromJson(Map<String, dynamic> j) => Vocab(
        idx: (j['idx'] as num?)?.toInt() ?? 0,
        deck: '${j['deck'] ?? 'koleksi'}',
        h: '${j['h'] ?? ''}',
        p: '${j['p'] ?? ''}',
        z: '${j['z'] ?? ''}',
        id: '${j['id'] ?? ''}',
        pos: '${j['pos'] ?? ''}',
        lv: (j['lv'] as num?)?.toInt() ?? 0,
        ex: '${j['ex'] ?? ''}',
        exp: '${j['exp'] ?? ''}',
        exid: '${j['exid'] ?? ''}',
      );
}

class Deck {
  Deck(this.id, this.mark, this.name, this.nameId);
  final String id, mark, name, nameId;
  factory Deck.fromJson(Map<String, dynamic> j) =>
      Deck('${j['id']}', '${j['mark']}', '${j['name']}', '${j['nameId']}');
}

class Sentence {
  Sentence(this.idx, this.scene, this.h, this.p, this.id);
  final int idx;
  final String scene, h, p, id;
  factory Sentence.fromJson(Map<String, dynamic> j) => Sentence(
      (j['idx'] as num?)?.toInt() ?? 0,
      '${j['scene']}',
      '${j['h']}',
      '${j['p']}',
      '${j['id']}');
}

class Scene {
  Scene(this.id, this.name);
  final String id, name;
  factory Scene.fromJson(Map<String, dynamic> j) =>
      Scene('${j['id']}', '${j['name']}');
}

class Potd {
  Potd(this.h, this.p, this.id);
  final String h, p, id;
}

class GuideStep {
  GuideStep(this.t, this.d);
  final String t, d;
}

class ToneItem {
  ToneItem(this.h, this.p, this.tone, this.id);
  final String h, p, id;
  final int tone;
}

class BuildItem {
  BuildItem(this.tok, this.p, this.id);
  final List<String> tok;
  final String p, id;
}

class GramEx {
  GramEx(this.h, this.p, this.id);
  final String h, p, id;
}

class Grammar {
  Grammar(this.t, this.pat, this.d, this.ex, this.tip, [this.q = const []]);
  final String t, pat, d, tip;
  final List<GramEx> ex;
  final List<GramQ> q; // soal latihan
}

/// Soal tata bahasa: 'fill' (isi ___ dengan salah satu [o]) atau
/// 'order' (susun [tok] menjadi kalimat).
class GramQ {
  GramQ({
    required this.k,
    this.q = '',
    this.a = '',
    this.o = const [],
    this.tok = const [],
    required this.p,
    required this.id,
  });
  final String k, q, a, p, id;
  final List<String> o, tok;

  /// Kalimat lengkap (jawaban benar).
  String get full => k == 'fill' ? q.replaceFirst('___', a) : tok.join();

  factory GramQ.fromJson(Map<String, dynamic> j) {
    List<String> strs(Object? x) => ((x as List?) ?? const []).map((e) => '$e').toList();
    return GramQ(
      k: '${j['k']}',
      q: '${j['q'] ?? ''}',
      a: '${j['a'] ?? ''}',
      o: strs(j['o']),
      tok: strs(j['tok']),
      p: '${j['p'] ?? ''}',
      id: '${j['id'] ?? ''}',
    );
  }
}

/// Dialog situasi (A = lawan bicara, B = kamu).
class Talk {
  Talk(this.id, this.icon, this.title, this.zh, this.a, this.lines);
  final String id, icon, title, zh, a;
  final List<TalkLine> lines;
  factory Talk.fromJson(Map<String, dynamic> j) => Talk(
        '${j['id']}',
        '${j['icon']}',
        '${j['title']}',
        '${j['zh']}',
        '${j['a']}',
        (j['lines'] as List)
            .map((e) => TalkLine('${e['s']}', '${e['h']}', '${e['p']}', '${e['id']}'))
            .toList(),
      );
}

class TalkLine {
  TalkLine(this.s, this.h, this.p, this.id);
  final String s, h, p, id;
  bool get mine => s == 'B';
}

/// Baris kamus: [tradisional, sederhana, pinyin, arti].
class DictRow {
  DictRow(this.trad, this.simp, this.pin, this.gloss);
  final String trad, simp, pin, gloss;
}

/// ===== Loader data (aset) =====

class LiuliData {
  static bool _loaded = false;

  static List<Vocab> vocab = [];
  static List<Deck> decks = [];
  static List<Sentence> sentences = [];
  static List<Scene> scenes = [];
  static List<Potd> potd = [];
  static List<GuideStep> steps = [];
  static Map<int, String> toneEx = {};
  static Map<int, String> toneDesc = {};
  static List<ToneItem> toneRef = [];
  static List<ToneItem> toneSyl = [];
  static List<BuildItem> build = [];
  static List<String> buildTokens = [];
  static List<Grammar> grammar = [];
  static List<Talk> dialogs = [];
  static List<List<String>> mw = []; // [word, id, measureWord]
  static Map<String, String> mwPy = {};
  static Map<String, String> emo = {};
  static List<List<dynamic>> tocflInfo = []; // [lv, cefr, desc]
  static Map<int, String> cefr = {};

  // Lazy (besar):
  static List<DictRow>? _dict;
  static Map<String, String>? _t2s;
  static Map<String, dynamic>? _hz;

  static Future<T> _json<T>(String file) async =>
      jsonDecode(await rootBundle.loadString('assets/liuli/$file')) as T;

  static Future<void> load() async {
    if (_loaded) return;
    vocab = (await _json<List>('vocab.json'))
        .map((e) => Vocab.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    decks = (await _json<List>('decks.json'))
        .map((e) => Deck.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    // Paket tambahan: "Kerja di Taiwan (PMI)" lalu kosakata A1–B2 tambahan
    // (deck baru ditaruh paling atas). Kata yang sudah ada dilewati karena
    // progres SRS disimpan per hanzi.
    final have = {for (final v in vocab) v.h};
    final extraDecks = <Deck>[];
    for (final file in ['vocab_kerja.json', 'vocab_plus.json']) {
      final pack = await _json<Map<String, dynamic>>(file);
      vocab = [
        ...vocab,
        ...(pack['words'] as List)
            .map((e) => Vocab.fromJson(Map<String, dynamic>.from(e)))
            .where((v) => have.add(v.h)),
      ];
      for (final d in [if (pack['deck'] != null) pack['deck'], ...?pack['decks']]) {
        extraDecks.add(Deck.fromJson(Map<String, dynamic>.from(d as Map)));
      }
    }
    decks = [...extraDecks, ...decks];
    sentences = (await _json<List>('sentences.json'))
        .map((e) => Sentence.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    scenes = (await _json<List>('scenes.json'))
        .map((e) => Scene.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    potd = (await _json<List>('potd.json'))
        .map((e) => Potd('${e['h']}', '${e['p']}', '${e['id']}'))
        .toList();
    steps = (await _json<List>('steps.json'))
        .map((e) => GuideStep('${e['t']}', '${e['d']}'))
        .toList();

    final tones = await _json<Map<String, dynamic>>('tones.json');
    toneEx = (tones['ex'] as Map)
        .map((k, v) => MapEntry(int.parse('$k'), '$v'));
    toneDesc = (tones['desc'] as Map)
        .map((k, v) => MapEntry(int.parse('$k'), '$v'));
    toneRef = (tones['ref'] as List)
        .map((e) => ToneItem('${e['h']}', '${e['p']}',
            (e['t'] as num).toInt(), '${e['id']}'))
        .toList();
    toneSyl = (tones['syl'] as List)
        .map((e) => ToneItem('${e['h']}', '${e['p']}',
            (e['tone'] as num).toInt(), '${e['id']}'))
        .toList();

    build = (await _json<List>('build.json'))
        .map((e) => BuildItem(
            (e['tok'] as List).map((x) => '$x').toList(),
            '${e['p']}',
            '${e['id']}'))
        .toList();
    buildTokens = {for (final b in build) ...b.tok}.toList();

    grammar = (await _json<List>('grammar.json'))
        .map((e) => Grammar(
              '${e['t']}',
              '${e['pat']}',
              '${e['d']}',
              (e['ex'] as List)
                  .map((x) => GramEx('${x['h']}', '${x['p']}', '${x['id']}'))
                  .toList(),
              '${e['tip']}',
              ((e['q'] as List?) ?? const [])
                  .map((x) => GramQ.fromJson(Map<String, dynamic>.from(x)))
                  .toList(),
            ))
        .toList();
    dialogs = (await _json<List>('dialogs.json'))
        .map((e) => Talk.fromJson(Map<String, dynamic>.from(e)))
        .toList();

    final mwj = await _json<Map<String, dynamic>>('mw.json');
    mw = (mwj['list'] as List)
        .map((e) => (e as List).map((x) => '$x').toList())
        .toList();
    mwPy = (mwj['py'] as Map).map((k, v) => MapEntry('$k', '$v'));

    emo = (await _json<Map<String, dynamic>>('emo.json'))
        .map((k, v) => MapEntry(k, '$v'));

    final toc = await _json<Map<String, dynamic>>('tocfl.json');
    tocflInfo = (toc['info'] as List).map((e) => (e as List)).toList();
    cefr = (toc['cefr'] as Map).map((k, v) => MapEntry(int.parse('$k'), '$v'));

    _loaded = true;
  }

  static Future<List<DictRow>> dict() async {
    if (_dict != null) return _dict!;
    final raw = await _json<List>('dict.json');
    _dict = raw
        .map((e) => DictRow('${e[0]}', '${e[1]}', '${e[2]}', '${e[3]}'))
        .toList();
    return _dict!;
  }

  static Future<Map<String, String>> t2s() async {
    if (_t2s != null) return _t2s!;
    _t2s = (await _json<Map<String, dynamic>>('t2s.json'))
        .map((k, v) => MapEntry(k, '$v'));
    return _t2s!;
  }

  static Map<String, String>? get t2sSync => _t2s;

  static Future<Map<String, dynamic>> hz() async {
    if (_hz != null) return _hz!;
    _hz = await _json<Map<String, dynamic>>('hzdata.json');
    return _hz!;
  }

  static Map<String, dynamic>? get hzSync => _hz;
}
