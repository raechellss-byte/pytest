import 'dart:async';
import 'dart:math';

import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'liuli_store.dart';

/// Gabungkan dua snapshot progres ([LiuliStore.snapshot]) tanpa kehilangan
/// belajar dari perangkat mana pun.
///
///  • Kartu SRS: per kata, yang terakhir dinilai (`at`) yang menang.
///  • Hitungan harian/akurasi: per tanggal ambil yang terbesar; tanggal digabung.
///  • Rentetan: ikut perangkat yang terakhir belajar.
///  • Pengaturan & koleksi: snapshot yang lebih baru menang — kecuali [union]
///    (sinkron pertama perangkat ini) → favorit & koleksi digabung.
///  • Bila salah satu direset setelah yang lain terakhir berubah → pakai yang
///    direset apa adanya (reset tidak "dihidupkan lagi" oleh data lama).
Map<String, dynamic> mergeLiuli(Map<String, dynamic> local, Map<String, dynamic> remote,
    {bool union = false}) {
  String s(Object? x) => x is String ? x : '';
  int n(Object? x) => x is num ? x.toInt() : 0;
  Map<String, dynamic> m(Object? x) =>
      x is Map ? Map<String, dynamic>.from(x) : <String, dynamic>{};
  Map<String, int> maxMap(Object? a, Object? b) {
    final out = <String, int>{};
    for (final src in [m(a), m(b)]) {
      src.forEach((k, v) => out[k] = max(out[k] ?? 0, n(v)));
    }
    return out;
  }

  final remoteNewer = s(remote['at']).compareTo(s(local['at'])) > 0;
  final newer = remoteNewer ? remote : local;
  final older = remoteNewer ? local : remote;
  if (s(newer['resetAt']).compareTo(s(older['at'])) > 0) return newer;

  // Kartu SRS.
  final srs = m(local['srs']);
  m(remote['srs']).forEach((k, b) {
    final a = srs[k];
    if (a == null) {
      srs[k] = b;
      return;
    }
    final ca = m(a), cb = m(b);
    final c = s(cb['at']).compareTo(s(ca['at']));
    if (c != 0) {
      srs[k] = c > 0 ? b : a;
    } else {
      srs[k] = n(cb['reps']) + n(cb['lapses']) > n(ca['reps']) + n(ca['lapses']) ? b : a;
    }
  });

  // Progres.
  final pa = m(local['prog']), pb = m(remote['prog']);
  final lc = s(pb['last']).compareTo(s(pa['last']));
  final lead = lc > 0 ? pb : (lc < 0 ? pa : (n(pb['streak']) > n(pa['streak']) ? pb : pa));
  final td = s(pb['todayDate']).compareTo(s(pa['todayDate']));
  final prog = <String, dynamic>{
    'streak': n(lead['streak']),
    'last': lead['last'],
    'freezes': lead['freezes'] ?? 2,
    'best': [n(pa['best']), n(pb['best']), n(lead['streak'])].reduce(max),
    'total': max(n(pa['total']), n(pb['total'])),
    'todayDate': td >= 0 ? pb['todayDate'] : pa['todayDate'],
    'todayCount': td == 0
        ? max(n(pa['todayCount']), n(pb['todayCount']))
        : n((td > 0 ? pb : pa)['todayCount']),
    'daily': maxMap(pa['daily'], pb['daily']),
    'try': maxMap(pa['try'], pb['try']),
    'miss': maxMap(pa['miss'], pb['miss']),
    'dates': ({
      ...((pa['dates'] as List?) ?? const []).map((e) => '$e'),
      ...((pb['dates'] as List?) ?? const []).map((e) => '$e'),
    }.toList()
      ..sort()),
  };

  // Catatan salah.
  final ma = m(local['miss']), mb = m(remote['miss']);
  final mn = remoteNewer ? mb : ma, mo = remoteNewer ? ma : mb;
  final recent = <String>{
    ...((mn['recent'] as List?) ?? const []).map((e) => '$e'),
    if (union) ...((mo['recent'] as List?) ?? const []).map((e) => '$e'),
  }.take(60).toList();

  // Favorit & koleksi.
  List<String> strs(Object? x) => ((x as List?) ?? const []).map((e) => '$e').toList();
  final saved = union
      ? {...strs(newer['saved']), ...strs(older['saved'])}.toList()
      : strs(newer['saved'] ?? older['saved']);
  List lists = (newer['lists'] as List?) ?? (older['lists'] as List?) ?? const [];
  if (union) {
    final byId = <String, Map<String, dynamic>>{};
    for (final l in [...((older['lists'] as List?) ?? const []), ...lists]) {
      final c = m(l);
      final prev = byId[s(c['id'])];
      byId[s(c['id'])] = prev == null
          ? c
          : {...c, 'words': {...strs(prev['words']), ...strs(c['words'])}.toList()};
    }
    lists = byId.values.toList();
  }

  // XP, misi, lencana: angka ambil terbesar, himpunan digabung.
  final ga = m(local['game']), gb = m(remote['game']);
  final qd = s(gb['questDate']).compareTo(s(ga['questDate']));
  final badgesAll = <String, String>{};
  for (final src in [m(ga['badges']), m(gb['badges'])]) {
    src.forEach((k, v) {
      final prev = badgesAll[k];
      if (prev == null || '$v'.compareTo(prev) < 0) badgesAll[k] = '$v';
    });
  }
  final game = <String, dynamic>{
    'xp': max(n(ga['xp']), n(gb['xp'])),
    'xpDaily': maxMap(ga['xpDaily'], gb['xpDaily']),
    'questDate': qd >= 0 ? gb['questDate'] : ga['questDate'],
    'questCount': qd == 0
        ? maxMap(ga['questCount'], gb['questCount'])
        : m((qd > 0 ? gb : ga)['questCount']),
    'questsDone': qd == 0
        ? {...strs(ga['questsDone']), ...strs(gb['questsDone'])}.toList()
        : strs((qd > 0 ? gb : ga)['questsDone']),
    'kindTotal': maxMap(ga['kindTotal'], gb['kindTotal']),
    'badges': badgesAll,
    'talksDone': {...strs(ga['talksDone']), ...strs(gb['talksDone'])}.toList(),
    'examBest': maxMap(ga['examBest'], gb['examBest']),
    'write': maxMap(ga['write'], gb['write']),
    // Set latihan menulis: ikut hari yang lebih baru; hari sama → centang digabung.
    'writeDay': s(gb['writeDay']).compareTo(s(ga['writeDay'])) >= 0 ? gb['writeDay'] : ga['writeDay'],
    'writeSet': (s(gb['writeDay']).compareTo(s(ga['writeDay'])) >= 0 ? gb : ga)['writeSet'] ?? const [],
    'writeToday': s(gb['writeDay']) == s(ga['writeDay'])
        ? {...strs(ga['writeToday']), ...strs(gb['writeToday'])}.toList()
        : strs((s(gb['writeDay']).compareTo(s(ga['writeDay'])) > 0 ? gb : ga)['writeToday']),
  };

  return {
    'game': game,
    'app': 'liuli',
    'v': 2,
    'at': newer['at'] ?? older['at'],
    if (newer['resetAt'] != null) 'resetAt': newer['resetAt'],
    'srs': srs,
    'prog': prog,
    'set': newer['set'] ?? older['set'],
    'saved': saved,
    'lists': lists,
    'miss': {'recent': recent, 'count': maxMap(ma['count'], mb['count'])},
    'hist': newer['hist'] ?? older['hist'] ?? const [],
  };
}

enum LiuliSyncState { off, syncing, ok, error }

/// Sinkron progres Belajar Mandarin ke akun (tabel Supabase `liuli_progress`).
/// Tanpa login → hanya tersimpan di perangkat. Semua kegagalan diam-diam:
/// belajar tetap jalan, status ditampilkan di Pengaturan.
class LiuliSync {
  static final state = ValueNotifier(LiuliSyncState.off);
  static DateTime? lastOk;
  static String? lastError;

  static const _kUid = 'liuli_sync_uid';
  static String? _uid;
  static Timer? _debounce;
  static bool _hooked = false;

  static SupabaseClient? get _db {
    try {
      return Supabase.instance.client;
    } catch (_) {
      return null; // mis. di widget test (Supabase belum diinisialisasi)
    }
  }

  static bool get signedIn => _db?.auth.currentUser != null;

  /// Tarik data akun, gabungkan dengan perangkat, lalu simpan balik.
  static Future<void> start() async {
    final db = _db;
    final user = db?.auth.currentUser;
    if (db == null || user == null) {
      stop();
      return;
    }
    _uid = user.id;
    state.value = LiuliSyncState.syncing;
    try {
      final store = LiuliStore.instance;
      await store.ensureLoaded();
      store.saving = true; // sudah masuk → riwayat boleh disimpan
      final prefs = await SharedPreferences.getInstance();
      final prevUid = prefs.getString(_kUid);
      final row = await db
          .from('liuli_progress')
          .select('data')
          .eq('user_id', user.id)
          .maybeSingle();
      final remote = row?['data'];
      _hook(); // pasang setelah tarik: applySnapshot tidak perlu memicu push dobel
      if (prevUid != null && prevUid != user.id) {
        // Perangkat ini sebelumnya dipakai akun lain → jangan campur progres.
        store.clearLocal();
        if (remote is Map) store.applySnapshot(Map<String, dynamic>.from(remote));
      } else if (remote is Map) {
        store.applySnapshot(mergeLiuli(
            store.snapshot(), Map<String, dynamic>.from(remote),
            union: prevUid == null));
      }
      await prefs.setString(_kUid, user.id);
      if (remote is Map || !store.isBlank) {
        await push();
      } else {
        state.value = LiuliSyncState.ok;
        lastOk = DateTime.now();
      }
    } catch (e) {
      lastError = '$e';
      state.value = LiuliSyncState.error;
      debugPrint('LiuliSync start gagal: $e');
    }
  }

  /// Mode tamu: berhenti mengirim & berhenti menyimpan riwayat di perangkat.
  /// Progres tetap bisa dipakai selama halaman terbuka; begitu masuk akun,
  /// [start] menggabungkannya ke akun.
  static void stop() {
    _uid = null;
    _debounce?.cancel();
    LiuliStore.instance.saving = false;
    state.value = LiuliSyncState.off;
  }

  /// Keluar akun: mode tamu + hapus riwayat di perangkat ini (tetap aman di
  /// akun), supaya pengguna lain di HP yang sama tidak melihatnya.
  static Future<void> signOut() async {
    stop();
    final store = LiuliStore.instance;
    await store.ensureLoaded();
    store.clearLocal();
  }

  static void _hook() {
    if (_hooked) return;
    _hooked = true;
    LiuliStore.instance.addListener(_schedule);
    AppLifecycleListener(onHide: flush, onPause: flush);
  }

  static void _schedule() {
    if (_uid == null) return;
    _debounce?.cancel();
    _debounce = Timer(const Duration(seconds: 4), push);
  }

  /// Kirim sekarang bila ada perubahan yang menunggu (mis. tab ditutup).
  static void flush() {
    if (_debounce?.isActive ?? false) {
      _debounce!.cancel();
      push();
    }
  }

  static Future<void> push() async {
    final db = _db;
    final uid = _uid;
    if (db == null || uid == null) return;
    final store = LiuliStore.instance;
    _debounce?.cancel();
    try {
      state.value = LiuliSyncState.syncing;
      final today = liuliToday();
      await db.from('liuli_progress').upsert({
        'user_id': uid,
        'data': store.snapshot(),
        // Kolom ringkas untuk pengingat push (dibaca edge function).
        'streak': store.streak,
        'last_day': store.last,
        'today_count': store.todayDate == today ? store.todayCount : 0,
        'daily_goal': store.dailyGoal,
        'remind': store.remind,
        'remind_hour': store.remindHour,
        'tz_offset': DateTime.now().timeZoneOffset.inMinutes,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id');
      lastOk = DateTime.now();
      lastError = null;
      state.value = LiuliSyncState.ok;
    } catch (e) {
      lastError = '$e';
      state.value = LiuliSyncState.error;
      debugPrint('LiuliSync push gagal: $e');
    }
  }
}
