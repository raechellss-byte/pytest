import 'dart:math';

import 'package:flutter/material.dart';

import 'liuli_common.dart';
import 'liuli_game.dart';
import 'liuli_game_ui.dart';
import 'liuli_store.dart';
import 'liuli_study.dart';

const _dayNames = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];

String _dayLabel(int offset) {
  if (offset == 0) return 'Hari ini';
  if (offset == 1) return 'Besok';
  return _dayNames[DateTime.now().add(Duration(days: offset)).weekday - 1];
}

String _dateLabel(int offset) {
  final d = DateTime.now().add(Duration(days: offset));
  return '${_dayNames[d.weekday - 1]} ${d.day}/${d.month}';
}

/// Layar "Statistik belajar": akurasi, prakiraan ulasan, aktivitas 30 hari,
/// kata tersulit.
class LiuliStatsScreen extends StatelessWidget {
  const LiuliStatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final forecast = store.dueForecast(7);
        final days30 = [for (var i = 29; i >= 0; i--) store.daily[liuliDay(-i)] ?? 0];
        final active = days30.where((c) => c > 0).length;
        final hit = days30.where((c) => c >= store.dailyGoal).length;
        final avg = active == 0 ? 0 : (days30.reduce((a, b) => a + b) / active).round();
        final acc = store.accuracy(7);
        final accPrev = store.accuracy(7, 7);
        final weak = store.weakList().take(5).toList();

        return Scaffold(
          appBar: AppBar(title: const Text('Statistik belajar', style: TextStyle(fontSize: 18))),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              Row(children: [
                _tile('Akurasi 7 hari', acc == null ? '–' : '${(acc * 100).round()}%',
                    acc == null
                        ? 'jawab kuis/kartu dulu'
                        : (accPrev == null ? 'minggu lalu belum ada data' : _delta(acc, accPrev))),
                _tile('Rata-rata', '$avg', 'ulasan per hari belajar'),
              ]),
              Row(children: [
                _tile('Target tercapai', '$hit', 'dari 30 hari terakhir'),
                _tile('Hari belajar', '$active', 'dari 30 hari terakhir'),
              ]),
              SectionHead('Lencana',
                  trailing: '${store.badgesEarned.length} / ${liuliBadges.length} didapat'),
              const LiuliBadgeGrid(),
              const SectionHead('Ulasan 7 hari ke depan'),
              Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(
                        forecast.every((c) => c == 0)
                            ? 'Belum ada kartu terjadwal — mulai pelajari kata baru.'
                            : '${forecast.reduce((a, b) => a + b)} kata akan jatuh tempo minggu ini. '
                                '"Hari ini" termasuk yang terlambat.',
                        style: TextStyle(fontSize: 12.5, color: LiuliColors.text2)),
                    const SizedBox(height: 12),
                    LiuliBarChart(
                      values: forecast,
                      initial: 0,
                      labels: [for (var i = 0; i < 7; i++) _dayLabel(i)],
                      describe: (i, v) => '${_dateLabel(i)} · $v kata jatuh tempo',
                    ),
                  ]),
                ),
              ),
              const SectionHead('Aktivitas 30 hari terakhir'),
              Card(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Jumlah ulasan per hari. Garis putus-putus = target harian '
                        '(${store.dailyGoal}).',
                        style: TextStyle(fontSize: 12.5, color: LiuliColors.text2)),
                    const SizedBox(height: 12),
                    LiuliBarChart(
                      values: days30,
                      goal: store.dailyGoal,
                      labels: [
                        for (var i = 29; i >= 0; i--)
                          i == 0 ? 'Hari ini' : (i % 7 == 0 ? _dateLabel(-i) : '')
                      ],
                      describe: (i, v) =>
                          '${i == 29 ? 'Hari ini' : _dateLabel(i - 29)} · $v ulasan'
                          '${v >= store.dailyGoal ? ' · target tercapai ✓' : ''}',
                    ),
                  ]),
                ),
              ),
              const SectionHead('Kata paling sulit', trailing: 'sering salah / lupa'),
              if (weak.isEmpty)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text('Belum ada — kata yang sering salah akan muncul di sini.',
                        style: TextStyle(color: LiuliColors.text2)),
                  ),
                )
              else
                Card(
                  child: Column(children: [
                    for (final v in weak)
                      ListTile(
                        dense: true,
                        title: Text(store.zh(v.h), style: hanziStyle(size: 20)),
                        subtitle: Text('${v.p} · ${v.id}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: LiuliColors.text2)),
                        trailing: Pill(
                            '✗ ${(store.missCount[v.h] ?? 0) + (store.srs[v.h]?.lapses ?? 0)}',
                            color: LiuliColors.seal),
                      ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                      child: SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: () => startLiuliStudy(context,
                              explicit: store.weakList(), label: 'Kata lemah'),
                          icon: const Icon(Icons.replay_rounded),
                          label: const Text('Latih kata lemah'),
                          style: FilledButton.styleFrom(
                              backgroundColor: LiuliColors.seal,
                              minimumSize: const Size(0, 46)),
                        ),
                      ),
                    ),
                  ]),
                ),
            ],
          ),
        );
      },
    );
  }

  String _delta(double now, double prev) {
    final d = ((now - prev) * 100).round();
    if (d == 0) return 'sama dgn minggu lalu';
    return '${d > 0 ? '▲' : '▼'} ${d.abs()} poin dari minggu lalu';
  }

  Widget _tile(String label, String value, String sub) => Expanded(
        child: Card(
          margin: const EdgeInsets.all(4),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label,
                  style: TextStyle(
                      fontSize: 12, fontWeight: FontWeight.w700, color: LiuliColors.text2)),
              const SizedBox(height: 2),
              Text(value,
                  style: TextStyle(
                      fontSize: 28, fontWeight: FontWeight.w900, color: LiuliColors.ink)),
              Text(sub,
                  maxLines: 2,
                  style: TextStyle(fontSize: 11, color: LiuliColors.text3, height: 1.25)),
            ]),
          ),
        ),
      );
}

/// Grafik batang satu seri (tanpa legenda: judul kartu yang menamai seri).
/// Ketuk batang → keterangannya tampil di bawah grafik.
class LiuliBarChart extends StatefulWidget {
  const LiuliBarChart({
    super.key,
    required this.values,
    required this.labels,
    required this.describe,
    this.goal,
    this.height = 132,
    this.initial,
  });
  final List<int> values;
  final List<String> labels; // '' = tanpa label di bawah batang itu
  final String Function(int index, int value) describe;
  final int? goal; // garis acuan putus-putus
  final double height;
  final int? initial; // batang terpilih awal (default: terakhir)

  @override
  State<LiuliBarChart> createState() => _LiuliBarChartState();
}

class _LiuliBarChartState extends State<LiuliBarChart> {
  int? _sel;

  // Lolos validator palet: terang #1F7A4D di putih, gelap #38A169 di #1B211D.
  Color get _bar => LiuliColors.isDark ? const Color(0xFF38A169) : LiuliColors.jade;

  @override
  Widget build(BuildContext context) {
    final vals = widget.values;
    final top = max(1, max(vals.fold<int>(0, max), widget.goal ?? 0));
    final sel = _sel ?? widget.initial ?? vals.length - 1;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(
        height: widget.height,
        child: LayoutBuilder(builder: (context, c) {
          final n = vals.length;
          const gap = 2.0;
          final w = (c.maxWidth - gap * (n - 1)) / n;
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: (d) => setState(() =>
                _sel = (d.localPosition.dx / (w + gap)).floor().clamp(0, n - 1)),
            child: CustomPaint(
              size: Size(c.maxWidth, widget.height),
              painter: _BarsPainter(
                values: vals,
                top: top,
                goal: widget.goal,
                selected: sel,
                bar: _bar,
                baseline: LiuliColors.text3.withValues(alpha: 0.5),
                goalColor: LiuliColors.text2,
                barWidth: w,
                gap: gap,
              ),
              // Anak berukuran penuh: menentukan ukuran kanvas & area ketuk.
              child: Semantics(
                label: [for (var i = 0; i < n; i++) widget.describe(i, vals[i])].join('; '),
                child: SizedBox(width: c.maxWidth, height: widget.height),
              ),
            ),
          );
        }),
      ),
      const SizedBox(height: 4),
      // Label sumbu-x: hanya yang diisi (jarang), rata tengah di bawah batangnya.
      SizedBox(
        height: 16,
        child: LayoutBuilder(builder: (context, c) {
          final n = vals.length;
          final slot = c.maxWidth / n;
          return Stack(clipBehavior: Clip.none, children: [
            for (var i = 0; i < n; i++)
              if (widget.labels[i].isNotEmpty)
                Positioned(
                  left: (slot * i + slot / 2 - 30).clamp(0.0, c.maxWidth - 60),
                  width: 60,
                  child: Text(widget.labels[i],
                      textAlign: i == n - 1 && n > 7 ? TextAlign.right : TextAlign.center,
                      style: TextStyle(
                          fontSize: 10.5,
                          color: LiuliColors.text3,
                          fontWeight: i == sel ? FontWeight.w800 : FontWeight.w500)),
                ),
          ]);
        }),
      ),
      const SizedBox(height: 8),
      Text(widget.describe(sel, vals[sel]),
          style: TextStyle(
              fontSize: 12.5, fontWeight: FontWeight.w700, color: LiuliColors.ink)),
    ]);
  }
}

class _BarsPainter extends CustomPainter {
  _BarsPainter({
    required this.values,
    required this.top,
    required this.goal,
    required this.selected,
    required this.bar,
    required this.baseline,
    required this.goalColor,
    required this.barWidth,
    required this.gap,
  });
  final List<int> values;
  final int top;
  final int? goal;
  final int selected;
  final Color bar, baseline, goalColor;
  final double barWidth, gap;

  @override
  void paint(Canvas canvas, Size size) {
    final h = size.height - 1;
    for (var i = 0; i < values.length; i++) {
      final v = values[i];
      final x = i * (barWidth + gap);
      if (v > 0) {
        final bh = max(3.0, h * v / top);
        // Ujung data membulat 4px, menempel di garis dasar.
        final r = RRect.fromRectAndCorners(
          Rect.fromLTWH(x, h - bh, barWidth, bh),
          topLeft: Radius.circular(min(4, barWidth / 2)),
          topRight: Radius.circular(min(4, barWidth / 2)),
        );
        canvas.drawRRect(
            r, Paint()..color = i == selected ? bar : bar.withValues(alpha: 0.72));
      }
      if (i == selected) {
        // Penanda batang terpilih (juga terlihat saat nilainya 0).
        canvas.drawRect(Rect.fromLTWH(x, h + 1, barWidth, 2), Paint()..color = bar);
      }
    }
    // Garis dasar & garis target digambar sebagai persegi tipis (andal di
    // semua renderer, termasuk CanvasKit web).
    canvas.drawRect(Rect.fromLTWH(0, h, size.width, 1), Paint()..color = baseline);
    final g = goal;
    if (g != null && g > 0) {
      final y = h - h * g / top;
      final p = Paint()..color = goalColor;
      for (var x = 0.0; x < size.width; x += 8) {
        canvas.drawRect(Rect.fromLTWH(x, y - 0.75, min(4, size.width - x), 1.5), p);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _BarsPainter o) =>
      o.values != values || o.selected != selected || o.bar != bar || o.top != top;
}
