import 'liuli_data.dart';
import 'liuli_store.dart';

/// ============================================================
/// Gamifikasi Belajar Mandarin: XP & level, misi harian, lencana.
/// Data (angka XP, progres misi, lencana) disimpan di [LiuliStore].
/// ============================================================

/// XP per satu aksi, menurut jenisnya.
const kXp = <String, int>{
  'review': 2, // menilai 1 kartu SRS
  'new': 0, // kata baru (XP-nya sudah dari 'review')
  'quiz': 2, // jawaban kuis benar
  'type': 3, // 1 kata selesai diketik (zhuyin)
  'gram': 3, // soal tata bahasa benar
  'talkline': 2, // jawaban dialog tepat
  'talk': 10, // 1 dialog latihan peran selesai
  'speak': 3, // ucapan skor ≥65
  'exam': 0, // XP ujian diberikan langsung sesuai skor
  'write': 3, // 1 karakter berhasil ditulis (urutan goresan)
  'questall': 0,
};

class Quest {
  const Quest(this.id, this.kind, this.target, this.title, this.icon, this.reward);
  final String id, kind, title, icon;
  final int target, reward;
}

const questPool = <Quest>[
  Quest('review', 'review', 15, 'Ulas 15 kartu', '🃏', 20),
  Quest('new', 'new', 5, 'Pelajari 5 kata baru', '🌱', 20),
  Quest('quiz', 'quiz', 10, 'Jawab benar 10 soal kuis', '❓', 20),
  Quest('type', 'type', 5, 'Ketik 5 kata dengan zhuyin', '⌨️', 20),
  Quest('gram', 'gram', 5, 'Benar 5 soal tata bahasa', '📐', 20),
  Quest('talk', 'talk', 1, 'Selesaikan 1 dialog latihan peran', '🎭', 25),
  Quest('speak', 'speak', 3, 'Ucapkan 3 kalimat (skor ≥65)', '🎤', 25),
  Quest('write', 'write', 5, 'Tulis 5 karakter (urutan goresan)', '✍️', 20),
];

/// Bonus bila ketiga misi hari itu selesai.
const kQuestAllBonus = 30;

/// 3 misi untuk tanggal [date]: selalu "Ulas kartu" + 2 lainnya yang dipilih
/// dari tanggal (sama di semua perangkat, berganti tiap hari).
List<Quest> questsFor(String date) {
  var seed = 0;
  for (final c in date.codeUnits) {
    seed = (seed * 31 + c) & 0x7fffffff;
  }
  final rest = questPool.skip(1).toList();
  final a = seed % rest.length;
  var b = (seed ~/ 7) % (rest.length - 1);
  if (b >= a) b++;
  return [questPool.first, rest[a], rest[b]];
}

// ---- Level ----

/// XP minimal untuk level [lv]: L2=100, L3=250, L4=450, … (+50 tiap level).
int xpForLevel(int lv) {
  var acc = 0, need = 100;
  for (var l = 1; l < lv; l++) {
    acc += need;
    need += 50;
  }
  return acc;
}

int levelForXp(int xp) {
  var lv = 1;
  while (xp >= xpForLevel(lv + 1)) {
    lv++;
  }
  return lv;
}

String levelTitle(int lv) => switch (lv) {
      <= 2 => '入門 Pemula',
      <= 4 => '學徒 Murid',
      <= 6 => '好學生 Pelajar tekun',
      <= 9 => '高手 Mahir',
      <= 14 => '達人 Ahli',
      _ => '大師 Master',
    };

// ---- Lencana ----

class LiuliBadge {
  const LiuliBadge(this.id, this.icon, this.title, this.desc, this.check);
  final String id, icon, title, desc;
  final bool Function(LiuliStore s) check;
}

int _tries7(LiuliStore s) {
  var n = 0;
  for (var i = 0; i < 7; i++) {
    n += s.dailyTry[liuliDay(-i)] ?? 0;
  }
  return n;
}

final liuliBadges = <LiuliBadge>[
  LiuliBadge('streak3', '🔥', 'Mulai panas', 'Belajar 3 hari berturut-turut', (s) => s.best >= 3),
  LiuliBadge('streak7', '📅', 'Seminggu penuh', 'Rentetan 7 hari', (s) => s.best >= 7),
  LiuliBadge('streak30', '🌟', 'Sebulan tanpa putus', 'Rentetan 30 hari', (s) => s.best >= 30),
  LiuliBadge('seen50', '🌱', 'Kenal 50 kata', 'Sudah mempelajari 50 kata', (s) => s.seenCount >= 50),
  LiuliBadge('seen200', '🌿', 'Kenal 200 kata', 'Sudah mempelajari 200 kata', (s) => s.seenCount >= 200),
  LiuliBadge('master50', '🏯', 'Kuasai 50 kata', '50 kata berstatus Dikuasai', (s) => s.masteredCount >= 50),
  LiuliBadge('master200', '👑', 'Kuasai 200 kata', '200 kata berstatus Dikuasai', (s) => s.masteredCount >= 200),
  LiuliBadge('kerja', '🧰', 'Siap kerja', 'Semua kata deck "Kerja di Taiwan" sudah dipelajari', (s) {
    final w = LiuliData.vocab.where((v) => v.deck == 'kerja');
    return w.isNotEmpty && w.every((v) => !s.isNew(v.h));
  }),
  LiuliBadge('talk1', '🎭', 'Dialog pertama', 'Selesaikan 1 dialog latihan peran', (s) => s.talksDone.isNotEmpty),
  LiuliBadge('talkall', '🗣️', 'Semua situasi', 'Selesaikan semua dialog latihan peran', (s) =>
      LiuliData.dialogs.isNotEmpty && LiuliData.dialogs.every((d) => s.talksDone.contains(d.id))),
  LiuliBadge('gram30', '📐', 'Jago pola kalimat', 'Benar 30 soal tata bahasa', (s) => (s.kindTotal['gram'] ?? 0) >= 30),
  LiuliBadge('type100', '⌨️', 'Jari zhuyin', 'Ketik 100 kata dengan zhuyin', (s) => (s.kindTotal['type'] ?? 0) >= 100),
  LiuliBadge('write50', '✍️', 'Tangan rajin', 'Tulis 50 karakter dengan urutan goresan benar', (s) =>
      (s.kindTotal['write'] ?? 0) >= 50),
  LiuliBadge('speak10', '🎤', 'Berani bicara', '10 ucapan dengan skor ≥65', (s) => (s.kindTotal['speak'] ?? 0) >= 10),
  LiuliBadge('acc90', '🎯', 'Tepat sasaran', 'Akurasi 7 hari ≥90% (minimal 50 jawaban)', (s) =>
      _tries7(s) >= 50 && (s.accuracy(7) ?? 0) >= 0.9),
  LiuliBadge('quest7', '🏆', 'Pemburu misi', 'Tuntaskan semua misi harian 7 kali', (s) =>
      (s.kindTotal['questall'] ?? 0) >= 7),
  LiuliBadge('exam', '📝', 'Lulus simulasi', 'Skor ≥70% di simulasi ujian TOCFL', (s) =>
      s.examBest.values.any((v) => v >= 70)),
  LiuliBadge('lv5', '⭐', 'Level 5', 'Kumpulkan XP sampai level 5', (s) => levelForXp(s.xp) >= 5),
  LiuliBadge('lv10', '🌠', 'Level 10', 'Kumpulkan XP sampai level 10', (s) => levelForXp(s.xp) >= 10),
];
