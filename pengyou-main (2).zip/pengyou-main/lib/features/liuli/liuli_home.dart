import 'dart:math';

import 'package:flutter/material.dart';

import 'liuli_common.dart';
import '../../screens/auth/login_prompt.dart';
import 'liuli_data.dart';
import 'liuli_sync.dart';
import 'liuli_game_ui.dart';
import 'liuli_stats.dart';
import 'liuli_store.dart';
import 'liuli_study.dart';

class LiuliHome extends StatelessWidget {
  const LiuliHome({super.key, required this.onGoTab});
  final void Function(int) onGoTab;

  @override
  Widget build(BuildContext context) {
    final store = LiuliStore.instance;
    final d = DateTime.now().day;
    final p = LiuliData.potd[d % LiuliData.potd.length];
    final due = store.dueCount;
    final fresh = min(store.newCount, store.newPerDay);
    final tc = store.todayDate == liuliToday() ? store.todayCount : 0;
    final goal = store.dailyGoal;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        // POTD hero
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [LiuliColors.jade, LiuliColors.jadeShade],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Stack(children: [
            Positioned(
              right: -6,
              bottom: -26,
              child: Text('學',
                  style: hanziStyle(size: 110)
                      .copyWith(color: Colors.white.withValues(alpha: 0.12))),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('UNGKAPAN HARI INI',
                  style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.8),
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1)),
              const SizedBox(height: 8),
              Text(store.zh(p.h),
                  style: hanziStyle(size: 34, color: Colors.white)),
              const SizedBox(height: 2),
              Text(p.p,
                  style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.9),
                      fontSize: 14,
                      fontStyle: FontStyle.italic)),
              const SizedBox(height: 4),
              Text(p.id,
                  style: TextStyle(color: Colors.white.withValues(alpha: 0.95))),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => store.speak(p.h),
                icon: const Icon(Icons.volume_up_rounded, size: 17),
                label: const Text('Dengar'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: BorderSide(color: Colors.white.withValues(alpha: 0.6)),
                  minimumSize: const Size(0, 38),
                ),
              ),
            ]),
          ]),
        ),
        const SizedBox(height: 12),
        // Tamu: progres hanya bertahan selama halaman terbuka.
        if (!LiuliSync.signedIn)
          const LoginNudgeCard(
            title: 'Mode tamu — progres tidak disimpan',
            text: 'Kamu bisa belajar sekarang, tapi kartu, rentetan, XP & lencana '
                'hilang saat halaman ditutup. Masuk dengan email supaya semuanya '
                'tersimpan di akun & bisa lanjut di HP lain.',
            next: '/belajar',
            color: LiuliColors.jade,
          ),
        LiuliQuestCard(onGoTab: onGoTab),
        const SizedBox(height: 4),
        // Goal ring + stats
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              SizedBox(
                width: 92,
                height: 92,
                child: CustomPaint(
                  painter: _RingPainter(goal == 0 ? 0 : (tc / goal).clamp(0, 1)),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('$tc',
                            style: const TextStyle(
                                fontSize: 24, fontWeight: FontWeight.w900)),
                        Text('/ $goal',
                            style: TextStyle(
                                fontSize: 11, color: LiuliColors.text3)),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        tc >= goal
                            ? 'Target hari ini tercapai — mantap!  ❄️ ${store.freezes}'
                            : 'Target harian: $goal ulasan.  ❄️ ${store.freezes}',
                        style: const TextStyle(fontSize: 12.5, height: 1.4)),
                    const SizedBox(height: 10),
                    Row(children: [
                      _miniStat('$due', 'Jatuh tempo', LiuliColors.seal),
                      _miniStat('${store.seenCount}', 'Dipelajari', LiuliColors.jade),
                      _miniStat('${store.masteredCount}', 'Dikuasai', LiuliColors.gold),
                    ]),
                  ],
                ),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        _mastery(context, store, due, fresh),
        // Activity tiles
        const SectionHead('Aktivitas belajar'),
        Row(children: [
          _tile('🔥', '${store.streak}', 'Rentetan'),
          _tile('🏆', '${store.best}', 'Rekor'),
          _tile('📅', '${store.daily.length}', 'Hari belajar'),
          _tile('✍️', '${store.total}', 'Total ulasan'),
        ]),
        const SizedBox(height: 12),
        _Heatmap(daily: store.daily),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: () =>
              Navigator.of(context).push(liuliRoute(const LiuliStatsScreen())),
          icon: const Icon(Icons.insights_rounded),
          label: const Text('Statistik: akurasi, jadwal ulasan, kata tersulit'),
          style: OutlinedButton.styleFrom(
            minimumSize: const Size(0, 46),
            foregroundColor: LiuliColors.jadeDeep,
            side: BorderSide(color: LiuliColors.jade.withValues(alpha: 0.35)),
          ),
        ),
        // Levels
        const SectionHead('Belajar per Level TOCFL', trailing: 'perkiraan'),
        ..._levels(context, store),
        // Deck otomatis dari riwayat jawaban
        const SectionHead('Deck otomatis', trailing: 'diperbarui sendiri'),
        _autoDeck(context,
            icon: Icons.trending_down_rounded,
            color: LiuliColors.seal,
            title: 'Kata lemah',
            sub: 'Paling sering salah / lupa — latih lagi',
            empty: 'Belum ada — kata yang sering salah akan muncul di sini',
            list: store.weakList()),
        _autoDeck(context,
            icon: Icons.bolt_rounded,
            color: Mastery.learning,
            title: 'Baru salah',
            sub: 'Jawaban salah terakhir di kartu, kuis & ketik',
            empty: 'Belum ada jawaban salah — mantap!',
            list: store.recentMissList()),
        _autoDeck(context,
            icon: Icons.star_rounded,
            color: LiuliColors.gold,
            title: 'Favorit',
            sub: 'Kata yang kamu simpan',
            empty: 'Simpan kata dengan ⭐ di kamus atau kartu',
            list: store.favoriteList()),
        // Decks
        SectionHead('Topik kosakata', trailing: '${LiuliData.vocab.length} kata'),
        ...LiuliData.decks.map((dk) => _deckTile(context, store, dk)),
      ],
    );
  }

  Widget _miniStat(String b, String s, Color c) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(b, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: c)),
          Text(s, style: TextStyle(fontSize: 10, color: LiuliColors.text2)),
        ]),
      );

  Widget _tile(String ic, String b, String s) => Expanded(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 3),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: LiuliColors.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.brown.withValues(alpha: 0.08)),
          ),
          child: Column(children: [
            Text(ic, style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 2),
            Text(b, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            Text(s,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 9.5, color: LiuliColors.text2)),
          ]),
        ),
      );

  /// Kartu "Penguasaan kosakata": bar 4 tingkat + tombol ulas/belajar.
  Widget _mastery(BuildContext context, LiuliStore store, int due, int fresh) {
    final buckets = [
      (store.newCount, 'Baru', Mastery.newC),
      (store.learningCount, 'Belajar', Mastery.learning),
      (store.familiarCount, 'Akrab', Mastery.familiar),
      (store.masteredCount, 'Dikuasai', Mastery.mastered),
    ];
    final String label;
    final Color color;
    final IconData icon;
    VoidCallback? onTap = () => startLiuliStudy(context, pred: null, label: null);
    if (due > 0) {
      label = 'Ulas $due kata jatuh tempo${fresh > 0 ? ' + $fresh baru' : ''}';
      color = LiuliColors.seal;
      icon = Icons.replay_rounded;
    } else if (fresh > 0) {
      label = 'Pelajari $fresh kata baru';
      color = LiuliColors.jade;
      icon = Icons.play_arrow_rounded;
    } else {
      label = 'Semua beres hari ini 🎉';
      color = LiuliColors.jade;
      icon = Icons.check_rounded;
      onTap = null;
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Text('Penguasaan kosakata',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
            const Spacer(),
            Text('${LiuliData.vocab.length} kata',
                style: TextStyle(fontSize: 12, color: LiuliColors.text2)),
          ]),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: SizedBox(
              height: 12,
              child: Row(children: [
                for (final b in buckets)
                  if (b.$1 > 0) Expanded(flex: b.$1, child: Container(color: b.$3)),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Wrap(spacing: 12, runSpacing: 4, children: [
            for (final b in buckets)
              Row(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 9,
                  height: 9,
                  decoration: BoxDecoration(
                      color: b.$3, borderRadius: BorderRadius.circular(3)),
                ),
                const SizedBox(width: 4),
                Text('${b.$1} ${b.$2}',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
              ]),
          ]),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: onTap,
              icon: Icon(icon),
              label: Text(label),
              style: FilledButton.styleFrom(
                  backgroundColor: color, minimumSize: const Size(0, 48)),
            ),
          ),
        ]),
      ),
    );
  }

  /// Level TOCFL berkode warna: lencana · progress · % dikuasai · jatuh tempo.
  List<Widget> _levels(BuildContext context, LiuliStore store) {
    final levels = {for (final v in LiuliData.vocab) v.lv}.toList()..sort();
    return [for (final lv in levels) _levelRow(context, store, lv)];
  }

  Widget _levelRow(BuildContext context, LiuliStore store, int lv) {
    final items = LiuliData.vocab.where((v) => v.lv == lv).toList();
    final master = items.where((v) => store.isMastered(v.h)).length;
    final due = items.where((v) => store.isDue(v.h)).length;
    final pct = items.isEmpty ? 0.0 : master / items.length;
    final c = levelColor(lv);
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => startLiuliStudy(context,
            pred: (v) => v.lv == lv, label: 'Level $lv · ${levelName(lv)}'),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Container(
              width: 52,
              height: 52,
              decoration:
                  BoxDecoration(color: c, borderRadius: BorderRadius.circular(14)),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('Lv$lv',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        height: 1.1)),
                Text(LiuliData.cefr[lv] ?? 'TOCFL',
                    style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.85),
                        fontSize: 10,
                        fontWeight: FontWeight.w700)),
              ]),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(
                    child: Text(levelName(lv),
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                  ),
                  if (due > 0) Pill('⏰ $due', color: Mastery.learning),
                ]),
                const SizedBox(height: 7),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: pct,
                    minHeight: 6,
                    backgroundColor: LiuliColors.surface2,
                    color: c,
                  ),
                ),
                const SizedBox(height: 6),
                Row(children: [
                  Pill('${items.length} kata', color: c),
                  const Spacer(),
                  Text('${(pct * 100).round()}% dikuasai',
                      style: TextStyle(
                          fontSize: 11.5, fontWeight: FontWeight.w700, color: c)),
                ]),
              ]),
            ),
            const SizedBox(width: 4),
            Icon(Icons.chevron_right, color: c),
          ]),
        ),
      ),
    );
  }

  /// Kartu deck otomatis (Kata lemah / Baru salah / Favorit).
  Widget _autoDeck(
    BuildContext context, {
    required IconData icon,
    required Color color,
    required String title,
    required String sub,
    required String empty,
    required List<Vocab> list,
  }) {
    final has = list.isNotEmpty;
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: has
            ? () => startLiuliStudy(context, explicit: list, label: title)
            : null,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: color.withValues(alpha: has ? 0.14 : 0.07),
                borderRadius: BorderRadius.circular(13),
              ),
              child: Icon(icon, color: has ? color : color.withValues(alpha: 0.4)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Text(title,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                  const SizedBox(width: 8),
                  if (has) Pill('${list.length} kata', color: color),
                ]),
                const SizedBox(height: 2),
                Text(has ? sub : empty,
                    style: TextStyle(fontSize: 11.5, color: LiuliColors.text2)),
              ]),
            ),
            Icon(Icons.chevron_right,
                color: has ? Colors.grey : Colors.grey.shade300),
          ]),
        ),
      ),
    );
  }

  Widget _deckTile(BuildContext context, LiuliStore store, Deck dk) {
    final items = LiuliData.vocab.where((v) => v.deck == dk.id).toList();
    if (items.isEmpty) return const SizedBox.shrink();
    final seen = items.where((v) => !store.isNew(v.h)).length;
    final master = items.where((v) => store.isMastered(v.h)).length;
    final pct = master / items.length;
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => startLiuliStudy(context,
            pred: (v) => v.deck == dk.id, label: dk.nameId),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Container(
              width: 44,
              height: 44,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: LiuliColors.jadeTint,
                borderRadius: BorderRadius.circular(13),
              ),
              child: Text(dk.mark, style: hanziStyle(size: 22, color: LiuliColors.jadeDeep)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${store.zh(dk.name)} · ${dk.nameId}',
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                  const SizedBox(height: 2),
                  Text('$seen/${items.length} dipelajari · $master dikuasai',
                      style: TextStyle(fontSize: 11.5, color: LiuliColors.text2)),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: pct,
                      minHeight: 5,
                      backgroundColor: LiuliColors.surface2,
                      color: LiuliColors.jade,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.grey),
          ]),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  _RingPainter(this.progress);
  final double progress;
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 5;
    final bg = Paint()
      ..color = LiuliColors.surface2
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9;
    canvas.drawCircle(c, r, bg);
    final fg = Paint()
      ..color = LiuliColors.jade
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(Rect.fromCircle(center: c, radius: r), -pi / 2,
        2 * pi * progress, false, fg);
  }

  @override
  bool shouldRepaint(covariant _RingPainter old) => old.progress != progress;
}

class _Heatmap extends StatelessWidget {
  const _Heatmap({required this.daily});
  final Map<String, int> daily;

  Color _color(int c) {
    if (c == 0) return LiuliColors.surface2;
    if (c < 4) return LiuliColors.jade.withValues(alpha: 0.30);
    if (c < 10) return LiuliColors.jade.withValues(alpha: 0.55);
    if (c < 20) return LiuliColors.jade.withValues(alpha: 0.78);
    return LiuliColors.jade;
  }

  @override
  Widget build(BuildContext context) {
    const weeks = 18;
    final t = DateTime.now();
    final today = DateTime(t.year, t.month, t.day);
    final lastSun = today.subtract(Duration(days: today.weekday % 7));
    final start = lastSun.subtract(const Duration(days: (weeks - 1) * 7));
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (var w = 0; w < weeks; w++)
                  Padding(
                    padding: const EdgeInsets.only(right: 3),
                    child: Column(children: [
                      for (var d = 0; d < 7; d++)
                        () {
                          final cur = start.add(Duration(days: w * 7 + d));
                          if (cur.isAfter(today)) {
                            return const SizedBox(width: 13, height: 13);
                          }
                          final key = cur.toIso8601String().substring(0, 10);
                          final c = daily[key] ?? 0;
                          return Container(
                            width: 13,
                            height: 13,
                            margin: const EdgeInsets.only(bottom: 3),
                            decoration: BoxDecoration(
                              color: _color(c),
                              borderRadius: BorderRadius.circular(3),
                            ),
                          );
                        }(),
                    ]),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            Text('Sedikit ', style: TextStyle(fontSize: 10, color: LiuliColors.text3)),
            for (final c in [0, 3, 9, 19, 25])
              Container(
                width: 11,
                height: 11,
                margin: const EdgeInsets.symmetric(horizontal: 1),
                decoration: BoxDecoration(
                    color: _color(c), borderRadius: BorderRadius.circular(3)),
              ),
            Text(' Banyak', style: TextStyle(fontSize: 10, color: LiuliColors.text3)),
          ]),
        ]),
      ),
    );
  }
}
