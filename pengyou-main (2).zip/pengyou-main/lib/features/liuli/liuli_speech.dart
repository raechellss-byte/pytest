import 'dart:math';

import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';

import 'liuli_common.dart';
import 'liuli_data.dart';
import 'liuli_store.dart';

final _han = RegExp(r'[㐀-鿿]');

/// Normalisasi untuk perbandingan: hanya Han, dikonversi ke simplified (T2S).
String _normCmp(String s) {
  final t2s = LiuliData.t2sSync;
  final b = StringBuffer();
  for (final c in s.runes.map(String.fromCharCode)) {
    if (_han.hasMatch(c)) b.write(t2s?[c] ?? c);
  }
  return b.toString();
}

class _Lcs {
  _Lcs(this.len, this.marks);
  final int len;
  final List<bool> marks; // panjang = a.length
}

_Lcs _lcsMarks(String a, String b) {
  final m = a.length, n = b.length;
  final dp = List.generate(m + 1, (_) => List<int>.filled(n + 1, 0));
  for (var x = 1; x <= m; x++) {
    for (var y = 1; y <= n; y++) {
      dp[x][y] = a[x - 1] == b[y - 1]
          ? dp[x - 1][y - 1] + 1
          : max(dp[x - 1][y], dp[x][y - 1]);
    }
  }
  final marks = List<bool>.filled(m, false);
  var x = m, y = n;
  while (x > 0 && y > 0) {
    if (a[x - 1] == b[y - 1]) {
      marks[x - 1] = true;
      x--;
      y--;
    } else if (dp[x - 1][y] >= dp[x][y - 1]) {
      x--;
    } else {
      y--;
    }
  }
  return _Lcs(dp[m][n], marks);
}

/// Skor kemiripan ucapan 0–100 terhadap [target] (alternatif terbaik dipakai).
/// Juga mengembalikan tanda per karakter Han target yang terucap benar.
({int score, String heard, List<bool> marks}) speechScore(
    String target, List<String> alts) {
  final t = _normCmp(target);
  var best = (score: -1, heard: alts.isNotEmpty ? alts.first : '', marks: <bool>[]);
  for (final tr in alts) {
    final lcs = _lcsMarks(t, _normCmp(tr));
    final sc = (lcs.len / max(1, t.length) * 100).round();
    if (sc > best.score) best = (score: sc, heard: tr, marks: lcs.marks);
  }
  return best;
}

class SpeakQuizScreen extends StatefulWidget {
  const SpeakQuizScreen({super.key});
  @override
  State<SpeakQuizScreen> createState() => _SpeakQuizScreenState();
}

class _SpeakQuizScreenState extends State<SpeakQuizScreen> {
  final _rng = Random();
  final SpeechToText _stt = SpeechToText();
  bool _available = false;
  bool _initTried = false;
  bool _listening = false;

  late List<Sentence> pool;
  int i = 0;
  final List<int> scores = [];

  int bestScore = -1;
  String heard = '';
  List<bool> marks = const [];
  String status = 'Ketuk 🎤 lalu ucapkan kalimatnya';

  final store = LiuliStore.instance;

  @override
  void initState() {
    super.initState();
    pool = [...LiuliData.sentences]..shuffle(_rng);
    pool = pool.take(8).toList();
    LiuliData.t2s(); // untuk normalisasi skor
    _initStt();
  }

  Future<void> _initStt() async {
    _initTried = true;
    try {
      _available = await _stt.initialize(
        onStatus: (s) {
          if (mounted && (s == 'done' || s == 'notListening')) {
            setState(() => _listening = false);
          }
        },
        onError: (e) {
          if (mounted) {
            setState(() {
              _listening = false;
              status = 'Tidak bisa mengenali (${e.errorMsg}). Coba lagi.';
            });
          }
        },
      );
    } catch (_) {
      _available = false;
    }
    if (mounted) {
      setState(() {
        if (!_available) {
          status =
              '⚠️ Perangkat/browser ini belum mendukung penilaian suara — pakai untuk latihan dengar & tirukan.';
        }
      });
    }
  }

  Future<void> _listen() async {
    if (!_initTried) await _initStt();
    if (!_available) return;
    final s = pool[i];
    setState(() {
      _listening = true;
      status = '🎙️ Mendengarkan… ucapkan sekarang';
    });
    await _stt.listen(
      listenOptions:
          SpeechListenOptions(partialResults: false, localeId: 'zh_TW'),
      onResult: (r) {
        if (!r.finalResult) return;
        final alts = r.alternates.isNotEmpty
            ? r.alternates.map((a) => a.recognizedWords).toList()
            : [r.recognizedWords];
        _score(s, alts);
      },
    );
  }

  void _score(Sentence s, List<String> alts) {
    final target = _normCmp(s.h);
    var best = (score: -1, tr: alts.isNotEmpty ? alts.first : '', marks: <bool>[]);
    for (final tr in alts) {
      final rn = _normCmp(tr);
      final lcs = _lcsMarks(target, rn);
      final sc = (lcs.len / max(1, target.length) * 100).round();
      if (sc > best.score) best = (score: sc, tr: tr, marks: lcs.marks);
    }
    if (best.score > bestScore) bestScore = best.score;
    // Petakan marks (per Han target char) ke urutan karakter tampilan.
    setState(() {
      _listening = false;
      heard = best.tr;
      marks = best.marks;
      status = best.score >= 85
          ? '完美！Nyaris sempurna 🎉'
          : best.score >= 65
              ? '不錯！Bagus, terus asah.'
              : best.score >= 40
                  ? '加油！Cukup dimengerti.'
                  : 'Coba lagi, ucapkan lebih jelas.';
    });
  }

  Color get _scoreColor => bestScore >= 65
      ? LiuliColors.good
      : bestScore >= 40
          ? LiuliColors.hard
          : LiuliColors.again;

  void _next() {
    _stt.stop();
    if (bestScore >= 0) store.logAnswer(bestScore >= 65);
    if (bestScore >= 65) store.award('speak');
    scores.add(bestScore < 0 ? 0 : bestScore);
    setState(() {
      i++;
      bestScore = -1;
      heard = '';
      marks = const [];
      status = _available
          ? 'Ketuk 🎤 lalu ucapkan kalimatnya'
          : '⚠️ Penilaian suara tidak tersedia — latihan dengar & tirukan.';
    });
  }

  @override
  void dispose() {
    _stt.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final done = i >= pool.length;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bicara 口說', style: TextStyle(fontSize: 17)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: LinearProgressIndicator(
            value: done ? 1 : i / pool.length,
            backgroundColor: LiuliColors.surface2,
            color: LiuliColors.seal,
            minHeight: 4,
          ),
        ),
      ),
      body: done ? _result() : _question(),
    );
  }

  Widget _question() {
    final s = pool[i];
    // Bangun tampilan target dengan highlight per Han char.
    var k = 0;
    final spans = <InlineSpan>[];
    for (final ch in s.h.runes.map(String.fromCharCode)) {
      if (_han.hasMatch(ch)) {
        final ok = k < marks.length ? marks[k] : null;
        k++;
        spans.add(TextSpan(
          text: store.zh(ch),
          style: hanziStyle(size: 30).copyWith(
            color: ok == null
                ? LiuliColors.ink
                : (ok ? LiuliColors.good : LiuliColors.again),
          ),
        ));
      } else {
        spans.add(TextSpan(text: store.zh(ch), style: hanziStyle(size: 30)));
      }
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Soal ${i + 1} / ${pool.length} · Ucapkan kalimat ini',
            textAlign: TextAlign.center,
            style: TextStyle(color: LiuliColors.text2, fontWeight: FontWeight.w700)),
        const SizedBox(height: 18),
        Center(child: Text.rich(TextSpan(children: spans), textAlign: TextAlign.center)),
        if (store.pinyin) ...[
          const SizedBox(height: 6),
          Center(
              child: Text(s.p,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: LiuliColors.jadeDeep))),
        ],
        const SizedBox(height: 4),
        Center(child: Text(s.id, textAlign: TextAlign.center, style: TextStyle(color: LiuliColors.text2))),
        const SizedBox(height: 12),
        Center(child: SayButton(text: s.h, label: 'Dengar contoh', compact: true)),
        const SizedBox(height: 20),
        Center(
          child: GestureDetector(
            onTap: _listening ? () => _stt.stop() : _listen,
            child: Container(
              width: 84,
              height: 84,
              decoration: BoxDecoration(
                color: _listening ? LiuliColors.seal : LiuliColors.jade,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                      color: (_listening ? LiuliColors.seal : LiuliColors.jade)
                          .withValues(alpha: 0.4),
                      blurRadius: _listening ? 20 : 10,
                      spreadRadius: _listening ? 4 : 0),
                ],
              ),
              child: const Icon(Icons.mic, color: Colors.white, size: 36),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Center(
            child: Text(status,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontWeight: FontWeight.w700,
                    color: bestScore >= 0 ? _scoreColor : LiuliColors.text2))),
        if (bestScore >= 0) ...[
          const SizedBox(height: 12),
          Center(
              child: Text('$bestScore%',
                  style: TextStyle(
                      fontSize: 44, fontWeight: FontWeight.w900, color: _scoreColor))),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 6),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: bestScore / 100,
                minHeight: 8,
                backgroundColor: LiuliColors.surface2,
                color: _scoreColor,
              ),
            ),
          ),
          Center(
              child: Text('Terdengar: ${heard.isEmpty ? "(kosong)" : heard}',
                  style: TextStyle(fontSize: 13, color: LiuliColors.text2))),
          const SizedBox(height: 6),
          Center(
            child: TextButton.icon(
              onPressed: _listen,
              icon: const Icon(Icons.mic, size: 16),
              label: const Text('Coba lagi'),
            ),
          ),
        ],
        const SizedBox(height: 16),
        FilledButton(
          onPressed: _next,
          style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
          child: Text(i + 1 >= pool.length ? 'Lihat hasil' : 'Lewati / berikutnya →'),
        ),
      ],
    );
  }

  Widget _result() {
    final arr = scores.where((x) => x > 0).toList();
    final avg =
        arr.isEmpty ? 0 : (arr.reduce((a, b) => a + b) / arr.length).round();
    final msg = avg >= 80
        ? '讚！Pengucapanmu jelas.'
        : avg >= 55
            ? '不錯！Terus latihan tiap hari.'
            : arr.isNotEmpty
                ? '加油！Fokus tiru audio native.'
                : 'Belum ada yang dinilai — pastikan mikrofon aktif.';
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('口說', style: hanziStyle(size: 50, color: LiuliColors.seal)),
          const SizedBox(height: 10),
          Text('Rata-rata $avg%',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text('$msg (${arr.length}/${pool.length} kalimat dinilai)',
              textAlign: TextAlign.center,
              style: TextStyle(color: LiuliColors.text2)),
          const SizedBox(height: 22),
          FilledButton(
            onPressed: () => setState(() {
              i = 0;
              scores.clear();
              bestScore = -1;
              heard = '';
              marks = const [];
              pool = [...LiuliData.sentences]..shuffle(_rng);
              pool = pool.take(8).toList();
            }),
            style: FilledButton.styleFrom(backgroundColor: LiuliColors.jade),
            child: const Text('Ulangi latihan bicara'),
          ),
          const SizedBox(height: 8),
          OutlinedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Selesai')),
        ]),
      ),
    );
  }
}
