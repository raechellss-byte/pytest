import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../i18n/strings.dart';

const onboardingSeenKey = 'onboarding_seen_v1';

class _Page {
  const _Page(this.emoji, this.titleKey, this.bodyKey, this.colors);
  final String emoji;
  final String titleKey;
  final String bodyKey;
  final List<Color> colors;
}

const _pages = [
  _Page('🤝', 'ob1_title', 'ob1_body', [Color(0xFFB01E2C), Color(0xFFE23744)]),
  _Page('📍', 'ob2_title', 'ob2_body', [Color(0xFF0E7C6E), Color(0xFF0E9C8B)]),
  _Page('🔔', 'ob3_title', 'ob3_body', [Color(0xFF9A5B00), Color(0xFFFFB020)]),
];

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _page = 0;

  Future<void> _finish() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(onboardingSeenKey, true);
    if (mounted) context.go('/beranda');
  }

  @override
  Widget build(BuildContext context) {
    final p = _pages[_page];
    return Scaffold(
      body: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: p.colors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Column(children: [
            Align(
              alignment: Alignment.topRight,
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                _LangToggle(),
                TextButton(
                  onPressed: _finish,
                  child: Text(tr('skip'),
                      style: const TextStyle(color: Colors.white70)),
                ),
              ]),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: _pages.length,
                onPageChanged: (i) => setState(() => _page = i),
                itemBuilder: (_, i) {
                  final page = _pages[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(28),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.16),
                            shape: BoxShape.circle,
                          ),
                          child: Text(page.emoji,
                              style: const TextStyle(fontSize: 72)),
                        ),
                        const SizedBox(height: 40),
                        Text(tr(page.titleKey),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 26,
                                fontWeight: FontWeight.w900,
                                height: 1.2)),
                        const SizedBox(height: 16),
                        Text(tr(page.bodyKey),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.92),
                                fontSize: 15,
                                height: 1.6)),
                      ],
                    ),
                  );
                },
              ),
            ),
            // Indikator titik
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_pages.length, (i) {
                final active = i == _page;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: active ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: active ? 1 : 0.4),
                    borderRadius: BorderRadius.circular(4),
                  ),
                );
              }),
            ),
            const SizedBox(height: 24),
            Padding(
              padding: const EdgeInsets.fromLTRB(32, 0, 32, 28),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: p.colors.last,
                  ),
                  onPressed: () {
                    if (_page < _pages.length - 1) {
                      _controller.nextPage(
                          duration: const Duration(milliseconds: 350),
                          curve: Curves.easeInOut);
                    } else {
                      _finish();
                    }
                  },
                  child: Text(_page < _pages.length - 1 ? tr('next') : tr('start')),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

/// Pemilih bahasa cepat (dipakai di onboarding).
class _LangToggle extends StatefulWidget {
  @override
  State<_LangToggle> createState() => _LangToggleState();
}

class _LangToggleState extends State<_LangToggle> {
  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.language, color: Colors.white),
      onSelected: (v) async {
        await Lang.instance.set(v);
        if (mounted) setState(() {});
      },
      itemBuilder: (_) => Lang.supported.entries
          .map((e) => PopupMenuItem(value: e.key, child: Text(e.value)))
          .toList(),
    );
  }
}
