import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../theme.dart';

class AdminInterpretersScreen extends StatefulWidget {
  const AdminInterpretersScreen({super.key});

  @override
  State<AdminInterpretersScreen> createState() =>
      _AdminInterpretersScreenState();
}

class _AdminInterpretersScreenState extends State<AdminInterpretersScreen> {
  late Future<List<Map<String, dynamic>>> _future;
  String _filter = 'pending'; // pending | verified | all

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await Supabase.instance.client
        .from('interpreter_profiles')
        .select('*, users(full_name, email, phone), '
            'language_pairs(source_language, target_language), '
            'interpreter_services(service_categories(name_id))')
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> _viewIdPhoto(String path) async {
    try {
      final url = await Supabase.instance.client.storage
          .from('verification')
          .createSignedUrl(path, 120);
      final uri = Uri.tryParse(url);
      if (uri != null) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal membuka foto: $e')));
      }
    }
  }

  Future<void> _setVerified(String profileId, bool value) async {
    await Supabase.instance.client.rpc('admin_set_verified',
        params: {'p_profile_id': profileId, 'p_verified': value});
    setState(() => _future = _load());
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(value
              ? 'Penerjemah diverifikasi ✓'
              : 'Verifikasi dicabut')));
    }
  }

  List<Map<String, dynamic>> _apply(List<Map<String, dynamic>> rows) {
    return switch (_filter) {
      // Yang lolos tes AI di atas, yang ditolak AI di bawah.
      'pending' => sortByAiVerdict(
          rows.where((r) => r['is_verified'] != true).toList()),
      'verified' => rows.where((r) => r['is_verified'] == true).toList(),
      _ => rows,
    };
  }

  Future<void> _showAnswers(Map<String, dynamic> r) async {
    final rows = await Supabase.instance.client
        .from('interpreter_screenings')
        .select('answers, scores, total, verdict, created_at')
        .eq('interpreter_id', r['id'])
        .order('created_at', ascending: false)
        .limit(1);
    if (!mounted) return;
    final s = rows.isEmpty ? null : rows.first;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _AnswersSheet(
          name: r['users']?['full_name'] ?? 'Pelamar', screening: s),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async => setState(() => _future = _load()),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const GradientHeader(
              title: 'Verifikasi Penerjemah',
              subtitle: 'Tinjau & setujui calon penerjemah',
              icon: Icons.verified_user,
              showBack: true,
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'pending', label: Text('Menunggu')),
                  ButtonSegment(value: 'verified', label: Text('Terverifikasi')),
                  ButtonSegment(value: 'all', label: Text('Semua')),
                ],
                selected: {_filter},
                onSelectionChanged: (s) => setState(() => _filter = s.first),
              ),
            ),
            FutureBuilder(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(40),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                if (snap.hasError) {
                  return Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('Gagal memuat: ${snap.error}'),
                  );
                }
                final rows = _apply(snap.data!);
                if (rows.isEmpty) {
                  return const EmptyState(
                    icon: Icons.how_to_reg,
                    message: 'Tidak ada penerjemah pada kategori ini.',
                  );
                }
                return Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                  child: Column(
                    children: rows.map(_card).toList(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(Map<String, dynamic> r) {
    final name = r['users']?['full_name'] ?? 'Tanpa nama';
    final verified = r['is_verified'] == true;
    final pairs = List<Map<String, dynamic>>.from(r['language_pairs'] ?? []);
    final services = List<Map<String, dynamic>>.from(r['interpreter_services'] ?? []);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              NameAvatar(name: name, radius: 24),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name,
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 15)),
                    Text(r['users']?['email'] ?? '',
                        style: TextStyle(
                            fontSize: 12, color: Colors.brown.shade500)),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: (verified ? Colors.green : Colors.orange)
                      .withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(verified ? 'Terverifikasi' : 'Menunggu',
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: verified
                            ? Colors.green.shade700
                            : Colors.orange.shade800)),
              ),
            ]),
            const SizedBox(height: 10),
            _row('Kota', r['city'] ?? '-'),
            _row('Tarif',
                r['hourly_rate'] != null ? 'NT\$ ${r['hourly_rate']}/jam' : '-'),
            if (pairs.isNotEmpty)
              _row('Bahasa',
                  pairs.map((p) => '${p['source_language']}→${p['target_language']}').join(', ')),
            if (services.isNotEmpty)
              _row('Layanan',
                  services.map((s) => s['service_categories']?['name_id'] ?? '').join(', ')),
            if ((r['bio'] ?? '').toString().isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(r['bio'], style: const TextStyle(fontSize: 13)),
            ],
            if (!verified) ...[
              const SizedBox(height: 10),
              _AiVerdict(profile: r, onAnswers: () => _showAnswers(r)),
            ],
            if ((r['id_photo_path'] ?? '').toString().isNotEmpty) ...[
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () => _viewIdPhoto(r['id_photo_path']),
                icon: const Icon(Icons.badge, size: 18),
                label: const Text('Lihat Foto ID'),
                style: OutlinedButton.styleFrom(
                    minimumSize: const Size.fromHeight(42)),
              ),
            ],
            const SizedBox(height: 12),
            Row(children: [
              if (!verified)
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => _setVerified(r['id'], true),
                    icon: const Icon(Icons.check, size: 18),
                    label: const Text('Verifikasi'),
                    style: FilledButton.styleFrom(
                        backgroundColor: Colors.green.shade600,
                        minimumSize: const Size.fromHeight(44)),
                  ),
                )
              else
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _setVerified(r['id'], false),
                    icon: const Icon(Icons.block, size: 18),
                    label: const Text('Cabut Verifikasi'),
                    style: OutlinedButton.styleFrom(
                        minimumSize: const Size.fromHeight(44)),
                  ),
                ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value) => adminRow(label, value);
}

/// Urutan antrean verifikasi: lolos AI → ditinjau → belum tes → ditolak AI.
List<Map<String, dynamic>> sortByAiVerdict(List<Map<String, dynamic>> rows) {
  const rank = {'pass': 0, 'review': 1, null: 2, 'reject': 3};
  return [...rows]..sort((a, b) =>
      (rank[a['ai_verdict']] ?? 2).compareTo(rank[b['ai_verdict']] ?? 2));
}

const _verdictLabel = {
  'pass': 'Lolos',
  'review': 'Perlu ditinjau',
  'reject': 'Ditolak AI',
};

/// Ringkasan penilaian AI pada kartu calon penerjemah.
class _AiVerdict extends StatelessWidget {
  const _AiVerdict({required this.profile, required this.onAnswers});
  final Map<String, dynamic> profile;
  final VoidCallback onAnswers;

  @override
  Widget build(BuildContext context) {
    final verdict = profile['ai_verdict'] as String?;
    if (verdict == null) {
      return Text('🤖 Belum ikut tes bahasa',
          style: TextStyle(fontSize: 12.5, color: Colors.brown.shade500));
    }
    final total = profile['ai_total'] as num?;
    // Tanpa skor = belum dinilai AI (API key belum dipasang / AI gagal).
    final manual = total == null;
    final color = switch (verdict) {
      'pass' => Colors.green.shade700,
      'reject' => Colors.red.shade700,
      _ => Colors.orange.shade800,
    };
    final flags = List<String>.from(profile['ai_flags'] ?? const []);
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(manual ? Icons.assignment_outlined : Icons.smart_toy_outlined,
                size: 18, color: color),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                  manual
                      ? 'Tes masuk · nilai manual'
                      : 'AI ${total.round()} · ${_verdictLabel[verdict] ?? verdict}',
                  style: TextStyle(fontWeight: FontWeight.w800, color: color)),
            ),
            TextButton(onPressed: onAnswers, child: const Text('Lihat jawaban')),
          ]),
          if ((profile['ai_summary'] ?? '').toString().isNotEmpty)
            Text('${profile['ai_summary']}', style: const TextStyle(fontSize: 13)),
          if (flags.isNotEmpty) ...[
            const SizedBox(height: 6),
            Wrap(spacing: 6, runSpacing: 4, children: [
              for (final f in flags)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.red.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(f.replaceAll('_', ' '),
                      style:
                          TextStyle(fontSize: 11, color: Colors.red.shade700)),
                ),
            ]),
          ],
        ],
      ),
    );
  }
}

/// Soal & jawaban tes terakhir, supaya admin bisa memeriksa penilaian AI.
class _AnswersSheet extends StatelessWidget {
  const _AnswersSheet({required this.name, required this.screening});
  final String name;
  final Map<String, dynamic>? screening;

  @override
  Widget build(BuildContext context) {
    final answers = List<Map<String, dynamic>>.from(screening?['answers'] ?? const []);
    final scores = Map<String, dynamic>.from(screening?['scores'] ?? const {});
    const scoreLabels = {
      'translation_id_zh': 'Indonesia → Mandarin',
      'translation_zh_id': 'Mandarin → Indonesia',
      'mandarin_writing': 'Menulis Mandarin',
      'seriousness': 'Kesungguhan',
    };
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.75,
      builder: (_, controller) => ListView(
        controller: controller,
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        children: [
          Text('Jawaban tes · $name',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (screening == null) const Text('Belum ada jawaban tes.'),
          for (final e in scoreLabels.entries)
            if (scores[e.key] != null)
              adminRow(e.value, '${scores[e.key]} / 100', labelWidth: 150),
          for (final a in answers) ...[
            const Divider(height: 24),
            Text('${a['context'] ?? 'Menulis bebas'} · ${a['kind']}',
                style: TextStyle(fontSize: 12, color: Colors.brown.shade500)),
            const SizedBox(height: 4),
            Text('${a['prompt']}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text('${a['answer']}', style: const TextStyle(fontSize: 15)),
          ],
        ],
      ),
    );
  }
}

/// Baris label–nilai kecil pada kartu & lembar jawaban.
Widget adminRow(String label, String value, {double labelWidth = 66}) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 2),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(
          width: labelWidth,
          child: Text(label,
              style: TextStyle(fontSize: 12.5, color: Colors.brown.shade500))),
      Expanded(
          child: Text(value,
              style: const TextStyle(
                  fontSize: 12.5, fontWeight: FontWeight.w600))),
    ]),
  );
}
