import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme.dart';
import '../booking/bookings_screen.dart' show statusLabels, statusColors;

class AdminBookingsScreen extends StatefulWidget {
  const AdminBookingsScreen({super.key});

  @override
  State<AdminBookingsScreen> createState() => _AdminBookingsScreenState();
}

class _AdminBookingsScreenState extends State<AdminBookingsScreen> {
  late Future<List<Map<String, dynamic>>> _future;
  String _filter = 'all';

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await Supabase.instance.client
        .from('bookings')
        .select('id, status, service_type, scheduled_at, description, '
            'users!bookings_client_id_fkey(full_name), '
            'interpreter_profiles(users(full_name)), '
            'service_categories(name_id)')
        .order('created_at', ascending: false)
        .limit(200);
    return List<Map<String, dynamic>>.from(rows);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async => setState(() => _future = _load()),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const GradientHeader(
              title: 'Pantau Pesanan',
              subtitle: 'Semua pemesanan di platform',
              icon: Icons.event_note,
              showBack: true,
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: [
                  _chip('all', 'Semua'),
                  _chip('requested', 'Menunggu'),
                  _chip('accepted', 'Diterima'),
                  _chip('in_progress', 'Berjalan'),
                  _chip('completed', 'Selesai'),
                  _chip('cancelled', 'Batal'),
                ]),
              ),
            ),
            FutureBuilder(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(40),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                var rows = snap.data ?? [];
                if (_filter != 'all') {
                  rows = rows.where((b) => b['status'] == _filter).toList();
                }
                if (rows.isEmpty) {
                  return const EmptyState(
                      icon: Icons.inbox, message: 'Tidak ada pesanan.');
                }
                return Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                  child: Column(children: rows.map(_card).toList()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _chip(String value, String label) {
    final sel = _filter == value;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: sel,
        onSelected: (_) => setState(() => _filter = value),
      ),
    );
  }

  Widget _card(Map<String, dynamic> b) {
    final status = b['status'] as String;
    final client = b['users']?['full_name'] ?? '-';
    final interp = (b['interpreter_profiles']?['users'])?['full_name'] ?? '-';
    final dt = DateTime.tryParse('${b['scheduled_at'] ?? ''}')?.toLocal();
    final color = statusColors[status] ?? Colors.grey;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 4),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(
                child: Text('$client → $interp',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(8)),
                child: Text(statusLabels[status] ?? status,
                    style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: color)),
              ),
            ]),
            const SizedBox(height: 4),
            Text(
              '${b['service_categories']?['name_id'] ?? '-'}'
              '${dt != null ? ' · ${DateFormat('d MMM y, HH:mm').format(dt)}' : ''}',
              style: TextStyle(fontSize: 12.5, color: Colors.brown.shade600),
            ),
            if ((b['description'] ?? '').toString().isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(b['description'],
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12.5)),
              ),
          ],
        ),
      ),
    );
  }
}
