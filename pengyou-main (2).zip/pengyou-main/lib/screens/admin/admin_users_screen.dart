import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme.dart';

const _roleLabels = {
  'client': 'Client',
  'interpreter': 'Penerjemah',
  'institution': 'Institusi',
  'admin': 'Admin',
};

class AdminUsersScreen extends StatefulWidget {
  const AdminUsersScreen({super.key});

  @override
  State<AdminUsersScreen> createState() => _AdminUsersScreenState();
}

class _AdminUsersScreenState extends State<AdminUsersScreen> {
  late Future<List<Map<String, dynamic>>> _future;
  String _search = '';

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await Supabase.instance.client
        .from('users')
        .select()
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> _toggleActive(Map<String, dynamic> u) async {
    final newValue = !(u['is_active'] == true);
    await Supabase.instance.client
        .from('users')
        .update({'is_active': newValue}).eq('id', u['id']);
    setState(() => _future = _load());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async => setState(() => _future = _load()),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const GradientHeader(
              title: 'Kelola Pengguna',
              subtitle: 'Semua akun terdaftar',
              icon: Icons.people_alt,
              showBack: true,
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                decoration: const InputDecoration(
                    hintText: 'Cari nama / email…',
                    prefixIcon: Icon(Icons.search)),
                onChanged: (v) => setState(() => _search = v.toLowerCase()),
              ),
            ),
            FutureBuilder(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(40),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                if (snap.hasError) {
                  return Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('Gagal memuat: ${snap.error}'),
                  );
                }
                var rows = snap.data!;
                if (_search.isNotEmpty) {
                  rows = rows.where((u) {
                    final n = '${u['full_name'] ?? ''}'.toLowerCase();
                    final e = '${u['email'] ?? ''}'.toLowerCase();
                    return n.contains(_search) || e.contains(_search);
                  }).toList();
                }
                if (rows.isEmpty) {
                  return const EmptyState(
                      icon: Icons.person_off, message: 'Tidak ada pengguna.');
                }
                return Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                  child: Column(children: rows.map(_card).toList()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(Map<String, dynamic> u) {
    final name = u['full_name'] ?? '-';
    final active = u['is_active'] == true;
    final role = u['role'] ?? 'client';
    final created = DateTime.tryParse('${u['created_at'] ?? ''}')?.toLocal();
    final roleColor = switch (role) {
      'admin' => const Color(0xFFE23744),
      'interpreter' => const Color(0xFF0E9C8B),
      'institution' => const Color(0xFF7C3AED),
      _ => const Color(0xFF2563EB),
    };
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 4),
      child: ListTile(
        leading: NameAvatar(name: name, radius: 22),
        title: Row(children: [
          Flexible(
              child: Text(name,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700))),
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            decoration: BoxDecoration(
                color: roleColor.withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(6)),
            child: Text(_roleLabels[role] ?? role,
                style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: roleColor)),
          ),
        ]),
        subtitle: Text(
          '${u['email'] ?? ''}'
          '${created != null ? '\nGabung ${DateFormat('d MMM y').format(created)}' : ''}',
        ),
        isThreeLine: created != null,
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Switch(value: active, onChanged: (_) => _toggleActive(u)),
            Text(active ? 'Aktif' : 'Nonaktif',
                style: TextStyle(
                    fontSize: 10,
                    color: active ? Colors.green : Colors.grey)),
          ],
        ),
      ),
    );
  }
}
