import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  Map<String, dynamic>? _stats;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final data = await Supabase.instance.client.rpc('admin_stats');
      setState(() {
        _stats = Map<String, dynamic>.from(data as Map);
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = 'Anda bukan admin, atau statistik belum tersedia.\n$e';
      });
    }
  }

  int _n(String key) => (_stats?[key] as num?)?.toInt() ?? 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const GradientHeader(
              title: 'Panel Admin',
              subtitle: 'Ruang kontrol PENGYOU',
              icon: Icons.admin_panel_settings,
              showBack: true,
            ),
            if (_loading)
              const Padding(
                padding: EdgeInsets.all(48),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_error != null)
              Padding(
                padding: const EdgeInsets.all(24),
                child: Card(
                  color: Colors.red.shade50,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(_error!),
                  ),
                ),
              )
            else ...[
              // Statistik
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
                child: Text('Statistik',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w800)),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  childAspectRatio: 1.6,
                  children: [
                    _StatTile(
                      label: 'Total Pengguna',
                      value: _n('total_users'),
                      icon: Icons.people,
                      color: const Color(0xFF2563EB),
                    ),
                    _StatTile(
                      label: 'Penerjemah',
                      value: _n('interpreters'),
                      sub: '${_n('verified_interpreters')} terverifikasi',
                      icon: Icons.record_voice_over,
                      color: const Color(0xFF0E9C8B),
                    ),
                    _StatTile(
                      label: 'Menunggu Verifikasi',
                      value: _n('pending_interpreters'),
                      icon: Icons.pending_actions,
                      color: const Color(0xFFEA580C),
                      highlight: _n('pending_interpreters') > 0,
                    ),
                    _StatTile(
                      label: 'Total Pesanan',
                      value: _n('total_bookings'),
                      sub: '${_n('active_bookings')} aktif',
                      icon: Icons.event_note,
                      color: const Color(0xFF7C3AED),
                    ),
                    _StatTile(
                      label: 'Pesanan Selesai',
                      value: _n('completed_bookings'),
                      icon: Icons.check_circle,
                      color: const Color(0xFF16A34A),
                    ),
                    _StatTile(
                      label: 'Berita',
                      value: _n('total_news'),
                      icon: Icons.newspaper,
                      color: const Color(0xFFDB2777),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              // Menu manajemen
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: Text('Manajemen',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w800)),
              ),
              _MenuTile(
                icon: Icons.verified_user,
                color: const Color(0xFF0E9C8B),
                title: 'Verifikasi Penerjemah',
                subtitle: '${_n('pending_interpreters')} menunggu',
                onTap: () => context.push('/admin/penerjemah'),
              ),
              _MenuTile(
                icon: Icons.people_alt,
                color: const Color(0xFF2563EB),
                title: 'Kelola Pengguna',
                subtitle: '${_n('total_users')} pengguna',
                onTap: () => context.push('/admin/pengguna'),
              ),
              _MenuTile(
                icon: Icons.newspaper,
                color: const Color(0xFFDB2777),
                title: 'Kelola Berita & Banner',
                subtitle: '${_n('total_news')} berita',
                onTap: () => context.push('/admin/berita'),
              ),
              _MenuTile(
                icon: Icons.event_note,
                color: const Color(0xFF7C3AED),
                title: 'Pantau Pesanan',
                subtitle: '${_n('total_bookings')} pesanan',
                onTap: () => context.push('/admin/pesanan'),
              ),
              _MenuTile(
                icon: Icons.map,
                color: const Color(0xFF0891B2),
                title: 'Kelola Tempat Peta',
                subtitle: 'Lembaga, imigrasi, RS, dll.',
                onTap: () => context.push('/admin/tempat'),
              ),
              const SizedBox(height: 24),
            ],
          ],
        ),
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    this.sub,
    this.highlight = false,
  });
  final String label;
  final int value;
  final String? sub;
  final IconData icon;
  final Color color;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: highlight ? color.withValues(alpha: 0.08) : Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const Spacer(),
              Text('$value',
                  style: TextStyle(
                      fontSize: 26, fontWeight: FontWeight.w900, color: color)),
            ]),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        fontSize: 12.5, fontWeight: FontWeight.w700)),
                if (sub != null)
                  Text(sub!,
                      style: TextStyle(
                          fontSize: 11, color: Colors.brown.shade500)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  const _MenuTile({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.14),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
