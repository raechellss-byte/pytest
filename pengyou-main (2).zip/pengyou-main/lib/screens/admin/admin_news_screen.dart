import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme.dart';

class AdminNewsScreen extends StatefulWidget {
  const AdminNewsScreen({super.key});

  @override
  State<AdminNewsScreen> createState() => _AdminNewsScreenState();
}

class _AdminNewsScreenState extends State<AdminNewsScreen> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await Supabase.instance.client
        .from('news')
        .select()
        .order('published_at', ascending: false)
        .limit(100);
    return List<Map<String, dynamic>>.from(rows);
  }

  void _reload() => setState(() => _future = _load());

  Future<void> _toggle(String id, String field, bool value) async {
    await Supabase.instance.client.from('news').update({field: value}).eq('id', id);
    _reload();
  }

  Future<void> _delete(Map<String, dynamic> n) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus berita?'),
        content: Text('"${n['title']}" akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: FilledButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;
    await Supabase.instance.client.from('news').delete().eq('id', n['id']);
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await _openEditor(null);
          _reload();
        },
        icon: const Icon(Icons.add),
        label: const Text('Berita Baru'),
      ),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const GradientHeader(
              title: 'Kelola Berita',
              subtitle: 'Tulis, edit, atur banner Beranda',
              icon: Icons.newspaper,
              showBack: true,
            ),
            FutureBuilder(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(40),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                final rows = snap.data ?? [];
                if (rows.isEmpty) {
                  return const EmptyState(
                      icon: Icons.article, message: 'Belum ada berita.');
                }
                return Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 88),
                  child: Column(children: rows.map(_card).toList()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(Map<String, dynamic> n) {
    final featured = n['is_featured'] == true;
    final active = n['is_active'] == true;
    final published = DateTime.tryParse('${n['published_at'] ?? ''}')?.toLocal();
    final color = AppColors.category(n['category'] as String?);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 4),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(
                width: 44, height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(12)),
                child: Text('${n['emoji'] ?? '📰'}',
                    style: const TextStyle(fontSize: 22)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(n['title'] ?? '',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 13.5)),
                    Text(
                        '${n['category'] ?? ''}'
                        '${published != null ? ' · ${DateFormat('d MMM').format(published)}' : ''}'
                        '${n['is_external'] == true ? ' · auto' : ''}',
                        style: TextStyle(
                            fontSize: 11, color: Colors.brown.shade500)),
                  ],
                ),
              ),
            ]),
            const Divider(height: 18),
            Row(children: [
              _toggleChip(
                  'Banner', featured, () => _toggle(n['id'], 'is_featured', !featured)),
              const SizedBox(width: 8),
              _toggleChip(
                  'Aktif', active, () => _toggle(n['id'], 'is_active', !active)),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.edit, size: 20),
                onPressed: () async {
                  await _openEditor(n);
                  _reload();
                },
              ),
              IconButton(
                icon: Icon(Icons.delete_outline, size: 20, color: Colors.red.shade400),
                onPressed: () => _delete(n),
              ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _toggleChip(String label, bool on, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: on
              ? AppColors.primary.withValues(alpha: 0.12)
              : Colors.grey.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(on ? Icons.check_circle : Icons.circle_outlined,
              size: 15,
              color: on ? AppColors.primary : Colors.grey),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: on ? AppColors.primaryDark : Colors.grey.shade700)),
        ]),
      ),
    );
  }

  Future<void> _openEditor(Map<String, dynamic>? existing) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _NewsEditor(existing: existing),
      ),
    );
  }
}

class _NewsEditor extends StatefulWidget {
  const _NewsEditor({this.existing});
  final Map<String, dynamic>? existing;

  @override
  State<_NewsEditor> createState() => _NewsEditorState();
}

class _NewsEditorState extends State<_NewsEditor> {
  late final TextEditingController _title;
  late final TextEditingController _summary;
  late final TextEditingController _body;
  late final TextEditingController _emoji;
  late final TextEditingController _imageUrl;
  late final TextEditingController _sourceUrl;
  String _category = 'Info';
  bool _featured = false;
  bool _saving = false;

  static const _categories = [
    'Info', 'Kejadian', 'Kebijakan PMI', 'Taiwan', 'Kesehatan',
    'Dokumen', 'Layanan', 'Ketenagakerjaan', 'Wisata',
  ];

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _title = TextEditingController(text: e?['title'] ?? '');
    _summary = TextEditingController(text: e?['summary'] ?? '');
    _body = TextEditingController(text: e?['body'] ?? '');
    _emoji = TextEditingController(text: e?['emoji'] ?? '📰');
    _imageUrl = TextEditingController(text: e?['image_url'] ?? '');
    _sourceUrl = TextEditingController(text: e?['source_url'] ?? '');
    _category = e?['category'] ?? 'Info';
    _featured = e?['is_featured'] == true;
  }

  Future<void> _save() async {
    if (_title.text.trim().isEmpty || _summary.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Judul & ringkasan wajib diisi.')));
      return;
    }
    setState(() => _saving = true);
    final data = {
      'title': _title.text.trim(),
      'summary': _summary.text.trim(),
      'body': _body.text.trim().isEmpty ? null : _body.text.trim(),
      'emoji': _emoji.text.trim().isEmpty ? '📰' : _emoji.text.trim(),
      'category': _category,
      'image_url': _imageUrl.text.trim().isEmpty ? null : _imageUrl.text.trim(),
      'source_url': _sourceUrl.text.trim().isEmpty ? null : _sourceUrl.text.trim(),
      'is_featured': _featured,
      'is_active': true,
    };
    try {
      final sb = Supabase.instance.client;
      if (widget.existing != null) {
        await sb.from('news').update(data).eq('id', widget.existing!['id']);
      } else {
        await sb.from('news').insert(data);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      children: [
        Text(widget.existing == null ? 'Berita Baru' : 'Edit Berita',
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),
        TextField(
          controller: _title,
          decoration: const InputDecoration(labelText: 'Judul *'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _summary,
          maxLines: 2,
          decoration: const InputDecoration(labelText: 'Ringkasan *'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _body,
          maxLines: 4,
          decoration: const InputDecoration(
              labelText: 'Isi lengkap (opsional)'),
        ),
        const SizedBox(height: 12),
        Row(children: [
          SizedBox(
            width: 90,
            child: TextField(
              controller: _emoji,
              decoration: const InputDecoration(labelText: 'Emoji'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: DropdownButtonFormField<String>(
              initialValue: _categories.contains(_category) ? _category : 'Info',
              decoration: const InputDecoration(labelText: 'Kategori'),
              items: _categories
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: (v) => setState(() => _category = v ?? 'Info'),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        TextField(
          controller: _imageUrl,
          decoration: const InputDecoration(
              labelText: 'URL Gambar banner (opsional)'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _sourceUrl,
          decoration: const InputDecoration(
              labelText: 'URL Sumber (opsional)'),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Tampilkan di banner Beranda'),
          value: _featured,
          onChanged: (v) => setState(() => _featured = v),
        ),
        const SizedBox(height: 8),
        FilledButton(
          onPressed: _saving ? null : _save,
          child: _saving
              ? const SizedBox(
                  height: 20, width: 20,
                  child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('Simpan'),
        ),
      ],
    );
  }
}
