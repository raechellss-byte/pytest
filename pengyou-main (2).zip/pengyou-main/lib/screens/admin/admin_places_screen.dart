import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme.dart';

const _placeCategories = {
  'agency': 'Lembaga Penerjemah',
  'immigration': 'Imigrasi',
  'hospital': 'Rumah Sakit',
  'station': 'Stasiun',
  'office': 'Kantor',
  'other': 'Lainnya',
};

const _placeIcons = {
  'agency': Icons.business,
  'immigration': Icons.assignment_ind,
  'hospital': Icons.local_hospital,
  'station': Icons.train,
  'office': Icons.apartment,
  'other': Icons.place,
};

const _placeColors = {
  'agency': Color(0xFF7C3AED),
  'immigration': Color(0xFF2563EB),
  'hospital': Color(0xFF0E9C8B),
  'station': Color(0xFFCA8A04),
  'office': Color(0xFF64748B),
  'other': Color(0xFF64748B),
};

class AdminPlacesScreen extends StatefulWidget {
  const AdminPlacesScreen({super.key});

  @override
  State<AdminPlacesScreen> createState() => _AdminPlacesScreenState();
}

class _AdminPlacesScreenState extends State<AdminPlacesScreen> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await Supabase.instance.client
        .from('map_places')
        .select()
        .order('category');
    return List<Map<String, dynamic>>.from(rows);
  }

  void _reload() => setState(() => _future = _load());

  Future<void> _delete(Map<String, dynamic> p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus tempat?'),
        content: Text('"${p['name']}" akan dihapus dari peta.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: FilledButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Hapus')),
        ],
      ),
    );
    if (ok != true) return;
    await Supabase.instance.client.from('map_places').delete().eq('id', p['id']);
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await _openEditor(null);
          _reload();
        },
        icon: const Icon(Icons.add_location_alt),
        label: const Text('Tambah Tempat'),
      ),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const GradientHeader(
              title: 'Kelola Tempat Peta',
              subtitle: 'Lembaga, imigrasi, rumah sakit, dll.',
              icon: Icons.map,
              showBack: true,
            ),
            FutureBuilder(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(40),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                final rows = snap.data ?? [];
                if (rows.isEmpty) {
                  return const EmptyState(
                      icon: Icons.wrong_location,
                      message: 'Belum ada tempat. Tambah lewat tombol di bawah.');
                }
                return Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 88),
                  child: Column(children: rows.map(_card).toList()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(Map<String, dynamic> p) {
    final cat = p['category'] ?? 'other';
    final color = _placeColors[cat] ?? Colors.grey;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 4),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
              color: color.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(12)),
          child: Icon(_placeIcons[cat] ?? Icons.place, color: color),
        ),
        title: Text(p['name'] ?? '',
            style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(
            '${_placeCategories[cat] ?? cat} · ${(p['lat'] as num?)?.toStringAsFixed(4)}, ${(p['lng'] as num?)?.toStringAsFixed(4)}'),
        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(
            icon: const Icon(Icons.edit, size: 20),
            onPressed: () async {
              await _openEditor(p);
              _reload();
            },
          ),
          IconButton(
            icon: Icon(Icons.delete_outline, size: 20, color: Colors.red.shade400),
            onPressed: () => _delete(p),
          ),
        ]),
      ),
    );
  }

  Future<void> _openEditor(Map<String, dynamic>? existing) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _PlaceEditor(existing: existing),
      ),
    );
  }
}

class _PlaceEditor extends StatefulWidget {
  const _PlaceEditor({this.existing});
  final Map<String, dynamic>? existing;

  @override
  State<_PlaceEditor> createState() => _PlaceEditorState();
}

class _PlaceEditorState extends State<_PlaceEditor> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _lat;
  late final TextEditingController _lng;
  late final TextEditingController _address;
  late final TextEditingController _note;
  String _category = 'agency';
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?['name'] ?? '');
    _lat = TextEditingController(text: e?['lat']?.toString() ?? '');
    _lng = TextEditingController(text: e?['lng']?.toString() ?? '');
    _address = TextEditingController(text: e?['address'] ?? '');
    _note = TextEditingController(text: e?['note'] ?? '');
    _category = e?['category'] ?? 'agency';
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final data = {
      'name': _name.text.trim(),
      'category': _category,
      'lat': double.parse(_lat.text.trim()),
      'lng': double.parse(_lng.text.trim()),
      'address': _address.text.trim().isEmpty ? null : _address.text.trim(),
      'note': _note.text.trim().isEmpty ? null : _note.text.trim(),
      'is_active': true,
    };
    try {
      final sb = Supabase.instance.client;
      if (widget.existing != null) {
        await sb.from('map_places').update(data).eq('id', widget.existing!['id']);
      } else {
        await sb.from('map_places').insert(data);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  String? _numValidator(String? v) {
    if (v == null || v.trim().isEmpty) return 'Wajib';
    if (double.tryParse(v.trim()) == null) return 'Angka tidak valid';
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: ListView(
        shrinkWrap: true,
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          Text(widget.existing == null ? 'Tambah Tempat' : 'Edit Tempat',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          TextFormField(
            controller: _name,
            decoration: const InputDecoration(labelText: 'Nama tempat *'),
            validator: (v) =>
                (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: _category,
            decoration: const InputDecoration(labelText: 'Kategori'),
            items: _placeCategories.entries
                .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                .toList(),
            onChanged: (v) => setState(() => _category = v ?? 'agency'),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: TextFormField(
                controller: _lat,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Latitude *'),
                validator: _numValidator,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextFormField(
                controller: _lng,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Longitude *'),
                validator: _numValidator,
              ),
            ),
          ]),
          const SizedBox(height: 6),
          Text(
              '💡 Cara ambil koordinat: buka Google Maps, klik kanan lokasi → '
              'angka pertama = latitude, kedua = longitude.',
              style: TextStyle(fontSize: 11.5, color: Colors.brown.shade500)),
          const SizedBox(height: 12),
          TextFormField(
            controller: _address,
            decoration: const InputDecoration(labelText: 'Alamat (opsional)'),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _note,
            maxLines: 2,
            decoration: const InputDecoration(labelText: 'Catatan (opsional)'),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _saving ? null : _save,
            child: _saving
                ? const SizedBox(
                    height: 20, width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Simpan'),
          ),
        ],
      ),
    );
  }
}
