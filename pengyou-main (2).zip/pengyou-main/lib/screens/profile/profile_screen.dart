import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../i18n/strings.dart';
import '../../theme.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? _user;
  Map<String, dynamic>? _interpreterProfile;
  final _bio = TextEditingController();
  final _rate = TextEditingController();
  final _arc = TextEditingController();
  final _nhi = TextEditingController();
  String? _city;
  bool _available = true;
  bool _saving = false;
  bool _savingId = false;

  SupabaseClient get sb => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final uid = sb.auth.currentUser!.id;
    final user = await sb.from('users').select().eq('id', uid).single();
    _arc.text = user['arc_no'] ?? '';
    _nhi.text = user['nhi_no'] ?? '';
    Map<String, dynamic>? ip;
    if (user['role'] == 'interpreter') {
      ip = await sb
          .from('interpreter_profiles')
          .select()
          .eq('user_id', uid)
          .maybeSingle();
      if (ip != null) {
        _bio.text = ip['bio'] ?? '';
        _rate.text = ip['hourly_rate']?.toString() ?? '';
        _city = ip['city'];
        _available = ip['is_available'] ?? true;
      }
    }
    if (mounted) setState(() { _user = user; _interpreterProfile = ip; });
  }

  Future<void> _saveInterpreterProfile() async {
    setState(() => _saving = true);
    try {
      await sb.from('interpreter_profiles').update({
        'bio': _bio.text.trim(),
        'city': _city,
        'hourly_rate': double.tryParse(_rate.text),
        'is_available': _available,
      }).eq('user_id', sb.auth.currentUser!.id);
      await _load(); // ganti kota → titik pencarian ikut pindah (trigger 016)
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Profil tersimpan.')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  /// Simpan No. ARC & No. NHI ke tabel users (dipakai lintas fitur, mis. Kesehatan).
  Future<void> _saveIdentity() async {
    setState(() => _savingId = true);
    try {
      await sb.from('users').update({
        'arc_no': _arc.text.trim().isEmpty ? null : _arc.text.trim(),
        'nhi_no': _nhi.text.trim().isEmpty ? null : _nhi.text.trim(),
      }).eq('id', sb.auth.currentUser!.id);
      if (_user != null) {
        _user!['arc_no'] = _arc.text.trim();
        _user!['nhi_no'] = _nhi.text.trim();
      }
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Identitas tersimpan.')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e')));
      }
    } finally {
      if (mounted) setState(() => _savingId = false);
    }
  }

  Future<void> _setLocationFromGps() async {
    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('Izin lokasi ditolak. Pilih kota lalu tekan '
                  'Simpan Profil — dipakai pusat kota.')));
        }
        return;
      }
      final pos = await Geolocator.getCurrentPosition();
      await sb.rpc('set_my_location',
          params: {'p_lng': pos.longitude, 'p_lat': pos.latitude});
      final verified = _interpreterProfile?['is_verified'] == true;
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(verified
                ? 'Lokasi tersimpan — Anda kini muncul di pencarian terdekat.'
                : 'Lokasi tersimpan — Anda muncul di pencarian setelah '
                    'diverifikasi admin.')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal menyimpan lokasi: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_user == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final isInterpreter = _user!['role'] == 'interpreter';
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          GradientHeader(
            title: _user!['full_name'],
            subtitle: '${_user!['email'] ?? ''} · '
                '${isInterpreter ? 'Penerjemah' : 'Client'}',
            icon: Icons.person,
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: _bodyChildren(context, isInterpreter),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _bodyChildren(BuildContext context, bool isInterpreter) {
    final isAdmin = _user?['role'] == 'admin';
    final isClient = _user?['role'] == 'client';
    // Daftar akun sebagai "Saya penerjemah" → profil masih kosong (tanpa
    // kota, bahasa & layanan); arahkan ke form yang sama.
    final ip = _interpreterProfile;
    final incomplete = isInterpreter &&
        (ip == null ||
            ip['city'] == null ||
            (ip['bio'] ?? '').toString().trim().isEmpty);
    return [
          // Ajakan jadi penerjemah (client) / lengkapi pendaftaran (penerjemah)
          if (isClient || incomplete) ...[
            Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF0E9C8B), Color(0xFF128C7E)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(22),
                  onTap: () async {
                    await context.push('/jadi-penerjemah');
                    _load();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Row(children: [
                      const Text('💼', style: TextStyle(fontSize: 30)),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                                isClient
                                    ? tr('become_interpreter')
                                    : 'Lengkapi pendaftaran penerjemah',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 16)),
                            const SizedBox(height: 2),
                            Text(
                                isClient
                                    ? tr('become_interpreter_sub')
                                    : 'Isi kota, tarif, bahasa & layanan agar '
                                        'klien bisa menemukan Anda',
                                style: const TextStyle(
                                    color: Colors.white70, fontSize: 12.5)),
                          ],
                        ),
                      ),
                      const Icon(Icons.arrow_forward, color: Colors.white),
                    ]),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],
          if (isAdmin) ...[
            Card(
              color: AppColors.primary.withValues(alpha: 0.06),
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.admin_panel_settings,
                      color: AppColors.primary),
                ),
                title: Text(tr('admin_panel'),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(tr('admin_panel_sub')),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.push('/admin'),
              ),
            ),
            const SizedBox(height: 8),
          ],
          // Bantuan & FAQ
          Card(
            child: ListTile(
              leading: const Icon(Icons.help_outline, color: Color(0xFFCA8A04)),
              title: Text(tr('help')),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.push('/bantuan'),
            ),
          ),
          const SizedBox(height: 12),
          // Pemilih bahasa
          Card(
            child: ListTile(
              leading: const Icon(Icons.language, color: Color(0xFF2563EB)),
              title: Text(tr('language')),
              trailing: DropdownButton<String>(
                value: Lang.instance.value,
                underline: const SizedBox.shrink(),
                items: Lang.supported.entries
                    .map((e) =>
                        DropdownMenuItem(value: e.key, child: Text(e.value)))
                    .toList(),
                onChanged: (v) async {
                  if (v != null) {
                    await Lang.instance.set(v);
                    if (mounted) setState(() {});
                  }
                },
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.event_note, color: Color(0xFF148F77)),
                title: Text(tr('my_orders')),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.push('/pesanan'),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.folder_shared, color: Color(0xFF2471A3)),
                title: Text(tr('my_documents')),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.push('/dokumen'),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          // Identitas untuk klinik (dipakai fitur Kesehatan/Sehat Rantau).
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(children: [
                    const Icon(Icons.badge_outlined, color: Color(0xFF0F766E)),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text('Identitas (untuk klinik)',
                          style: Theme.of(context)
                              .textTheme
                              .titleSmall
                              ?.copyWith(fontWeight: FontWeight.w800)),
                    ),
                  ]),
                  const SizedBox(height: 4),
                  Text(
                      'Dipakai lintas fitur (mis. Kesehatan) supaya kamu tak perlu '
                      'mengisi ulang. Tersimpan di akunmu.',
                      style:
                          TextStyle(fontSize: 12.5, color: Colors.brown.shade500)),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _arc,
                    decoration: const InputDecoration(
                        labelText: 'No. ARC / 居留證', hintText: 'opsional'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _nhi,
                    decoration: const InputDecoration(
                        labelText: 'No. NHI / 健保卡', hintText: 'opsional'),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _savingId ? null : _saveIdentity,
                    icon: _savingId
                        ? const SizedBox(
                            height: 18,
                            width: 18,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.check),
                    label: const Text('Simpan identitas'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (isInterpreter) ...[
            Text('Profil Penerjemah', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            if (_interpreterProfile?['is_verified'] != true)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('⏳ Menunggu verifikasi admin. Profil Anda belum '
                      'muncul di pencarian sampai terverifikasi.'),
                ),
              ),
            if (_interpreterProfile != null &&
                _interpreterProfile!['is_verified'] != true &&
                !incomplete)
              _TestStatus(
                profile: _interpreterProfile!,
                onStart: () async {
                  await context.push('/tes-penerjemah');
                  _load();
                },
              ),
            _LocationStatus(isSet: _interpreterProfile?['location'] != null),
            const SizedBox(height: 12),
            TextField(
              controller: _bio,
              maxLines: 3,
              decoration: const InputDecoration(
                  labelText: 'Bio', hintText: 'Pengalaman, spesialisasi…'),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _city,
              decoration: const InputDecoration(labelText: 'Kota'),
              items: AppConfig.cities.keys
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: (v) => setState(() => _city = v),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _rate,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  labelText: 'Tarif per jam (NT\$)'),
            ),
            SwitchListTile(
              title: const Text('Tersedia menerima pesanan'),
              value: _available,
              onChanged: (v) => setState(() => _available = v),
            ),
            OutlinedButton.icon(
              onPressed: _setLocationFromGps,
              icon: const Icon(Icons.my_location),
              label: const Text('Set lokasi saya dari GPS'),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _saving ? null : _saveInterpreterProfile,
              child: _saving
                  ? const SizedBox(
                      height: 20, width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Simpan Profil'),
            ),
            const Divider(height: 32),
          ],
          OutlinedButton.icon(
            onPressed: () => sb.auth.signOut(),
            icon: const Icon(Icons.logout),
            label: Text(tr('logout')),
          ),
        ];
  }
}

/// Hasil tes bahasa (migrasi 017; dinilai AI bila API key terpasang, selain
/// itu oleh admin) bagi penerjemah yang belum diverifikasi.
class _TestStatus extends StatelessWidget {
  const _TestStatus({required this.profile, required this.onStart});
  final Map<String, dynamic> profile;
  final VoidCallback onStart;

  @override
  Widget build(BuildContext context) {
    final verdict = profile['ai_verdict'] as String?;
    final total = profile['ai_total'] as num?;
    final feedback = (profile['ai_feedback'] ?? '').toString();
    final (icon, color, title, sub, action) = switch (verdict) {
      'pass' => (
          Icons.verified,
          Colors.green.shade700,
          'Lolos tes bahasa${total != null ? ' · skor ${total.round()}' : ''}',
          'Menunggu persetujuan admin.',
          null,
        ),
      'review' => (
          Icons.manage_search,
          AppColors.info,
          'Tes bahasa sedang ditinjau admin',
          feedback,
          null,
        ),
      'reject' => (
          Icons.refresh,
          Colors.orange.shade800,
          'Belum lolos tes bahasa',
          feedback,
          'Coba lagi',
        ),
      _ => (
          Icons.translate,
          AppColors.primary,
          'Ikuti tes bahasa',
          '5 soal singkat (±10 menit) — agar admin cepat menyetujui.',
          'Mulai tes',
        ),
    };
    return Card(
      color: color.withValues(alpha: 0.07),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(4, 4, 12, 4),
        child: Row(children: [
          Expanded(
            child: ListTile(
              leading: Icon(icon, color: color),
              title: Text(title,
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: sub.isEmpty ? null : Text(sub),
            ),
          ),
          if (action != null)
            FilledButton(onPressed: onStart, child: Text(action)),
        ]),
      ),
    );
  }
}

/// Status titik lokasi yang dipakai "Cari Terdekat" & peta.
class _LocationStatus extends StatelessWidget {
  const _LocationStatus({required this.isSet});
  final bool isSet;

  @override
  Widget build(BuildContext context) {
    final color = isSet ? AppColors.info : Colors.orange.shade800;
    return Card(
      color: color.withValues(alpha: 0.07),
      child: ListTile(
        leading: Icon(isSet ? Icons.location_on : Icons.location_off,
            color: color),
        title: Text(
            isSet
                ? 'Lokasi pencarian sudah diatur'
                : 'Lokasi pencarian belum diatur',
            style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(isSet
            ? 'Klien di sekitar titik ini bisa menemukan Anda. Perbarui '
                'dengan GPS bila pindah.'
            : 'Pilih kota lalu tekan Simpan Profil, atau "Set lokasi saya '
                'dari GPS".'),
      ),
    );
  }
}
