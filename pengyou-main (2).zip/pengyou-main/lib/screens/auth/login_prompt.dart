import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'login_screen.dart' show nextQuery;

/// Ajakan masuk akun untuk fitur yang menyimpan riwayat (Belajar, Sehat).
/// Tamu tetap boleh memakai fiturnya; riwayat baru tersimpan setelah masuk.

/// Lembar "Masuk dulu" — dipakai saat tamu menekan aksi yang menyimpan
/// (simpan klinik, catat kunjungan, dll). [next] = rute untuk kembali.
Future<void> showLoginRequired(
  BuildContext context, {
  required String reason,
  required String next,
  Color color = const Color(0xFF0F766E),
}) {
  return showModalBottomSheet(
    context: context,
    showDragHandle: true,
    backgroundColor: Colors.white,
    builder: (sheet) => Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(color: color.withValues(alpha: 0.12), shape: BoxShape.circle),
          child: Icon(Icons.lock_person_rounded, color: color, size: 32),
        ),
        const SizedBox(height: 14),
        const Text('Masuk dulu, yuk',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text(reason,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.blueGrey.shade600, height: 1.45)),
        const SizedBox(height: 18),
        _LoginButtons(next: next, color: color, close: () => Navigator.pop(sheet)),
        TextButton(
          onPressed: () => Navigator.pop(sheet),
          child: Text('Nanti saja', style: TextStyle(color: Colors.blueGrey.shade500)),
        ),
      ]),
    ),
  );
}

class _LoginButtons extends StatelessWidget {
  const _LoginButtons({required this.next, required this.color, this.close});
  final String next;
  final Color color;
  final VoidCallback? close;

  @override
  Widget build(BuildContext context) {
    void go(String path) {
      close?.call();
      context.go('$path${nextQuery(next)}');
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      FilledButton.icon(
        onPressed: () => go('/login'),
        icon: const Icon(Icons.login_rounded),
        label: const Text('Masuk dengan email'),
        style: FilledButton.styleFrom(
            backgroundColor: color, foregroundColor: Colors.white, minimumSize: const Size(0, 48)),
      ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        onPressed: () => go('/daftar'),
        icon: const Icon(Icons.person_add_alt_rounded),
        label: const Text('Daftar akun baru'),
        style: OutlinedButton.styleFrom(
          foregroundColor: color,
          side: BorderSide(color: color.withValues(alpha: 0.4), width: 1.5),
          minimumSize: const Size(0, 46),
        ),
      ),
    ]);
  }
}

/// Kartu ajakan masuk (di dalam halaman), mis. "Mode tamu — progres tidak disimpan".
class LoginNudgeCard extends StatelessWidget {
  const LoginNudgeCard({
    super.key,
    required this.title,
    required this.text,
    required this.next,
    this.color = const Color(0xFF0F766E),
    this.compact = false,
  });

  final String title, text, next;
  final Color color;
  final bool compact; // hanya tombol "Masuk" (tanpa "Daftar")

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.25), width: 1.5),
        boxShadow: [
          BoxShadow(
              color: color.withValues(alpha: 0.08), blurRadius: 14, offset: const Offset(0, 5)),
        ],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.12), shape: BoxShape.circle),
            child: Icon(Icons.lock_outline_rounded, color: color, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              const SizedBox(height: 3),
              Text(text,
                  style: TextStyle(fontSize: 12.5, color: Colors.blueGrey.shade600, height: 1.4)),
            ]),
          ),
        ]),
        const SizedBox(height: 12),
        if (compact)
          FilledButton.icon(
            onPressed: () => context.go('/login${nextQuery(next)}'),
            icon: const Icon(Icons.login_rounded, size: 18),
            label: const Text('Masuk dengan email'),
            style: FilledButton.styleFrom(
                backgroundColor: color, foregroundColor: Colors.white, minimumSize: const Size(0, 44)),
          )
        else
          _LoginButtons(next: next, color: color),
      ]),
    );
  }
}
