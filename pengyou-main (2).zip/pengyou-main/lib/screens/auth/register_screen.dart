import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../i18n/strings.dart';
import 'login_screen.dart' show nextQuery, safeNext, signInWithGoogle;

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key, this.next});
  final String? next; // rute asal, lihat LoginScreen.next

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  String _role = 'client';
  bool _loading = false;

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final res = await Supabase.instance.client.auth.signUp(
        email: _email.text.trim(),
        password: _password.text,
        data: {'full_name': _name.text.trim(), 'role': _role},
      );
      if (!mounted) return;
      if (res.session != null) {
        context.go(safeNext(widget.next));
      } else {
        // Konfirmasi email aktif di project Supabase
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Cek email Anda untuk konfirmasi, lalu masuk.')));
        context.go('/login${nextQuery(widget.next)}');
      }
    } on AuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal daftar: ${e.message}')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('sign_up')),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => context.go(safeNext(widget.next)),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SegmentedButton<String>(
                      segments: [
                        ButtonSegment(value: 'client', label: Text(tr('i_need_interpreter'))),
                        ButtonSegment(value: 'interpreter', label: Text(tr('i_am_interpreter'))),
                      ],
                      selected: {_role},
                      onSelectionChanged: (s) => setState(() => _role = s.first),
                    ),
                    const SizedBox(height: 24),
                    TextFormField(
                      controller: _name,
                      decoration: InputDecoration(labelText: tr('full_name')),
                      validator: (v) =>
                          (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _email,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(labelText: tr('email')),
                      validator: (v) =>
                          (v == null || !v.contains('@')) ? 'Email tidak valid' : null,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _password,
                      obscureText: true,
                      decoration: InputDecoration(
                          labelText: tr('password'), helperText: 'min. 6'),
                      validator: (v) =>
                          (v == null || v.length < 6) ? 'Minimal 6 karakter' : null,
                    ),
                    const SizedBox(height: 24),
                    FilledButton(
                      onPressed: _loading ? null : _register,
                      child: _loading
                          ? const SizedBox(
                              height: 20, width: 20,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : Text(tr('sign_up')),
                    ),
                    const SizedBox(height: 12),
                    Row(children: [
                      const Expanded(child: Divider()),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        child: Text(tr('or'),
                            style: TextStyle(color: Colors.brown.shade400)),
                      ),
                      const Expanded(child: Divider()),
                    ]),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () => signInWithGoogle(context),
                      icon: const Icon(Icons.g_mobiledata, size: 28),
                      label: Text(tr('sign_up_google')),
                    ),
                    TextButton(
                      onPressed: () => context.go('/login${nextQuery(widget.next)}'),
                      child: Text(tr('have_account')),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
