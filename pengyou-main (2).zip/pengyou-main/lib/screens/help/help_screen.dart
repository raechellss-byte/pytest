import 'package:flutter/material.dart';

import '../../theme.dart';

class _Faq {
  const _Faq(this.q, this.a);
  final String q;
  final String a;
}

class _Section {
  const _Section(this.icon, this.color, this.title, this.items);
  final IconData icon;
  final Color color;
  final String title;
  final List<_Faq> items;
}

const _sections = <_Section>[
  _Section(Icons.info, Color(0xFFE23744), 'Umum', [
    _Faq('Apa itu PENGYOU?',
        'PENGYOU (朋友 = "teman") adalah platform yang mempertemukan pekerja '
            'migran Indonesia di Taiwan dengan penerjemah/pendamping bahasa '
            'Indonesia–Mandarin, plus pengingat dokumen penting.'),
    _Faq('Apakah aplikasi ini gratis?',
        'Membuat akun, mencari penerjemah, chat, dan pengingat dokumen gratis. '
            'Tarif jasa penerjemah ditentukan masing-masing penerjemah.'),
    _Faq('Bahasa apa saja yang tersedia?',
        'Aplikasi tersedia dalam Bahasa Indonesia, English, dan 中文. Ganti di '
            'menu Akun → Bahasa.'),
  ]),
  _Section(Icons.search, Color(0xFF2563EB), 'Mencari & Memesan', [
    _Faq('Bagaimana mencari penerjemah terdekat?',
        'Buka tab Cari → tekan "Terdekat" (izinkan lokasi) atau pilih kota. '
            'Anda juga bisa buka "Lihat Peta" untuk melihat penerjemah & lembaga '
            'di peta.'),
    _Faq('Bagaimana cara memesan?',
        'Buka profil penerjemah → "Pesan" → isi jenis layanan (tatap muka/'
            'telepon/dokumen), jadwal, lokasi, dan deskripsi → kirim. Penerjemah '
            'akan menerima notifikasi dan mengonfirmasi.'),
    _Faq('Bisakah saya bertanya dulu sebelum memesan?',
        'Bisa. Di profil penerjemah tekan "Chat" untuk bertanya ketersediaan, '
            'tarif, atau detail lain sebelum membuat pesanan.'),
    _Faq('Bagaimana membatalkan pesanan?',
        'Buka Akun → Pesanan Saya → pilih pesanan → tombol "Batalkan" '
            '(selama belum berjalan).'),
  ]),
  _Section(Icons.folder_shared, Color(0xFF0E9C8B), 'Dokumen & Pengingat', [
    _Faq('Bagaimana mendaftarkan dokumen?',
        'Akun → Dokumen Saya → Tambah → pilih jenis (ARC, paspor, asuransi, '
            'dll.), isi tanggal kedaluwarsa, dan (opsional) foto dokumen.'),
    _Faq('Kapan saya diingatkan?',
        'Kami mengingatkan 30, 14, dan 7 hari sebelum dokumen kedaluwarsa — '
            'lewat tab Notifikasi di aplikasi dan (bila diaktifkan) email.'),
    _Faq('Apakah data dokumen saya aman?',
        'Ya. Dokumen disimpan terenkripsi dan hanya bisa dilihat oleh Anda '
            'sendiri. Bahkan admin tidak dapat mengintip isi dokumen pribadi Anda.'),
  ]),
  _Section(Icons.record_voice_over, Color(0xFF7C3AED), 'Jadi Penerjemah', [
    _Faq('Bagaimana cara menjadi penerjemah?',
        'Akun → "Jadi Penerjemah" → isi bahasa, kota, tarif, bio, layanan, dan '
            'unggah foto ID untuk verifikasi → kirim.'),
    _Faq('Berapa lama proses verifikasi?',
        'Profil Anda ditinjau admin. Setelah disetujui, Anda otomatis muncul di '
            'pencarian dan bisa menerima pesanan. Pastikan juga mengatur lokasi '
            'GPS di profil agar muncul di pencarian terdekat.'),
  ]),
  _Section(Icons.person, Color(0xFFCA8A04), 'Akun', [
    _Faq('Login pakai apa?',
        'Bisa dengan email + kata sandi, atau tombol "Masuk dengan Google".'),
    _Faq('Bagaimana mengganti bahasa?',
        'Akun → Bahasa → pilih Indonesia / English / 中文.'),
  ]),
];

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          const GradientHeader(
            title: 'Bantuan & FAQ',
            subtitle: 'Pertanyaan yang sering diajukan',
            icon: Icons.help,
            showBack: true,
          ),
          // Kontak darurat / bantuan pemerintah
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
            child: Card(
              color: const Color(0xFFE23744).withValues(alpha: 0.06),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                        color: AppColors.primary.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(14)),
                    child: const Icon(Icons.phone_in_talk,
                        color: AppColors.primary),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Hotline Pemerintah 1955',
                            style: TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 15)),
                        SizedBox(height: 2),
                        Text(
                            'Gratis, 24 jam, tersedia layanan bahasa Indonesia '
                            'untuk keluhan ketenagakerjaan.',
                            style: TextStyle(fontSize: 12.5, height: 1.4)),
                      ],
                    ),
                  ),
                ]),
              ),
            ),
          ),
          // Seksi FAQ
          for (final s in _sections) _sectionWidget(context, s),
          const Padding(
            padding: EdgeInsets.fromLTRB(24, 12, 24, 32),
            child: Text(
                'Masih butuh bantuan? Hubungi tim PENGYOU lewat halaman kontak '
                'komunitas, atau tanyakan langsung ke penerjemah lewat chat.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12.5, color: Color(0xFF9A8478))),
          ),
        ],
      ),
    );
  }

  Widget _sectionWidget(BuildContext context, _Section s) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 16, 6),
        child: Row(children: [
          Icon(s.icon, color: s.color, size: 20),
          const SizedBox(width: 8),
          Text(s.title,
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w800)),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Card(
          child: Column(
            children: [
              for (var i = 0; i < s.items.length; i++) ...[
                if (i > 0) const Divider(height: 1),
                Theme(
                  data: Theme.of(context)
                      .copyWith(dividerColor: Colors.transparent),
                  child: ExpansionTile(
                    tilePadding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
                    childrenPadding:
                        const EdgeInsets.fromLTRB(16, 0, 16, 14),
                    expandedCrossAxisAlignment: CrossAxisAlignment.start,
                    title: Text(s.items[i].q,
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 14)),
                    iconColor: s.color,
                    children: [
                      Text(s.items[i].a,
                          style: TextStyle(
                              fontSize: 13.5,
                              height: 1.55,
                              color: Colors.brown.shade700)),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    ]);
  }
}
