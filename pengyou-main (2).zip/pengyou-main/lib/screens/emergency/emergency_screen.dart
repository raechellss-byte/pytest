import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../theme.dart';

/// ============================================================
/// Layar Darurat / SOS — akses cepat saat genting (bisa tanpa login).
///  • Panggilan cepat: 110 Polisi · 119 Ambulans/Damkar · 112 Darurat HP ·
///    1955 Hotline Pekerja Migran (bahasa Indonesia) · KDEI Taipei.
///  • Ambil & bagikan lokasi GPS (buka di Maps / salin koordinat) agar mudah
///    memberi tahu petugas di mana kamu berada.
///  • Frasa Mandarin darurat untuk ditunjukkan ke orang sekitar.
/// ============================================================

class _Contact {
  const _Contact(this.icon, this.color, this.number, this.name, this.note);
  final IconData icon;
  final Color color;
  final String number; // untuk tel:
  final String name;
  final String note;
}

const _contacts = <_Contact>[
  _Contact(Icons.local_police, Color(0xFFC0392B), '110', 'Polisi',
      'Kejahatan, kecelakaan, keselamatan'),
  _Contact(Icons.local_hospital, Color(0xFFC0392B), '119',
      'Ambulans & Pemadam', 'Sakit parah, kebakaran, gawat darurat'),
  _Contact(Icons.phone_in_talk, Color(0xFFE67E22), '112',
      'Darurat dari HP', 'Tetap tersambung walau tanpa SIM/pulsa'),
  _Contact(Icons.support_agent, Color(0xFF0F766E), '1955',
      'Hotline Pekerja Migran', '24 jam · gratis · ada bahasa Indonesia'),
  _Contact(Icons.flag, Color(0xFF2471A3), '+886287526170',
      'KDEI Taipei (kantor RI)', 'Perwakilan Indonesia di Taiwan'),
];

/// Frasa Mandarin darurat (ditunjukkan/diucapkan ke orang sekitar).
const _sos = <(String, String, String)>[
  ('Saya butuh bantuan!', '我需要幫助！', 'wǒ xūyào bāngzhù'),
  ('Tolong panggil ambulans!', '請叫救護車！', 'qǐng jiào jiùhùchē'),
  ('Tolong panggil polisi!', '請報警！', 'qǐng bàojǐng'),
];

class EmergencyScreen extends StatefulWidget {
  const EmergencyScreen({super.key});
  @override
  State<EmergencyScreen> createState() => _EmergencyScreenState();
}

class _EmergencyScreenState extends State<EmergencyScreen> {
  String? _coords; // "25.03360, 121.56540"
  bool _locating = false;
  String _locMsg = 'Ambil lokasi GPS-mu agar bisa diberitahukan ke petugas.';

  Future<void> _call(String number) async {
    final uri = Uri(scheme: 'tel', path: number);
    try {
      await launchUrl(uri);
    } catch (_) {
      _toast('Tidak bisa membuka aplikasi telepon.');
    }
  }

  Future<void> _locate() async {
    setState(() {
      _locating = true;
      _locMsg = 'Mengambil lokasi…';
    });
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        setState(() => _locMsg = 'Izin lokasi ditolak. Aktifkan lalu coba lagi.');
        return;
      }
      final pos = await Geolocator.getCurrentPosition();
      setState(() {
        _coords =
            '${pos.latitude.toStringAsFixed(5)}, ${pos.longitude.toStringAsFixed(5)}';
        _locMsg = 'Lokasimu (sebutkan/tunjukkan ke petugas):';
      });
    } catch (_) {
      setState(() => _locMsg = 'Gagal mengambil lokasi. Coba lagi.');
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _openMaps() async {
    if (_coords == null) return;
    final q = _coords!.replaceAll(' ', '');
    final uri =
        Uri.parse('https://www.google.com/maps/search/?api=1&query=$q');
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      _toast('Tidak bisa membuka Maps.');
    }
  }

  void _copyCoords() {
    if (_coords == null) return;
    Clipboard.setData(ClipboardData(text: _coords!));
    _toast('Koordinat disalin ✓');
  }

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          const GradientHeader(
            title: 'Darurat / SOS',
            subtitle: 'Panggilan cepat & bagikan lokasimu',
            icon: Icons.emergency_share,
            showBack: true,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Panggilan darurat',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('Ketuk untuk langsung menelepon.',
                    style: TextStyle(color: Colors.brown.shade600, fontSize: 13)),
                const SizedBox(height: 12),
                for (final c in _contacts) _contactCard(c),
                const SizedBox(height: 20),
                _locationCard(),
                const SizedBox(height: 20),
                _sosPhrasesCard(),
                const SizedBox(height: 8),
                Text(
                    'Nomor 110/119/112/1955 berlaku di seluruh Taiwan. 1955 gratis '
                    'dan menyediakan penerjemah bahasa Indonesia.',
                    style: TextStyle(
                        fontSize: 11.5, color: Colors.brown.shade400, height: 1.4)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _contactCard(_Contact c) {
    // Nomor tampilan: rapikan KDEI agar mudah dibaca.
    final display = c.number.startsWith('+886')
        ? '+886 2 8752 6170'
        : c.number;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => _call(c.number),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: c.color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(c.icon, color: c.color, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Text(display,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            color: c.color)),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(c.name,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w700)),
                    ),
                  ]),
                  const SizedBox(height: 2),
                  Text(c.note,
                      style: TextStyle(
                          fontSize: 12, color: Colors.brown.shade600)),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(color: c.color, shape: BoxShape.circle),
              child: const Icon(Icons.call, color: Colors.white, size: 20),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _locationCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF2471A3).withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF2471A3).withValues(alpha: 0.25)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: const [
          Icon(Icons.my_location, color: Color(0xFF2471A3)),
          SizedBox(width: 8),
          Text('Lokasi Saya',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
        ]),
        const SizedBox(height: 8),
        Text(_locMsg,
            style: TextStyle(fontSize: 13, color: Colors.brown.shade700)),
        if (_coords != null) ...[
          const SizedBox(height: 8),
          SelectableText(_coords!,
              style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF1B4F72))),
        ],
        const SizedBox(height: 12),
        if (_coords == null)
          FilledButton.icon(
            onPressed: _locating ? null : _locate,
            icon: _locating
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.gps_fixed),
            label: Text(_locating ? 'Mengambil…' : 'Ambil lokasi GPS'),
            style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF2471A3),
                minimumSize: const Size(double.infinity, 48)),
          )
        else
          Row(children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _openMaps,
                icon: const Icon(Icons.map),
                label: const Text('Buka di Maps'),
                style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF2471A3),
                    minimumSize: const Size(0, 46)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _copyCoords,
                icon: const Icon(Icons.copy, size: 18),
                label: const Text('Salin'),
                style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF1B4F72),
                    minimumSize: const Size(0, 46)),
              ),
            ),
          ]),
      ]),
    );
  }

  Widget _sosPhrasesCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFC0392B).withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFC0392B).withValues(alpha: 0.2)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: const [
          Text('🆘', style: TextStyle(fontSize: 18)),
          SizedBox(width: 8),
          Expanded(
            child: Text('Tunjukkan ke orang sekitar',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
          ),
        ]),
        const SizedBox(height: 10),
        for (final (id, zh, py) in _sos)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(zh,
                  style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      height: 1.25,
                      color: Color(0xFF7B241C))),
              Text('$id · $py',
                  style: TextStyle(fontSize: 12.5, color: Colors.brown.shade600)),
            ]),
          ),
      ]),
    );
  }
}
