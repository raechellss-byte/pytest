import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CreateBookingScreen extends StatefulWidget {
  const CreateBookingScreen({super.key, required this.interpreterId});
  final String interpreterId;

  @override
  State<CreateBookingScreen> createState() => _CreateBookingScreenState();
}

class _CreateBookingScreenState extends State<CreateBookingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _address = TextEditingController();
  final _description = TextEditingController();
  String _serviceType = 'onsite';
  String? _categoryId;
  DateTime? _scheduledAt;
  int _duration = 60;
  bool _loading = false;
  List<Map<String, dynamic>> _categories = [];

  @override
  void initState() {
    super.initState();
    Supabase.instance.client
        .from('service_categories')
        .select('id, name_id')
        .then((rows) {
      if (mounted) {
        setState(() => _categories = List<Map<String, dynamic>>.from(rows));
      }
    });
  }

  Future<void> _pickDateTime() async {
    final date = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 90)),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
        context: context, initialTime: const TimeOfDay(hour: 9, minute: 0));
    if (time == null) return;
    setState(() => _scheduledAt =
        DateTime(date.year, date.month, date.day, time.hour, time.minute));
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_scheduledAt == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pilih tanggal & jam terlebih dahulu.')));
      return;
    }
    setState(() => _loading = true);
    final sb = Supabase.instance.client;
    try {
      await sb.from('bookings').insert({
        'client_id': sb.auth.currentUser!.id,
        'interpreter_id': widget.interpreterId,
        'category_id': _categoryId,
        'service_type': _serviceType,
        'scheduled_at': _scheduledAt!.toUtc().toIso8601String(),
        'duration_minutes': _duration,
        'location_address': _address.text.trim().isEmpty ? null : _address.text.trim(),
        'description': _description.text.trim(),
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Pesanan terkirim, menunggu konfirmasi penerjemah.')));
        context.go('/pesanan');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal membuat pesanan: $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Buat Pemesanan')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Jenis layanan', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'onsite', label: Text('Tatap muka')),
                ButtonSegment(value: 'phone', label: Text('Telepon')),
                ButtonSegment(value: 'document', label: Text('Dokumen')),
              ],
              selected: {_serviceType},
              onSelectionChanged: (s) => setState(() => _serviceType = s.first),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _categoryId,
              decoration: const InputDecoration(labelText: 'Kategori'),
              items: _categories
                  .map((c) => DropdownMenuItem(
                      value: c['id'] as String, child: Text(c['name_id'])))
                  .toList(),
              onChanged: (v) => setState(() => _categoryId = v),
              validator: (v) => v == null ? 'Pilih kategori' : null,
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: _pickDateTime,
              icon: const Icon(Icons.calendar_month),
              label: Text(_scheduledAt == null
                  ? 'Pilih tanggal & jam'
                  : DateFormat('EEE, d MMM y – HH:mm').format(_scheduledAt!)),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              initialValue: _duration,
              decoration: const InputDecoration(labelText: 'Durasi'),
              items: const [
                DropdownMenuItem(value: 60, child: Text('1 jam')),
                DropdownMenuItem(value: 120, child: Text('2 jam')),
                DropdownMenuItem(value: 180, child: Text('3 jam')),
                DropdownMenuItem(value: 240, child: Text('4 jam')),
              ],
              onChanged: (v) => setState(() => _duration = v ?? 60),
            ),
            const SizedBox(height: 16),
            if (_serviceType == 'onsite')
              TextFormField(
                controller: _address,
                decoration: const InputDecoration(
                    labelText: 'Alamat lokasi layanan',
                    hintText: 'mis. RS Taichung Veterans General Hospital'),
                validator: (v) => _serviceType == 'onsite' &&
                        (v == null || v.trim().isEmpty)
                    ? 'Alamat wajib untuk layanan tatap muka'
                    : null,
              ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _description,
              maxLines: 4,
              decoration: const InputDecoration(
                  labelText: 'Deskripsi kebutuhan',
                  hintText: 'Ceritakan urusan Anda (mis. kontrol dokter, urus ARC)'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _loading ? null : _submit,
              child: _loading
                  ? const SizedBox(
                      height: 20, width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Kirim Pemesanan'),
            ),
          ],
        ),
      ),
    );
  }
}
