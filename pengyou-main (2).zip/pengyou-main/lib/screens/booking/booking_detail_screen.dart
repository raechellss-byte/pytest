import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'bookings_screen.dart' show statusLabels;

class BookingDetailScreen extends StatefulWidget {
  const BookingDetailScreen({super.key, required this.bookingId});
  final String bookingId;

  @override
  State<BookingDetailScreen> createState() => _BookingDetailScreenState();
}

class _BookingDetailScreenState extends State<BookingDetailScreen> {
  final _msgController = TextEditingController();
  final _scrollController = ScrollController();
  Map<String, dynamic>? _booking;
  List<Map<String, dynamic>> _messages = [];
  StreamSubscription? _sub;
  bool _iAmInterpreter = false;
  bool _hasReviewed = false;

  SupabaseClient get sb => Supabase.instance.client;
  String get myId => sb.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _load();
    _sub = sb
        .from('messages')
        .stream(primaryKey: ['id'])
        .eq('booking_id', widget.bookingId)
        .order('created_at')
        .listen((rows) {
      if (mounted) {
        setState(() => _messages = List<Map<String, dynamic>>.from(rows));
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scrollController.hasClients) {
            _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
          }
        });
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _msgController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final b = await sb
        .from('bookings')
        .select('*, users!bookings_client_id_fkey(full_name), '
            'interpreter_profiles(user_id, users(full_name)), '
            'service_categories(name_id)')
        .eq('id', widget.bookingId)
        .single();
    final reviews = await sb
        .from('reviews')
        .select('id')
        .eq('booking_id', widget.bookingId)
        .eq('reviewer_id', myId);
    if (mounted) {
      setState(() {
        _booking = b;
        _iAmInterpreter = b['interpreter_profiles']?['user_id'] == myId;
        _hasReviewed = (reviews as List).isNotEmpty;
      });
    }
  }

  Future<void> _setStatus(String status) async {
    await sb.from('bookings').update({'status': status}).eq('id', widget.bookingId);
    _load();
  }

  Future<void> _send() async {
    final text = _msgController.text.trim();
    if (text.isEmpty) return;
    _msgController.clear();
    await sb.from('messages').insert({
      'booking_id': widget.bookingId,
      'sender_id': myId,
      'content': text,
    });
  }

  Future<void> _review() async {
    int rating = 5;
    final commentCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Beri Ulasan'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (i) => IconButton(
                icon: Icon(i < rating ? Icons.star : Icons.star_border,
                    color: Colors.amber),
                onPressed: () => setD(() => rating = i + 1),
              )),
            ),
            TextField(
              controller: commentCtrl,
              decoration: const InputDecoration(labelText: 'Komentar (opsional)'),
              maxLines: 3,
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Kirim')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final revieweeId = _iAmInterpreter
        ? _booking!['client_id']
        : _booking!['interpreter_profiles']['user_id'];
    await sb.from('reviews').insert({
      'booking_id': widget.bookingId,
      'reviewer_id': myId,
      'reviewee_id': revieweeId,
      'rating': rating,
      'comment': commentCtrl.text.trim().isEmpty ? null : commentCtrl.text.trim(),
    });
    _load();
  }

  List<Widget> _statusActions() {
    final status = _booking!['status'] as String;
    final actions = <Widget>[];
    if (_iAmInterpreter) {
      if (status == 'requested') {
        actions.addAll([
          FilledButton(onPressed: () => _setStatus('accepted'), child: const Text('Terima')),
          const SizedBox(width: 8),
          OutlinedButton(onPressed: () => _setStatus('cancelled'), child: const Text('Tolak')),
        ]);
      } else if (status == 'accepted') {
        actions.add(FilledButton(
            onPressed: () => _setStatus('in_progress'), child: const Text('Mulai Layanan')));
      } else if (status == 'in_progress') {
        actions.add(FilledButton(
            onPressed: () => _setStatus('completed'), child: const Text('Selesaikan')));
      }
    } else {
      if (status == 'requested' || status == 'accepted') {
        actions.add(OutlinedButton(
            onPressed: () => _setStatus('cancelled'), child: const Text('Batalkan')));
      }
    }
    if (status == 'completed' && !_hasReviewed) {
      actions.add(TextButton.icon(
          onPressed: _review,
          icon: const Icon(Icons.star),
          label: const Text('Beri Ulasan')));
    }
    return actions;
  }

  @override
  Widget build(BuildContext context) {
    if (_booking == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    }
    final b = _booking!;
    final dt = DateTime.tryParse(b['scheduled_at'] ?? '')?.toLocal();
    final String? otherName;
    if (_iAmInterpreter) {
      otherName = b['users']?['full_name'];
    } else {
      otherName = (b['interpreter_profiles']?['users'])?['full_name'];
    }

    return Scaffold(
      appBar: AppBar(title: Text(otherName ?? 'Pesanan')),
      body: Column(children: [
        Card(
          margin: const EdgeInsets.all(12),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Status: ${statusLabels[b['status']] ?? b['status']}',
                  style: Theme.of(context).textTheme.titleMedium),
              if (dt != null) Text('Jadwal: ${DateFormat('EEE, d MMM y – HH:mm').format(dt)}'),
              if (b['service_categories'] != null)
                Text('Kategori: ${b['service_categories']['name_id']}'),
              if (b['location_address'] != null)
                Text('Lokasi: ${b['location_address']}'),
              if ((b['description'] ?? '').toString().isNotEmpty)
                Text('Catatan: ${b['description']}'),
              const SizedBox(height: 8),
              Wrap(spacing: 4, children: _statusActions()),
            ]),
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: ListView.builder(
            controller: _scrollController,
            padding: const EdgeInsets.all(12),
            itemCount: _messages.length,
            itemBuilder: (context, i) {
              final m = _messages[i];
              final mine = m['sender_id'] == myId;
              return Align(
                alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 3),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.75),
                  decoration: BoxDecoration(
                    color: mine
                        ? Theme.of(context).colorScheme.primaryContainer
                        : Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(m['content'] ?? ''),
                ),
              );
            },
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _msgController,
                  decoration: const InputDecoration(
                      hintText: 'Tulis pesan…',
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8)),
                  onSubmitted: (_) => _send(),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: _send, icon: const Icon(Icons.send)),
            ]),
          ),
        ),
      ]),
    );
  }
}
