import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme.dart';

const statusLabels = {
  'requested': 'Menunggu konfirmasi',
  'accepted': 'Diterima',
  'in_progress': 'Sedang berjalan',
  'completed': 'Selesai',
  'cancelled': 'Dibatalkan',
};

const statusColors = {
  'requested': Colors.orange,
  'accepted': Colors.blue,
  'in_progress': Colors.teal,
  'completed': Colors.green,
  'cancelled': Colors.grey,
};

class BookingsScreen extends StatefulWidget {
  const BookingsScreen({super.key});

  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}

class _BookingsScreenState extends State<BookingsScreen> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    // RLS memastikan hanya pesanan milik saya (sebagai client atau penerjemah).
    final rows = await Supabase.instance.client
        .from('bookings')
        .select('id, status, service_type, scheduled_at, description, '
            'users!bookings_client_id_fkey(full_name), '
            'interpreter_profiles(users(full_name))')
        .order('scheduled_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async => setState(() => _future = _load()),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const GradientHeader(
              title: 'Pesanan Saya',
              subtitle: 'Riwayat dan status pemesanan Anda',
              icon: Icons.event_note,
              showBack: true,
            ),
            FutureBuilder(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(48),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                if (snap.hasError) {
                  return Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('Gagal memuat: ${snap.error}'),
                  );
                }
                final rows = snap.data!;
                if (rows.isEmpty) {
                  return const EmptyState(
                    icon: Icons.event_available,
                    message: 'Belum ada pesanan.\n'
                        'Cari penerjemah di tab Cari untuk memulai.',
                  );
                }
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: rows.map((b) {
                      final status = b['status'] as String;
                      final clientName = b['users']?['full_name'] ?? '-';
                      final interpName = (b['interpreter_profiles']?['users']
                              )?['full_name'] ?? '-';
                      final dt = DateTime.tryParse(b['scheduled_at'] ?? '')
                          ?.toLocal();
                      final color = statusColors[status] ?? Colors.grey;
                      return Card(
                        child: InkWell(
                          borderRadius: BorderRadius.circular(20),
                          onTap: () => context.go('/pesanan/${b['id']}'),
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Row(children: [
                              NameAvatar(name: interpName, radius: 24),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('$clientName ↔ $interpName',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w700)),
                                    if (dt != null)
                                      Text(
                                          DateFormat('EEE, d MMM y – HH:mm')
                                              .format(dt),
                                          style: TextStyle(
                                              fontSize: 13,
                                              color: Colors.brown.shade600)),
                                    Text(b['description'] ?? '',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            fontSize: 13,
                                            color: Colors.brown.shade600)),
                                    const SizedBox(height: 6),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: color.withValues(alpha: 0.12),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Text(
                                          statusLabels[status] ?? status,
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w700,
                                              color: color)),
                                    ),
                                  ],
                                ),
                              ),
                              const Icon(Icons.chevron_right,
                                  color: Colors.brown),
                            ]),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
