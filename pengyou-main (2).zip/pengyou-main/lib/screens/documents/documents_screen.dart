import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme.dart';

const documentTypeLabels = {
  'arc': 'ARC (Kartu Izin Tinggal)',
  'passport': 'Paspor',
  'work_permit': 'Izin Kerja',
  'insurance': 'Asuransi',
  'health_check': 'Cek Kesehatan',
  'contract': 'Kontrak Kerja',
  'other': 'Lainnya',
};

const documentTypeIcons = {
  'arc': Icons.badge,
  'passport': Icons.book,
  'work_permit': Icons.work,
  'insurance': Icons.health_and_safety,
  'health_check': Icons.medical_services,
  'contract': Icons.description,
  'other': Icons.folder,
};

class DocumentsScreen extends StatefulWidget {
  const DocumentsScreen({super.key});

  @override
  State<DocumentsScreen> createState() => _DocumentsScreenState();
}

class _DocumentsScreenState extends State<DocumentsScreen> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await Supabase.instance.client
        .from('documents')
        .select()
        .order('expiry_date');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<void> _markRenewed(String id) async {
    await Supabase.instance.client
        .from('documents')
        .update({'is_renewed': true}).eq('id', id);
    setState(() => _future = _load());
  }

  (String, Color) _expiryInfo(DateTime expiry, bool renewed) {
    if (renewed) return ('Sudah diperbarui', Colors.green);
    final days = expiry.difference(DateTime.now()).inDays;
    if (days < 0) return ('KEDALUWARSA ${-days} hari lalu', Colors.red);
    if (days <= 30) return ('$days hari lagi!', Colors.red);
    if (days <= 90) return ('$days hari lagi', Colors.orange);
    return ('$days hari lagi', Colors.green);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await context.push('/dokumen/tambah');
          setState(() => _future = _load());
        },
        icon: const Icon(Icons.add),
        label: const Text('Tambah'),
      ),
      body: RefreshIndicator(
        onRefresh: () async => setState(() => _future = _load()),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const GradientHeader(
              title: 'Dokumen Saya',
              subtitle: 'Kami ingatkan 30, 14, dan 7 hari sebelum kedaluwarsa',
              icon: Icons.folder_shared,
              showBack: true,
            ),
            FutureBuilder(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(48),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                if (snap.hasError) {
                  return Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('Gagal memuat: ${snap.error}'),
                  );
                }
                final rows = snap.data!;
                if (rows.isEmpty) {
                  return const EmptyState(
                    icon: Icons.badge_outlined,
                    message:
                        'Daftarkan dokumen penting Anda (ARC, paspor, izin kerja) '
                        'agar diingatkan sebelum kedaluwarsa.',
                  );
                }
                return Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
                  child: Column(
                    children: rows.map((d) {
                      final expiry = DateTime.parse(d['expiry_date']);
                      final (label, color) =
                          _expiryInfo(expiry, d['is_renewed'] == true);
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: color.withValues(alpha: 0.12),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Icon(Icons.description, color: color),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                      documentTypeLabels[d['document_type']] ??
                                          d['document_type'],
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w700)),
                                  Text(
                                      'Berlaku s/d ${DateFormat('d MMM y').format(expiry)}',
                                      style: TextStyle(
                                          fontSize: 13,
                                          color: Colors.brown.shade600)),
                                  const SizedBox(height: 4),
                                  Text(label,
                                      style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w700,
                                          color: color)),
                                ],
                              ),
                            ),
                            d['is_renewed'] == true
                                ? const Icon(Icons.check_circle,
                                    color: Colors.green)
                                : TextButton(
                                    onPressed: () => _markRenewed(d['id']),
                                    child: const Text('Sudah\ndiperbarui',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(fontSize: 11)),
                                  ),
                          ]),
                        ),
                      );
                    }).toList(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
