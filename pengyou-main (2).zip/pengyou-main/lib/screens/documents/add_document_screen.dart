import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'documents_screen.dart' show documentTypeLabels;

class AddDocumentScreen extends StatefulWidget {
  const AddDocumentScreen({super.key});

  @override
  State<AddDocumentScreen> createState() => _AddDocumentScreenState();
}

class _AddDocumentScreenState extends State<AddDocumentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _number = TextEditingController();
  String _type = 'arc';
  DateTime? _issueDate;
  DateTime? _expiryDate;
  Uint8List? _photo;
  bool _loading = false;

  Future<void> _pickPhoto() async {
    final picked = await ImagePicker().pickImage(
        source: ImageSource.camera, maxWidth: 1600, imageQuality: 85);
    if (picked == null) return;
    var bytes = await picked.readAsBytes();
    try {
      // Kompres agar hemat kuota data pengguna.
      bytes = await FlutterImageCompress.compressWithList(
          bytes, quality: 70, minWidth: 1280, minHeight: 1280);
    } catch (_) {
      // Jika platform tidak mendukung kompresi, pakai asli.
    }
    setState(() => _photo = bytes);
  }

  Future<DateTime?> _pickDate({DateTime? initial}) => showDatePicker(
        context: context,
        initialDate: initial ?? DateTime.now(),
        firstDate: DateTime(2000),
        lastDate: DateTime(2040),
      );

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_expiryDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tanggal kedaluwarsa wajib diisi.')));
      return;
    }
    setState(() => _loading = true);
    final sb = Supabase.instance.client;
    final uid = sb.auth.currentUser!.id;
    try {
      String? filePath;
      if (_photo != null) {
        filePath = '$uid/${DateTime.now().millisecondsSinceEpoch}_$_type.jpg';
        await sb.storage.from('documents').uploadBinary(filePath, _photo!,
            fileOptions: const FileOptions(contentType: 'image/jpeg'));
      }
      await sb.from('documents').insert({
        'user_id': uid,
        'document_type': _type,
        'document_number':
            _number.text.trim().isEmpty ? null : _number.text.trim(),
        'file_path': filePath,
        'issue_date': _issueDate == null
            ? null
            : DateFormat('yyyy-MM-dd').format(_issueDate!),
        'expiry_date': DateFormat('yyyy-MM-dd').format(_expiryDate!),
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Dokumen tersimpan. Anda akan diingatkan '
                '30, 14, dan 7 hari sebelum kedaluwarsa.')));
        context.pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal menyimpan: $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('d MMM y');
    return Scaffold(
      appBar: AppBar(title: const Text('Tambah Dokumen')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            DropdownButtonFormField<String>(
              initialValue: _type,
              decoration: const InputDecoration(labelText: 'Jenis dokumen'),
              items: documentTypeLabels.entries
                  .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                  .toList(),
              onChanged: (v) => setState(() => _type = v ?? 'arc'),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _number,
              decoration: const InputDecoration(
                  labelText: 'Nomor dokumen (opsional)'),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () async {
                final d = await _pickDate(initial: _issueDate);
                if (d != null) setState(() => _issueDate = d);
              },
              icon: const Icon(Icons.calendar_today),
              label: Text(_issueDate == null
                  ? 'Tanggal terbit (opsional)'
                  : 'Terbit: ${df.format(_issueDate!)}'),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () async {
                final d = await _pickDate(initial: _expiryDate);
                if (d != null) setState(() => _expiryDate = d);
              },
              icon: const Icon(Icons.event_busy),
              label: Text(_expiryDate == null
                  ? 'Tanggal kedaluwarsa *'
                  : 'Kedaluwarsa: ${df.format(_expiryDate!)}'),
            ),
            const SizedBox(height: 16),
            if (_photo != null) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.memory(_photo!, height: 200, fit: BoxFit.cover),
              ),
              const SizedBox(height: 8),
            ],
            OutlinedButton.icon(
              onPressed: _pickPhoto,
              icon: const Icon(Icons.photo_camera),
              label: Text(_photo == null ? 'Foto dokumen (opsional)' : 'Ganti foto'),
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _loading ? null : _save,
              child: _loading
                  ? const SizedBox(
                      height: 20, width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Simpan Dokumen'),
            ),
          ],
        ),
      ),
    );
  }
}
