import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../theme.dart';

class BecomeInterpreterScreen extends StatefulWidget {
  const BecomeInterpreterScreen({super.key});

  @override
  State<BecomeInterpreterScreen> createState() =>
      _BecomeInterpreterScreenState();
}

class _BecomeInterpreterScreenState extends State<BecomeInterpreterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _bio = TextEditingController();
  final _rate = TextEditingController();
  String? _city;
  final Set<String> _pairs = {'id-zh'}; // default ID→ZH
  final Set<String> _categoryIds = {};
  Uint8List? _idPhoto;
  bool _useGps = true;
  bool _loading = false;
  List<Map<String, dynamic>> _categories = [];

  SupabaseClient get sb => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    sb.from('service_categories').select('id, name_id').then((rows) {
      if (mounted) {
        setState(() => _categories = List<Map<String, dynamic>>.from(rows));
      }
    });
  }

  Future<void> _pickIdPhoto() async {
    final picked = await ImagePicker()
        .pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
    if (picked == null) return;
    var bytes = await picked.readAsBytes();
    try {
      bytes = await FlutterImageCompress.compressWithList(bytes,
          quality: 70, minWidth: 1280, minHeight: 1280);
    } catch (_) {}
    setState(() => _idPhoto = bytes);
  }

  /// Posisi GPS saat ini, atau null bila izin ditolak / gagal / terlalu lama.
  Future<Position?> _currentPosition() async {
    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        return null;
      }
      return await Geolocator.getCurrentPosition(
          locationSettings:
              const LocationSettings(timeLimit: Duration(seconds: 10)));
    } catch (_) {
      return null;
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_pairs.isEmpty) {
      _snack('Pilih minimal satu pasangan bahasa.');
      return;
    }
    setState(() => _loading = true);
    final uid = sb.auth.currentUser!.id;
    try {
      // 1. Jadikan penerjemah + buat profil.
      await sb.rpc('become_interpreter', params: {
        'p_bio': _bio.text.trim(),
        'p_city': _city,
        'p_hourly_rate': double.tryParse(_rate.text),
      });

      // 2. Ambil id profil.
      final profile = await sb
          .from('interpreter_profiles')
          .select('id')
          .eq('user_id', uid)
          .single();
      final interpreterId = profile['id'];

      // 3. Pasangan bahasa (hapus lama, isi baru).
      await sb.from('language_pairs').delete().eq('interpreter_id', interpreterId);
      final pairRows = _pairs.map((p) {
        final parts = p.split('-');
        return {
          'interpreter_id': interpreterId,
          'source_language': parts[0],
          'target_language': parts[1],
          'proficiency': 'fluent',
        };
      }).toList();
      if (pairRows.isNotEmpty) {
        await sb.from('language_pairs').insert(pairRows);
      }

      // 4. Kategori layanan.
      await sb.from('interpreter_services').delete().eq('interpreter_id', interpreterId);
      if (_categoryIds.isNotEmpty) {
        await sb.from('interpreter_services').insert(_categoryIds
            .map((c) => {'interpreter_id': interpreterId, 'category_id': c})
            .toList());
      }

      // 5. Foto ID (opsional) ke bucket verification privat.
      if (_idPhoto != null) {
        final path = '$uid/id_${DateTime.now().millisecondsSinceEpoch}.jpg';
        await sb.storage.from('verification').uploadBinary(path, _idPhoto!,
            fileOptions: const FileOptions(contentType: 'image/jpeg', upsert: true));
        await sb
            .from('interpreter_profiles')
            .update({'id_photo_path': path}).eq('id', interpreterId);
      }

      // 6. Titik untuk "Cari Terdekat": GPS bila diizinkan; selain itu server
      //    memakai pusat kota domisili (trigger di 016_interpreter_search.sql).
      final gps = _useGps ? await _currentPosition() : null;
      if (gps != null) {
        await sb.rpc('set_my_location',
            params: {'p_lng': gps.longitude, 'p_lat': gps.latitude});
      }

      if (mounted) {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            icon: const Icon(Icons.verified, color: AppColors.info, size: 48),
            title: const Text('Pendaftaran Terkirim!'),
            content: Text(
                'Terima kasih! Profil penerjemah Anda sedang menunggu '
                'verifikasi admin. Setelah disetujui, Anda akan muncul di '
                'pencarian dan bisa menerima pesanan.\n\n'
                '📍 Lokasi pencarian: '
                '${gps != null ? 'posisi GPS Anda saat ini' : 'pusat kota $_city'}'
                ' (bisa diperbarui di Profil).\n\n'
                '📝 Langkah terakhir: tes bahasa singkat (5 soal) '
                'agar admin bisa cepat menyetujui.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  context.go('/akun');
                },
                child: const Text('Nanti saja'),
              ),
              FilledButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  context.go('/tes-penerjemah');
                },
                child: const Text('Mulai tes bahasa'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      _snack('Gagal mendaftar: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _snack(String m) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const GradientHeader(
              title: 'Jadi Penerjemah',
              subtitle: 'Bergabung & dapat penghasilan tambahan',
              icon: Icons.record_voice_over,
              showBack: true,
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Info manfaat
                  Card(
                    color: AppColors.info.withValues(alpha: 0.07),
                    child: const Padding(
                      padding: EdgeInsets.all(14),
                      child: Row(children: [
                        Text('💼', style: TextStyle(fontSize: 26)),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                              'Bantu sesama PMI, atur jadwal & tarif sendiri, '
                              'dan dapatkan penghasilan tambahan.',
                              style: TextStyle(height: 1.4)),
                        ),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text('Bahasa yang dikuasai',
                      style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, children: [
                    _pairChip('id-zh', 'Indonesia → Mandarin'),
                    _pairChip('zh-id', 'Mandarin → Indonesia'),
                  ]),
                  const SizedBox(height: 20),
                  DropdownButtonFormField<String>(
                    initialValue: _city,
                    decoration: const InputDecoration(
                        labelText: 'Kota domisili', prefixIcon: Icon(Icons.place)),
                    items: AppConfig.cities.keys
                        .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                        .toList(),
                    onChanged: (v) => setState(() => _city = v),
                    validator: (v) => v == null ? 'Pilih kota' : null,
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: _useGps,
                    onChanged: (v) => setState(() => _useGps = v),
                    title: const Text('Pakai lokasi saya sekarang (GPS)'),
                    subtitle: const Text(
                        'Agar klien terdekat menemukan Anda. Jika mati atau '
                        'izin ditolak, dipakai pusat kota.'),
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: _rate,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                        labelText: 'Tarif per jam (NT\$)',
                        prefixIcon: Icon(Icons.payments)),
                    validator: (v) => (double.tryParse(v ?? '') == null)
                        ? 'Masukkan angka tarif'
                        : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _bio,
                    maxLines: 3,
                    decoration: const InputDecoration(
                        labelText: 'Bio / pengalaman',
                        hintText: 'mis. Mahasiswa di Taichung, fasih Mandarin, '
                            'pengalaman dampingi ke rumah sakit',
                        alignLabelWithHint: true),
                    validator: (v) => (v == null || v.trim().length < 10)
                        ? 'Ceritakan sedikit (min. 10 karakter)'
                        : null,
                  ),
                  const SizedBox(height: 20),
                  Text('Layanan yang ditawarkan',
                      style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: _categories.map((c) {
                      final id = c['id'] as String;
                      final sel = _categoryIds.contains(id);
                      return FilterChip(
                        label: Text(c['name_id']),
                        selected: sel,
                        onSelected: (v) => setState(() {
                          v ? _categoryIds.add(id) : _categoryIds.remove(id);
                        }),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),
                  Text('Foto identitas (untuk verifikasi)',
                      style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 4),
                  Text('KTP/paspor Anda. Disimpan aman & hanya dilihat admin '
                      'untuk verifikasi.',
                      style: TextStyle(
                          fontSize: 12, color: Colors.brown.shade500)),
                  const SizedBox(height: 8),
                  if (_idPhoto != null) ...[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.memory(_idPhoto!, height: 160, fit: BoxFit.cover),
                    ),
                    const SizedBox(height: 8),
                  ],
                  OutlinedButton.icon(
                    onPressed: _pickIdPhoto,
                    icon: const Icon(Icons.upload_file),
                    label: Text(_idPhoto == null
                        ? 'Unggah foto ID (opsional)'
                        : 'Ganti foto'),
                  ),
                  const SizedBox(height: 24),
                  FilledButton(
                    onPressed: _loading ? null : _submit,
                    child: _loading
                        ? const SizedBox(
                            height: 20, width: 20,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Text('Kirim Pendaftaran'),
                  ),
                  const SizedBox(height: 12),
                  Text(
                      'Dengan mendaftar, Anda setuju profil ditinjau admin '
                      'sebelum aktif.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 11, color: Colors.brown.shade400)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _pairChip(String value, String label) {
    final sel = _pairs.contains(value);
    return FilterChip(
      label: Text(label),
      selected: sel,
      onSelected: (v) => setState(() {
        v ? _pairs.add(value) : _pairs.remove(value);
      }),
    );
  }
}
