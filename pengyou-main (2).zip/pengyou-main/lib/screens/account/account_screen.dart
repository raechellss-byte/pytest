import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../i18n/strings.dart';
import '../../theme.dart';
import '../profile/profile_screen.dart';

/// Tab "Akun": tampilkan profil bila sudah login, atau ajakan masuk/daftar
/// bila belum. Memantau perubahan status auth agar otomatis berganti.
class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, _) {
        final loggedIn =
            Supabase.instance.client.auth.currentSession != null;
        if (loggedIn) return const ProfileScreen();
        return const _LoggedOutView();
      },
    );
  }
}

class _LoggedOutView extends StatelessWidget {
  const _LoggedOutView();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          GradientHeader(
            title: tr('account_title'),
            subtitle: tr('login_prompt'),
            icon: Icons.person,
            trailing: PopupMenuButton<String>(
              icon: const Icon(Icons.language, color: Colors.white),
              onSelected: (v) => Lang.instance.set(v),
              itemBuilder: (_) => Lang.supported.entries
                  .map((e) => PopupMenuItem(value: e.key, child: Text(e.value)))
                  .toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: AppColors.primary.withValues(alpha: 0.08),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.account_circle,
                    size: 72, color: AppColors.primary.withValues(alpha: 0.6)),
              ),
              const SizedBox(height: 20),
              Text(tr('not_logged_in'),
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(
                tr('login_prompt'),
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.brown.shade600, height: 1.5),
              ),
              const SizedBox(height: 28),
              FilledButton.icon(
                onPressed: () => context.go('/login'),
                icon: const Icon(Icons.login),
                label: Text(tr('sign_in')),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => context.go('/daftar'),
                icon: const Icon(Icons.person_add),
                label: Text(tr('sign_up_free')),
              ),
              const SizedBox(height: 20),
              TextButton.icon(
                onPressed: () => context.push('/bantuan'),
                icon: const Icon(Icons.help_outline),
                label: Text(tr('help')),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}
