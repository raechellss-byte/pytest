import 'dart:math';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme.dart';

/// Pilih soal tes: 2 Indonesia→Mandarin, 2 Mandarin→Indonesia, 1 menulis bebas.
List<Map<String, dynamic>> pickTestQuestions(
  List<Map<String, dynamic>> rows,
  Random rnd,
) {
  List<Map<String, dynamic>> take(String kind, int n) =>
      (rows.where((r) => r['kind'] == kind).toList()..shuffle(rnd))
          .take(n)
          .toList();
  return [...take('id_zh', 2), ...take('zh_id', 2), ...take('intro', 1)];
}

const _kindLabel = {
  'id_zh': 'Terjemahkan ke bahasa Mandarin',
  'zh_id': 'Terjemahkan ke bahasa Indonesia',
  'intro': 'Tulis dalam bahasa Mandarin',
};

/// Tes bahasa calon penerjemah. Dinilai AI di Edge Function
/// `screen-interpreter`; persetujuan akhir tetap oleh admin.
class InterpreterTestScreen extends StatefulWidget {
  const InterpreterTestScreen({super.key, this.random});
  final Random? random; // untuk tes

  @override
  State<InterpreterTestScreen> createState() => _InterpreterTestScreenState();
}

class _InterpreterTestScreenState extends State<InterpreterTestScreen> {
  List<Map<String, dynamic>>? _questions;
  final _answers = <String, TextEditingController>{};
  String? _error;
  bool _sending = false;
  Map<String, dynamic>? _result;

  SupabaseClient get sb => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in _answers.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _questions = null;
      _error = null;
      _result = null;
    });
    try {
      final rows = await sb
          .from('interpreter_test_questions')
          .select('id, kind, prompt, context')
          .eq('is_active', true);
      final picked = pickTestQuestions(
        List<Map<String, dynamic>>.from(rows),
        widget.random ?? Random(),
      );
      for (final c in _answers.values) {
        c.dispose();
      }
      _answers
        ..clear()
        ..addEntries(
          picked.map(
            (q) => MapEntry(q['id'] as String, TextEditingController()),
          ),
        );
      if (mounted) setState(() => _questions = picked);
    } catch (e) {
      if (mounted) setState(() => _error = 'Gagal memuat soal: $e');
    }
  }

  Future<void> _submit() async {
    if (_answers.values.any((c) => c.text.trim().isEmpty)) {
      _snack('Semua soal wajib dijawab.');
      return;
    }
    setState(() => _sending = true);
    try {
      final res = await sb.functions.invoke(
        'screen-interpreter',
        body: {
          'answers': [
            for (final e in _answers.entries)
              {'question_id': e.key, 'answer': e.value.text.trim()},
          ],
        },
      );
      final data = Map<String, dynamic>.from(res.data as Map);
      if (data['ok'] == true) {
        setState(() => _result = data);
      } else {
        _snack('${data['error'] ?? 'Gagal mengirim tes.'}');
      }
    } catch (e) {
      _snack('Gagal mengirim tes. Periksa koneksi lalu coba lagi.');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _snack(String m) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          const GradientHeader(
            title: 'Tes Bahasa',
            subtitle: '5 soal singkat · ±10 menit',
            icon: Icons.translate,
            showBack: true,
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: _result != null
                  ? [_ResultCard(result: _result!, onRetry: _load)]
                  : _testChildren(context),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _testChildren(BuildContext context) {
    if (_error != null) {
      return [
        Card(
          color: Colors.orange.shade50,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(_error!),
          ),
        ),
      ];
    }
    final qs = _questions;
    if (qs == null) {
      return const [
        Padding(
          padding: EdgeInsets.all(32),
          child: Center(child: CircularProgressIndicator()),
        ),
      ];
    }
    return [
      Card(
        color: AppColors.info.withValues(alpha: 0.07),
        child: const Padding(
          padding: EdgeInsets.all(14),
          child: Text(
            'Jawab sendiri tanpa mesin penerjemah — yang dinilai ketepatan '
            'makna, karena salah terjemah di rumah sakit bisa berbahaya. '
            'Jawaban dinilai, lalu admin memberi persetujuan akhir. '
            'Maksimal 3 kali tes per hari.',
            style: TextStyle(height: 1.4),
          ),
        ),
      ),
      const SizedBox(height: 8),
      for (final (i, q) in qs.indexed) ...[
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(
                      '${i + 1}. ${_kindLabel[q['kind']] ?? ''}',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    if (q['context'] != null)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.info.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '${q['context']}',
                          style: const TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                            color: AppColors.info,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  '${q['prompt']}',
                  style: const TextStyle(fontSize: 16, height: 1.45),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _answers[q['id']],
                  maxLines: q['kind'] == 'intro' ? 5 : 2,
                  minLines: q['kind'] == 'intro' ? 3 : 1,
                  maxLength: 800,
                  decoration: InputDecoration(
                    hintText: q['kind'] == 'zh_id'
                        ? 'Terjemahan bahasa Indonesia…'
                        : 'Jawaban dalam bahasa Mandarin…',
                    counterText: '',
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
      const SizedBox(height: 20),
      FilledButton.icon(
        onPressed: _sending || qs.isEmpty ? null : _submit,
        icon: _sending
            ? const SizedBox(
                height: 18,
                width: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : const Icon(Icons.send),
        label: Text(_sending ? 'Sedang dinilai… (±30 detik)' : 'Kirim jawaban'),
      ),
    ];
  }
}

class _ResultCard extends StatelessWidget {
  const _ResultCard({required this.result, required this.onRetry});
  final Map<String, dynamic> result;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final verdict = result['verdict'] as String?;
    final total = result['total'] as num?;
    final left = (result['attempts_left'] as num?)?.toInt() ?? 0;
    final (icon, color, title, body) = switch (verdict) {
      'pass' => (
        Icons.verified,
        Colors.green.shade700,
        'Lolos tes bahasa',
        'Tinggal persetujuan admin. Setelah disetujui, Anda muncul di '
            'pencarian "Cari Terdekat".',
      ),
      'reject' => (
        Icons.refresh,
        Colors.orange.shade800,
        'Belum lolos',
        left > 0
            ? 'Pelajari catatan di bawah lalu coba lagi. Sisa percobaan '
                  'hari ini: $left.'
            : 'Batas tes hari ini sudah habis. Coba lagi besok.',
      ),
      _ => (
        Icons.manage_search,
        AppColors.info,
        'Sedang ditinjau admin',
        'Jawaban Anda sudah tersimpan dan akan dinilai admin.',
      ),
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Card(
          color: color.withValues(alpha: 0.07),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Icon(icon, size: 56, color: color),
                const SizedBox(height: 10),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: color,
                  ),
                ),
                if (total != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    'Skor ${total.round()} / 100',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ],
                const SizedBox(height: 10),
                Text(body, textAlign: TextAlign.center),
              ],
            ),
          ),
        ),
        if ((result['feedback'] ?? '').toString().isNotEmpty)
          Card(
            child: ListTile(
              leading: const Icon(Icons.tips_and_updates_outlined),
              title: const Text(
                'Catatan penilai',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              subtitle: Text('${result['feedback']}'),
            ),
          ),
        const SizedBox(height: 12),
        if (verdict == 'reject' && left > 0)
          FilledButton.icon(
            onPressed: onRetry,
            icon: const Icon(Icons.replay),
            label: const Text('Coba lagi dengan soal baru'),
          ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: () => context.go('/akun'),
          child: const Text('Kembali ke Profil'),
        ),
      ],
    );
  }
}
