import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../config.dart';
import '../../i18n/strings.dart';
import '../../theme.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<Map<String, dynamic>>? _results;
  bool _loading = false;
  String? _error;
  String? _cityLabel;
  double _maxKm = 20;

  Future<void> _searchNearMe() async {
    setState(() { _loading = true; _error = null; _cityLabel = null; });
    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        setState(() {
          _loading = false;
          _error = 'Izin lokasi ditolak. Silakan pilih kota secara manual.';
        });
        return;
      }
      final pos = await Geolocator.getCurrentPosition();
      await _fetch(pos.latitude, pos.longitude);
    } catch (e) {
      setState(() {
        _loading = false;
        _error = 'Gagal mengambil lokasi. Silakan pilih kota manual.';
      });
    }
  }

  Future<void> _searchCity(String city) async {
    final (lat, lng) = AppConfig.cities[city]!;
    setState(() { _loading = true; _error = null; _cityLabel = city; });
    await _fetch(lat, lng);
  }

  Future<void> _fetch(double lat, double lng) async {
    try {
      final data = await Supabase.instance.client.rpc('nearest_interpreters',
          params: {'p_lng': lng, 'p_lat': lat, 'p_max_km': _maxKm});
      setState(() {
        _results = List<Map<String, dynamic>>.from(data as List);
        _loading = false;
      });
    } catch (e) {
      setState(() { _loading = false; _error = 'Gagal memuat data: $e'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          GradientHeader(
            title: tr('search_title'),
            subtitle: tr('search_subtitle'),
            icon: Icons.travel_explore,
            child: Column(children: [
              Row(children: [
                Expanded(
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: AppColors.primaryDark,
                    ),
                    onPressed: _loading ? null : _searchNearMe,
                    icon: const Icon(Icons.my_location),
                    label: Text(tr('nearest')),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white.withValues(alpha: 0.22),
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () => context.go('/cari/peta'),
                    icon: const Icon(Icons.map),
                    label: Text(tr('view_map')),
                  ),
                ),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _cityLabel,
                        isExpanded: true,
                        dropdownColor: AppColors.primaryDark,
                        iconEnabledColor: Colors.white,
                        style: const TextStyle(color: Colors.white),
                        hint: Text(tr('choose_city'),
                            style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.8))),
                        items: AppConfig.cities.keys
                            .map((c) =>
                                DropdownMenuItem(value: c, child: Text(c)))
                            .toList(),
                        onChanged: _loading
                            ? null
                            : (c) { if (c != null) _searchCity(c); },
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<double>(
                      value: _maxKm,
                      dropdownColor: AppColors.primaryDark,
                      iconEnabledColor: Colors.white,
                      style: const TextStyle(color: Colors.white),
                      items: const [5.0, 10.0, 20.0, 30.0, 50.0]
                          .map((km) => DropdownMenuItem(
                              value: km, child: Text('${km.round()} km')))
                          .toList(),
                      onChanged: (v) =>
                          setState(() => _maxKm = v ?? 20),
                    ),
                  ),
                ),
              ]),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              if (_loading)
                const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(child: CircularProgressIndicator()),
                ),
              if (_error != null)
                Card(
                  color: Colors.orange.shade50,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(children: [
                      Icon(Icons.info_outline, color: Colors.orange.shade800),
                      const SizedBox(width: 10),
                      Expanded(child: Text(_error!)),
                    ]),
                  ),
                ),
              if (_results == null && !_loading && _error == null)
                const EmptyState(
                  icon: Icons.travel_explore,
                  message:
                      'Tekan "Cari Terdekat" atau pilih kota untuk menemukan '
                      'penerjemah Indonesia–Mandarin di sekitar Anda.',
                ),
              if (_results != null && _results!.isEmpty && !_loading)
                const EmptyState(
                  icon: Icons.person_search,
                  message:
                      'Belum ada penerjemah terverifikasi dalam radius ini.\n'
                      'Coba perbesar radius atau pilih kota lain.',
                ),
              if (_results != null && _results!.isNotEmpty)
                LayoutBuilder(
                  builder: (context, constraints) {
                    if (constraints.maxWidth >= 680) {
                      final w = (constraints.maxWidth - 14) / 2;
                      return Wrap(
                        spacing: 14,
                        runSpacing: 14,
                        children: _results!
                            .map(
                              (r) => SizedBox(
                                width: w,
                                child: _InterpreterCard(data: r),
                              ),
                            )
                            .toList(),
                      );
                    }
                    return Column(
                      children: _results!
                          .map(
                            (r) => Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: _InterpreterCard(data: r),
                            ),
                          )
                          .toList(),
                    );
                  },
                ),
            ]),
          ),
        ],
      ),
    );
  }
}

class _InterpreterCard extends StatelessWidget {
  const _InterpreterCard({required this.data});
  final Map<String, dynamic> data;

  @override
  Widget build(BuildContext context) {
    final name = data['full_name'] as String? ?? '?';
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => context.go('/cari/penerjemah/${data['interpreter_id']}'),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            NameAvatar(name: name, radius: 26),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Expanded(
                      child: Text(name,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 16)),
                    ),
                    const Icon(Icons.verified,
                        size: 18, color: Color(0xFF2471A3)),
                  ]),
                  const SizedBox(height: 4),
                  // Wrap: tidak terpotong di HP sempit / ukuran huruf besar.
                  Wrap(crossAxisAlignment: WrapCrossAlignment.center, children: [
                    const Icon(Icons.star_rounded,
                        size: 18, color: Color(0xFFF5B041)),
                    Text(
                        ' ${(data['rating_avg'] as num?)?.toStringAsFixed(1) ?? '-'}'
                        ' (${data['rating_count'] ?? 0})',
                        style: TextStyle(color: Colors.brown.shade700)),
                    const SizedBox(width: 12),
                    Icon(Icons.place_outlined,
                        size: 16, color: Colors.brown.shade400),
                    Text(
                        ' ${(data['distance_km'] as num?)?.toStringAsFixed(1)} km',
                        style: TextStyle(color: Colors.brown.shade700)),
                  ]),
                  if (data['hourly_rate'] != null) ...[
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.primary.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text('NT\$ ${data['hourly_rate']}/jam',
                          style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 13,
                              color: AppColors.primaryDark)),
                    ),
                  ],
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.brown),
          ]),
        ),
      ),
    );
  }
}
