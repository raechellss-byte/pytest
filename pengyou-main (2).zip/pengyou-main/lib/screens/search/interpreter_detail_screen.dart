import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme.dart';

class InterpreterDetailScreen extends StatefulWidget {
  const InterpreterDetailScreen({super.key, required this.interpreterId});
  final String interpreterId;

  @override
  State<InterpreterDetailScreen> createState() => _InterpreterDetailScreenState();
}

class _InterpreterDetailScreenState extends State<InterpreterDetailScreen> {
  Map<String, dynamic>? _profile;
  List<Map<String, dynamic>> _reviews = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sb = Supabase.instance.client;
    final profile = await sb
        .from('interpreter_profiles')
        .select('*, users(full_name), language_pairs(*), '
            'interpreter_services(custom_rate, service_categories(name_id))')
        .eq('id', widget.interpreterId)
        .single();
    final reviews = await sb
        .from('reviews')
        .select('rating, comment, created_at')
        .eq('reviewee_id', profile['user_id'])
        .order('created_at', ascending: false)
        .limit(10);
    if (mounted) {
      setState(() {
        _profile = profile;
        _reviews = List<Map<String, dynamic>>.from(reviews);
        _loading = false;
      });
    }
  }

  Future<void> _startChat() async {
    final sb = Supabase.instance.client;
    if (sb.auth.currentSession == null) {
      context.go('/login');
      return;
    }
    final otherUserId = _profile?['user_id'];
    final otherName = _profile?['users']?['full_name'] ?? 'Penerjemah';
    if (otherUserId == null) return;
    try {
      final cid = await sb.rpc('get_or_create_conversation',
          params: {'p_other': otherUserId});
      if (mounted) context.push('/pesan/$cid', extra: otherName);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal memulai chat: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final p = _profile!;
    final name = p['users']?['full_name'] ?? 'Penerjemah';
    final services = List<Map<String, dynamic>>.from(p['interpreter_services'] ?? []);
    final pairs = List<Map<String, dynamic>>.from(p['language_pairs'] ?? []);

    return Scaffold(
      appBar: AppBar(title: Text(name)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            NameAvatar(name: name, radius: 32),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name, style: Theme.of(context).textTheme.titleLarge),
                Row(children: [
                  const Icon(Icons.star, size: 18, color: Colors.amber),
                  Text(' ${(p['rating_avg'] as num?)?.toStringAsFixed(1)}'
                      ' (${p['rating_count']} ulasan)'),
                  const SizedBox(width: 8),
                  if (p['is_verified'] == true)
                    const Chip(
                      label: Text('Terverifikasi'),
                      avatar: Icon(Icons.verified, size: 16),
                      visualDensity: VisualDensity.compact,
                    ),
                ]),
                if (p['city'] != null) Text('📍 ${p['city']}'),
              ]),
            ),
          ]),
          const SizedBox(height: 16),
          if (p['hourly_rate'] != null)
            Text('Tarif: NT\$ ${p['hourly_rate']}/jam',
                style: Theme.of(context).textTheme.titleMedium),
          if (p['bio'] != null) ...[
            const SizedBox(height: 8),
            Text(p['bio']),
          ],
          const SizedBox(height: 16),
          if (pairs.isNotEmpty) ...[
            Text('Bahasa', style: Theme.of(context).textTheme.titleMedium),
            Wrap(
              spacing: 8,
              children: pairs
                  .map((lp) => Chip(
                      label: Text('${lp['source_language']} → ${lp['target_language']}')))
                  .toList(),
            ),
          ],
          if (services.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('Layanan', style: Theme.of(context).textTheme.titleMedium),
            Wrap(
              spacing: 8,
              children: services
                  .map((s) => Chip(
                      label: Text(s['service_categories']?['name_id'] ?? '-')))
                  .toList(),
            ),
          ],
          const SizedBox(height: 24),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _startChat,
                icon: const Icon(Icons.chat_bubble_outline),
                label: const Text('Chat'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: FilledButton.icon(
                onPressed: () =>
                    context.go('/cari/penerjemah/${widget.interpreterId}/pesan'),
                icon: const Icon(Icons.event_available),
                label: const Text('Pesan'),
              ),
            ),
          ]),
          const SizedBox(height: 24),
          Text('Ulasan', style: Theme.of(context).textTheme.titleMedium),
          if (_reviews.isEmpty) const Text('Belum ada ulasan.'),
          ..._reviews.map((r) => ListTile(
                leading: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.star, size: 16, color: Colors.amber),
                  Text('${r['rating']}'),
                ]),
                title: Text(r['comment'] ?? ''),
              )),
        ],
      ),
    );
  }
}
