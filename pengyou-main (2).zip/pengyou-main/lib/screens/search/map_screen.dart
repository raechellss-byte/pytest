import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart' hide Path;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../theme.dart';

/// Info kategori tempat: warna + ikon + label.
const _placeStyle = <String, (Color, IconData, String)>{
  'agency': (Color(0xFF7C3AED), Icons.business, 'Lembaga Penerjemah'),
  'immigration': (Color(0xFF2563EB), Icons.assignment_ind, 'Imigrasi'),
  'hospital': (Color(0xFF0E9C8B), Icons.local_hospital, 'Rumah Sakit'),
  'station': (Color(0xFFCA8A04), Icons.train, 'Stasiun'),
  'office': (Color(0xFF64748B), Icons.apartment, 'Kantor'),
  'other': (Color(0xFF64748B), Icons.place, 'Tempat'),
};

const _osmColor = Color(0xFFEA580C);

/// Kategori yang bisa difilter di legenda (urutan tampil).
const _filterCats = <(String, Color, IconData, String)>[
  ('interpreter', AppColors.primary, Icons.record_voice_over, 'Penerjemah'),
  ('agency', Color(0xFF7C3AED), Icons.business, 'Lembaga'),
  ('immigration', Color(0xFF2563EB), Icons.assignment_ind, 'Imigrasi'),
  ('hospital', Color(0xFF0E9C8B), Icons.local_hospital, 'RS'),
  ('station', Color(0xFFCA8A04), Icons.train, 'Stasiun'),
  ('osm', _osmColor, Icons.travel_explore, 'Agen (OSM)'),
];

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final _map = MapController();
  List<Map<String, dynamic>> _interpreters = [];
  List<Map<String, dynamic>> _places = [];
  List<Map<String, dynamic>> _osm = []; // hasil pencarian OSM (Overpass)
  bool _loading = true;
  bool _osmLoading = false;

  LatLng? _userLoc;
  bool _locating = false;
  // Kategori yang aktif ditampilkan (default: semua).
  final Set<String> _cats = {
    for (final c in _filterCats) c.$1,
  };

  static const _taichung = LatLng(24.1477, 120.6736);
  static const _distance = Distance();

  SupabaseClient get sb => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _load();
    _locate(); // ambil lokasi pengguna saat peta dibuka
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait([
        sb.rpc('interpreters_for_map'),
        sb.from('map_places').select().eq('is_active', true),
      ]);
      if (mounted) {
        setState(() {
          _interpreters = List<Map<String, dynamic>>.from(results[0] as List);
          _places = List<Map<String, dynamic>>.from(results[1] as List);
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Gagal memuat peta: $e')));
      }
    }
  }

  /// Minta lokasi GPS pengguna, lalu fokuskan peta ke sana.
  Future<void> _locate({bool announce = false}) async {
    if (_locating) return;
    setState(() => _locating = true);
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (announce) _toast('Layanan lokasi perangkat mati.');
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (announce) _toast('Izin lokasi ditolak — peta pakai Taichung.');
        return;
      }
      final pos = await Geolocator.getCurrentPosition();
      if (!mounted) return;
      setState(() => _userLoc = LatLng(pos.latitude, pos.longitude));
      _map.move(_userLoc!, 14);
    } catch (_) {
      if (announce) _toast('Gagal mengambil lokasi.');
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  void _toast(String m) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(m)));

  /// Jarak dari lokasi pengguna (null jika GPS belum ada).
  String? _distLine(num? lat, num? lng) {
    if (_userLoc == null || lat == null || lng == null) return null;
    final km = _distance.as(
        LengthUnit.Kilometer, _userLoc!, LatLng(lat.toDouble(), lng.toDouble()));
    return '📍 ${km.toStringAsFixed(1)} km dari lokasimu';
  }

  // -------- Pencarian agen/penerjemah dari OpenStreetMap (Overpass) --------

  LatLng _searchCenter() {
    try {
      return _map.camera.center;
    } catch (_) {
      return _userLoc ?? _taichung;
    }
  }

  Future<void> _searchOsm() async {
    if (_osmLoading) return;
    setState(() => _osmLoading = true);
    final c = _searchCenter();
    final around = '(around:6000,${c.latitude},${c.longitude})';
    // Query lengkap: agen ketenagakerjaan + nama mengandung 翻譯/仲介/translation.
    final full = '[out:json][timeout:25];'
        '('
        'nwr["office"="employment_agency"]$around;'
        'nwr["name"~"翻譯|翻译|仲介|翻訳|translation|interpreter|agency",i]$around;'
        ');'
        'out center 80;';
    // Cadangan (ASCII saja) bila query CJK ditolak server.
    final fallback = '[out:json][timeout:25];'
        '(nwr["office"="employment_agency"]$around;);'
        'out center 80;';
    try {
      String body;
      try {
        body = await _overpass(full);
      } catch (_) {
        body = await _overpass(fallback);
      }
      final data = jsonDecode(body) as Map<String, dynamic>;
      final els = (data['elements'] as List?) ?? const [];
      final out = <Map<String, dynamic>>[];
      final seen = <String>{};
      for (final e in els) {
        final m = e as Map<String, dynamic>;
        final tags = (m['tags'] as Map?)?.cast<String, dynamic>() ?? {};
        final name =
            (tags['name'] ?? tags['name:en'] ?? tags['name:zh'])?.toString();
        if (name == null || name.trim().isEmpty) continue;
        double? lat, lng;
        if (m['lat'] != null) {
          lat = (m['lat'] as num).toDouble();
          lng = (m['lon'] as num).toDouble();
        } else if (m['center'] != null) {
          lat = (m['center']['lat'] as num).toDouble();
          lng = (m['center']['lon'] as num).toDouble();
        }
        if (lat == null || lng == null) continue;
        final key = '$name@${lat.toStringAsFixed(4)},${lng.toStringAsFixed(4)}';
        if (!seen.add(key)) continue;
        out.add({
          'name': name,
          'lat': lat,
          'lng': lng,
          'address': _osmAddr(tags),
          'phone': tags['phone'] ?? tags['contact:phone'],
          'website': tags['website'] ?? tags['contact:website'],
          'office': tags['office'],
        });
      }
      if (!mounted) return;
      setState(() {
        _osm = out;
        _cats.add('osm');
      });
      _toast(out.isEmpty
          ? 'Belum ada agen ter-tag di OSM sekitar sini. Geser peta lalu coba lagi.'
          : '${out.length} tempat ditemukan dari OpenStreetMap.');
    } catch (_) {
      if (mounted) _toast('Gagal mencari (OSM). Coba lagi sebentar.');
    } finally {
      if (mounted) setState(() => _osmLoading = false);
    }
  }

  Future<String> _overpass(String query) async {
    const hosts = [
      'https://overpass-api.de/api/interpreter',
      'https://overpass.kumi.systems/api/interpreter',
    ];
    Object? lastErr;
    for (final h in hosts) {
      try {
        final r = await http
            .post(Uri.parse(h), body: {'data': query})
            .timeout(const Duration(seconds: 30));
        if (r.statusCode == 200) return r.body;
        lastErr = 'HTTP ${r.statusCode}';
      } catch (e) {
        lastErr = e;
      }
    }
    throw Exception(lastErr);
  }

  String _osmAddr(Map<String, dynamic> t) {
    final parts = [
      t['addr:housenumber'],
      t['addr:street'],
      t['addr:district'],
      t['addr:city'],
    ].where((e) => e != null && '$e'.isNotEmpty).map((e) => '$e');
    return parts.join(', ');
  }

  Future<void> _openUrl(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  void _showOsm(Map<String, dynamic> p) {
    final name = '${p['name']}';
    final addr = '${p['address'] ?? ''}';
    _sheet(
      color: _osmColor,
      icon: Icons.travel_explore,
      tag: p['office'] == 'employment_agency' ? 'Agen / 仲介 (OSM)' : 'Tempat (OSM)',
      title: name,
      lines: [
        if (addr.isNotEmpty) addr,
        if ((p['phone'] ?? '').toString().isNotEmpty) '☎ ${p['phone']}',
        if (_distLine(p['lat'] as num?, p['lng'] as num?) != null)
          _distLine(p['lat'] as num?, p['lng'] as num?),
        'Sumber: OpenStreetMap — verifikasi sebelum berkunjung.',
      ],
      action: Row(children: [
        Expanded(
          child: FilledButton.icon(
            onPressed: () {
              Navigator.pop(context);
              _openUrl(
                  'https://www.google.com/maps/dir/?api=1&destination=${Uri.encodeComponent('$name ${addr.isEmpty ? '' : addr}')}');
            },
            icon: const Icon(Icons.directions),
            label: const Text('Rute'),
          ),
        ),
        if ((p['website'] ?? '').toString().isNotEmpty) ...[
          const SizedBox(width: 10),
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () => _openUrl('${p['website']}'),
              icon: const Icon(Icons.open_in_new),
              label: const Text('Situs'),
            ),
          ),
        ],
      ]),
    );
  }

  void _showPlace(Map<String, dynamic> p) {
    final (color, icon, label) =
        _placeStyle[p['category']] ?? _placeStyle['other']!;
    _sheet(
      color: color,
      icon: icon,
      tag: label,
      title: p['name'] ?? '',
      lines: [
        if ((p['address'] ?? '').toString().isNotEmpty) p['address'],
        if ((p['note'] ?? '').toString().isNotEmpty) p['note'],
        if (_distLine(p['lat'] as num?, p['lng'] as num?) != null)
          _distLine(p['lat'] as num?, p['lng'] as num?),
      ],
    );
  }

  void _showInterpreter(Map<String, dynamic> i) {
    _sheet(
      color: AppColors.primary,
      icon: Icons.record_voice_over,
      tag: 'Penerjemah',
      title: i['full_name'] ?? 'Penerjemah',
      lines: [
        '⭐ ${(i['rating_avg'] as num?)?.toStringAsFixed(1) ?? '-'}'
            '${i['hourly_rate'] != null ? '  ·  NT\$ ${i['hourly_rate']}/jam' : ''}',
        if (_distLine(i['lat'] as num?, i['lng'] as num?) != null)
          _distLine(i['lat'] as num?, i['lng'] as num?),
      ],
      action: FilledButton.icon(
        onPressed: () {
          Navigator.pop(context);
          context.go('/cari/penerjemah/${i['interpreter_id']}');
        },
        icon: const Icon(Icons.person),
        label: const Text('Lihat Profil'),
      ),
    );
  }

  void _sheet({
    required Color color,
    required IconData icon,
    required String tag,
    required String title,
    required List<dynamic> lines,
    Widget? action,
  }) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(14)),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(tag,
                    style: TextStyle(
                        color: color, fontSize: 12, fontWeight: FontWeight.w800)),
                Text(title,
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w800)),
              ]),
            ),
          ]),
          const SizedBox(height: 12),
          ...lines.where((l) => l != null).map((l) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('$l', style: const TextStyle(height: 1.4))),
              )),
          if (action != null) ...[
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: action),
          ],
        ]),
      ),
    );
  }

  Marker _pin({
    required LatLng point,
    required Color color,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Marker(
      point: point,
      width: 46,
      height: 54,
      alignment: Alignment.topCenter,
      child: GestureDetector(
        onTap: onTap,
        child: Column(children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.3),
                    blurRadius: 4,
                    offset: const Offset(0, 2)),
              ],
            ),
            child: Icon(icon, color: Colors.white, size: 18),
          ),
          CustomPaint(size: const Size(10, 8), painter: _PinTail(color)),
        ]),
      ),
    );
  }

  int _placeCount(String cat) =>
      _places.where((p) => p['category'] == cat).length;

  int _countFor(String cat) => switch (cat) {
        'interpreter' => _interpreters.length,
        'osm' => _osm.length,
        _ => _placeCount(cat),
      };

  @override
  Widget build(BuildContext context) {
    final markers = <Marker>[
      for (final p in _places)
        if (_cats.contains(p['category']) &&
            p['lat'] != null &&
            p['lng'] != null)
          _pin(
            point: LatLng((p['lat'] as num).toDouble(), (p['lng'] as num).toDouble()),
            color: (_placeStyle[p['category']] ?? _placeStyle['other']!).$1,
            icon: (_placeStyle[p['category']] ?? _placeStyle['other']!).$2,
            onTap: () => _showPlace(p),
          ),
      if (_cats.contains('osm'))
        for (final p in _osm)
          _pin(
            point: LatLng(p['lat'] as double, p['lng'] as double),
            color: _osmColor,
            icon: Icons.travel_explore,
            onTap: () => _showOsm(p),
          ),
      if (_cats.contains('interpreter'))
        for (final i in _interpreters)
          if (i['lat'] != null && i['lng'] != null)
            _pin(
              point: LatLng((i['lat'] as num).toDouble(), (i['lng'] as num).toDouble()),
              color: AppColors.primary,
              icon: Icons.record_voice_over,
              onTap: () => _showInterpreter(i),
            ),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Peta Lembaga & Penerjemah')),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton.extended(
            heroTag: 'osm-search',
            onPressed: _osmLoading ? null : _searchOsm,
            backgroundColor: _osmColor,
            icon: _osmLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2.4, color: Colors.white))
                : const Icon(Icons.travel_explore),
            label: const Text('Cari agen'),
          ),
          const SizedBox(height: 10),
          FloatingActionButton(
            heroTag: 'my-loc',
            onPressed: () {
              if (_userLoc != null) {
                _map.move(_userLoc!, 15);
              } else {
                _locate(announce: true);
              }
            },
            tooltip: 'Lokasi saya',
            child: _locating
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                        strokeWidth: 2.4, color: Colors.white))
                : const Icon(Icons.my_location),
          ),
        ],
      ),
      body: Stack(children: [
        FlutterMap(
          mapController: _map,
          options: const MapOptions(
            initialCenter: _taichung,
            initialZoom: 13,
            minZoom: 4,
            maxZoom: 18,
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'app.pengyou',
            ),
            if (_userLoc != null)
              MarkerLayer(markers: [
                Marker(
                  point: _userLoc!,
                  width: 24,
                  height: 24,
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF1E6FB8),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 3),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black.withValues(alpha: 0.3),
                            blurRadius: 4),
                      ],
                    ),
                  ),
                ),
              ]),
            MarkerLayer(markers: markers),
            const RichAttributionWidget(attributions: [
              TextSourceAttribution('© OpenStreetMap'),
            ]),
          ],
        ),
        if (_loading)
          const Center(child: CircularProgressIndicator()),
        // Legenda = filter kategori (ketuk untuk on/off).
        Positioned(
          left: 12,
          top: 12,
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(4, 2, 4, 6),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.filter_alt_outlined,
                          size: 14, color: Colors.brown.shade400),
                      const SizedBox(width: 4),
                      Text('Filter',
                          style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: Colors.brown.shade500)),
                    ]),
                  ),
                  for (final c in _filterCats)
                    _filterRow(
                      cat: c.$1,
                      color: c.$2,
                      icon: c.$3,
                      label: c.$4,
                      count: _countFor(c.$1),
                    ),
                ],
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _filterRow({
    required String cat,
    required Color color,
    required IconData icon,
    required String label,
    required int count,
  }) {
    final on = _cats.contains(cat);
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: () => setState(() {
        if (on) {
          _cats.remove(cat);
        } else {
          _cats.add(cat);
        }
      }),
      child: Opacity(
        opacity: on ? 1 : 0.4,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 4),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              child: Icon(icon, color: Colors.white, size: 12),
            ),
            const SizedBox(width: 6),
            Text('$label ($count)',
                style: const TextStyle(
                    fontSize: 11.5, fontWeight: FontWeight.w600)),
            const SizedBox(width: 4),
            Icon(on ? Icons.check_circle : Icons.circle_outlined,
                size: 13, color: on ? color : Colors.grey),
          ]),
        ),
      ),
    );
  }
}

class _PinTail extends CustomPainter {
  _PinTail(this.color);
  final Color color;
  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant _PinTail old) => old.color != color;
}
