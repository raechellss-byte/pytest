import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.conversationId, this.otherName});
  final String conversationId;
  final String? otherName;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _scroll = ScrollController();
  List<Map<String, dynamic>> _messages = [];
  StreamSubscription? _sub;

  SupabaseClient get sb => Supabase.instance.client;
  String get myId => sb.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    _sub = sb
        .from('direct_messages')
        .stream(primaryKey: ['id'])
        .eq('conversation_id', widget.conversationId)
        .order('created_at')
        .listen((rows) {
      if (mounted) {
        setState(() => _messages = List<Map<String, dynamic>>.from(rows));
        _markRead();
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scroll.hasClients) {
            _scroll.jumpTo(_scroll.position.maxScrollExtent);
          }
        });
      }
    });
    _markRead();
  }

  Future<void> _markRead() async {
    try {
      await sb.rpc('mark_messages_read',
          params: {'p_conversation_id': widget.conversationId});
    } catch (_) {/* diamkan */}
  }

  @override
  void dispose() {
    _sub?.cancel();
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    _controller.clear();
    await sb.from('direct_messages').insert({
      'conversation_id': widget.conversationId,
      'sender_id': myId,
      'content': text,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          NameAvatar(name: widget.otherName ?? '?', radius: 18),
          const SizedBox(width: 10),
          Text(widget.otherName ?? 'Chat'),
        ]),
      ),
      body: Column(children: [
        Expanded(
          child: _messages.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Text(
                        'Mulai percakapan dengan ${widget.otherName ?? 'penerjemah'}.\n'
                        'Tanyakan ketersediaan, tarif, atau detail lain sebelum memesan.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.brown.shade400)),
                  ),
                )
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.all(12),
                  itemCount: _messages.length,
                  itemBuilder: (context, i) {
                    final m = _messages[i];
                    final mine = m['sender_id'] == myId;
                    final time = DateTime.tryParse('${m['created_at']}')?.toLocal();
                    return Align(
                      alignment:
                          mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 3),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 10),
                        constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width * 0.72),
                        decoration: BoxDecoration(
                          color: mine
                              ? AppColors.primary
                              : Colors.white,
                          borderRadius: BorderRadius.only(
                            topLeft: const Radius.circular(16),
                            topRight: const Radius.circular(16),
                            bottomLeft: Radius.circular(mine ? 16 : 4),
                            bottomRight: Radius.circular(mine ? 4 : 16),
                          ),
                          border: mine
                              ? null
                              : Border.all(
                                  color: Colors.brown.withValues(alpha: 0.1)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(m['content'] ?? '',
                                style: TextStyle(
                                    color: mine ? Colors.white : AppColors.ink)),
                            if (time != null)
                              Text(DateFormat('HH:mm').format(time),
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: mine
                                          ? Colors.white70
                                          : Colors.brown.shade400)),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _controller,
                  minLines: 1,
                  maxLines: 4,
                  decoration: const InputDecoration(
                      hintText: 'Tulis pesan…',
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 14, vertical: 10)),
                  onSubmitted: (_) => _send(),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: _send, icon: const Icon(Icons.send)),
            ]),
          ),
        ),
      ]),
    );
  }
}
