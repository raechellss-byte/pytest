import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../i18n/strings.dart';
import '../../theme.dart';

/// Tab Pesan: daftar percakapan bila login, atau ajakan masuk bila belum.
class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, _) {
        final loggedIn =
            Supabase.instance.client.auth.currentSession != null;
        if (loggedIn) return const _MessagesBody();
        return Scaffold(
          body: ListView(padding: EdgeInsets.zero, children: [
            GradientHeader(
              title: tr('nav_messages'),
              subtitle: tr('login_prompt'),
              icon: Icons.chat_bubble,
            ),
            EmptyState(
                icon: Icons.forum_outlined, message: tr('login_prompt')),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: FilledButton.icon(
                onPressed: () => context.go('/login'),
                icon: const Icon(Icons.login),
                label: Text(tr('sign_in')),
              ),
            ),
          ]),
        );
      },
    );
  }
}

class _MessagesBody extends StatefulWidget {
  const _MessagesBody();

  @override
  State<_MessagesBody> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<_MessagesBody> {
  late Future<List<Map<String, dynamic>>> _future;
  Set<String> _unreadConvos = {};
  SupabaseClient get sb => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    // Percakapan yang punya pesan belum dibaca (untuk titik merah).
    try {
      final unread = await sb
          .from('direct_messages')
          .select('conversation_id')
          .eq('is_read', false)
          .neq('sender_id', sb.auth.currentUser!.id);
      _unreadConvos = {
        for (final m in (unread as List)) '${m['conversation_id']}'
      };
    } catch (_) {
      _unreadConvos = {};
    }
    final rows = await sb
        .from('conversations')
        .select('id, user_a, user_b, last_message, last_message_at, '
            'a:users!user_a(full_name), b:users!user_b(full_name)')
        .order('last_message_at', ascending: false, nullsFirst: false);
    return List<Map<String, dynamic>>.from(rows);
  }

  @override
  Widget build(BuildContext context) {
    final myId = sb.auth.currentUser!.id;
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async => setState(() => _future = _load()),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            GradientHeader(
              title: tr('nav_messages'),
              subtitle: 'Percakapan Anda dengan penerjemah',
              icon: Icons.chat_bubble,
            ),
            FutureBuilder(
              future: _future,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(40),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                final rows = snap.data ?? [];
                if (rows.isEmpty) {
                  return const EmptyState(
                    icon: Icons.forum_outlined,
                    message: 'Belum ada percakapan.\n'
                        'Buka profil penerjemah di tab Cari lalu ketuk "Chat" '
                        'untuk mulai bertanya.',
                  );
                }
                return Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
                  child: Column(
                    children: rows.map((c) {
                      final otherName = c['user_a'] == myId
                          ? (c['b']?['full_name'] ?? 'Pengguna')
                          : (c['a']?['full_name'] ?? 'Pengguna');
                      final time = DateTime.tryParse('${c['last_message_at'] ?? ''}')
                          ?.toLocal();
                      final unread = _unreadConvos.contains('${c['id']}');
                      return Card(
                        child: ListTile(
                          leading: NameAvatar(name: otherName, radius: 24),
                          title: Text(otherName,
                              style: TextStyle(
                                  fontWeight:
                                      unread ? FontWeight.w800 : FontWeight.w700)),
                          subtitle: Text(
                              c['last_message'] ?? 'Belum ada pesan',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  fontWeight: unread
                                      ? FontWeight.w700
                                      : FontWeight.normal,
                                  color: unread
                                      ? AppColors.ink
                                      : Colors.brown.shade500)),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              if (time != null)
                                Text(DateFormat('d MMM').format(time),
                                    style: TextStyle(
                                        fontSize: 11,
                                        color: Colors.brown.shade400)),
                              if (unread) ...[
                                const SizedBox(height: 4),
                                Container(
                                  width: 10, height: 10,
                                  decoration: const BoxDecoration(
                                      color: AppColors.primary,
                                      shape: BoxShape.circle),
                                ),
                              ],
                            ],
                          ),
                          onTap: () async {
                            await context.push('/pesan/${c['id']}',
                                extra: otherName);
                            if (mounted) setState(() => _future = _load());
                          },
                        ),
                      );
                    }).toList(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
