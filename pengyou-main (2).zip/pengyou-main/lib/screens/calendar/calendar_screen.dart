import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../theme.dart';
import '../documents/documents_screen.dart'
    show documentTypeLabels, documentTypeIcons;

enum _EventType { document, booking, memo }

class _Event {
  _Event({
    required this.type,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.icon,
    this.memoId,
    this.onTap,
  });
  final _EventType type;
  final String title;
  final String subtitle;
  final Color color;
  final IconData icon;
  final String? memoId;
  final VoidCallback? onTap;
}

DateTime _dayKey(DateTime d) => DateTime.utc(d.year, d.month, d.day);

/// Tab Kalender: tampilkan agenda bila login, atau ajakan masuk bila belum.
class CalendarScreen extends StatelessWidget {
  const CalendarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, _) {
        final loggedIn =
            Supabase.instance.client.auth.currentSession != null;
        if (loggedIn) return const _CalendarBody();
        return Scaffold(
          body: ListView(padding: EdgeInsets.zero, children: [
            const GradientHeader(
              title: 'Kalender',
              subtitle: 'Agenda dokumen, jadwal & memo Anda',
              icon: Icons.calendar_month,
            ),
            const EmptyState(
              icon: Icons.event_note,
              message:
                  'Masuk untuk melihat kalender masa berlaku dokumen, jadwal '
                  'kontrol, dan menambah memo pribadi Anda.',
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: FilledButton.icon(
                onPressed: () => context.go('/login'),
                icon: const Icon(Icons.login),
                label: const Text('Masuk'),
              ),
            ),
          ]),
        );
      },
    );
  }
}

class _CalendarBody extends StatefulWidget {
  const _CalendarBody();

  @override
  State<_CalendarBody> createState() => _CalendarBodyState();
}

class _CalendarBodyState extends State<_CalendarBody> {
  final Map<DateTime, List<_Event>> _events = {};
  DateTime _focusedDay = DateTime.now();
  DateTime _selectedDay = DateTime.now();
  CalendarFormat _format = CalendarFormat.month;
  bool _loading = true;

  SupabaseClient get sb => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    _events.clear();
    final uid = sb.auth.currentUser!.id;

    void add(DateTime day, _Event e) {
      _events.putIfAbsent(_dayKey(day), () => []).add(e);
    }

    // Dokumen (masa berlaku)
    final docs = await sb
        .from('documents')
        .select()
        .eq('is_renewed', false);
    for (final d in List<Map<String, dynamic>>.from(docs)) {
      final expiry = DateTime.tryParse('${d['expiry_date']}');
      if (expiry == null) continue;
      final label = documentTypeLabels[d['document_type']] ?? d['document_type'];
      add(expiry, _Event(
        type: _EventType.document,
        title: '$label kedaluwarsa',
        subtitle: 'Masa berlaku berakhir. Segera perpanjang bila perlu.',
        color: const Color(0xFFC0392B),
        icon: documentTypeIcons[d['document_type']] ?? Icons.description,
        onTap: () => context.push('/dokumen'),
      ));
    }

    // Pesanan / jadwal
    final bookings = await sb
        .from('bookings')
        .select('id, status, scheduled_at, service_categories(name_id, slug), '
            'interpreter_profiles(users(full_name))')
        .neq('status', 'cancelled');
    for (final b in List<Map<String, dynamic>>.from(bookings)) {
      final dt = DateTime.tryParse('${b['scheduled_at']}')?.toLocal();
      if (dt == null) continue;
      final slug = b['service_categories']?['slug'];
      final cat = b['service_categories']?['name_id'] ?? 'Pendampingan';
      final withName =
          (b['interpreter_profiles']?['users'])?['full_name'] ?? 'penerjemah';
      final isMedical = slug == 'medis';
      add(dt, _Event(
        type: _EventType.booking,
        title: isMedical ? 'Kontrol dokter' : cat,
        subtitle: '${DateFormat('HH:mm').format(dt)} · bersama $withName',
        color: const Color(0xFF148F77),
        icon: isMedical ? Icons.medical_services : Icons.event_available,
        onTap: () => context.push('/pesanan/${b['id']}'),
      ));
    }

    // Memo pribadi
    final notes = await sb
        .from('calendar_notes')
        .select()
        .eq('user_id', uid);
    for (final n in List<Map<String, dynamic>>.from(notes)) {
      final dt = DateTime.tryParse('${n['event_date']}');
      if (dt == null) continue;
      add(dt, _Event(
        type: _EventType.memo,
        title: n['title'] ?? 'Memo',
        subtitle: (n['note'] ?? '').toString(),
        color: const Color(0xFF8E44AD),
        icon: Icons.push_pin,
        memoId: n['id'],
      ));
    }

    if (mounted) setState(() => _loading = false);
  }

  List<_Event> _eventsFor(DateTime day) => _events[_dayKey(day)] ?? [];

  Future<void> _addMemo() async {
    final titleCtrl = TextEditingController();
    final noteCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Memo · ${DateFormat('d MMM y').format(_selectedDay)}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
            controller: titleCtrl,
            decoration: const InputDecoration(
                labelText: 'Judul', hintText: 'mis. Cek kesehatan bulanan'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: noteCtrl,
            decoration: const InputDecoration(labelText: 'Catatan (opsional)'),
            maxLines: 3,
          ),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Simpan')),
        ],
      ),
    );
    if (ok != true || titleCtrl.text.trim().isEmpty) return;
    await sb.from('calendar_notes').insert({
      'user_id': sb.auth.currentUser!.id,
      'title': titleCtrl.text.trim(),
      'note': noteCtrl.text.trim().isEmpty ? null : noteCtrl.text.trim(),
      'event_date': DateFormat('yyyy-MM-dd').format(_selectedDay),
    });
    await _load();
  }

  Future<void> _deleteMemo(String id) async {
    await sb.from('calendar_notes').delete().eq('id', id);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final dayEvents = _eventsFor(_selectedDay);
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addMemo,
        icon: const Icon(Icons.add),
        label: const Text('Memo'),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const GradientHeader(
              title: 'Kalender',
              subtitle: 'Agenda dokumen, jadwal & memo Anda',
              icon: Icons.calendar_month,
            ),
            Card(
              margin: const EdgeInsets.all(12),
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: TableCalendar<_Event>(
                  locale: 'id_ID',
                  firstDay: DateTime.utc(2020),
                  lastDay: DateTime.utc(2035, 12, 31),
                  focusedDay: _focusedDay,
                  calendarFormat: _format,
                  availableCalendarFormats: const {
                    CalendarFormat.month: 'Bulan',
                    CalendarFormat.twoWeeks: '2 Minggu',
                    CalendarFormat.week: 'Minggu',
                  },
                  selectedDayPredicate: (d) => isSameDay(d, _selectedDay),
                  eventLoader: _eventsFor,
                  startingDayOfWeek: StartingDayOfWeek.monday,
                  onDaySelected: (sel, foc) => setState(() {
                    _selectedDay = sel;
                    _focusedDay = foc;
                  }),
                  onFormatChanged: (f) => setState(() => _format = f),
                  onPageChanged: (foc) => _focusedDay = foc,
                  calendarStyle: CalendarStyle(
                    todayDecoration: BoxDecoration(
                      color: AppColors.accent.withValues(alpha: 0.5),
                      shape: BoxShape.circle,
                    ),
                    selectedDecoration: const BoxDecoration(
                      color: AppColors.primary,
                      shape: BoxShape.circle,
                    ),
                    markerDecoration: const BoxDecoration(
                      color: Color(0xFF8E44AD),
                      shape: BoxShape.circle,
                    ),
                    markersMaxCount: 3,
                  ),
                  headerStyle: const HeaderStyle(
                    formatButtonShowsNext: false,
                    titleCentered: true,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: Row(children: [
                const Icon(Icons.event, size: 20, color: AppColors.primary),
                const SizedBox(width: 6),
                Text(DateFormat('EEEE, d MMMM y', 'id_ID').format(_selectedDay),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
              ]),
            ),
            if (_loading)
              const Padding(
                padding: EdgeInsets.all(32),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (dayEvents.isEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                child: Text('Tidak ada agenda di tanggal ini.',
                    style: TextStyle(color: Colors.brown.shade500)),
              )
            else
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 88),
                child: Column(
                  children: dayEvents.map((e) => Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: e.color.withValues(alpha: 0.14),
                            child: Icon(e.icon, color: e.color, size: 20),
                          ),
                          title: Text(e.title,
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: e.subtitle.isEmpty ? null : Text(e.subtitle),
                          trailing: e.type == _EventType.memo
                              ? IconButton(
                                  icon: const Icon(Icons.delete_outline),
                                  onPressed: () => _deleteMemo(e.memoId!),
                                )
                              : const Icon(Icons.chevron_right),
                          onTap: e.onTap,
                        ),
                      )).toList(),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
