import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../i18n/strings.dart';
import '../../theme.dart';
import '../documents/documents_screen.dart'
    show documentTypeLabels, documentTypeIcons;

enum _Kind { document, booking, memo }

class _Item {
  _Item({
    required this.kind,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.daysLeft,
    required this.sortDate,
    this.onTap,
  });
  final _Kind kind;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final int daysLeft; // negatif = sudah lewat
  final DateTime sortDate;
  final VoidCallback? onTap;

  String get countdown {
    if (daysLeft < 0) return 'Lewat ${-daysLeft} hari';
    if (daysLeft == 0) return 'HARI INI';
    if (daysLeft == 1) return 'Besok';
    return '$daysLeft hari lagi';
  }
}

/// Tab Notifikasi: pengingat bila login, atau ajakan masuk bila belum.
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, _) {
        final loggedIn =
            Supabase.instance.client.auth.currentSession != null;
        if (loggedIn) return const _NotificationsBody();
        return Scaffold(
          body: ListView(padding: EdgeInsets.zero, children: [
            GradientHeader(
              title: tr('notif_title'),
              subtitle: tr('notif_login'),
              icon: Icons.notifications,
              showBack: true,
            ),
            EmptyState(
              icon: Icons.notifications_none,
              message: tr('notif_login'),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: FilledButton.icon(
                onPressed: () => context.go('/login'),
                icon: const Icon(Icons.login),
                label: const Text('Masuk'),
              ),
            ),
          ]),
        );
      },
    );
  }
}

class _NotificationsBody extends StatefulWidget {
  const _NotificationsBody();

  @override
  State<_NotificationsBody> createState() => _NotificationsBodyState();
}

class _NotificationsBodyState extends State<_NotificationsBody> {
  late Future<List<_Item>> _future;
  SupabaseClient get sb => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  (String, Color) _docUrgency(int days) {
    if (days < 0) return ('KEDALUWARSA', const Color(0xFFDC2626));
    if (days <= 7) return ('SEGERA', const Color(0xFFDC2626));
    if (days <= 30) return ('PERHATIAN', const Color(0xFFEA580C));
    return ('AMAN', const Color(0xFF16A34A));
  }

  Future<List<_Item>> _load() async {
    final items = <_Item>[];
    final today = DateTime.now();
    final t0 = DateTime(today.year, today.month, today.day);

    // Dokumen
    final docs =
        await sb.from('documents').select().eq('is_renewed', false);
    for (final d in List<Map<String, dynamic>>.from(docs)) {
      final expiry = DateTime.tryParse('${d['expiry_date']}');
      if (expiry == null) continue;
      final days = expiry.difference(t0).inDays;
      if (days > 60) continue; // hanya yang relevan
      final label = documentTypeLabels[d['document_type']] ?? d['document_type'];
      final (_, color) = _docUrgency(days);
      items.add(_Item(
        kind: _Kind.document,
        title: label,
        subtitle: 'Berlaku s/d ${DateFormat('d MMM y').format(expiry)}',
        icon: documentTypeIcons[d['document_type']] ?? Icons.description,
        color: color,
        daysLeft: days,
        sortDate: expiry,
        onTap: () => context.push('/dokumen'),
      ));
    }

    // Pesanan mendatang
    final bookings = await sb
        .from('bookings')
        .select('id, status, scheduled_at, service_categories(name_id, slug), '
            'interpreter_profiles(users(full_name))')
        .gte('scheduled_at', today.toUtc().toIso8601String())
        .neq('status', 'cancelled')
        .order('scheduled_at')
        .limit(20);
    for (final b in List<Map<String, dynamic>>.from(bookings)) {
      final dt = DateTime.tryParse('${b['scheduled_at']}')?.toLocal();
      if (dt == null) continue;
      final days = DateTime(dt.year, dt.month, dt.day).difference(t0).inDays;
      final slug = b['service_categories']?['slug'];
      final cat = b['service_categories']?['name_id'] ?? 'Pendampingan';
      final withName =
          (b['interpreter_profiles']?['users'])?['full_name'] ?? 'penerjemah';
      final medical = slug == 'medis';
      items.add(_Item(
        kind: _Kind.booking,
        title: medical ? 'Kontrol dokter' : cat,
        subtitle: '${DateFormat('EEE, d MMM • HH:mm', 'id_ID').format(dt)} · $withName',
        icon: medical ? Icons.medical_services : Icons.event_available,
        color: const Color(0xFF0E9C8B),
        daysLeft: days,
        sortDate: dt,
        onTap: () => context.push('/pesanan/${b['id']}'),
      ));
    }

    // Memo kalender mendatang
    try {
      final notes = await sb
          .from('calendar_notes')
          .select()
          .gte('event_date', DateFormat('yyyy-MM-dd').format(t0))
          .order('event_date')
          .limit(20);
      for (final n in List<Map<String, dynamic>>.from(notes)) {
        final dt = DateTime.tryParse('${n['event_date']}');
        if (dt == null) continue;
        final days = dt.difference(t0).inDays;
        if (days > 30) continue;
        items.add(_Item(
          kind: _Kind.memo,
          title: n['title'] ?? 'Memo',
          subtitle: (n['note'] ?? 'Pengingat pribadi').toString(),
          icon: Icons.push_pin,
          color: const Color(0xFF7C3AED),
          daysLeft: days,
          sortDate: dt,
        ));
      }
    } catch (_) {/* tabel memo mungkin belum ada */}

    items.sort((a, b) => a.sortDate.compareTo(b.sortDate));
    return items;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async => setState(() => _future = _load()),
        child: FutureBuilder(
          future: _future,
          builder: (context, snap) {
            final items = snap.data ?? [];
            final docs = items.where((i) => i.kind == _Kind.document).toList();
            final agenda =
                items.where((i) => i.kind != _Kind.document).toList();
            // Item paling mendesak (dokumen) untuk kartu hero.
            final urgent = docs.where((d) => d.daysLeft <= 30).toList();
            final hero = urgent.isEmpty ? null : urgent.first;
            final urgentCount = docs.where((d) => d.daysLeft <= 30).length;

            return ListView(
              padding: EdgeInsets.zero,
              children: [
                GradientHeader(
                  title: tr('notif_title'),
                  subtitle: urgentCount > 0
                      ? '$urgentCount ${tr('notif_docs').replaceAll('🪪 ', '').toLowerCase()}'
                      : tr('notif_ok'),
                  icon: Icons.notifications_active,
                  showBack: true,
                ),
                if (snap.connectionState == ConnectionState.waiting)
                  const Padding(
                    padding: EdgeInsets.all(48),
                    child: Center(child: CircularProgressIndicator()),
                  )
                else if (items.isEmpty)
                  const EmptyState(
                    icon: Icons.check_circle_outline,
                    message: 'Tidak ada pengingat saat ini. 🎉\n\n'
                        'Daftarkan dokumen (ARC, asuransi) di menu Dokumen agar '
                        'kami ingatkan sebelum kedaluwarsa.',
                  )
                else ...[
                  if (hero != null) _HeroCard(item: hero, urgency: _docUrgency),
                  if (docs.isNotEmpty)
                    _section(context, tr('notif_docs'), docs
                        .map((d) => _DocCard(item: d, urgency: _docUrgency))
                        .toList()),
                  if (agenda.isNotEmpty)
                    _section(context, tr('notif_agenda'),
                        agenda.map((a) => _AgendaCard(item: a)).toList()),
                  const SizedBox(height: 24),
                ],
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _section(BuildContext context, String title, List<Widget> children) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 16, 6),
        child: Text(title,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w800)),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Column(children: children),
      ),
    ]);
  }
}

/// Kartu besar untuk pengingat paling mendesak.
class _HeroCard extends StatelessWidget {
  const _HeroCard({required this.item, required this.urgency});
  final _Item item;
  final (String, Color) Function(int) urgency;

  @override
  Widget build(BuildContext context) {
    final (label, color) = urgency(item.daysLeft);
    final darker = Color.lerp(color, Colors.black, 0.25)!;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color, darker],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
              color: color.withValues(alpha: 0.35),
              blurRadius: 16,
              offset: const Offset(0, 6)),
        ],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(14)),
            child: Icon(item.icon, color: Colors.white, size: 26),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label,
                  style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.9),
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1)),
              Text(item.title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w800)),
            ]),
          ),
        ]),
        const SizedBox(height: 14),
        Row(children: [
          const Icon(Icons.timelapse, color: Colors.white, size: 18),
          const SizedBox(width: 6),
          Text(
              item.daysLeft < 0
                  ? 'Sudah kedaluwarsa ${-item.daysLeft} hari lalu'
                  : item.daysLeft == 0
                      ? 'Kedaluwarsa HARI INI'
                      : 'Tinggal ${item.daysLeft} hari lagi',
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 15)),
        ]),
        const SizedBox(height: 4),
        Text(item.subtitle,
            style: TextStyle(color: Colors.white.withValues(alpha: 0.85))),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: item.onTap,
            icon: const Icon(Icons.autorenew),
            label: const Text('Perbarui / Kelola Dokumen'),
            style: FilledButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: darker,
            ),
          ),
        ),
      ]),
    );
  }
}

/// Kartu dokumen dengan pil hitung mundur + bar urgensi.
class _DocCard extends StatelessWidget {
  const _DocCard({required this.item, required this.urgency});
  final _Item item;
  final (String, Color) Function(int) urgency;

  @override
  Widget build(BuildContext context) {
    final (_, color) = urgency(item.daysLeft);
    // Progress: makin dekat kedaluwarsa makin penuh (jendela 60 hari).
    final progress = item.daysLeft < 0
        ? 1.0
        : (1 - (item.daysLeft / 60)).clamp(0.05, 1.0);
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: item.onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(
              width: 48, height: 48,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.14),
                  shape: BoxShape.circle),
              child: Icon(item.icon, color: color),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.title,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 14.5)),
                  const SizedBox(height: 2),
                  Text(item.subtitle,
                      style: TextStyle(
                          fontSize: 12, color: Colors.brown.shade500)),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: progress.toDouble(),
                      minHeight: 5,
                      backgroundColor: color.withValues(alpha: 0.12),
                      valueColor: AlwaysStoppedAnimation(color),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            _CountdownPill(text: item.countdown, color: color),
          ]),
        ),
      ),
    );
  }
}

class _AgendaCard extends StatelessWidget {
  const _AgendaCard({required this.item});
  final _Item item;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: item.onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(
              width: 46, height: 46,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: item.color.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(14)),
              child: Icon(item.icon, color: item.color, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.title,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 14.5)),
                  const SizedBox(height: 2),
                  Text(item.subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 12, color: Colors.brown.shade500)),
                ],
              ),
            ),
            const SizedBox(width: 10),
            _CountdownPill(text: item.countdown, color: item.color),
          ]),
        ),
      ),
    );
  }
}

class _CountdownPill extends StatelessWidget {
  const _CountdownPill({required this.text, required this.color});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(text,
          style: TextStyle(
              fontSize: 11.5, fontWeight: FontWeight.w800, color: color)),
    );
  }
}
