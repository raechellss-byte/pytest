import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../config.dart';
import '../../i18n/strings.dart';
import '../../services/exchange_rate.dart';
import '../../services/push_service.dart';
import '../../services/weather.dart';
import '../../theme.dart';
import '../auth/login_screen.dart' show nextQuery;
import '../documents/documents_screen.dart' show documentTypeLabels;
import 'news_hot.dart';

/// Konten cadangan bila tabel `news` belum dibuat / kosong / gagal dimuat.
const _fallbackNews = <Map<String, dynamic>>[
  {
    'title': 'Jangan sampai ARC Anda kedaluwarsa',
    'summary':
        'ARC/izin kerja yang lewat tanggal bisa membuat Anda kehilangan asuransi '
        'kesehatan (NHI) dan berisiko jadi tidak berdokumen. Daftarkan dokumen Anda '
        'agar diingatkan 30, 14, dan 7 hari sebelumnya.',
    'category': 'Dokumen',
    'emoji': '🪪',
    'source_name': 'Info Komunitas',
    'is_featured': true,
  },
  {
    'title': 'Hotline 1955 — bantuan bahasa Indonesia 24 jam',
    'summary':
        'Pemerintah Taiwan menyediakan hotline 1955 gratis, 24 jam, dengan layanan '
        'interpretasi bahasa Indonesia lewat telepon.',
    'category': 'Layanan',
    'emoji': '📞',
    'source_name': 'Info Komunitas',
    'is_featured': true,
  },
  {
    'title': 'Pastikan kartu NHI Anda aktif',
    'summary':
        'Kartu National Health Insurance (NHI) membuat biaya berobat jauh lebih '
        'murah. Kartu ini terkait status izin tinggal — jaga agar ARC tetap berlaku.',
    'category': 'Kesehatan',
    'emoji': '🏥',
    'source_name': 'Info Komunitas',
    'is_featured': true,
  },
  {
    'title': 'Butuh pendamping ke rumah sakit?',
    'summary':
        'Banyak pekerja migran yang sakit tidak berobat karena tak ada pendamping '
        'bahasa. Cari penerjemah terdekat lewat tab Cari.',
    'category': 'Kesehatan',
    'emoji': '🤝',
    'source_name': 'Info Komunitas',
    'is_featured': false,
  },
];

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Map<String, dynamic>>> _future;
  ExchangeRate? _rate;
  Weather? _weather;
  int _urgentCount = 0;
  Map<String, dynamic>? _urgentDoc;
  bool _pushAsk = false; // tampilkan tombol "Aktifkan notifikasi"
  bool _newsErr = false; // berita gagal dimuat (pakai fallback)

  @override
  void initState() {
    super.initState();
    _future = _loadNews();
    _loadRate();
    _loadWeather();
    _loadUrgentCount();
    _checkPush();
  }

  Future<void> _checkPush() async {
    final need = await PushService.needsEnable();
    if (mounted) setState(() => _pushAsk = need);
  }

  /// Kartu ajakan mengaktifkan notifikasi (muncul kalau izin belum diberikan).
  Widget _pushPrompt() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: DuoCard(
        color: AppColors.blueSoft,
        borderColor: AppColors.blueInk.withValues(alpha: 0.25),
        lipColor: AppColors.blueInk.withValues(alpha: 0.2),
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.notifications_active_outlined,
                color: AppColors.blueInk,
              ),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Aktifkan notifikasi biar diingatkan saat dokumen mau habis & ada kabar penting.',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  height: 1.35,
                  color: AppColors.ink,
                ),
              ),
            ),
            const SizedBox(width: 10),
            DuoButton(
              label: 'Aktifkan',
              compact: true,
              backgroundColor: AppColors.blueInk,
              lipColor: const Color(0xFF123E6B),
              onPressed: () async {
                final ok = await PushService.enable();
                if (!mounted) return;
                setState(() => _pushAsk = !ok);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      ok
                          ? 'Notifikasi aktif ✓'
                          : 'Izin notifikasi belum diberikan',
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  /// Catatan kecil saat data gagal dimuat (mis. offline).
  Widget _offlineNote(String msg) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
          decoration: BoxDecoration(
            color: AppColors.amberSoft,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppColors.accent.withValues(alpha: 0.45),
              width: 1.5,
            ),
          ),
          child: Row(
            children: [
              const Icon(Icons.wifi_off_rounded,
                  size: 18, color: AppColors.amberInk),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  msg,
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.amberInk,
                  ),
                ),
              ),
            ],
          ),
        ),
      );

  /// Dokumen mendesak (≤30 hari) untuk badge lonceng + banner pengingat.
  Future<void> _loadUrgentCount() async {
    if (Supabase.instance.client.auth.currentSession == null) return;
    try {
      final soon = DateTime.now().add(const Duration(days: 30));
      final rows = await Supabase.instance.client
          .from('documents')
          .select('document_type, expiry_date, is_renewed')
          .eq('is_renewed', false)
          .lte('expiry_date', soon.toIso8601String())
          .order('expiry_date');
      final list = List<Map<String, dynamic>>.from(rows);
      if (mounted) {
        setState(() {
          _urgentCount = list.length;
          _urgentDoc = list.isNotEmpty ? list.first : null;
        });
      }
    } catch (_) {}
  }

  Future<void> _loadRate() async {
    final r = await ExchangeRateService.fetch();
    if (mounted) setState(() => _rate = r);
  }

  Future<void> _loadWeather() async {
    final (lat, lng) = AppConfig.cities['Taichung']!;
    final w = await WeatherService.fetch(lat, lng);
    if (mounted) setState(() => _weather = w);
  }

  Future<List<Map<String, dynamic>>> _loadNews() async {
    try {
      final rows = await Supabase.instance.client
          .from('news')
          .select()
          .eq('is_active', true)
          .order('published_at', ascending: false)
          .limit(60);
      final list = List<Map<String, dynamic>>.from(rows);
      if (mounted) setState(() => _newsErr = false);
      return list.isEmpty ? _fallbackNews : list;
    } catch (_) {
      if (mounted) setState(() => _newsErr = true);
      return _fallbackNews;
    }
  }

  String get _greetingName {
    final meta = Supabase.instance.client.auth.currentUser?.userMetadata;
    final name = meta?['full_name'] as String?;
    if (name != null && name.trim().isNotEmpty) return name.split(' ').first;
    return 'Sahabat';
  }

  bool get _isLoggedIn => Supabase.instance.client.auth.currentSession != null;

  void _requireLoginThen(String route) {
    if (_isLoggedIn) {
      context.push(route);
    } else {
      context.go('/login${nextQuery(route)}');
    }
  }

  String _summaryTitle(String? kind) => switch (kind) {
        'day' => tr('hot_today'),
        'week' => tr('hot_week'),
        'month' => tr('hot_month'),
        _ => 'Hot',
      };

  void _onBannerOpen(Map<String, dynamic> n) => _openNews(
        n['__summary'] != null
            ? Map<String, dynamic>.from(n['article'] as Map)
            : n,
      );

  void _onBannerMore(Map<String, dynamic> n) {
    if (n['__summary'] != null) {
      final title = _summaryTitle(n['__summary'] as String?);
      _openNewsList(title, List<Map<String, dynamic>>.from(n['items'] ?? []));
    } else {
      _openNews(n);
    }
  }

  void _openNewsList(String title, List<Map<String, dynamic>> items) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.7,
        maxChildSize: 0.92,
        minChildSize: 0.4,
        builder: (_, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 12),
              child: Row(
                children: [
                  const Text('🔥', style: TextStyle(fontSize: 22)),
                  const SizedBox(width: 8),
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            ...items.map(
              (n) => _NewsCard(
                data: n,
                onTap: () {
                  Navigator.pop(context);
                  _openNews(n);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openNews(Map<String, dynamic> n) {
    final body = (n['body'] ?? '').toString().trim();
    final summary = (n['summary'] ?? '').toString().trim();
    final published =
        DateTime.tryParse('${n['published_at'] ?? ''}')?.toLocal();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.65,
        maxChildSize: 0.92,
        minChildSize: 0.4,
        builder: (_, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 32),
          children: [
            if (n['image_url'] != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Image.network(
                  n['image_url'],
                  height: 190,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
            const SizedBox(height: 12),
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    '${n['emoji'] ?? '📰'}  ${n['category'] ?? 'Info'}',
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 12,
                      color: AppColors.primaryDark,
                    ),
                  ),
                ),
                const Spacer(),
                if (published != null)
                  Text(
                    DateFormat('d MMM y').format(published),
                    style:
                        const TextStyle(color: AppColors.muted, fontSize: 12),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              n['title'] ?? '',
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w900,
                height: 1.28,
              ),
            ),
            const SizedBox(height: 16),
            if (summary.isNotEmpty)
              Text(
                summary,
                style: TextStyle(
                  fontSize: 16,
                  height: 1.6,
                  fontWeight:
                      body.isNotEmpty ? FontWeight.w700 : FontWeight.normal,
                ),
              ),
            if (body.isNotEmpty && body != summary) ...[
              const SizedBox(height: 12),
              Text(body, style: const TextStyle(fontSize: 16, height: 1.6)),
            ],
            if (summary.isEmpty && body.isEmpty)
              const Text(
                'Belum ada keterangan tambahan untuk kabar ini.',
                style: TextStyle(
                  fontSize: 15,
                  color: AppColors.muted,
                  fontStyle: FontStyle.italic,
                ),
              ),
            if (n['source_name'] != null) ...[
              const SizedBox(height: 20),
              Text(
                'Sumber: ${n['source_name']}',
                style: const TextStyle(
                  color: AppColors.muted,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
            if ((n['source_url'] ?? '').toString().isNotEmpty) ...[
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: () async {
                  final uri = Uri.tryParse(n['source_url']);
                  if (uri != null) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
                icon: const Icon(Icons.open_in_new_rounded),
                label: Text(tr('read_source')),
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isDesktop = width >= AppBreakpoints.mobileMax;
    final isTwoColDesktop = width >= 1020;

    return Scaffold(
      backgroundColor: AppColors.surfaceTint,
      body: RefreshIndicator(
        onRefresh: () async {
          setState(() => _future = _loadNews());
          await _loadRate();
          await _loadWeather();
          await _loadUrgentCount();
        },
        child: ListView(
          padding: EdgeInsets.fromLTRB(
            isDesktop ? 28 : 16,
            isDesktop ? 24 : 0,
            isDesktop ? 28 : 16,
            32,
          ),
          children: [
            // Top bar khusus Mobile (karena di Desktop sudah ada Sidebar kiri)
            if (!isDesktop)
              SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.only(top: 10, bottom: 12),
                  child: _MobileTopBar(
                    urgentCount: _urgentCount,
                    onBell: () => context.push('/notifikasi'),
                    onSos: () => context.push('/darurat'),
                  ),
                ),
              ),

            if (isTwoColDesktop)
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 7,
                    child: _buildMainContent(context, isDesktop: true),
                  ),
                  const SizedBox(width: 24),
                  Expanded(
                    flex: 4,
                    child: _buildSideWidgets(context),
                  ),
                ],
              )
            else
              _buildMainContent(context, isDesktop: isDesktop, includeWidgets: true),
          ],
        ),
      ),
    );
  }

  /// Kolom utama Beranda (Hero, Unggulan Belajar & Sehat, Bento Grid 6 Fitur, Berita).
  Widget _buildMainContent(
    BuildContext context, {
    required bool isDesktop,
    bool includeWidgets = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // 1. Hero Sambutan & Status Pengguna
        _HeroWelcomeCard(
          name: _greetingName,
          isLoggedIn: _isLoggedIn,
          isDesktop: isDesktop,
          urgentCount: _urgentCount,
          onBell: () => context.push('/notifikasi'),
        ),
        const SizedBox(height: 16),

        // Jika layar 1 kolom (Mobile / Tablet), tampilkan Kurs NTD & Cuaca tepat di bawah Hero
        if (includeWidgets) ...[
          _RateAndWeatherCompact(
            rate: _rate,
            weather: _weather,
            onSos: () => context.push('/darurat'),
          ),
          const SizedBox(height: 16),
        ],

        // Pengingat dokumen mendesak (ARC/paspor/kontrak)
        if (_urgentDoc != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: _DocExpiryReminder(
              doc: _urgentDoc!,
              extra: _urgentCount - 1,
              onTap: () => _requireLoginThen('/dokumen'),
            ),
          ),
        if (_pushAsk) _pushPrompt(),
        if (_newsErr)
          _offlineNote(
            'Gagal memuat berita terbaru — menampilkan info penting.',
          ),

        // 2. Jalur Unggulan (Terinspirasi Duolingo & Brilliant.org)
        const _SectionHeader(
          eyebrow: 'JALUR INTERAKTIF',
          title: 'Belajar Bahasa & Kesehatan di Taiwan',
          icon: Icons.auto_awesome_rounded,
          iconColor: AppColors.primary,
        ),
        const SizedBox(height: 10),
        LayoutBuilder(
          builder: (context, constraints) {
            final sideBySide = constraints.maxWidth >= 540;
            final liuliCard = _FeaturedPathCard(
              tag: 'MANDARIN TAIWAN · TOCFL',
              tagBg: AppColors.greenSoft,
              tagFg: AppColors.greenInk,
              title: 'Belajar Mandarin (Liúlì)',
              subtitle:
                  'Kosakata sehari-hari, latihan nada, tulis Hanzi & kuis interaktif ala Duolingo.',
              ctaLabel: 'Mulai Belajar',
              watermark: '學',
              accentColor: const Color(0xFF1F7A4D),
              lipColor: const Color(0xFF145233),
              bgColor: Colors.white,
              icon: Icons.translate_rounded,
              onTap: () => context.push('/belajar'),
            );
            final sehatCard = _FeaturedPathCard(
              tag: 'KLINIK NHI · TERJEMAH MEDIS',
              tagBg: AppColors.tealSoft,
              tagFg: AppColors.tealInk,
              title: 'Sehat Rantau & NHI',
              subtitle:
                  'Cari klinik & RS ber-NHI sesuai keluhan + terjemah gejala langsung ke dokter.',
              ctaLabel: 'Cari Klinik NHI',
              watermark: '醫',
              accentColor: AppColors.primary,
              lipColor: AppColors.primaryDark,
              bgColor: Colors.white,
              icon: Icons.local_hospital_rounded,
              onTap: () => context.push('/sehat'),
            );

            if (sideBySide) {
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: liuliCard),
                  const SizedBox(width: 14),
                  Expanded(child: sehatCard),
                ],
              );
            }
            return Column(
              children: [
                liuliCard,
                const SizedBox(height: 12),
                sehatCard,
              ],
            );
          },
        ),
        const SizedBox(height: 22),

        // 3. Bento Grid — 6 Layanan Utama (Rapi, Seimbang, Tanpa Ruang Kosong)
        const _SectionHeader(
          eyebrow: 'SATU PINTU',
          title: 'Layanan & Pendampingan',
          icon: Icons.grid_view_rounded,
          iconColor: AppColors.accentDark,
        ),
        const SizedBox(height: 10),
        _BentoServicesGrid(
          onFindInterpreter: () => context.go('/cari'),
          onOpenMap: () => context.go('/cari/peta'),
          onDocuments: () => _requireLoginThen('/dokumen'),
          onOrders: () => _requireLoginThen('/pesanan'),
          onEmergency: () => context.push('/darurat'),
          onHelp: () => context.push('/bantuan'),
        ),
        const SizedBox(height: 24),

        // 4. Sorotan Berita Terpanas (Carousel)
        FutureBuilder(
          future: _future,
          builder: (context, snap) {
            final banners =
                buildBanners(snap.data ?? _fallbackNews, DateTime.now());
            if (banners.isEmpty) return const SizedBox.shrink();
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _SectionHeader(
                  eyebrow: 'SOROTAN UTAMA',
                  title: tr('news_title'),
                  icon: Icons.local_fire_department_rounded,
                  iconColor: AppColors.coral,
                ),
                const SizedBox(height: 10),
                _NewsBanner(
                  items: banners,
                  onOpen: _onBannerOpen,
                  onMore: _onBannerMore,
                ),
                const SizedBox(height: 20),
              ],
            );
          },
        ),

        // 5. Daftar Kabar & Info Terbaru
        const _SectionHeader(
          eyebrow: 'INFO KOMUNITAS',
          title: 'Kabar Terbaru untuk Kamu',
          icon: Icons.newspaper_rounded,
          iconColor: AppColors.primary,
        ),
        const SizedBox(height: 10),
        FutureBuilder(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Padding(
                padding: EdgeInsets.all(40),
                child: Center(child: CircularProgressIndicator()),
              );
            }
            final items = [
              for (final s in clusterStories(snap.data ?? _fallbackNews))
                s.article,
            ].take(10).toList();
            return Column(
              children: items
                  .map(
                    (n) => _NewsCard(
                      data: n,
                      onTap: () => _openNews(n),
                    ),
                  )
                  .toList(),
            );
          },
        ),
      ],
    );
  }

  /// Kolom Kanan khusus Desktop Lebar (>= 1020px) ala Duolingo / Brilliant.org.
  Widget _buildSideWidgets(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // 1. Kartu Kurs NTD → Rupiah (identik dengan .s-card--rate di webcontoh)
        _RateSparklineCard(rate: _rate),
        const SizedBox(height: 16),

        // 2. Kartu Cuaca & Info Kota
        _WeatherDesktopCard(weather: _weather),
        const SizedBox(height: 16),

        // 3. Kartu Darurat & Hotline 1955
        _EmergencyDesktopCard(onTap: () => context.push('/darurat')),
        const SizedBox(height: 16),

        // 4. Kartu Pengingat Dokumen Ringkas
        _DocsQuickSummaryCard(
          urgentCount: _urgentCount,
          isLoggedIn: _isLoggedIn,
          onTap: () => _requireLoginThen('/dokumen'),
        ),
      ],
    );
  }
}

/// Top Navbar untuk layar Mobile (< 840px) — menampilkan Logo `朋 PENGYOU`,
/// pemilih bahasa `ID/EN/中文`, lonceng notifikasi, dan tombol cepat SOS.
class _MobileTopBar extends StatelessWidget {
  const _MobileTopBar({
    required this.urgentCount,
    required this.onBell,
    required this.onSos,
  });

  final int urgentCount;
  final VoidCallback onBell;
  final VoidCallback onSos;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Expanded(
          child: PengyouLogo(size: 36),
        ),
        const LangPillSwitcher(),
        const SizedBox(width: 8),
        // Tombol Lonceng Notifikasi
        _BellButton(urgentCount: urgentCount, onTap: onBell),
        const SizedBox(width: 8),
        // Tombol Darurat SOS Ringkas
        Material(
          color: AppColors.roseSoft,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: onSos,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppColors.danger.withValues(alpha: 0.3),
                  width: 1.5,
                ),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.sos_rounded, color: AppColors.danger, size: 18),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _BellButton extends StatelessWidget {
  const _BellButton({
    required this.urgentCount,
    required this.onTap,
    this.onDark = false,
  });

  final int urgentCount;
  final VoidCallback onTap;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
              color: onDark
                  ? Colors.white.withValues(alpha: 0.16)
                  : Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: onDark
                    ? Colors.white.withValues(alpha: 0.25)
                    : AppColors.line,
                width: 2,
              ),
            ),
            child: Icon(
              Icons.notifications_none_rounded,
              color: onDark ? Colors.white : AppColors.ink,
              size: 21,
            ),
          ),
          if (urgentCount > 0)
            Positioned(
              right: -4,
              top: -4,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                decoration: const BoxDecoration(
                  color: AppColors.accent,
                  shape: BoxShape.circle,
                ),
                child: Text(
                  '$urgentCount',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.ink,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Kartu Hero Sambutan di bagian atas Beranda — menyatukan nuansa `webcontoh`
/// ("朋友 · artinya teman") dengan CTA yang jelas.
class _HeroWelcomeCard extends StatelessWidget {
  const _HeroWelcomeCard({
    required this.name,
    required this.isLoggedIn,
    required this.isDesktop,
    required this.urgentCount,
    required this.onBell,
  });

  final String name;
  final bool isLoggedIn;
  final bool isDesktop;
  final int urgentCount;
  final VoidCallback onBell;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            AppColors.primaryDark,
            AppColors.primary,
            Color(0xFF14A094),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(26),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryDark.withValues(alpha: 0.18),
            blurRadius: 22,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          // Hiasan karakter 朋 transparan di kanan bawah
          Positioned(
            right: -12,
            bottom: -28,
            child: Text(
              '朋',
              style: TextStyle(
                fontSize: isDesktop ? 150 : 120,
                fontWeight: FontWeight.w900,
                color: Colors.white.withValues(alpha: 0.08),
                height: 1.0,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(isDesktop ? 26 : 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 11,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.18),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: const Text(
                        '朋友 · ARTINYA "TEMAN"',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.7,
                        ),
                      ),
                    ),
                    const Spacer(),
                    if (isDesktop)
                      _BellButton(
                        urgentCount: urgentCount,
                        onTap: onBell,
                        onDark: true,
                      ),
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  'Halo, $name! 👋',
                  style: GoogleFonts.nunito(
                    color: Colors.white,
                    fontSize: isDesktop ? 30 : 25,
                    fontWeight: FontWeight.w900,
                    letterSpacing: -0.4,
                    height: 1.15,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  tr('home_greeting'),
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.92),
                    fontSize: isDesktop ? 15.5 : 14,
                    fontWeight: FontWeight.w600,
                    height: 1.4,
                  ),
                ),
                if (!isLoggedIn) ...[
                  const SizedBox(height: 18),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      DuoButton(
                        label: 'Masuk Akun',
                        icon: Icons.login_rounded,
                        backgroundColor: AppColors.accent,
                        lipColor: AppColors.accentDark,
                        foregroundColor: AppColors.ink,
                        compact: true,
                        onPressed: () => context.go('/login'),
                      ),
                      DuoButton(
                        label: 'Daftar Gratis',
                        icon: Icons.person_add_alt_1_rounded,
                        backgroundColor: Colors.white.withValues(alpha: 0.16),
                        lipColor: Colors.black.withValues(alpha: 0.18),
                        foregroundColor: Colors.white,
                        borderColor: Colors.white.withValues(alpha: 0.35),
                        compact: true,
                        onPressed: () => context.go('/daftar'),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Baris Kurs NTD→IDR & Cuaca untuk tampilan Mobile / Tablet (< 1020px).
class _RateAndWeatherCompact extends StatelessWidget {
  const _RateAndWeatherCompact({
    required this.rate,
    required this.weather,
    required this.onSos,
  });

  final ExchangeRate? rate;
  final Weather? weather;
  final VoidCallback onSos;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _RateSparklineCard(rate: rate),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: DuoCard(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                child: Row(
                  children: [
                    Text(
                      weather?.emoji ?? '🌤️',
                      style: const TextStyle(fontSize: 24),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            tr('weather_label'),
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: AppColors.muted,
                            ),
                          ),
                          Text(
                            weather == null
                                ? 'Memuat…'
                                : '${weather!.tempC.round()}°C · ${weather!.desc}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w900,
                              color: AppColors.ink,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: DuoCard(
                color: AppColors.roseSoft,
                borderColor: AppColors.danger.withValues(alpha: 0.28),
                lipColor: AppColors.danger.withValues(alpha: 0.22),
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                onTap: onSos,
                child: const Row(
                  children: [
                    Text('🆘', style: TextStyle(fontSize: 22)),
                    SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Darurat / SOS',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                              color: AppColors.roseInk,
                            ),
                          ),
                          Text(
                            '110 · 119 · 1955',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w800,
                              color: AppColors.roseInk,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      Icons.chevron_right_rounded,
                      color: AppColors.roseInk,
                      size: 20,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

/// Kartu Kurs NTD → Rupiah dengan grafik sparkline (serasi dengan `.s-card--rate` di `webcontoh`).
class _RateSparklineCard extends StatelessWidget {
  const _RateSparklineCard({required this.rate});
  final ExchangeRate? rate;

  @override
  Widget build(BuildContext context) {
    return DuoCard(
      color: Colors.white,
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppColors.primaryLight,
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Text('💱', style: TextStyle(fontSize: 24)),
          ),
          const SizedBox(width: 14),
          Expanded(
            flex: 5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tr('rate_label').toUpperCase(),
                  style: const TextStyle(
                    color: AppColors.muted,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(height: 2),
                if (rate == null)
                  const Text(
                    'Memuat kurs…',
                    style: TextStyle(
                      color: AppColors.ink,
                      fontWeight: FontWeight.w900,
                      fontSize: 17,
                    ),
                  )
                else ...[
                  Text(
                    'Rp ${rate!.twdToIdr.toStringAsFixed(2)}',
                    style: GoogleFonts.nunito(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w900,
                      fontSize: 24,
                      letterSpacing: -0.5,
                      height: 1.1,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Wrap(
                    crossAxisAlignment: WrapCrossAlignment.center,
                    spacing: 6,
                    children: [
                      const Text(
                        'per NT\$1',
                        style: TextStyle(
                          color: AppColors.muted,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      if (rate!.changePct != null)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: rate!.changePct! >= 0
                                ? AppColors.greenSoft
                                : AppColors.amberSoft,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            '${rate!.changePct! >= 0 ? '▲' : '▼'} ${rate!.changePct!.abs().toStringAsFixed(2)}% (7h)',
                            style: TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.w900,
                              color: rate!.changePct! >= 0
                                  ? AppColors.greenInk
                                  : AppColors.amberInk,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          if (rate != null && rate!.history.length >= 2) ...[
            const SizedBox(width: 10),
            Expanded(
              flex: 4,
              child: SizedBox(
                height: 48,
                child: CustomPaint(
                  painter: _SparklinePainter(
                    rate!.history,
                    color: AppColors.primary,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Kartu Cuaca di kolom kanan Desktop.
class _WeatherDesktopCard extends StatelessWidget {
  const _WeatherDesktopCard({required this.weather});
  final Weather? weather;

  @override
  Widget build(BuildContext context) {
    return DuoCard(
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppColors.amberSoft,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Text(
              weather?.emoji ?? '🌤️',
              style: const TextStyle(fontSize: 25),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tr('weather_label').toUpperCase(),
                  style: const TextStyle(
                    color: AppColors.muted,
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  weather == null
                      ? 'Memuat cuaca…'
                      : '${weather!.tempC.round()}°C · ${weather!.desc}',
                  style: const TextStyle(
                    color: AppColors.ink,
                    fontWeight: FontWeight.w900,
                    fontSize: 17,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Kartu Darurat & Hotline 1955 di kolom kanan Desktop.
class _EmergencyDesktopCard extends StatelessWidget {
  const _EmergencyDesktopCard({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return DuoCard(
      color: AppColors.roseSoft,
      borderColor: AppColors.danger.withValues(alpha: 0.3),
      lipColor: AppColors.danger.withValues(alpha: 0.25),
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.danger,
                  borderRadius: BorderRadius.circular(13),
                ),
                child: const Icon(
                  Icons.sos_rounded,
                  color: Colors.white,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Darurat & Hotline 1955',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        color: AppColors.roseInk,
                      ),
                    ),
                    Text(
                      '24 jam gratis · Bahasa Indonesia',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.roseInk,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.arrow_forward_ios_rounded,
                size: 16,
                color: AppColors.roseInk,
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Text(
            'Panggil cepat Polisi (110), Ambulans (119), Konseling PMI (1955) & bagikan koordinat GPS-mu.',
            style: TextStyle(
              fontSize: 12.5,
              color: AppColors.ink,
              fontWeight: FontWeight.w600,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}

/// Kartu ringkasan pengingat dokumen di kolom kanan Desktop.
class _DocsQuickSummaryCard extends StatelessWidget {
  const _DocsQuickSummaryCard({
    required this.urgentCount,
    required this.isLoggedIn,
    required this.onTap,
  });

  final int urgentCount;
  final bool isLoggedIn;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return DuoCard(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.amberSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text('🪪', style: TextStyle(fontSize: 21)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Pengingat ARC & Paspor',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    Text(
                      !isLoggedIn
                          ? 'Masuk untuk pantau masa berlaku'
                          : urgentCount > 0
                              ? '$urgentCount dokumen perlu perhatian!'
                              : 'Semua dokumen aman terkendali ✓',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: urgentCount > 0
                            ? AppColors.danger
                            : AppColors.muted,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Contoh bar progres visual seperti di webcontoh
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.surfaceTint,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.line),
            ),
            child: const Row(
              children: [
                Icon(
                  Icons.notifications_active_rounded,
                  size: 16,
                  color: AppColors.primary,
                ),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Notifikasi otomatis H-30, H-14, dan H-7 sebelum habis.',
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                      color: AppColors.muted,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Kartu Unggulan Belajar Mandarin & Kesehatan NHI (gaya Duolingo & Brilliant.org).
class _FeaturedPathCard extends StatelessWidget {
  const _FeaturedPathCard({
    required this.tag,
    required this.tagBg,
    required this.tagFg,
    required this.title,
    required this.subtitle,
    required this.ctaLabel,
    required this.watermark,
    required this.accentColor,
    required this.lipColor,
    required this.bgColor,
    required this.icon,
    required this.onTap,
  });

  final String tag;
  final Color tagBg;
  final Color tagFg;
  final String title;
  final String subtitle;
  final String ctaLabel;
  final String watermark;
  final Color accentColor;
  final Color lipColor;
  final Color bgColor;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return DuoCard(
      color: bgColor,
      borderColor: accentColor.withValues(alpha: 0.28),
      lipColor: accentColor.withValues(alpha: 0.22),
      padding: EdgeInsets.zero,
      onTap: onTap,
      child: Stack(
        children: [
          Positioned(
            right: -8,
            bottom: -22,
            child: Text(
              watermark,
              style: TextStyle(
                fontSize: 108,
                fontWeight: FontWeight.w900,
                color: accentColor.withValues(alpha: 0.08),
                height: 1.0,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: tagBg,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        tag,
                        style: TextStyle(
                          color: tagFg,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    const Spacer(),
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: tagBg,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(icon, color: accentColor, size: 22),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  title,
                  style: GoogleFonts.nunito(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: AppColors.ink,
                    height: 1.15,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 13.5,
                    color: AppColors.muted,
                    fontWeight: FontWeight.w600,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 16),
                DuoButton(
                  label: '$ctaLabel →',
                  backgroundColor: accentColor,
                  lipColor: lipColor,
                  compact: true,
                  onPressed: onTap,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Grid 6 Layanan Utama dengan warna ubin pastel dari `webcontoh`
/// (3 kolom di layar >= 620px, 2 kolom di layar < 620px — tanpa ruang kosong).
class _BentoServicesGrid extends StatelessWidget {
  const _BentoServicesGrid({
    required this.onFindInterpreter,
    required this.onOpenMap,
    required this.onDocuments,
    required this.onOrders,
    required this.onEmergency,
    required this.onHelp,
  });

  final VoidCallback onFindInterpreter;
  final VoidCallback onOpenMap;
  final VoidCallback onDocuments;
  final VoidCallback onOrders;
  final VoidCallback onEmergency;
  final VoidCallback onHelp;

  @override
  Widget build(BuildContext context) {
    final items = <_BentoItemData>[
      _BentoItemData(
        emoji: '🤝',
        title: 'Cari Penerjemah',
        subtitle: 'Pendamping RS & kantor',
        bg: AppColors.tealSoft,
        ink: AppColors.tealInk,
        onTap: onFindInterpreter,
      ),
      _BentoItemData(
        emoji: '🗺️',
        title: 'Peta Sekitar',
        subtitle: 'RS, agensi & imigrasi',
        bg: AppColors.greenSoft,
        ink: AppColors.greenInk,
        onTap: onOpenMap,
      ),
      _BentoItemData(
        emoji: '🪪',
        title: 'Dokumen Saya',
        subtitle: 'Pengingat ARC & paspor',
        bg: AppColors.amberSoft,
        ink: AppColors.amberInk,
        onTap: onDocuments,
      ),
      _BentoItemData(
        emoji: '📅',
        title: 'Pesanan Saya',
        subtitle: 'Jadwal pendampingan',
        bg: AppColors.violetSoft,
        ink: AppColors.violetInk,
        onTap: onOrders,
      ),
      _BentoItemData(
        emoji: '🆘',
        title: 'Darurat / SOS',
        subtitle: '110 · 119 · 1955 & GPS',
        bg: AppColors.roseSoft,
        ink: AppColors.roseInk,
        onTap: onEmergency,
      ),
      _BentoItemData(
        emoji: '❓',
        title: 'Bantuan & FAQ',
        subtitle: 'Panduan hidup di Taiwan',
        bg: AppColors.blueSoft,
        ink: AppColors.blueInk,
        onTap: onHelp,
      ),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final cols = constraints.maxWidth >= 600 ? 3 : 2;
        final spacing = 12.0;
        final itemWidth =
            (constraints.maxWidth - spacing * (cols - 1)) / cols;

        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: items
              .map(
                (item) => SizedBox(
                  width: itemWidth,
                  child: _BentoTile(item: item),
                ),
              )
              .toList(),
        );
      },
    );
  }
}

class _BentoItemData {
  const _BentoItemData({
    required this.emoji,
    required this.title,
    required this.subtitle,
    required this.bg,
    required this.ink,
    required this.onTap,
  });

  final String emoji;
  final String title;
  final String subtitle;
  final Color bg;
  final Color ink;
  final VoidCallback onTap;
}

class _BentoTile extends StatelessWidget {
  const _BentoTile({required this.item});
  final _BentoItemData item;

  @override
  Widget build(BuildContext context) {
    return DuoCard(
      color: Colors.white,
      padding: const EdgeInsets.all(14),
      onTap: item.onTap,
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: item.bg,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Text(item.emoji, style: const TextStyle(fontSize: 23)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  item.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.nunito(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w900,
                    color: AppColors.ink,
                    height: 1.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  item.subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.muted,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({
    required this.eyebrow,
    required this.title,
    required this.icon,
    required this.iconColor,
  });

  final String eyebrow;
  final String title;
  final IconData icon;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: iconColor.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: iconColor, size: 19),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                eyebrow,
                style: TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.9,
                  color: iconColor,
                ),
              ),
              Text(
                title,
                style: GoogleFonts.nunito(
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                  color: AppColors.ink,
                  height: 1.15,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// Grafik garis mini (sparkline) untuk riwayat kurs.
class _SparklinePainter extends CustomPainter {
  _SparklinePainter(this.data, {required this.color});
  final List<double> data;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    if (data.length < 2) return;
    final minV = data.reduce((a, b) => a < b ? a : b);
    final maxV = data.reduce((a, b) => a > b ? a : b);
    final range = (maxV - minV).abs() < 1e-9 ? 1.0 : (maxV - minV);
    final dx = size.width / (data.length - 1);

    Offset pt(int i) => Offset(
          i * dx,
          size.height -
              ((data[i] - minV) / range) * size.height * 0.80 -
              size.height * 0.10,
        );

    final path = Path()..moveTo(pt(0).dx, pt(0).dy);
    for (var i = 1; i < data.length; i++) {
      path.lineTo(pt(i).dx, pt(i).dy);
    }

    // Area gradasi di bawah garis.
    final fill = Path.from(path)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(
      fill,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            color.withValues(alpha: 0.25),
            color.withValues(alpha: 0.0),
          ],
        ).createShader(Offset.zero & size),
    );

    // Garis.
    canvas.drawPath(
      path,
      Paint()
        ..color = color
        ..strokeWidth = 2.4
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round,
    );

    // Titik terakhir.
    final last = pt(data.length - 1);
    canvas.drawCircle(last, 3.5, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant _SparklinePainter old) => old.data != data;
}

/// Pengingat dokumen mendekati kedaluwarsa, tampil menonjol di Beranda.
class _DocExpiryReminder extends StatelessWidget {
  const _DocExpiryReminder({
    required this.doc,
    required this.extra,
    required this.onTap,
  });
  final Map<String, dynamic> doc;
  final int extra;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final expiry = DateTime.tryParse('${doc['expiry_date']}');
    if (expiry == null) return const SizedBox.shrink();
    final days = expiry.difference(DateTime.now()).inDays;
    final label = documentTypeLabels[doc['document_type']] ?? 'Dokumen';
    final expired = days < 0;
    final color = (expired || days <= 7)
        ? AppColors.danger
        : const Color(0xFFD97706);
    final bgColor =
        (expired || days <= 7) ? AppColors.roseSoft : AppColors.amberSoft;
    final headline = expired
        ? '$label kedaluwarsa ${-days} hari lalu'
        : days == 0
            ? '$label habis HARI INI'
            : '$label habis $days hari lagi';

    return DuoCard(
      color: bgColor,
      borderColor: color.withValues(alpha: 0.4),
      lipColor: color.withValues(alpha: 0.3),
      padding: const EdgeInsets.all(14),
      onTap: onTap,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              border: Border.all(color: color.withValues(alpha: 0.3)),
            ),
            child: Icon(
              expired ? Icons.error_outline : Icons.warning_amber_rounded,
              color: color,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  headline,
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    color: color,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Berlaku s/d ${DateFormat('d MMM y').format(expiry)}'
                  '${extra > 0 ? ' · +$extra dokumen lain' : ''} · ketuk untuk kelola',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppColors.ink,
                  ),
                ),
              ],
            ),
          ),
          Icon(Icons.chevron_right_rounded, color: color),
        ],
      ),
    );
  }
}

/// Banner berputar otomatis berisi hot news.
class _NewsBanner extends StatefulWidget {
  const _NewsBanner({
    required this.items,
    required this.onOpen,
    required this.onMore,
  });
  final List<Map<String, dynamic>> items;
  final void Function(Map<String, dynamic>) onOpen;
  final void Function(Map<String, dynamic>) onMore;

  @override
  State<_NewsBanner> createState() => _NewsBannerState();
}

class _NewsBannerState extends State<_NewsBanner> {
  final _controller = PageController();
  Timer? _timer;
  int _page = 0;
  DateTime _pausedUntil = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    if (widget.items.length > 1) {
      _timer = Timer.periodic(const Duration(seconds: 5), (_) {
        if (!_controller.hasClients) return;
        if (DateTime.now().isBefore(_pausedUntil)) return;
        _animateTo((_page + 1) % widget.items.length);
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _pause() =>
      _pausedUntil = DateTime.now().add(const Duration(seconds: 7));

  void _animateTo(int i) {
    _controller.animateToPage(
      i,
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeInOut,
    );
  }

  void _go(int delta) {
    _pause();
    final n = widget.items.length;
    _animateTo((_page + delta + n) % n);
  }

  @override
  Widget build(BuildContext context) {
    final many = widget.items.length > 1;
    return Column(
      children: [
        SizedBox(
          height: 214,
          child: Stack(
            children: [
              NotificationListener<ScrollNotification>(
                onNotification: (notif) {
                  if (notif is ScrollStartNotification ||
                      notif is UserScrollNotification) {
                    _pause();
                  }
                  return false;
                },
                child: PageView.builder(
                  controller: _controller,
                  itemCount: widget.items.length,
                  onPageChanged: (i) => setState(() => _page = i),
                  itemBuilder: (_, i) => _BannerCard(
                    data: widget.items[i],
                    onTap: () => widget.onOpen(widget.items[i]),
                    onMore: () => widget.onMore(widget.items[i]),
                  ),
                ),
              ),
              if (many) ...[
                Positioned(
                  left: 8,
                  top: 0,
                  bottom: 0,
                  child: Center(
                    child: _NavArrow(
                      icon: Icons.chevron_left_rounded,
                      onTap: () => _go(-1),
                    ),
                  ),
                ),
                Positioned(
                  right: 8,
                  top: 0,
                  bottom: 0,
                  child: Center(
                    child: _NavArrow(
                      icon: Icons.chevron_right_rounded,
                      onTap: () => _go(1),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(widget.items.length, (i) {
            final active = i == _page;
            return GestureDetector(
              onTap: () => _go(i - _page),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 22 : 8,
                height: 8,
                decoration: BoxDecoration(
                  color: active
                      ? AppColors.primary
                      : AppColors.primary.withValues(alpha: 0.25),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            );
          }),
        ),
      ],
    );
  }
}

class _NavArrow extends StatelessWidget {
  const _NavArrow({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withValues(alpha: 0.38),
      shape: const CircleBorder(),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(5),
          child: Icon(icon, color: Colors.white, size: 22),
        ),
      ),
    );
  }
}

class _BannerCard extends StatelessWidget {
  const _BannerCard({
    required this.data,
    required this.onMore,
    required this.onTap,
  });
  final Map<String, dynamic> data;
  final VoidCallback onMore;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    if (data['__summary'] != null) {
      return _buildSummary(context);
    }
    final imageUrl = data['image_url'] as String?;
    final base = AppColors.category(data['category'] as String?);
    final darker = Color.lerp(base, Colors.black, 0.42)!;
    final lighter = Color.lerp(base, Colors.white, 0.12)!;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          colors: [darker, base, lighter],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(
          color: darker.withValues(alpha: 0.4),
          width: 2,
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (imageUrl != null)
            Image.network(
              imageUrl,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          if (imageUrl == null)
            Positioned(
              right: -8,
              bottom: -16,
              child: Text(
                '${data['emoji'] ?? '📰'}',
                style: TextStyle(
                  fontSize: 120,
                  color: Colors.white.withValues(alpha: 0.13),
                ),
              ),
            ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.black.withValues(alpha: imageUrl != null ? 0.65 : 0.35),
                  Colors.black.withValues(alpha: 0.08),
                ],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
            ),
          ),
          Positioned.fill(
            child: Material(
              color: Colors.transparent,
              child: InkWell(onTap: onTap),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(44, 14, 44, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.22),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    '${data['emoji'] ?? '📰'}  ${data['category'] ?? 'Info'}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '${data['title'] ?? ''}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    height: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  data['summary'] ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.92),
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                    height: 1.3,
                  ),
                ),
                const SizedBox(height: 10),
                FilledButton(
                  onPressed: onMore,
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.accent,
                    foregroundColor: AppColors.ink,
                    minimumSize: const Size(0, 34),
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    textStyle: const TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 12.5,
                    ),
                  ),
                  child: Text(tr('read_more')),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummary(BuildContext context) {
    final type = data['__summary'];
    final label = switch (type) {
      'day' => tr('hot_today'),
      'week' => tr('hot_week'),
      'month' => tr('hot_month'),
      _ => 'Hot',
    };
    final a = Map<String, dynamic>.from(data['article'] as Map? ?? const {});
    final sources = (data['sources'] as num?)?.toInt() ?? 1;
    final imageUrl = '${a['image_url'] ?? ''}';
    final colors = switch (type) {
      'day' => const [Color(0xFF0B5A54), Color(0xFF0F766E)],
      'week' => const [Color(0xFFB7410E), Color(0xFFE67E22)],
      _ => const [Color(0xFF4A2E9E), Color(0xFF2563EB)],
    };
    final meta = [
      '${a['emoji'] ?? '📰'} ${a['category'] ?? 'Info'}',
      if ('${a['source_name'] ?? ''}'.isNotEmpty) '${a['source_name']}',
      timeAgo(DateTime.tryParse('${a['published_at'] ?? ''}')),
    ].where((x) => x.isNotEmpty).join('  ·  ');
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (imageUrl.isNotEmpty)
            Image.network(
              imageUrl,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            )
          else
            Positioned(
              right: -10,
              bottom: -22,
              child: Text(
                '${a['emoji'] ?? '📰'}',
                style: TextStyle(
                  fontSize: 130,
                  color: Colors.white.withValues(alpha: 0.14),
                ),
              ),
            ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                colors: [
                  Colors.black.withValues(alpha: 0.86),
                  Colors.black
                      .withValues(alpha: imageUrl.isNotEmpty ? 0.35 : 0.1),
                  colors.first
                      .withValues(alpha: imageUrl.isNotEmpty ? 0.45 : 0.0),
                ],
                stops: const [0, 0.6, 1],
              ),
            ),
          ),
          Positioned.fill(
            child: Material(
              color: Colors.transparent,
              child: InkWell(onTap: onTap),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(44, 14, 44, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        '🔥 ${label.toUpperCase()}',
                        style: TextStyle(
                          color: colors.first,
                          fontSize: 10.5,
                          letterSpacing: 0.4,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    const Spacer(),
                    if (sources > 1)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.35),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          tr('n_media').replaceAll('{n}', '$sources'),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                  ],
                ),
                const Spacer(),
                Text(
                  meta,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.85),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${a['title'] ?? ''}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17.5,
                    fontWeight: FontWeight.w900,
                    height: 1.22,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    FilledButton(
                      onPressed: onTap,
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        foregroundColor: AppColors.ink,
                        minimumSize: const Size(0, 32),
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        textStyle: const TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                        ),
                      ),
                      child: Text(tr('read_more')),
                    ),
                    const SizedBox(width: 6),
                    TextButton(
                      onPressed: onMore,
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white,
                        minimumSize: const Size(0, 32),
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        textStyle: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                        ),
                      ),
                      child: Text('${tr('see_all')} ›'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// "5 menit lalu", "3 jam lalu", "Kemarin", "4 hari lalu", lalu tanggal.
String timeAgo(DateTime? t) {
  if (t == null) return '';
  final d = DateTime.now().difference(t.toLocal());
  if (d.inMinutes < 1) return tr('just_now');
  if (d.inMinutes < 60) {
    return tr('min_ago').replaceAll('{n}', '${d.inMinutes}');
  }
  if (d.inHours < 24) return tr('hour_ago').replaceAll('{n}', '${d.inHours}');
  if (d.inDays < 2) return tr('yesterday');
  if (d.inDays < 7) return tr('day_ago').replaceAll('{n}', '${d.inDays}');
  return DateFormat('d MMM', Lang.instance.value == 'id' ? 'id_ID' : null)
      .format(t.toLocal());
}

class _NewsCard extends StatelessWidget {
  const _NewsCard({required this.data, required this.onTap});
  final Map<String, dynamic> data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final published =
        DateTime.tryParse('${data['published_at'] ?? ''}')?.toLocal();
    final catColor = AppColors.category(data['category'] as String?);

    return DuoCard(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      onTap: onTap,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 54,
            height: 54,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: catColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              '${data['emoji'] ?? '📰'}',
              style: const TextStyle(fontSize: 27),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: catColor.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        '${data['category'] ?? 'Info'}',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          color: catColor,
                        ),
                      ),
                    ),
                    if (published != null) ...[
                      const Spacer(),
                      Text(
                        DateFormat('d MMM').format(published),
                        style: const TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                          color: AppColors.muted,
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  data['title'] ?? '',
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 15.5,
                    height: 1.3,
                    color: AppColors.ink,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  data['summary'] ?? '',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    color: AppColors.muted,
                    fontWeight: FontWeight.w600,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
