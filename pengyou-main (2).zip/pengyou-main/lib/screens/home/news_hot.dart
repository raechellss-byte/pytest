/// Pemilihan "Hot Hari / Minggu / Bulan Ini" untuk banner Beranda.
///
/// Tidak ada data jumlah pembaca, jadi "hot" = kejadian yang diberitakan
/// paling banyak media. Berita dengan judul mirip (kejadian yang sama dari
/// sumber berbeda) dikelompokkan jadi satu cerita, lalu tiap periode memilih
/// cerita terpanas yang BELUM dipakai periode sebelumnya — jadi ketiga slide
/// selalu berisi kejadian berbeda.
library;

typedef News = Map<String, dynamic>;

/// Satu kejadian: beberapa berita (dari media berbeda) dengan judul mirip.
class HotStory {
  HotStory(this.members);
  final List<News> members; // terbaru di depan

  /// Berita yang ditampilkan: yang terbaru dan punya gambar, bila ada.
  News get article =>
      members.firstWhere((n) => '${n['image_url'] ?? ''}'.isNotEmpty,
          orElse: () => members.first);

  int get sources => members.length;
  DateTime get latest => published(members.first)!;
}

DateTime? published(News n) => DateTime.tryParse('${n['published_at'] ?? ''}');

const _stop = {
  'yang', 'dan', 'di', 'ke', 'dari', 'untuk', 'dengan', 'ini', 'itu', 'akan',
  'pada', 'dalam', 'oleh', 'jadi', 'sebagai', 'atas', 'lebih', 'para', 'juga',
  'bisa', 'tak', 'tidak', 'ada', 'agar', 'kini', 'usai', 'saat', 'baru',
  'hasil', 'jelang', 'soal', 'terkait', 'begini', 'apa', 'cara',
  'taiwan', 'indonesia', 'warga', 'the', 'and', 'for', 'with',
};

/// Kata penting judul (huruf kecil, tanpa tanda baca, tanpa kata umum).
Set<String> _tokens(String title) => title
    .toLowerCase()
    .replaceAll(RegExp(r'[^a-z0-9\s]'), ' ')
    .split(RegExp(r'\s+'))
    .where((w) => w.length >= 3 || RegExp(r'^\d{2,}$').hasMatch(w))
    .where((w) => !_stop.contains(w))
    .toSet();

/// Dua kata dianggap sama bila identik atau salah satunya awalan yang lain
/// (≥5 huruf), mis. "ketamin" ~ "ketamine", "terintegrasi" ~ "terinteg".
bool _sameWord(String a, String b) =>
    a == b ||
    (a.length >= 5 && b.length >= 5 && (a.startsWith(b) || b.startsWith(a)));

int _shared(Set<String> a, Set<String> b) =>
    a.where((x) => b.any((y) => _sameWord(x, y))).length;

/// Judul membahas kejadian yang sama?
bool sameStory(String a, String b) {
  final ta = _tokens(a), tb = _tokens(b);
  if (ta.isEmpty || tb.isEmpty) return false;
  final s = _shared(ta, tb);
  final small = ta.length < tb.length ? ta.length : tb.length;
  return s >= 3 || (s >= 2 && s / small >= 0.5);
}

/// Kelompokkan berita menjadi cerita (single-link), terbaru di depan.
List<HotStory> clusterStories(List<News> news) {
  final list = [...news]..sort((a, b) =>
      '${b['published_at'] ?? ''}'.compareTo('${a['published_at'] ?? ''}'));
  final parent = List.generate(list.length, (i) => i);
  int find(int i) => parent[i] == i ? i : parent[i] = find(parent[i]);
  for (var i = 0; i < list.length; i++) {
    for (var j = i + 1; j < list.length; j++) {
      if (sameStory('${list[i]['title']}', '${list[j]['title']}')) {
        parent[find(j)] = find(i);
      }
    }
  }
  final groups = <int, List<News>>{};
  for (var i = 0; i < list.length; i++) {
    (groups[find(i)] ??= []).add(list[i]);
  }
  return groups.values.map(HotStory.new).toList();
}

/// Cerita dalam [days] hari terakhir, terpanas dulu: jumlah media dalam
/// rentang itu, lalu yang terbaru.
List<HotStory> rankWithin(List<News> news, DateTime now, int days) {
  final recent = news.where((n) {
    final p = published(n);
    return p != null && now.difference(p).inHours < days * 24;
  }).toList();
  return clusterStories(recent)
    ..sort((a, b) {
      final c = b.sources.compareTo(a.sources);
      return c != 0 ? c : b.latest.compareTo(a.latest);
    });
}

/// Susun slide banner: berita pilihan admin (is_featured) dulu, lalu satu
/// cerita terpanas per periode (hari → minggu → bulan) tanpa kejadian dobel.
/// Bila slide masih < 3, ditambah berita terbaru yang belum tampil.
List<News> buildBanners(List<News> all, DateTime now) {
  final used = <String>[]; // judul yang sudah tampil
  bool isUsed(HotStory s) =>
      s.members.any((m) => used.any((u) => sameStory(u, '${m['title']}')));

  final banners = <News>[];
  for (final f in all.where((n) => n['is_featured'] == true)) {
    banners.add(f);
    used.add('${f['title']}');
  }
  for (final (kind, days) in const [('day', 1), ('week', 7), ('month', 30)]) {
    final ranked = rankWithin(all, now, days);
    final pick = ranked.where((s) => !isUsed(s)).firstOrNull;
    if (pick == null) continue;
    used.add('${pick.article['title']}');
    banners.add({
      '__summary': kind,
      'article': pick.article,
      'sources': pick.sources,
      // "Lihat semua": satu berita per kejadian dalam periode ini.
      'items': [for (final s in ranked) s.article],
    });
  }
  if (banners.length < 3) {
    for (final s in clusterStories(all)) {
      if (banners.length >= 3) break;
      if (isUsed(s)) continue;
      used.add('${s.article['title']}');
      banners.add(s.article);
    }
  }
  return banners;
}
