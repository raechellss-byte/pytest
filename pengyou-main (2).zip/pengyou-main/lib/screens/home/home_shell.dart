import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../i18n/strings.dart';
import '../../theme.dart';
import '../auth/login_screen.dart' show nextQuery;

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.shell});
  final StatefulNavigationShell shell;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _unreadMessages = 0;

  @override
  void initState() {
    super.initState();
    _loadBadges();
    // Muat ulang badge saat status login berubah.
    Supabase.instance.client.auth.onAuthStateChange.listen((_) {
      if (mounted) _loadBadges();
    });
  }

  Future<void> _loadBadges() async {
    final sb = Supabase.instance.client;
    if (sb.auth.currentSession == null) {
      if (mounted) setState(() => _unreadMessages = 0);
      return;
    }
    // Pesan belum dibaca untuk badge tab Pesan.
    try {
      final rows = await sb
          .from('direct_messages')
          .select('id')
          .eq('is_read', false)
          .neq('sender_id', sb.auth.currentUser!.id);
      if (mounted) setState(() => _unreadMessages = (rows as List).length);
    } catch (_) {}
  }

  void _selectBranch(int i) {
    widget.shell.goBranch(i, initialLocation: i == widget.shell.currentIndex);
    _loadBadges();
  }

  void _goProtected(String route) {
    final loggedIn = Supabase.instance.client.auth.currentSession != null;
    if (loggedIn) {
      context.push(route);
    } else {
      context.go('/login${nextQuery(route)}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDesktop = AppBreakpoints.isDesktop(context);

    if (isDesktop) {
      return Scaffold(
        backgroundColor: AppColors.surfaceTint,
        body: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _DesktopSidebar(
              currentIndex: widget.shell.currentIndex,
              unreadMessages: _unreadMessages,
              onSelectBranch: _selectBranch,
              onGoProtected: _goProtected,
            ),
            Expanded(
              child: Align(
                alignment: Alignment.topCenter,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1180),
                  child: widget.shell,
                ),
              ),
            ),
          ],
        ),
      );
    }

    // Mode Mobile (< 840px)
    return Scaffold(
      body: widget.shell,
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: AppColors.line, width: 2)),
        ),
        child: NavigationBar(
          selectedIndex: widget.shell.currentIndex,
          onDestinationSelected: _selectBranch,
          destinations: [
            NavigationDestination(
              icon: const Icon(Icons.home_outlined),
              selectedIcon: const Icon(Icons.home_rounded),
              label: tr('nav_home'),
            ),
            NavigationDestination(
              icon: const Icon(Icons.search_rounded),
              selectedIcon: const Icon(Icons.saved_search_rounded),
              label: tr('nav_search'),
            ),
            NavigationDestination(
              icon: const Icon(Icons.calendar_month_outlined),
              selectedIcon: const Icon(Icons.calendar_month_rounded),
              label: tr('nav_calendar'),
            ),
            NavigationDestination(
              icon: Badge(
                isLabelVisible: _unreadMessages > 0,
                label: Text('$_unreadMessages'),
                child: const Icon(Icons.chat_bubble_outline_rounded),
              ),
              selectedIcon: Badge(
                isLabelVisible: _unreadMessages > 0,
                label: Text('$_unreadMessages'),
                child: const Icon(Icons.chat_bubble_rounded),
              ),
              label: tr('nav_messages'),
            ),
            NavigationDestination(
              icon: const Icon(Icons.person_outline_rounded),
              selectedIcon: const Icon(Icons.person_rounded),
              label: tr('nav_account'),
            ),
          ],
        ),
      ),
    );
  }
}

/// Sidebar kiri untuk tampilan Desktop (terinspirasi Duolingo Web & Brilliant.org).
class _DesktopSidebar extends StatelessWidget {
  const _DesktopSidebar({
    required this.currentIndex,
    required this.unreadMessages,
    required this.onSelectBranch,
    required this.onGoProtected,
  });

  final int currentIndex;
  final int unreadMessages;
  final ValueChanged<int> onSelectBranch;
  final ValueChanged<String> onGoProtected;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 268,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(right: BorderSide(color: AppColors.line, width: 2)),
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Brand Header (identik dengan webcontoh)
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 18, 16),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => onSelectBranch(0),
                child: const PengyouLogo(
                  size: 40,
                  subtitle: 'Teman Hidup di Taiwan',
                ),
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
                children: [
                  _sectionLabel('MENU UTAMA'),
                  _SidebarItem(
                    icon: Icons.home_rounded,
                    label: tr('nav_home'),
                    selected: currentIndex == 0,
                    color: AppColors.primary,
                    onTap: () => onSelectBranch(0),
                  ),
                  _SidebarItem(
                    icon: Icons.translate_rounded,
                    label: 'Belajar Mandarin',
                    badgeText: 'LIÚLÌ',
                    badgeColor: const Color(0xFF1F7A4D),
                    selected: false,
                    color: const Color(0xFF1F7A4D),
                    onTap: () => context.push('/belajar'),
                  ),
                  _SidebarItem(
                    icon: Icons.local_hospital_rounded,
                    label: 'Kesehatan & NHI',
                    badgeText: 'NHI',
                    badgeColor: AppColors.primary,
                    selected: false,
                    color: AppColors.primary,
                    onTap: () => context.push('/sehat'),
                  ),
                  _SidebarItem(
                    icon: Icons.travel_explore_rounded,
                    label: tr('nav_search'),
                    selected: currentIndex == 1,
                    color: const Color(0xFF2563EB),
                    onTap: () => onSelectBranch(1),
                  ),
                  _SidebarItem(
                    icon: Icons.calendar_month_rounded,
                    label: tr('nav_calendar'),
                    selected: currentIndex == 2,
                    color: const Color(0xFF7C3AED),
                    onTap: () => onSelectBranch(2),
                  ),
                  _SidebarItem(
                    icon: Icons.chat_bubble_rounded,
                    label: tr('nav_messages'),
                    selected: currentIndex == 3,
                    color: const Color(0xFFD97706),
                    unreadCount: unreadMessages,
                    onTap: () => onSelectBranch(3),
                  ),
                  _SidebarItem(
                    icon: Icons.person_rounded,
                    label: tr('nav_account'),
                    selected: currentIndex == 4,
                    color: AppColors.ink,
                    onTap: () => onSelectBranch(4),
                  ),
                  const SizedBox(height: 14),
                  _sectionLabel('PINTASAN LAYANAN'),
                  _SidebarItem(
                    icon: Icons.badge_rounded,
                    label: 'Dokumen & ARC',
                    selected: false,
                    color: const Color(0xFFD97706),
                    onTap: () => onGoProtected('/dokumen'),
                  ),
                  _SidebarItem(
                    icon: Icons.event_note_rounded,
                    label: 'Pesanan Saya',
                    selected: false,
                    color: AppColors.primary,
                    onTap: () => onGoProtected('/pesanan'),
                  ),
                  _SidebarItem(
                    icon: Icons.map_rounded,
                    label: 'Peta Sekitar',
                    selected: false,
                    color: const Color(0xFF2E6B1E),
                    onTap: () => context.go('/cari/peta'),
                  ),
                  _SidebarItem(
                    icon: Icons.help_outline_rounded,
                    label: 'Bantuan & FAQ',
                    selected: false,
                    color: AppColors.muted,
                    onTap: () => context.push('/bantuan'),
                  ),
                ],
              ),
            ),
            // Footer Sidebar: Pemilih Bahasa + Tombol Darurat SOS
            Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
              decoration: const BoxDecoration(
                border: Border(top: BorderSide(color: AppColors.line, width: 1.5)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Bahasa',
                        style: GoogleFonts.nunito(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w800,
                          color: AppColors.muted,
                        ),
                      ),
                      const LangPillSwitcher(),
                    ],
                  ),
                  const SizedBox(height: 12),
                  DuoButton(
                    label: 'Darurat / SOS 1955',
                    icon: Icons.sos_rounded,
                    backgroundColor: AppColors.danger,
                    lipColor: const Color(0xFF8E2419),
                    compact: true,
                    expanded: true,
                    onPressed: () => context.push('/darurat'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
        child: Text(
          text,
          style: GoogleFonts.nunito(
            fontSize: 11,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.0,
            color: AppColors.muted.withValues(alpha: 0.8),
          ),
        ),
      );
}

class _SidebarItem extends StatelessWidget {
  const _SidebarItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.color,
    required this.onTap,
    this.badgeText,
    this.badgeColor,
    this.unreadCount = 0,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final Color color;
  final VoidCallback onTap;
  final String? badgeText;
  final Color? badgeColor;
  final int unreadCount;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Material(
        color: selected ? AppColors.primaryLight : Colors.transparent,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: selected
                    ? AppColors.primary.withValues(alpha: 0.45)
                    : Colors.transparent,
                width: 2,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: selected
                        ? AppColors.primary
                        : color.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    icon,
                    size: 20,
                    color: selected ? Colors.white : color,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.nunito(
                      fontSize: 14.5,
                      fontWeight: selected ? FontWeight.w900 : FontWeight.w800,
                      color: selected ? AppColors.primaryDark : AppColors.ink,
                    ),
                  ),
                ),
                if (unreadCount > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.danger,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      '$unreadCount',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  )
                else if (badgeText != null)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: (badgeColor ?? AppColors.primary)
                          .withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      badgeText!,
                      style: GoogleFonts.nunito(
                        color: badgeColor ?? AppColors.primary,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.4,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
