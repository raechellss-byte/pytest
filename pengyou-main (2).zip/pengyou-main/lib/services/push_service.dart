import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../firebase_options.dart';

/// Layanan push notification (Firebase Cloud Messaging) — fokus web.
///
/// Prinsip izin yang sopan:
///  • Saat login → [syncIfGranted]: HANYA simpan token kalau user SUDAH
///    mengizinkan notifikasi sebelumnya. Tidak memunculkan prompt.
///  • Prompt izin baru muncul saat user menekan tombol "Aktifkan notifikasi"
///    → [enable].
///  • [needsEnable] dipakai UI untuk memutuskan apakah menampilkan tombolnya.
class PushService {
  static bool _ready = false;

  static bool get _enabled => kIsWeb && AppConfig.pushConfigured;

  static Future<void> init() async {
    if (!_enabled) return;
    try {
      await Firebase.initializeApp(options: DefaultFirebaseOptions.web);
      _ready = true;
    } catch (e) {
      debugPrint('PushService init gagal: $e');
    }
  }

  /// true bila layak menampilkan tombol "Aktifkan notifikasi"
  /// (web + terkonfigurasi + user login + izin belum diberikan).
  static Future<bool> needsEnable() async {
    if (!_ready) return false;
    if (Supabase.instance.client.auth.currentUser == null) return false;
    try {
      final s = await FirebaseMessaging.instance.getNotificationSettings();
      return s.authorizationStatus != AuthorizationStatus.authorized;
    } catch (_) {
      return false;
    }
  }

  /// Dipanggil saat login: simpan token tanpa prompt, HANYA jika sudah diizinkan.
  static Future<void> syncIfGranted() async {
    if (!_ready) return;
    try {
      final s = await FirebaseMessaging.instance.getNotificationSettings();
      if (s.authorizationStatus == AuthorizationStatus.authorized) {
        await _registerToken();
      }
    } catch (e) {
      debugPrint('PushService syncIfGranted gagal: $e');
    }
  }

  /// Dipicu tombol: minta izin (prompt), lalu simpan token. Return true bila aktif.
  static Future<bool> enable() async {
    if (!_ready) return false;
    try {
      final s = await FirebaseMessaging.instance.requestPermission();
      if (s.authorizationStatus != AuthorizationStatus.authorized) return false;
      await _registerToken();
      return true;
    } catch (e) {
      debugPrint('PushService enable gagal: $e');
      return false;
    }
  }

  static Future<void> _registerToken() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;
    final messaging = FirebaseMessaging.instance;
    final token = await messaging.getToken(vapidKey: AppConfig.firebaseVapidKey);
    if (token != null) await _saveToken(user.id, token);
    messaging.onTokenRefresh.listen((t) {
      final u = Supabase.instance.client.auth.currentUser;
      if (u != null) _saveToken(u.id, t);
    });
  }

  static Future<void> _saveToken(String userId, String token) async {
    try {
      await Supabase.instance.client.from('push_tokens').upsert(
        {
          'user_id': userId,
          'token': token,
          'platform': 'web',
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        },
        onConflict: 'token',
      );
    } catch (e) {
      debugPrint('PushService simpan token gagal: $e');
    }
  }
}
