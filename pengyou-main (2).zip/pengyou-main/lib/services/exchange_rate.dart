import 'dart:convert';

import 'package:http/http.dart' as http;

/// Kurs 1 TWD (NT$) ke IDR (Rupiah) + riwayat 7 hari untuk grafik.
class ExchangeRate {
  ExchangeRate({
    required this.twdToIdr,
    required this.history,
    required this.updatedAt,
  });
  final double twdToIdr; // nilai terkini (float)
  final List<double> history; // urut lama → baru
  final DateTime updatedAt;

  /// Perubahan persen dari titik pertama ke terakhir dalam riwayat.
  double? get changePct {
    if (history.length < 2 || history.first == 0) return null;
    return (history.last - history.first) / history.first * 100;
  }
}

class ExchangeRateService {
  static ExchangeRate? _cache;
  static const _base =
      'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api';

  static String _two(int n) => n.toString().padLeft(2, '0');

  /// Ambil kurs TWD→IDR untuk satu tag tanggal ('latest' atau 'YYYY-MM-DD').
  static Future<double?> _rateFor(String tag) async {
    try {
      final res = await http
          .get(Uri.parse('$_base@$tag/v1/currencies/twd.min.json'))
          .timeout(const Duration(seconds: 6));
      if (res.statusCode != 200) return null;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return (data['twd']?['idr'] as num?)?.toDouble();
    } catch (_) {
      return null;
    }
  }

  static Future<ExchangeRate?> fetch() async {
    final now = DateTime.now();
    // Riwayat 6 hari terakhir (paralel) + nilai terkini sebagai titik "hari ini".
    final histFutures = <Future<double?>>[];
    for (final d in [6, 5, 4, 3, 2, 1]) {
      final date = now.subtract(Duration(days: d));
      histFutures.add(_rateFor('${date.year}-${_two(date.month)}-${_two(date.day)}'));
    }
    final results = await Future.wait([_rateFor('latest'), ...histFutures]);
    final current = results.first;
    final history = results.skip(1).whereType<double>().toList();
    if (current != null) history.add(current);

    if (current == null && history.isEmpty) return _cache;
    final rate = ExchangeRate(
      twdToIdr: current ?? history.last,
      history: history,
      updatedAt: DateTime.now(),
    );
    _cache = rate;
    return rate;
  }
}
