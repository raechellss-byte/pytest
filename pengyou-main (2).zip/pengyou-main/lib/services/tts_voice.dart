import 'package:flutter_tts/flutter_tts.dart';

/// Pilih suara TTS untuk [locale] (mis. 'zh-TW'). flutter_tts versi web
/// diam-diam mengabaikan setLanguage bila tidak ada suara dengan locale persis
/// itu, sehingga teks Mandarin dibacakan suara default (Inggris). Di sini
/// dipakai suara bahasa yang sama bila locale persisnya tidak ada.
/// true = suara yang cocok dipasang.
Future<bool> useVoiceFor(FlutterTts tts, String locale) async {
  try {
    final raw = await tts.getVoices;
    final voices = <Map<String, String>>[
      for (final v in (raw is List ? raw : const []))
        if (v is Map) {'name': '${v['name']}', 'locale': '${v['locale']}'},
    ];
    final best = bestVoice(voices, locale);
    if (best != null) {
      await tts.setVoice(best);
      return true;
    }
  } catch (_) {}
  try {
    await tts.setLanguage(locale);
  } catch (_) {}
  return false;
}

/// Urutan pilihan: locale persis → zh-CN untuk zh-TW (sama-sama Mandarin;
/// zh-HK biasanya Kanton, jadi dihindari) → bahasa yang sama mana pun.
Map<String, String>? bestVoice(List<Map<String, String>> voices, String locale) {
  String norm(String s) => s.replaceAll('_', '-').toLowerCase();
  // Android lama memakai kode 'in' untuk bahasa Indonesia.
  String lang(String s) => switch (norm(s).split('-').first) {
    'in' => 'id',
    final l => l,
  };
  final want = norm(locale);
  Map<String, String>? first(bool Function(String loc) test) {
    for (final v in voices) {
      if (test(v['locale'] ?? '')) return v;
    }
    return null;
  }

  return first((l) => norm(l) == want) ??
      (want == 'zh-tw'
          ? first((l) => norm(l) == 'zh-cn' || norm(l).startsWith('cmn'))
          : null) ??
      first((l) => lang(l) == lang(want) && !norm(l).startsWith('zh-hk'));
}
