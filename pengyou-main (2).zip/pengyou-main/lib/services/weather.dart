import 'dart:convert';

import 'package:http/http.dart' as http;

class Weather {
  Weather({required this.tempC, required this.emoji, required this.desc});
  final double tempC;
  final String emoji;
  final String desc;
}

class WeatherService {
  /// Cuaca terkini via open-meteo (gratis, tanpa API key, mendukung CORS).
  static Future<Weather?> fetch(double lat, double lng) async {
    try {
      final res = await http
          .get(Uri.parse('https://api.open-meteo.com/v1/forecast'
              '?latitude=$lat&longitude=$lng&current=temperature_2m,weather_code'))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode != 200) return null;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final cur = data['current'] as Map<String, dynamic>?;
      if (cur == null) return null;
      final temp = (cur['temperature_2m'] as num?)?.toDouble() ?? 0;
      final code = (cur['weather_code'] as num?)?.toInt() ?? 0;
      final (emoji, desc) = _mapCode(code);
      return Weather(tempC: temp, emoji: emoji, desc: desc);
    } catch (_) {
      return null;
    }
  }

  /// Kode cuaca WMO → emoji + deskripsi Indonesia.
  static (String, String) _mapCode(int code) {
    if (code == 0) return ('☀️', 'Cerah');
    if (code <= 3) return ('⛅', 'Berawan');
    if (code == 45 || code == 48) return ('🌫️', 'Berkabut');
    if (code >= 51 && code <= 57) return ('🌦️', 'Gerimis');
    if (code >= 61 && code <= 67) return ('🌧️', 'Hujan');
    if (code >= 71 && code <= 77) return ('🌨️', 'Salju');
    if (code >= 80 && code <= 82) return ('🌧️', 'Hujan lebat');
    if (code >= 85 && code <= 86) return ('🌨️', 'Salju lebat');
    if (code >= 95) return ('⛈️', 'Badai petir');
    return ('🌡️', 'Cuaca');
  }
}
