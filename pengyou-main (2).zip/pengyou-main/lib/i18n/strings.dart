import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Pengelola bahasa aplikasi (id / en / zh). Simpan pilihan di device.
class Lang extends ValueNotifier<String> {
  Lang._(super.value);
  static final Lang instance = Lang._('id');
  static const _key = 'app_lang_v1';

  static const supported = {
    'id': 'Indonesia',
    'en': 'English',
    'zh': '中文',
  };

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final v = p.getString(_key);
      if (v != null && supported.containsKey(v)) value = v;
    } catch (_) {}
  }

  Future<void> set(String code) async {
    if (!supported.containsKey(code)) return;
    value = code;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_key, code);
    } catch (_) {}
  }
}

/// Terjemahkan sebuah kunci ke bahasa aktif.
String tr(String key) {
  final m = _strings[key];
  if (m == null) return key;
  return m[Lang.instance.value] ?? m['id'] ?? key;
}

// ============================================================
// Kamus terjemahan  (id / en / zh)
// ============================================================
const _strings = <String, Map<String, String>>{
  // Menu bawah
  'nav_home': {'id': 'Beranda', 'en': 'Home', 'zh': '首頁'},
  'nav_search': {'id': 'Cari', 'en': 'Search', 'zh': '搜尋'},
  'nav_calendar': {'id': 'Kalender', 'en': 'Calendar', 'zh': '行事曆'},
  'nav_notif': {'id': 'Notifikasi', 'en': 'Alerts', 'zh': '通知'},
  'nav_messages': {'id': 'Pesan', 'en': 'Messages', 'zh': '訊息'},
  'nav_account': {'id': 'Akun', 'en': 'Account', 'zh': '帳號'},

  // Umum
  'loading': {'id': 'Memuat…', 'en': 'Loading…', 'zh': '載入中…'},
  'or': {'id': 'atau', 'en': 'or', 'zh': '或'},
  'save': {'id': 'Simpan', 'en': 'Save', 'zh': '儲存'},
  'skip': {'id': 'Lewati', 'en': 'Skip', 'zh': '略過'},
  'next': {'id': 'Lanjut', 'en': 'Next', 'zh': '下一步'},
  'start': {'id': 'Mulai', 'en': 'Get Started', 'zh': '開始'},
  'sign_in': {'id': 'Masuk', 'en': 'Sign In', 'zh': '登入'},
  'sign_up': {'id': 'Daftar', 'en': 'Sign Up', 'zh': '註冊'},
  'logout': {'id': 'Keluar', 'en': 'Log Out', 'zh': '登出'},

  // Onboarding
  'ob1_title': {
    'id': 'Selamat datang di PENGYOU',
    'en': 'Welcome to PENGYOU',
    'zh': '歡迎使用 PENGYOU'
  },
  'ob1_body': {
    'id': 'Teman & pendamping bahasa Indonesia–Mandarin untuk pekerja migran Indonesia di Taiwan. PENGYOU (朋友) artinya "teman".',
    'en': 'Your Indonesian–Mandarin language companion for Indonesian migrant workers in Taiwan. PENGYOU (朋友) means "friend".',
    'zh': '為在台印尼移工提供的印尼語—中文語言陪伴夥伴。PENGYOU（朋友）意即「朋友」。'
  },
  'ob2_title': {
    'id': 'Cari penerjemah terdekat',
    'en': 'Find nearby interpreters',
    'zh': '尋找附近的翻譯'
  },
  'ob2_body': {
    'id': 'Temukan penerjemah tepercaya di sekitar Anda — lewat lokasi GPS atau peta. Chat dulu untuk tanya-tanya, lalu pesan pendampingan.',
    'en': 'Find trusted interpreters near you — via GPS or map. Chat first to ask questions, then book accompaniment.',
    'zh': '透過 GPS 或地圖尋找您附近值得信賴的翻譯。先聊天詢問，再預約陪同服務。'
  },
  'ob3_title': {
    'id': 'Jangan sampai dokumen kedaluwarsa',
    'en': "Don't let documents expire",
    'zh': '別讓證件過期'
  },
  'ob3_body': {
    'id': 'Daftarkan ARC, paspor, & asuransi. PENGYOU mengingatkan 30, 14, dan 7 hari sebelum habis — lewat aplikasi & email.',
    'en': 'Register your ARC, passport & insurance. PENGYOU reminds you 30, 14, and 7 days before they expire — in-app and by email.',
    'zh': '登記您的居留證、護照與保險。PENGYOU 會在到期前 30、14、7 天提醒您——透過應用程式與電子郵件。'
  },

  // Login / Register
  'app_tagline': {
    'id': 'Teman & pendamping bahasa PMI di Taiwan',
    'en': 'Language companion for migrant workers in Taiwan',
    'zh': '在台移工的語言陪伴夥伴'
  },
  'email': {'id': 'Email', 'en': 'Email', 'zh': '電子郵件'},
  'password': {'id': 'Kata sandi', 'en': 'Password', 'zh': '密碼'},
  'full_name': {'id': 'Nama lengkap', 'en': 'Full name', 'zh': '全名'},
  'sign_in_google': {
    'id': 'Masuk dengan Google',
    'en': 'Sign in with Google',
    'zh': '使用 Google 登入'
  },
  'sign_up_google': {
    'id': 'Daftar dengan Google',
    'en': 'Sign up with Google',
    'zh': '使用 Google 註冊'
  },
  'no_account': {
    'id': 'Belum punya akun? Daftar gratis',
    'en': "Don't have an account? Sign up free",
    'zh': '還沒有帳號？免費註冊'
  },
  'have_account': {
    'id': 'Sudah punya akun? Masuk',
    'en': 'Already have an account? Sign in',
    'zh': '已有帳號？登入'
  },
  'i_need_interpreter': {
    'id': 'Saya butuh penerjemah',
    'en': 'I need an interpreter',
    'zh': '我需要翻譯'
  },
  'i_am_interpreter': {
    'id': 'Saya penerjemah',
    'en': "I'm an interpreter",
    'zh': '我是翻譯'
  },

  // Beranda
  'home_greeting': {
    'id': 'Apa yang bisa PENGYOU bantu hari ini?',
    'en': 'What can PENGYOU help you with today?',
    'zh': 'PENGYOU 今天能為您做什麼？'
  },
  'rate_label': {'id': 'Kurs NT\$ → Rupiah', 'en': 'Rate NT\$ → IDR', 'zh': '匯率 NT\$ → 印尼盾'},
  'weather_label': {'id': 'Cuaca Taichung', 'en': 'Taichung Weather', 'zh': '台中天氣'},
  'qa_find': {'id': 'Cari\nPenerjemah', 'en': 'Find\nInterpreter', 'zh': '尋找\n翻譯'},
  'qa_docs': {'id': 'Dokumen\nSaya', 'en': 'My\nDocuments', 'zh': '我的\n文件'},
  'qa_orders': {'id': 'Pesanan\nSaya', 'en': 'My\nOrders', 'zh': '我的\n訂單'},
  'news_title': {
    'id': 'Kabar & Info Taiwan',
    'en': 'Taiwan News & Info',
    'zh': '台灣新聞與資訊'
  },
  'hot_today': {'id': 'Hot Hari Ini', 'en': 'Hot Today', 'zh': '今日熱門'},
  'hot_week': {'id': 'Hot Minggu Ini', 'en': 'Hot This Week', 'zh': '本週熱門'},
  'hot_month': {'id': 'Hot Bulan Ini', 'en': 'Hot This Month', 'zh': '本月熱門'},
  'read_more': {'id': 'SELENGKAPNYA', 'en': 'READ MORE', 'zh': '閱讀更多'},
  'see_all': {'id': 'LIHAT SEMUA', 'en': 'SEE ALL', 'zh': '查看全部'},
  'n_media': {'id': '{n} media', 'en': '{n} outlets', 'zh': '{n} 家媒體'},
  'just_now': {'id': 'Baru saja', 'en': 'Just now', 'zh': '剛剛'},
  'min_ago': {'id': '{n} menit lalu', 'en': '{n} min ago', 'zh': '{n} 分鐘前'},
  'hour_ago': {'id': '{n} jam lalu', 'en': '{n} h ago', 'zh': '{n} 小時前'},
  'yesterday': {'id': 'Kemarin', 'en': 'Yesterday', 'zh': '昨天'},
  'day_ago': {'id': '{n} hari lalu', 'en': '{n} days ago', 'zh': '{n} 天前'},
  'read_source': {
    'id': 'Baca artikel selengkapnya',
    'en': 'Read full article',
    'zh': '閱讀完整文章'
  },

  // Cari
  'search_title': {'id': 'Cari Penerjemah', 'en': 'Find Interpreter', 'zh': '尋找翻譯'},
  'search_subtitle': {
    'id': 'Temukan pendamping bahasa terdekat dari Anda',
    'en': 'Find the nearest language companion',
    'zh': '尋找離您最近的語言陪伴'
  },
  'nearest': {'id': 'Terdekat', 'en': 'Nearest', 'zh': '最近'},
  'view_map': {'id': 'Lihat Peta', 'en': 'View Map', 'zh': '查看地圖'},
  'choose_city': {'id': 'Atau pilih kota…', 'en': 'Or choose a city…', 'zh': '或選擇城市…'},

  // Notifikasi
  'notif_title': {'id': 'Notifikasi', 'en': 'Notifications', 'zh': '通知'},
  'notif_ok': {
    'id': 'Semua dokumen Anda aman 👍',
    'en': 'All your documents are safe 👍',
    'zh': '您的證件都沒問題 👍'
  },
  'notif_login': {
    'id': 'Masuk untuk melihat pengingat dokumen (ARC, asuransi) dan jadwal kontrol dokter Anda.',
    'en': 'Sign in to see document reminders (ARC, insurance) and your medical appointments.',
    'zh': '登入以查看證件提醒（居留證、保險）與您的看診行程。'
  },
  'notif_docs': {'id': '🪪 Dokumen Anda', 'en': '🪪 Your Documents', 'zh': '🪪 您的證件'},
  'notif_agenda': {'id': '🗓️ Agenda Mendatang', 'en': '🗓️ Upcoming', 'zh': '🗓️ 即將到來'},

  // Akun
  'account_title': {'id': 'Akun', 'en': 'Account', 'zh': '帳號'},
  'not_logged_in': {'id': 'Anda belum masuk', 'en': "You're not signed in", 'zh': '您尚未登入'},
  'login_prompt': {
    'id': 'Masuk atau daftar gratis untuk memesan penerjemah, mengobrol, dan mendapat pengingat dokumen penting Anda.',
    'en': 'Sign in or register free to book interpreters, chat, and get reminders for your important documents.',
    'zh': '登入或免費註冊以預約翻譯、聊天，並取得重要證件提醒。'
  },
  'sign_up_free': {'id': 'Daftar Gratis', 'en': 'Sign Up Free', 'zh': '免費註冊'},
  'my_messages': {'id': 'Pesan Saya', 'en': 'My Messages', 'zh': '我的訊息'},
  'my_orders': {'id': 'Pesanan Saya', 'en': 'My Orders', 'zh': '我的訂單'},
  'my_documents': {'id': 'Dokumen Saya', 'en': 'My Documents', 'zh': '我的文件'},
  'admin_panel': {'id': 'Panel Admin', 'en': 'Admin Panel', 'zh': '管理面板'},
  'admin_panel_sub': {
    'id': 'Ruang kontrol PENGYOU',
    'en': 'PENGYOU control center',
    'zh': 'PENGYOU 控制中心'
  },
  'become_interpreter': {
    'id': 'Jadi Penerjemah',
    'en': 'Become an Interpreter',
    'zh': '成為翻譯'
  },
  'become_interpreter_sub': {
    'id': 'Bantu sesama PMI & dapat penghasilan tambahan',
    'en': 'Help fellow workers & earn extra income',
    'zh': '幫助同鄉並賺取額外收入'
  },
  'role_client': {'id': 'Client', 'en': 'Client', 'zh': '客戶'},
  'role_interpreter': {'id': 'Penerjemah', 'en': 'Interpreter', 'zh': '翻譯'},

  // Pengaturan bahasa
  'language': {'id': 'Bahasa', 'en': 'Language', 'zh': '語言'},
  'choose_language': {'id': 'Pilih Bahasa', 'en': 'Choose Language', 'zh': '選擇語言'},

  // Bantuan
  'help': {'id': 'Bantuan & FAQ', 'en': 'Help & FAQ', 'zh': '幫助與常見問題'},
};
