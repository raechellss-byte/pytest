import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'theme.dart';
import 'i18n/strings.dart';
import 'services/push_service.dart';
import 'features/sehat/sehat_app.dart';
import 'features/liuli/liuli_app.dart';
import 'features/liuli/liuli_sync.dart';
import 'features/sehat/sehat_sync.dart';
import 'screens/onboarding/onboarding_screen.dart';
import 'screens/account/account_screen.dart';
import 'screens/account/become_interpreter_screen.dart';
import 'screens/account/interpreter_test_screen.dart';
import 'screens/admin/admin_bookings_screen.dart';
import 'screens/admin/admin_dashboard_screen.dart';
import 'screens/admin/admin_interpreters_screen.dart';
import 'screens/admin/admin_news_screen.dart';
import 'screens/admin/admin_places_screen.dart';
import 'screens/admin/admin_users_screen.dart';
import 'screens/calendar/calendar_screen.dart';
import 'screens/chat/chat_screen.dart';
import 'screens/chat/messages_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/booking/booking_detail_screen.dart';
import 'screens/booking/bookings_screen.dart';
import 'screens/booking/create_booking_screen.dart';
import 'screens/documents/add_document_screen.dart';
import 'screens/documents/documents_screen.dart';
import 'screens/emergency/emergency_screen.dart';
import 'screens/help/help_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/home/home_shell.dart';
import 'screens/notifications/notifications_screen.dart';
import 'screens/search/interpreter_detail_screen.dart';
import 'screens/search/map_screen.dart';
import 'screens/search/search_screen.dart';

final supabase = Supabase.instance.client;

const String _appInitialLocation = '/beranda';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('id_ID', null);
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    publishableKey: AppConfig.supabasePublishableKey,
  );
  await Lang.instance.load();
  // Push notification (FCM, web). No-op bila VAPID belum dikonfigurasi.
  await PushService.init();
  // Saat login / sesi dipulihkan: simpan token TANPA prompt (hanya kalau sudah
  // diizinkan). Permintaan izin dilakukan lewat tombol "Aktifkan notifikasi".
  Supabase.instance.client.auth.onAuthStateChange.listen((data) {
    final signedIn = data.event == AuthChangeEvent.signedIn ||
        (data.event == AuthChangeEvent.initialSession && data.session != null);
    if (signedIn) {
      PushService.syncIfGranted();
      // Riwayat Belajar Mandarin & Sehat Rantau ikut akun (gabung perangkat ↔ akun).
      LiuliSync.start();
      SehatSync.start();
    }
    // Belum masuk → mode tamu: fitur tetap jalan, riwayat tidak disimpan.
    if (data.event == AuthChangeEvent.initialSession && data.session == null) {
      LiuliSync.stop();
      SehatSync.stop();
    }
    // Keluar akun → hapus riwayat di perangkat (tetap aman di akun).
    if (data.event == AuthChangeEvent.signedOut) {
      LiuliSync.signOut();
      SehatSync.signOut();
    }
  });
  runApp(const NihaoApp());
}

final _router = GoRouter(
  initialLocation: _appInitialLocation,
  refreshListenable: _AuthNotifier(),
  redirect: (context, state) {
    final loc = state.matchedLocation;
    if (loc == '/') return '/beranda';
    final loggedIn = Supabase.instance.client.auth.currentSession != null;
    final onAuthPage = loc == '/login' || loc == '/daftar';
    // Halaman yang wajib login: pesanan, dokumen, dan pembuatan booking.
    final needsAuth = loc.startsWith('/pesanan') ||
        loc.startsWith('/dokumen') ||
        loc.startsWith('/admin') ||
        loc.startsWith('/jadi-penerjemah') ||
        loc.startsWith('/tes-penerjemah') ||
        loc.startsWith('/pesan/') ||
        (loc.endsWith('/pesan') && loc != '/pesan');
    // Sudah masuk di halaman login/daftar → kembali ke fitur asal (?next=).
    if (loggedIn && onAuthPage) {
      return safeNext(state.uri.queryParameters['next']);
    }
    if (!loggedIn && needsAuth) {
      return '/login${nextQuery(loc)}';
    }
    return null;
  },
  routes: [
    GoRoute(path: '/onboarding', builder: (_, __) => const OnboardingScreen()),
    GoRoute(
      path: '/login',
      builder: (_, s) => LoginScreen(next: s.uri.queryParameters['next']),
    ),
    GoRoute(
      path: '/daftar',
      builder: (_, s) => RegisterScreen(next: s.uri.queryParameters['next']),
    ),
    GoRoute(
      path: '/bantuan',
      builder: (_, __) => const ResponsivePageFrame(child: HelpScreen()),
    ),
    // Fitur gabungan: Sehat Rantau & Liúlì (punya scaffold + nav responsif sendiri).
    GoRoute(path: '/sehat', builder: (_, __) => const SehatApp()),
    GoRoute(path: '/belajar', builder: (_, __) => const LiuliApp()),
    // Darurat/SOS — publik (bisa diakses tanpa login saat genting).
    GoRoute(
      path: '/darurat',
      builder: (_, __) => const ResponsivePageFrame(child: EmergencyScreen()),
    ),
    // Halaman yang butuh login penuh (di luar shell, punya tombol kembali).
    GoRoute(
      path: '/pesanan',
      builder: (_, __) => const ResponsivePageFrame(child: BookingsScreen()),
      routes: [
        GoRoute(
          path: ':id',
          builder: (_, s) => ResponsivePageFrame(
            child: BookingDetailScreen(bookingId: s.pathParameters['id']!),
          ),
        ),
      ],
    ),
    GoRoute(
      path: '/dokumen',
      builder: (_, __) => const ResponsivePageFrame(child: DocumentsScreen()),
      routes: [
        GoRoute(
          path: 'tambah',
          builder: (_, __) =>
              const ResponsivePageFrame(child: AddDocumentScreen()),
        ),
      ],
    ),
    // Panel admin (hanya untuk role admin — ditegakkan RLS di database).
    GoRoute(
      path: '/admin',
      builder: (_, __) =>
          const ResponsivePageFrame(child: AdminDashboardScreen()),
      routes: [
        GoRoute(
          path: 'penerjemah',
          builder: (_, __) =>
              const ResponsivePageFrame(child: AdminInterpretersScreen()),
        ),
        GoRoute(
          path: 'pengguna',
          builder: (_, __) =>
              const ResponsivePageFrame(child: AdminUsersScreen()),
        ),
        GoRoute(
          path: 'berita',
          builder: (_, __) =>
              const ResponsivePageFrame(child: AdminNewsScreen()),
        ),
        GoRoute(
          path: 'pesanan',
          builder: (_, __) =>
              const ResponsivePageFrame(child: AdminBookingsScreen()),
        ),
        GoRoute(
          path: 'tempat',
          builder: (_, __) =>
              const ResponsivePageFrame(child: AdminPlacesScreen()),
        ),
      ],
    ),
    GoRoute(
      path: '/jadi-penerjemah',
      builder: (_, __) =>
          const ResponsivePageFrame(child: BecomeInterpreterScreen()),
    ),
    GoRoute(
      path: '/tes-penerjemah',
      builder: (_, __) =>
          const ResponsivePageFrame(child: InterpreterTestScreen()),
    ),
    // Notifikasi dibuka dari lonceng di Beranda.
    GoRoute(
      path: '/notifikasi',
      builder: (_, __) =>
          const ResponsivePageFrame(child: NotificationsScreen()),
    ),
    // Shell utama dengan navigasi responsif (Sidebar Desktop & Bottom Nav Mobile).
    StatefulShellRoute.indexedStack(
      builder: (_, __, shell) => HomeShell(shell: shell),
      branches: [
        StatefulShellBranch(routes: [
          GoRoute(path: '/beranda', builder: (_, __) => const HomeScreen()),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(
            path: '/cari',
            builder: (_, __) => const SearchScreen(),
            routes: [
              GoRoute(path: 'peta', builder: (_, __) => const MapScreen()),
              GoRoute(
                path: 'penerjemah/:id',
                builder: (_, s) => InterpreterDetailScreen(
                  interpreterId: s.pathParameters['id']!,
                ),
                routes: [
                  GoRoute(
                    path: 'pesan',
                    builder: (_, s) => CreateBookingScreen(
                      interpreterId: s.pathParameters['id']!,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(
            path: '/kalender',
            builder: (_, __) => const CalendarScreen(),
          ),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(
            path: '/pesan',
            builder: (_, __) => const MessagesScreen(),
            routes: [
              GoRoute(
                path: ':cid',
                builder: (_, s) => ChatScreen(
                  conversationId: s.pathParameters['cid']!,
                  otherName: s.extra as String?,
                ),
              ),
            ],
          ),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: '/akun', builder: (_, __) => const AccountScreen()),
        ]),
      ],
    ),
  ],
);

class _AuthNotifier extends ChangeNotifier {
  _AuthNotifier() {
    Supabase.instance.client.auth.onAuthStateChange
        .listen((_) => notifyListeners());
  }
}

/// Pembungkus halaman mandiri (di luar HomeShell) agar di Desktop tampil
/// rapi dengan Top Navbar PENGYOU + kontainer terpusat, dan di Mobile tampil
/// penuh seperti biasa.
class ResponsivePageFrame extends StatelessWidget {
  const ResponsivePageFrame({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    if (!AppBreakpoints.isDesktop(context)) return child;
    return ColoredBox(
      color: AppColors.surfaceTint,
      child: Column(
        children: [
          Container(
            height: 68,
            padding: const EdgeInsets.symmetric(horizontal: 28),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(bottom: BorderSide(color: AppColors.line, width: 2)),
            ),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1080),
                child: Row(
                  children: [
                    InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => context.go('/beranda'),
                      child: const PengyouLogo(size: 36),
                    ),
                    const Spacer(),
                    const LangPillSwitcher(),
                    const SizedBox(width: 12),
                    DuoButton(
                      label: 'Ke Beranda',
                      icon: Icons.home_rounded,
                      compact: true,
                      backgroundColor: Colors.white,
                      foregroundColor: AppColors.primary,
                      borderColor: AppColors.line,
                      lipColor: AppColors.line,
                      onPressed: () => context.go('/beranda'),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: Align(
              alignment: Alignment.topCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 960),
                child: child,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class NihaoApp extends StatelessWidget {
  const NihaoApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Rebuild seluruh aplikasi saat bahasa diganti.
    return ValueListenableBuilder<String>(
      valueListenable: Lang.instance,
      builder: (context, _, __) => MaterialApp.router(
        title: 'PENGYOU — Teman Pendamping Hidup di Taiwan',
        debugShowCheckedModeBanner: false,
        theme: buildAppTheme(),
        routerConfig: _router,
      ),
    );
  }
}
