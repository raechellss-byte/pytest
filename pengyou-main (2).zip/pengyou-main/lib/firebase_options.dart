import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

/// Opsi Firebase untuk PENGYOU (project `pengyou-3d147`).
/// Fokus web dulu; kalau nanti build Android, tambahkan opsi Android via
/// `flutterfire configure`. Nilai ini publik (bukan rahasia).
class DefaultFirebaseOptions {
  static FirebaseOptions get web => const FirebaseOptions(
        apiKey: 'AIzaSyCZo0wZmH2srsCSNGmic9UTfmjbmXuL8AI',
        appId: '1:91670127733:web:e7af33ae55c2fb0108843c',
        messagingSenderId: '91670127733',
        projectId: 'pengyou-3d147',
        authDomain: 'pengyou-3d147.firebaseapp.com',
        storageBucket: 'pengyou-3d147.firebasestorage.app',
      );
}
