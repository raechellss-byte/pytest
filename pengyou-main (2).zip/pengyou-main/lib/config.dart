/// Konfigurasi Supabase.
///
/// Isi lewat --dart-define saat menjalankan:
/// flutter run --dart-define=SUPABASE_URL=https://xxx.supabase.co \
///             --dart-define=SUPABASE_ANON_KEY=eyJ...
class AppConfig {
  static const supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://nxjkkkqoewwdxenjvtjq.supabase.co',
  );
  // Kunci "publishable" Supabase (aman untuk browser/app — dilindungi RLS).
  static const supabasePublishableKey = String.fromEnvironment(
    'SUPABASE_PUBLISHABLE_KEY',
    defaultValue: 'sb_publishable_UdCyX_RIALJSZ3AhPQm2_w_vvXg7wuS',
  );

  static bool get isConfigured =>
      !supabaseUrl.contains('YOUR-PROJECT') &&
      supabasePublishableKey.startsWith('sb_');

  // ---- Firebase Cloud Messaging (push notification, web) ----
  // VAPID key publik dari Firebase → Project settings → Cloud Messaging →
  // Web Push certificates. Aman ditaruh di kode (kunci publik).
  static const firebaseVapidKey = String.fromEnvironment(
    'FIREBASE_VAPID_KEY',
    defaultValue:
        'BEG80jQaoAlvCDZYrV6IDvcmv0zJsuJWRITsf_80oWjjyFl1F7IIFM5kFzBXwUr4wKTkJy_IHBQoMWu2tAE-X5k',
  );

  /// Push aktif hanya bila VAPID key sudah diisi.
  static bool get pushConfigured => !firebaseVapidKey.startsWith('PASTE_');

  /// Fallback kota jika izin lokasi ditolak (fokus MVP: Taichung).
  static const cities = <String, (double lat, double lng)>{
    'Taichung': (24.1477, 120.6736),
    'Taipei': (25.0330, 121.5654),
    'Taoyuan': (24.9936, 121.3010),
    'Kaohsiung': (22.6273, 120.3014),
    'Tainan': (22.9999, 120.2270),
    'Hsinchu': (24.8138, 120.9675),
  };
}
