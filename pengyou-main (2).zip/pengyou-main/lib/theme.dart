import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import 'i18n/strings.dart';

/// Palet PENGYOU — diselaraskan 100% dengan website marketing (`webcontoh`)
/// dan terinspirasi gaya taktil Duolingo & Brilliant.org.
class AppColors {
  // Brand utama (Teal PENGYOU dari webcontoh)
  static const primary = Color(0xFF0F766E); // --teal
  static const primaryDark = Color(0xFF0B5A54); // --teal-d
  static const primaryLight = Color(0xFFD9F2EE); // --teal-l

  // Aksen & status
  static const accent = Color(0xFFF4A73B); // --amber
  static const accentDark = Color(0xFFCF8A1F);
  static const accentLight = Color(0xFFFDF0D8); // --amber-l
  static const coral = Color(0xFFEF6F5E); // --coral
  static const danger = Color(0xFFC0392B);
  static const info = Color(0xFF0F766E);

  // Permukaan, garis & teks (webcontoh)
  static const surfaceTint = Color(0xFFFBFAF6); // --bg (krem hangat)
  static const card = Colors.white; // --card
  static const line = Color(0xFFE6E9E4); // --line (border 2px khas Duolingo/Brilliant)
  static const lineDark = Color(0xFFD2D7CF);
  static const ink = Color(0xFF16302E); // --ink
  static const muted = Color(0xFF4F6663); // --muted

  // Ubin pastel (t1, t2, t3, t4 dari webcontoh)
  static const greenSoft = Color(0xFFE1F3D8); // --green-l
  static const greenInk = Color(0xFF2E6B1E);
  static const amberSoft = Color(0xFFFDF0D8); // --amber-l
  static const amberInk = Color(0xFF9A6208);
  static const roseSoft = Color(0xFFFDE4E1); // --rose-l
  static const roseInk = Color(0xFFB0392B);
  static const violetSoft = Color(0xFFE9E4FB); // --violet-l
  static const violetInk = Color(0xFF5B3FC4);
  static const tealSoft = Color(0xFFD9F2EE); // --teal-l
  static const tealInk = Color(0xFF0F766E);
  static const blueSoft = Color(0xFFE1EDF8);
  static const blueInk = Color(0xFF1E5E9E);

  /// Warna per kategori berita/fitur.
  static const categoryColors = <String, Color>{
    'Kejadian': Color(0xFFEF6F5E),
    'Kebijakan PMI': Color(0xFF5B3FC4),
    'Taiwan': Color(0xFF2563EB),
    'Kesehatan': Color(0xFF0F766E),
    'Dokumen': Color(0xFFD97706),
    'Layanan': Color(0xFF0891B2),
    'Ketenagakerjaan': Color(0xFFCA8A04),
    'Wisata': Color(0xFFDB2777),
  };

  static Color category(String? name) =>
      categoryColors[name] ?? const Color(0xFF0F766E);
}

/// Breakpoint responsif aplikasi web (Mobile vs Desktop).
class AppBreakpoints {
  static const double mobileMax = 840;
  static const double desktopWide = 1140;

  static bool isDesktop(BuildContext context) =>
      MediaQuery.of(context).size.width >= mobileMax;

  static bool isWideDesktop(BuildContext context) =>
      MediaQuery.of(context).size.width >= desktopWide;
}

ThemeData buildAppTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.primary,
    primary: AppColors.primary,
    secondary: AppColors.accent,
    surface: Colors.white,
  );

  // Font Nunito seperti di webcontoh (--font: 'Nunito', system-ui, sans-serif)
  final baseText = GoogleFonts.nunitoTextTheme();

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.surfaceTint,
    textTheme: baseText.apply(
      bodyColor: AppColors.ink,
      displayColor: AppColors.ink,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: AppColors.surfaceTint,
      foregroundColor: AppColors.ink,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: GoogleFonts.nunito(
        fontSize: 21,
        fontWeight: FontWeight.w900,
        color: AppColors.ink,
        letterSpacing: -0.3,
      ),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: Colors.white,
      shadowColor: AppColors.ink.withValues(alpha: 0.06),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: const BorderSide(color: AppColors.line, width: 2),
      ),
      margin: const EdgeInsets.symmetric(vertical: 6),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      hintStyle: const TextStyle(
        color: AppColors.muted,
        fontWeight: FontWeight.w600,
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.line, width: 2),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.line, width: 2),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.primary, width: 2.2),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        textStyle: GoogleFonts.nunito(
          fontSize: 15.5,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.2,
        ),
        elevation: 0,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(50),
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        side: const BorderSide(color: AppColors.line, width: 2),
        foregroundColor: AppColors.primary,
        textStyle: GoogleFonts.nunito(
          fontSize: 15,
          fontWeight: FontWeight.w800,
        ),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: AppColors.primary,
        textStyle: GoogleFonts.nunito(fontWeight: FontWeight.w800),
      ),
    ),
    segmentedButtonTheme: SegmentedButtonThemeData(
      style: SegmentedButton.styleFrom(
        selectedBackgroundColor: AppColors.primary,
        selectedForegroundColor: Colors.white,
        foregroundColor: AppColors.muted,
        side: const BorderSide(color: AppColors.line, width: 2),
        textStyle: GoogleFonts.nunito(fontWeight: FontWeight.w800),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      indicatorColor: AppColors.primaryLight,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      height: 68,
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return GoogleFonts.nunito(
          fontSize: 12,
          fontWeight: selected ? FontWeight.w900 : FontWeight.w700,
          color: selected ? AppColors.primary : AppColors.muted,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return IconThemeData(
          color: selected ? AppColors.primary : AppColors.muted,
          size: 24,
        );
      }),
    ),
    chipTheme: ChipThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
      side: const BorderSide(color: AppColors.line, width: 1.5),
      backgroundColor: AppColors.primaryLight.withValues(alpha: 0.55),
      labelStyle: GoogleFonts.nunito(
        fontWeight: FontWeight.w800,
        color: AppColors.primaryDark,
      ),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: AppColors.primary,
      foregroundColor: Colors.white,
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: AppColors.ink,
      contentTextStyle: GoogleFonts.nunito(
        color: Colors.white,
        fontWeight: FontWeight.w700,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    dividerTheme: const DividerThemeData(
      color: AppColors.line,
      thickness: 1.5,
    ),
  );
}

/// Logo resmi PENGYOU yang identik dengan website marketing (`webcontoh`):
/// Kotak teal membulat dengan huruf `朋` + tulisan `PENGYOU`.
class PengyouLogo extends StatelessWidget {
  const PengyouLogo({
    super.key,
    this.dark = false,
    this.size = 38,
    this.subtitle,
  });

  final bool dark;
  final double size;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    final markBg = dark ? Colors.white : AppColors.primary;
    final markFg = dark ? AppColors.primary : Colors.white;
    final textColor = dark ? Colors.white : AppColors.primary;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: markBg,
            borderRadius: BorderRadius.circular(size * 0.32),
            boxShadow: [
              BoxShadow(
                color: dark
                    ? Colors.black.withValues(alpha: 0.18)
                    : AppColors.primaryDark,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Text(
            '朋',
            style: TextStyle(
              color: markFg,
              fontSize: size * 0.52,
              fontWeight: FontWeight.w900,
              height: 1.0,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'PENGYOU',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: GoogleFonts.nunito(
                  color: textColor,
                  fontSize: size * 0.54,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.3,
                  height: 1.05,
                ),
              ),
              if (subtitle != null)
                Text(
                  subtitle!,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.nunito(
                    color: dark
                        ? Colors.white.withValues(alpha: 0.78)
                        : AppColors.muted,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

/// Pemilih bahasa bergaya pil seperti di navbar `webcontoh` (ID | EN | 中文).
class LangPillSwitcher extends StatelessWidget {
  const LangPillSwitcher({super.key, this.onDark = false});

  final bool onDark;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: Lang.instance,
      builder: (context, current, _) {
        const items = [('id', 'ID'), ('en', 'EN'), ('zh', '中文')];
        return Container(
          decoration: BoxDecoration(
            color: onDark
                ? Colors.white.withValues(alpha: 0.14)
                : Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: onDark
                  ? Colors.white.withValues(alpha: 0.28)
                  : AppColors.line,
              width: 2,
            ),
          ),
          clipBehavior: Clip.antiAlias,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final (code, label) in items)
                InkWell(
                  onTap: () => Lang.instance.set(code),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 9,
                      vertical: 5,
                    ),
                    color: current == code
                        ? (onDark ? Colors.white : AppColors.primary)
                        : Colors.transparent,
                    child: Text(
                      label,
                      style: GoogleFonts.nunito(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w900,
                        color: current == code
                            ? (onDark ? AppColors.primaryDark : Colors.white)
                            : (onDark
                                ? Colors.white.withValues(alpha: 0.85)
                                : AppColors.muted),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

/// Kartu bergaya Duolingo / Brilliant.org dengan border 2px tegas & efek
/// bibir bawah taktil (3D lip).
class DuoCard extends StatelessWidget {
  const DuoCard({
    super.key,
    required this.child,
    this.onTap,
    this.padding = const EdgeInsets.all(18),
    this.color = Colors.white,
    this.borderColor = AppColors.line,
    this.lipColor,
    this.radius = 22,
    this.margin,
  });

  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry padding;
  final Color color;
  final Color borderColor;
  final Color? lipColor;
  final double radius;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    final effectiveLip = lipColor ?? borderColor;
    return Container(
      margin: margin,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderColor, width: 2),
        boxShadow: [
          BoxShadow(
            color: effectiveLip,
            offset: const Offset(0, 3),
            blurRadius: 0,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(radius - 2),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(radius - 2),
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

/// Tombol taktil 3D ala Duolingo & `webcontoh` (`.btn--primary` / `.btn--ghost`).
class DuoButton extends StatelessWidget {
  const DuoButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.backgroundColor = AppColors.primary,
    this.lipColor = AppColors.primaryDark,
    this.foregroundColor = Colors.white,
    this.borderColor,
    this.compact = false,
    this.expanded = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final Color backgroundColor;
  final Color lipColor;
  final Color foregroundColor;
  final Color? borderColor;
  final bool compact;
  final bool expanded;

  @override
  Widget build(BuildContext context) {
    final content = Row(
      mainAxisSize: expanded ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (icon != null) ...[
          Icon(icon, size: compact ? 17 : 19, color: foregroundColor),
          const SizedBox(width: 7),
        ],
        Flexible(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.nunito(
              color: foregroundColor,
              fontSize: compact ? 13.5 : 15,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.2,
            ),
          ),
        ),
      ],
    );

    return Container(
      width: expanded ? double.infinity : null,
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(compact ? 13 : 16),
        border: borderColor != null
            ? Border.all(color: borderColor!, width: 2)
            : null,
        boxShadow: [
          BoxShadow(
            color: lipColor,
            offset: const Offset(0, 3.5),
            blurRadius: 0,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(compact ? 13 : 16),
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(compact ? 13 : 16),
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: compact ? 14 : 20,
              vertical: compact ? 9 : 13,
            ),
            child: content,
          ),
        ),
      ),
    );
  }
}

/// Header bergradasi Teal PENGYOU — serasi dengan `webcontoh`.
class GradientHeader extends StatelessWidget {
  const GradientHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.icon,
    this.child,
    this.showBack = false,
    this.trailing,
  });

  final String title;
  final String? subtitle;
  final IconData? icon;
  final Widget? child;
  final bool showBack;
  final Widget? trailing;

  void _handleBack(BuildContext context) {
    final nav = Navigator.of(context);
    if (nav.canPop()) {
      nav.pop();
    } else {
      GoRouter.maybeOf(context)?.go('/beranda');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDesktop = AppBreakpoints.isDesktop(context);
    return Container(
      width: double.infinity,
      margin: isDesktop ? const EdgeInsets.fromLTRB(20, 16, 20, 0) : null,
      padding: EdgeInsets.fromLTRB(
        isDesktop ? 28 : 20,
        isDesktop ? 24 : 20,
        isDesktop ? 28 : 20,
        26,
      ),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            AppColors.primaryDark,
            AppColors.primary,
            Color(0xFF14A094),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: isDesktop
            ? BorderRadius.circular(28)
            : const BorderRadius.vertical(bottom: Radius.circular(30)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryDark.withValues(alpha: 0.18),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Stack(
        children: [
          // Lingkaran dekoratif transparan (seperti blob di webcontoh)
          Positioned(
            right: -30,
            top: -40,
            child: Container(
              width: 130,
              height: 130,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.accent.withValues(alpha: 0.14),
              ),
            ),
          ),
          Positioned(
            left: -25,
            bottom: -35,
            child: Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.07),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (showBack)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Material(
                      color: Colors.white.withValues(alpha: 0.16),
                      borderRadius: BorderRadius.circular(12),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: () => _handleBack(context),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.arrow_back_rounded,
                                color: Colors.white,
                                size: 18,
                              ),
                              SizedBox(width: 6),
                              Text(
                                'Kembali',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              Row(
                children: [
                  if (icon != null) ...[
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.18),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.24),
                        ),
                      ),
                      child: Icon(icon, color: Colors.white, size: 26),
                    ),
                    const SizedBox(width: 14),
                  ],
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: GoogleFonts.nunito(
                            color: Colors.white,
                            fontSize: isDesktop ? 26 : 23,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.4,
                            height: 1.15,
                          ),
                        ),
                        if (subtitle != null) ...[
                          const SizedBox(height: 3),
                          Text(
                            subtitle!,
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.9),
                              fontSize: 13.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (trailing != null) trailing!,
                ],
              ),
              if (child != null) ...[const SizedBox(height: 18), child!],
            ],
          ),
        ],
      ),
    );
  }
}

/// Empty state dengan ikon besar bergaya ramah.
class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.message});
  final IconData icon;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(40),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(26),
            decoration: BoxDecoration(
              color: AppColors.primaryLight,
              shape: BoxShape.circle,
              border: Border.all(
                color: AppColors.primary.withValues(alpha: 0.2),
                width: 2,
              ),
            ),
            child: Icon(icon, size: 54, color: AppColors.primary),
          ),
          const SizedBox(height: 20),
          Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 15,
              color: AppColors.muted,
              fontWeight: FontWeight.w700,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}

/// Avatar berwarna konsisten berdasarkan nama.
class NameAvatar extends StatelessWidget {
  const NameAvatar({super.key, required this.name, this.radius = 24});
  final String name;
  final double radius;

  static const _palette = [
    Color(0xFF0F766E),
    Color(0xFF5B3FC4),
    Color(0xFF2563EB),
    Color(0xFFD97706),
    Color(0xFF2E6B1E),
    Color(0xFFDB2777),
  ];

  @override
  Widget build(BuildContext context) {
    final color = _palette[name.hashCode.abs() % _palette.length];
    return Container(
      width: radius * 2,
      height: radius * 2,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color, color.withValues(alpha: 0.75)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        shape: BoxShape.circle,
      ),
      alignment: Alignment.center,
      child: Text(
        name.isEmpty ? '?' : name.substring(0, 1).toUpperCase(),
        style: GoogleFonts.nunito(
          color: Colors.white,
          fontWeight: FontWeight.w900,
          fontSize: radius * 0.82,
        ),
      ),
    );
  }
}
