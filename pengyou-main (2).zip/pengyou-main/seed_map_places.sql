-- ============================================================
-- SEED: map_places — Lembaga / Imigrasi / RS / Stasiun untuk banyak kota
-- Jalankan di: Supabase Dashboard proyek zhuanti → SQL Editor → Run.
-- (SQL Editor berjalan sebagai admin, jadi RLS map_places tidak menghalangi.)
--
-- CATATAN PENTING:
--  • Koordinat di sini PERKIRAAN (level pusat kota / landmark). Sudah cukup untuk
--    menampilkan pin, tetapi sebaiknya diperbaiki lewat Table Editor bila perlu
--    presisi. Rute tetap akurat karena pakai alamat.
--  • Semua entri adalah tempat/instansi publik nyata yang berguna untuk PMI —
--    bukan bisnis fiktif. Verifikasi ulang alamat sebelum diandalkan.
--  • Skrip ini AMAN dijalankan ulang (idempotent): baris dengan nama sama tidak
--    akan terduplikasi.
-- ============================================================

-- Cegah duplikat saat skrip dijalankan ulang (indeks unik pada nama).
create unique index if not exists map_places_name_uniq
  on public.map_places (name);

insert into public.map_places (name, category, lat, lng, address, note) values
-- ---------- IMIGRASI (NIA 移民署 — layanan ARC & izin tinggal) ----------
('Kantor Imigrasi Taipei (NIA)', 'immigration', 25.0369, 121.5064,
  'No. 15, Guangzhou St, Zhongzheng, Taipei City', 'Layanan ARC & izin tinggal'),
('Kantor Imigrasi New Taipei (NIA)', 'immigration', 25.0116, 121.4585,
  'Banqiao District, New Taipei City', 'Layanan ARC & izin tinggal'),
('Kantor Imigrasi Taoyuan (NIA)', 'immigration', 24.9937, 121.3009,
  'Taoyuan District, Taoyuan City', 'Layanan ARC & izin tinggal'),
('Kantor Imigrasi Hsinchu (NIA)', 'immigration', 24.8036, 120.9686,
  'North District, Hsinchu City', 'Layanan ARC & izin tinggal'),
('Kantor Imigrasi Changhua (NIA)', 'immigration', 24.0762, 120.5390,
  'Changhua City, Changhua County', 'Layanan ARC & izin tinggal'),
('Kantor Imigrasi Tainan (NIA)', 'immigration', 22.9908, 120.2140,
  'East District, Tainan City', 'Layanan ARC & izin tinggal'),
('Kantor Imigrasi Kaohsiung (NIA)', 'immigration', 22.6270, 120.3010,
  'Zhenxing Rd, Lingya, Kaohsiung City', 'Layanan ARC & izin tinggal'),
('Kantor Imigrasi Pingtung (NIA)', 'immigration', 22.6690, 120.4870,
  'Pingtung City, Pingtung County', 'Layanan ARC & izin tinggal'),

-- ---------- LEMBAGA / PENDAMPING (agency) ----------
('KDEI Taipei (Kantor Dagang & Ekonomi Indonesia)', 'agency', 25.0798, 121.5760,
  'Ruiguang Rd, Neihu, Taipei City',
  'Perwakilan RI di Taiwan — bantuan dokumen, ketenagakerjaan, perlindungan WNI'),
('Pusat Layanan Pekerja Migran Taipei', 'agency', 25.0418, 121.5410,
  'Taipei City', 'Konsultasi pekerja migran (Dinas Tenaga Kerja) — ada penerjemah'),
('Pusat Layanan Pekerja Migran Taoyuan', 'agency', 24.9930, 121.3010,
  'Taoyuan City', 'Konsultasi & pendampingan pekerja migran'),
('Pusat Layanan Pekerja Migran Taichung', 'agency', 24.1490, 120.6740,
  'Taichung City', 'Konsultasi & pendampingan pekerja migran'),

-- ---------- RUMAH SAKIT BESAR (hospital) ----------
('National Taiwan University Hospital', 'hospital', 25.0410, 121.5190,
  'Zhongzheng District, Taipei City', 'RS rujukan besar di Taipei'),
('Taipei Veterans General Hospital', 'hospital', 25.1205, 121.5200,
  'Beitou District, Taipei City', 'RS besar di Taipei utara'),
('Far Eastern Memorial Hospital', 'hospital', 25.0006, 121.4519,
  'Banqiao District, New Taipei City', 'RS besar di New Taipei'),
('Chang Gung Memorial Hospital, Linkou', 'hospital', 25.0360, 121.3830,
  'Guishan District, Taoyuan City', 'RS rujukan terbesar di utara'),
('National Taiwan University Hospital Hsinchu', 'hospital', 24.8060, 120.9700,
  'Hsinchu City', 'RS besar di Hsinchu'),
('Changhua Christian Hospital', 'hospital', 24.0836, 120.5453,
  'Changhua City', 'RS besar di Changhua'),
('National Cheng Kung University Hospital', 'hospital', 22.9979, 120.2210,
  'North District, Tainan City', 'RS rujukan besar di Tainan'),
('Chi Mei Medical Center', 'hospital', 22.9430, 120.2110,
  'Yongkang District, Tainan City', 'RS besar di Tainan'),
('Kaohsiung Medical University Hospital', 'hospital', 22.6470, 120.3080,
  'Sanmin District, Kaohsiung City', 'RS besar di Kaohsiung'),
('Kaohsiung Veterans General Hospital', 'hospital', 22.7250, 120.3130,
  'Zuoying District, Kaohsiung City', 'RS besar di Kaohsiung'),

-- ---------- STASIUN UTAMA (station) ----------
('Stasiun Taipei (Taipei Main Station)', 'station', 25.0478, 121.5170,
  'Zhongzheng District, Taipei City', 'Hub TRA/HSR/MRT'),
('Stasiun Banqiao (New Taipei)', 'station', 25.0143, 121.4636,
  'Banqiao District, New Taipei City', 'Hub TRA/HSR/MRT'),
('Stasiun Taoyuan (TRA)', 'station', 24.9890, 121.3140,
  'Taoyuan District, Taoyuan City', 'Stasiun utama'),
('Stasiun Hsinchu (TRA)', 'station', 24.8017, 120.9718,
  'North District, Hsinchu City', 'Stasiun utama'),
('Stasiun HSR Taichung (Wuri)', 'station', 24.1124, 120.6156,
  'Wuri District, Taichung City', 'Stasiun kereta cepat'),
('Stasiun Tainan (TRA)', 'station', 22.9970, 120.2130,
  'East District, Tainan City', 'Stasiun utama'),
('Stasiun Kaohsiung (Kaohsiung Main Station)', 'station', 22.6396, 120.3020,
  'Sanmin District, Kaohsiung City', 'Hub TRA/HSR/MRT')

on conflict (name) do nothing;

-- Selesai. Buka tab Peta di aplikasi → filter kategori & pin akan muncul.
