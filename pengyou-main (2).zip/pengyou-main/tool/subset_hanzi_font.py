"""Buat font hanzi Belajar Mandarin (assets/fonts/LiuliHanzi-*.ttf).

Tanpa font sendiri, CanvasKit (Flutter web) mengunduh potongan Noto Sans
SC/HK/KR dari Google satu per satu setiap ada huruf baru, lalu memasang ulang
semua font & mengatur ulang semua teks -> layar tersendat saat menggulir.
Di sini Noto Sans TC (bentuk huruf Taiwan) dipangkas ke huruf yang dipakai
app saja (materi Liuli kecuali kamus 25.000 kata, teks di lib/, + bentuk
sederhananya), dalam dua ketebalan.

Pakai (dari folder proyek), jalankan ulang bila materi Liuli bertambah:
  python tool/subset_hanzi_font.py <NotoSansTC[wght].ttf>
Sumber: https://github.com/google/fonts/tree/main/ofl/notosanstc (OFL 1.1).
Butuh: pip install fonttools
"""
import glob
import io
import json
import os
import sys
import unicodedata

from fontTools import subset
from fontTools.ttLib import TTFont
from fontTools.varLib import instancer

WEIGHTS = {"Regular": 400, "Bold": 700}
OUT_DIR = os.path.join("assets", "fonts")
# Kamus lengkap & tabel konversi tidak dimasukkan (terlalu besar); huruf yang
# tidak ada di font ini tetap tampil lewat font cadangan otomatis CanvasKit.
SKIP = {"dict.json", "t2s.json"}


def used_chars():
    text = []
    for f in sorted(glob.glob(os.path.join("assets", "liuli", "*.json"))):
        if os.path.basename(f) not in SKIP:
            text.append(open(f, encoding="utf-8").read())
    for f in glob.glob(os.path.join("lib", "**", "*.dart"), recursive=True):
        text.append(open(f, encoding="utf-8").read())
    chars = {c for c in "".join(text) if ord(c) >= 0x80}
    t2s = json.load(open(os.path.join("assets", "liuli", "t2s.json"), encoding="utf-8"))
    chars |= {t2s[c] for c in chars if c in t2s}  # mode huruf sederhana
    # Tanda baca CJK & lebar penuh selalu ikut.
    chars |= {chr(c) for c in range(0x3000, 0x3040)}
    chars |= {chr(c) for c in range(0xFF01, 0xFF5F)}
    # Emoji dibiarkan ke Noto Color Emoji.
    return {c for c in chars if unicodedata.category(c) != "So" or ord(c) < 0x2000}


def main(src):
    chars = used_chars()
    base = TTFont(src)
    cmap = base.getBestCmap()
    keep = sorted(ord(c) for c in chars if ord(c) in cmap)
    hanzi = sum(1 for u in keep if 0x3400 <= u <= 0x9FFF)
    print(f"{len(keep)} karakter ({hanzi} hanzi) dari {len(chars)} yang dipakai")
    os.makedirs(OUT_DIR, exist_ok=True)
    for name, wght in WEIGHTS.items():
        font = instancer.instantiateVariableFont(TTFont(src), {"wght": wght})
        opts = subset.Options()
        opts.layout_features = ["*"]
        opts.hinting = False
        opts.name_IDs = ["*"]
        sub = subset.Subsetter(opts)
        sub.populate(unicodes=keep)
        sub.subset(font)
        font["OS/2"].usWeightClass = wght
        out = os.path.join(OUT_DIR, f"LiuliHanzi-{name}.ttf")
        buf = io.BytesIO()
        font.save(buf)
        open(out, "wb").write(buf.getvalue())
        print(f"{out}: {len(buf.getvalue()) // 1024} KB")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
