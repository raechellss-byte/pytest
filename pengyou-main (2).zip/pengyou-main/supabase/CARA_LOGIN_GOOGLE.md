# Cara mengaktifkan Login dengan Google

Tombol "Masuk/Daftar dengan Google" sudah ada di aplikasi. Agar berfungsi,
lakukan pengaturan berikut **sekali**.

## Bagian A — Google Cloud Console

1. Buka **https://console.cloud.google.com** → buat proyek baru (mis. "PENGYOU").
2. Menu **APIs & Services → OAuth consent screen**:
   - Pilih **External** → Create.
   - Isi: App name = `PENGYOU`, User support email = email Anda, Developer email.
   - Scopes: cukup default (email, profile). Save.
   - Bagian **Audience/Publishing**: klik **Publish app** agar semua orang bisa
     login (kalau masih "Testing", hanya email yang Anda daftarkan sebagai
     test user yang bisa masuk).
3. Menu **APIs & Services → Credentials → Create Credentials → OAuth client ID**:
   - Application type: **Web application**.
   - **Authorized JavaScript origins**:
     - `https://pengyouapp.netlify.app`
   - **Authorized redirect URIs** (SALIN dari Supabase — lihat Bagian B):
     - `https://nxjkkkqoewwdxenjvtjq.supabase.co/auth/v1/callback`
   - Create → **salin Client ID dan Client Secret**.

## Bagian B — Supabase

1. Buka Supabase → **Authentication → Sign In / Providers**.
2. Cari **Google** → aktifkan (Enable).
3. Tempel **Client ID** dan **Client Secret** dari Google tadi.
4. Di halaman itu ada **Callback URL (for OAuth)** — pastikan nilainya
   `https://nxjkkkqoewwdxenjvtjq.supabase.co/auth/v1/callback`. Itulah yang
   dimasukkan ke "Authorized redirect URIs" di Google (Bagian A langkah 3).
5. Save.
6. Pastikan **Authentication → URL Configuration → Site URL** =
   `https://pengyouapp.netlify.app` (sudah diatur sebelumnya).

## Bagian C — Deploy & uji

1. Drop folder `build/web` ke Netlify (versi terbaru sudah ada tombol Google).
2. Buka situs → klik **Masuk dengan Google** → pilih akun → otomatis kembali
   dan masuk.

## Catatan

- Pengguna yang masuk lewat Google otomatis jadi peran **client**. Kalau ada
  yang ingin jadi **penerjemah**, untuk sekarang daftar lewat email (yang ada
  pilihan peran), atau nanti kita buatkan halaman "jadi penerjemah" setelah login.
- Login Google ini untuk versi **web**. Untuk aplikasi Android nanti perlu
  konfigurasi tambahan (deep link) — dibahas terpisah saat masuk fase mobile.
