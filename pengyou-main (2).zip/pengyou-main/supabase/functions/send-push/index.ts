// ============================================================
// Edge Function: send-push
// Mengirim push notification (FCM HTTP v1) ke token di tabel `push_tokens`.
//
// Butuh SECRET di env Supabase:
//   FCM_SERVICE_ACCOUNT  = isi file service account Firebase (JSON), boleh
//                          mentah ATAU di-base64 (disarankan base64 biar 1 baris).
//   (SUPABASE_URL & SUPABASE_SERVICE_ROLE_KEY otomatis tersedia.)
//
// Cara panggil (POST, body JSON):
//   { "title": "Judul", "body": "Isi pesan", "user_ids": ["uuid", ...] }
//   - user_ids opsional; kalau kosong → kirim ke SEMUA token.
// ============================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const PROJECT_ID = "pengyou-3d147";

function json(o: unknown) {
  return new Response(JSON.stringify(o), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
}

function b64urlFromBytes(bytes: Uint8Array): string {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function b64urlFromString(s: string): string {
  return b64urlFromBytes(new TextEncoder().encode(s));
}
function pemToDer(pem: string): Uint8Array {
  const body = pem
    .replace(/-----BEGIN [^-]+-----/, "")
    .replace(/-----END [^-]+-----/, "")
    .replace(/\s+/g, "");
  const bin = atob(body);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

// Terima service account sebagai JSON mentah atau base64.
function parseServiceAccount(raw: string): Record<string, string> {
  try {
    return JSON.parse(raw);
  } catch (_) { /* coba base64 */ }
  try {
    return JSON.parse(atob(raw.trim()));
  } catch (_) {
    throw new Error("FCM_SERVICE_ACCOUNT bukan JSON/base64 yang valid");
  }
}

// Tukar service account → OAuth access token untuk FCM.
async function getAccessToken(sa: Record<string, string>): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: "RS256", typ: "JWT" };
  const claims = {
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
  };
  const unsigned =
    `${b64urlFromString(JSON.stringify(header))}.${b64urlFromString(JSON.stringify(claims))}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToDer(sa.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = new Uint8Array(
    await crypto.subtle.sign(
      "RSASSA-PKCS1-v1_5",
      key,
      new TextEncoder().encode(unsigned),
    ),
  );
  const jwt = `${unsigned}.${b64urlFromBytes(sig)}`;
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt,
    }),
  });
  const j = await res.json();
  if (!j.access_token) {
    throw new Error("gagal ambil access_token: " + JSON.stringify(j));
  }
  return j.access_token as string;
}

Deno.serve(async (req) => {
  try {
    // --- Kunci: hanya pemanggil dengan header rahasia yang boleh ---
    // Set secret PUSH_ADMIN_KEY di Supabase, lalu kirim header x-push-key.
    const adminKey = Deno.env.get("PUSH_ADMIN_KEY");
    if (!adminKey) {
      return json({ ok: false, error: "PUSH_ADMIN_KEY belum diatur (kunci wajib)" });
    }
    if (req.headers.get("x-push-key") !== adminKey) {
      return new Response(JSON.stringify({ ok: false, error: "unauthorized" }), {
        status: 401,
        headers: { "Content-Type": "application/json" },
      });
    }

    const saRaw = Deno.env.get("FCM_SERVICE_ACCOUNT");
    if (!saRaw) return json({ ok: false, error: "FCM_SERVICE_ACCOUNT belum di-set" });
    const sa = parseServiceAccount(saRaw);

    const body = await req.json().catch(() => ({}));
    const title = String(body.title ?? "PENGYOU");
    const message = String(body.body ?? "");
    const userIds: unknown = body.user_ids;

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );
    let q = supabase.from("push_tokens").select("token,user_id");
    if (Array.isArray(userIds) && userIds.length > 0) {
      q = q.in("user_id", userIds as string[]);
    }
    const { data: rows, error } = await q;
    if (error) return json({ ok: false, error: error.message });
    const tokens = (rows ?? []).map((r: Record<string, unknown>) => String(r.token));
    if (tokens.length === 0) return json({ ok: true, sent: 0, note: "tidak ada token" });

    const accessToken = await getAccessToken(sa);
    let sent = 0;
    const stale: string[] = [];
    const failed: string[] = [];
    for (const token of tokens) {
      const r = await fetch(
        `https://fcm.googleapis.com/v1/projects/${PROJECT_ID}/messages:send`,
        {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            message: { token, notification: { title, body: message } },
          }),
        },
      );
      if (r.ok) {
        sent++;
      } else {
        const txt = await r.text();
        // Token kedaluwarsa/tidak valid → tandai untuk dihapus.
        if (r.status === 404 || r.status === 400) stale.push(token);
        if (failed.length < 3) failed.push(txt);
      }
    }
    // Bersihkan token mati.
    if (stale.length > 0) {
      try {
        await supabase.from("push_tokens").delete().in("token", stale);
      } catch (_) { /* abaikan */ }
    }

    return json({ ok: true, sent, removed: stale.length, total: tokens.length, failed });
  } catch (e) {
    return json({ ok: false, error: String((e as Error)?.message ?? e) });
  }
});
