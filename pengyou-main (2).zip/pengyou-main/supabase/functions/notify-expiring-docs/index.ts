// ============================================================
// Edge Function: notify-expiring-docs
// Dipanggil CRON harian. Kirim push ke pemilik dokumen (ARC/paspor/kontrak)
// yang akan kedaluwarsa pada tonggak hari-H: 30, 14, 7, 3, 1 hari lagi.
// (Dibatasi tonggak itu agar user tidak di-spam tiap hari.)
//
// Secret yang dipakai (sama seperti send-push):
//   FCM_SERVICE_ACCOUNT  = service account Firebase (JSON mentah / base64)
//   PUSH_ADMIN_KEY       = kunci; pemanggil wajib kirim header x-push-key
// ============================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const PROJECT_ID = "pengyou-3d147";
const MILESTONES = new Set([30, 14, 7, 3, 1]);
const LABELS: Record<string, string> = {
  arc: "ARC (Izin Tinggal)",
  passport: "Paspor",
  work_permit: "Izin Kerja",
  insurance: "Asuransi",
  health_check: "Cek Kesehatan",
  contract: "Kontrak Kerja",
  other: "Dokumen",
};

function json(o: unknown, status = 200) {
  return new Response(JSON.stringify(o), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function b64urlBytes(b: Uint8Array): string {
  let s = "";
  for (const x of b) s += String.fromCharCode(x);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function b64urlStr(s: string): string {
  return b64urlBytes(new TextEncoder().encode(s));
}
function pemToDer(pem: string): Uint8Array {
  const body = pem
    .replace(/-----BEGIN [^-]+-----/, "")
    .replace(/-----END [^-]+-----/, "")
    .replace(/\s+/g, "");
  const bin = atob(body);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function parseSA(raw: string): Record<string, string> {
  try {
    return JSON.parse(raw);
  } catch (_) { /* try base64 */ }
  return JSON.parse(atob(raw.trim()));
}
async function getAccessToken(sa: Record<string, string>): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const unsigned = `${b64urlStr(JSON.stringify({ alg: "RS256", typ: "JWT" }))}.` +
    `${b64urlStr(JSON.stringify({
      iss: sa.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600,
    }))}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToDer(sa.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = new Uint8Array(
    await crypto.subtle.sign(
      "RSASSA-PKCS1-v1_5",
      key,
      new TextEncoder().encode(unsigned),
    ),
  );
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: `${unsigned}.${b64urlBytes(sig)}`,
    }),
  });
  const j = await res.json();
  if (!j.access_token) throw new Error("token: " + JSON.stringify(j));
  return j.access_token as string;
}

function daysLeft(expiry: string): number {
  const ms = new Date(expiry).getTime() - Date.now();
  return Math.ceil(ms / 86400000);
}

Deno.serve(async (req) => {
  try {
    const adminKey = Deno.env.get("PUSH_ADMIN_KEY");
    if (!adminKey) return json({ ok: false, error: "PUSH_ADMIN_KEY belum diatur" });
    if (req.headers.get("x-push-key") !== adminKey) {
      return json({ ok: false, error: "unauthorized" }, 401);
    }
    const saRaw = Deno.env.get("FCM_SERVICE_ACCOUNT");
    if (!saRaw) return json({ ok: false, error: "FCM_SERVICE_ACCOUNT belum di-set" });
    const sa = parseSA(saRaw);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    // Dokumen belum diperbarui, kedaluwarsa dalam 0..30 hari ke depan.
    const soon = new Date(Date.now() + 31 * 86400000).toISOString();
    const nowIso = new Date().toISOString();
    const { data: docs, error } = await supabase
      .from("documents")
      .select("document_type, expiry_date, user_id, is_renewed")
      .eq("is_renewed", false)
      .gt("expiry_date", nowIso)
      .lte("expiry_date", soon);
    if (error) return json({ ok: false, error: error.message });

    // Saring hanya yang pas di tonggak hari-H.
    const due = (docs ?? []).filter((d: Record<string, unknown>) =>
      MILESTONES.has(daysLeft(String(d.expiry_date)))
    );
    if (due.length === 0) return json({ ok: true, sent: 0, note: "tidak ada yang jatuh tempo hari ini" });

    // Ambil token per user.
    const userIds = [...new Set(due.map((d: Record<string, unknown>) => String(d.user_id)))];
    const { data: toks } = await supabase
      .from("push_tokens")
      .select("user_id, token")
      .in("user_id", userIds);
    const byUser = new Map<string, string[]>();
    for (const t of toks ?? []) {
      const u = String((t as Record<string, unknown>).user_id);
      const arr = byUser.get(u) ?? [];
      arr.push(String((t as Record<string, unknown>).token));
      byUser.set(u, arr);
    }

    const accessToken = await getAccessToken(sa);
    let sent = 0;
    for (const d of due) {
      const rec = d as Record<string, unknown>;
      const tokens = byUser.get(String(rec.user_id)) ?? [];
      if (tokens.length === 0) continue;
      const label = LABELS[String(rec.document_type)] ?? "Dokumen";
      const n = daysLeft(String(rec.expiry_date));
      const body = `$label Anda habis dalam $n hari. Perpanjang & tandai di PENGYOU.`
        .replace("$label", label)
        .replace("$n", String(n));
      for (const token of tokens) {
        const r = await fetch(
          `https://fcm.googleapis.com/v1/projects/${PROJECT_ID}/messages:send`,
          {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${accessToken}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              message: {
                token,
                notification: { title: "Pengingat dokumen", body },
              },
            }),
          },
        );
        if (r.ok) sent++;
      }
    }
    return json({ ok: true, sent, due: due.length });
  } catch (e) {
    return json({ ok: false, error: String((e as Error)?.message ?? e) });
  }
});
