// ============================================================
// Edge Function: notify-study
// Dipanggil CRON tiap jam (menit 0). Kirim pengingat belajar Mandarin ke user
// yang: menyalakan pengingat, jam lokalnya = jam pengingat pilihannya, dan
// BELUM belajar hari itu. Hanya user yang aktif ≤30 hari terakhir.
//
// Data dari tabel liuli_progress (migrasi 014) + push_tokens (migrasi 012).
// Secret (sama seperti send-push / notify-expiring-docs):
//   FCM_SERVICE_ACCOUNT  = service account Firebase (JSON mentah / base64)
//   PUSH_ADMIN_KEY       = kunci; pemanggil wajib kirim header x-push-key
//   SITE_URL (opsional)  = default https://pengyouapp.netlify.app
// ============================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const PROJECT_ID = "pengyou-3d147";

function json(o: unknown, status = 200) {
  return new Response(JSON.stringify(o), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function b64urlBytes(b: Uint8Array): string {
  let s = "";
  for (const x of b) s += String.fromCharCode(x);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function b64urlStr(s: string): string {
  return b64urlBytes(new TextEncoder().encode(s));
}
function pemToDer(pem: string): Uint8Array {
  const body = pem
    .replace(/-----BEGIN [^-]+-----/, "")
    .replace(/-----END [^-]+-----/, "")
    .replace(/\s+/g, "");
  const bin = atob(body);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function parseSA(raw: string): Record<string, string> {
  try {
    return JSON.parse(raw);
  } catch (_) { /* try base64 */ }
  return JSON.parse(atob(raw.trim()));
}
async function getAccessToken(sa: Record<string, string>): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const unsigned = `${b64urlStr(JSON.stringify({ alg: "RS256", typ: "JWT" }))}.` +
    `${b64urlStr(JSON.stringify({
      iss: sa.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600,
    }))}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToDer(sa.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = new Uint8Array(
    await crypto.subtle.sign(
      "RSASSA-PKCS1-v1_5",
      key,
      new TextEncoder().encode(unsigned),
    ),
  );
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: `${unsigned}.${b64urlBytes(sig)}`,
    }),
  });
  const j = await res.json();
  if (!j.access_token) throw new Error("token: " + JSON.stringify(j));
  return j.access_token as string;
}

type Row = {
  user_id: string;
  streak: number;
  last_day: string | null;
  daily_goal: number;
  remind_hour: number;
  tz_offset: number;
};

/** Waktu lokal user: [jam, tanggal hari ini, tanggal kemarin]. */
function localNow(tzOffsetMin: number): [number, string, string] {
  const t = new Date(Date.now() + tzOffsetMin * 60000);
  const y = new Date(t.getTime() - 86400000);
  return [t.getUTCHours(), t.toISOString().slice(0, 10), y.toISOString().slice(0, 10)];
}

function message(r: Row, yesterday: string): { title: string; body: string } {
  if (r.streak >= 2 && r.last_day === yesterday) {
    return {
      title: `🔥 Rentetan ${r.streak} hari`,
      body: "Kamu belum belajar hari ini. 5 menit saja supaya rentetanmu tidak putus!",
    };
  }
  return {
    title: "📚 Waktunya belajar Mandarin",
    body: `Target harianmu ${r.daily_goal} ulasan. Sedikit tiap hari jauh lebih ampuh — yuk mulai.`,
  };
}

Deno.serve(async (req) => {
  try {
    const adminKey = Deno.env.get("PUSH_ADMIN_KEY");
    if (!adminKey) return json({ ok: false, error: "PUSH_ADMIN_KEY belum diatur" });
    if (req.headers.get("x-push-key") !== adminKey) {
      return json({ ok: false, error: "unauthorized" }, 401);
    }
    const saRaw = Deno.env.get("FCM_SERVICE_ACCOUNT");
    if (!saRaw) return json({ ok: false, error: "FCM_SERVICE_ACCOUNT belum di-set" });
    const sa = parseSA(saRaw);
    const site = Deno.env.get("SITE_URL") ?? "https://pengyouapp.netlify.app";

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    const since = new Date(Date.now() - 30 * 86400000).toISOString();
    const { data: rows, error } = await supabase
      .from("liuli_progress")
      .select("user_id, streak, last_day, daily_goal, remind_hour, tz_offset")
      .eq("remind", true)
      .gte("updated_at", since);
    if (error) return json({ ok: false, error: error.message });

    // Yang jam lokalnya pas & belum belajar hari ini.
    const due: { row: Row; yesterday: string }[] = [];
    for (const r of (rows ?? []) as Row[]) {
      const [hour, today, yesterday] = localNow(r.tz_offset ?? 480);
      if (hour !== r.remind_hour) continue;
      if (r.last_day === today) continue;
      due.push({ row: r, yesterday });
    }
    if (due.length === 0) return json({ ok: true, sent: 0, note: "tidak ada yang perlu diingatkan jam ini" });

    const { data: toks } = await supabase
      .from("push_tokens")
      .select("user_id, token")
      .in("user_id", due.map((d) => d.row.user_id));
    const byUser = new Map<string, string[]>();
    for (const t of (toks ?? []) as { user_id: string; token: string }[]) {
      byUser.set(t.user_id, [...(byUser.get(t.user_id) ?? []), t.token]);
    }

    const accessToken = await getAccessToken(sa);
    let sent = 0;
    const dead: string[] = [];
    for (const { row, yesterday } of due) {
      const { title, body } = message(row, yesterday);
      for (const token of byUser.get(row.user_id) ?? []) {
        // Pesan data-only: service worker yang menampilkan + membuka link saat diklik.
        const r = await fetch(
          `https://fcm.googleapis.com/v1/projects/${PROJECT_ID}/messages:send`,
          {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${accessToken}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              message: {
                token,
                data: { title, body, link: `${site}/#/belajar`, tag: "liuli-study" },
                webpush: { headers: { Urgency: "high", TTL: "3600" } },
              },
            }),
          },
        );
        if (r.ok) {
          sent++;
        } else if (r.status === 404) {
          // Hanya token yang memang sudah tidak terdaftar (bukan salah format pesan).
          if ((await r.text()).includes("UNREGISTERED")) dead.push(token);
        }
      }
    }
    // Bersihkan token yang sudah tidak berlaku.
    if (dead.length) await supabase.from("push_tokens").delete().in("token", dead);
    return json({ ok: true, sent, users: due.length, removed_tokens: dead.length });
  } catch (e) {
    return json({ ok: false, error: String((e as Error)?.message ?? e) });
  }
});
