# Cara mengaktifkan tes bahasa penerjemah

Calon penerjemah mengerjakan 5 soal singkat (2 terjemahan Indonesia→Mandarin,
2 Mandarin→Indonesia, 1 menulis bebas dalam Mandarin) lewat Edge Function
**`screen-interpreter`**. Yang menyetujui selalu admin di
Panel Admin → Verifikasi Penerjemah (1 klik).

Ada dua mode:

| Mode | Biaya | Siapa yang menilai jawaban |
|---|---|---|
| **Gratis** (default) | Rp0 | Admin membaca jawaban (tombol **Lihat jawaban**) lalu memutuskan |
| **Dengan AI** (opsional) | ± US$0,05 per tes | Claude memberi skor + ringkasan; admin tinggal 1 klik |

Foto KTP **tidak pernah** dikirim ke AI.

## Mode gratis (cukup sekali)

### 1. Jalankan migrasi 017

Supabase → **SQL Editor** → New query → tempel isi
`supabase/migrations/017_interpreter_ai_screening.sql` → **Run**.
(Membuat bank 14 soal, tabel riwayat tes, dan kolom hasil tes.)

### 2. Buat Edge Function

1. Supabase → **Edge Functions** → **Deploy a new function** → *Via Editor*.
2. Nama fungsi: **`screen-interpreter`** (harus sama persis).
3. Hapus kode contoh, salin **seluruh isi**
   `supabase/functions/screen-interpreter/index.ts`, tempel → **Deploy**.
   (File `index.test.ts` tidak perlu ikut.)
4. Tab **Details/Settings** fungsi → matikan **"Verify JWT"** → Save.
   Login tetap diperiksa di dalam fungsi.

Edge Function gratis di paket Free Supabase (jatah ratusan ribu panggilan
per bulan — jauh di atas kebutuhan tes ini).

### 3. Uji sekali

1. Daftar akun kedua (email lain) sebagai **"Saya penerjemah"**, atau pakai
   akun client → Profil → **Jadi Penerjemah**.
2. Lengkapi pendaftaran → **Mulai tes bahasa** → jawab 5 soal → Kirim.
   Pelamar melihat "Sedang ditinjau admin".
3. Masuk sebagai admin → Panel Admin → **Verifikasi Penerjemah** — kartu
   pelamar menampilkan **"Tes masuk · nilai manual"**. Tekan
   **Lihat jawaban**, baca, lalu **Verifikasi** bila setuju.

## Opsional: nyalakan penilaian AI

Tidak perlu mengubah kode — cukup pasang kuncinya. Fungsi otomatis
memakai AI begitu kunci ada.

1. **console.anthropic.com** → masuk/daftar → **Billing** → isi saldo
   (US$5 cukup untuk ±100 tes) → **Limits** → atur batas belanja bulanan.
2. **API Keys** → **Create Key** → salin (hanya tampil sekali).
   **Jangan** kirim kunci ini ke chat/siapa pun.
3. Supabase → **Edge Functions** → **Secrets** → **Add new secret**:
   Name `ANTHROPIC_API_KEY`, Value = kunci tadi.

Setelah itu kartu admin menampilkan mis. **"AI 82 · Lolos"** + ringkasan.
Untuk kembali ke mode gratis, hapus secret tersebut.

Kalau muncul `Penilaian AI sedang gangguan` (lihat tab **Logs** fungsi):
kunci salah / saldo habis / API sedang gangguan. Percobaan yang gagal begini
**tidak** dihitung ke batas harian.

### Aturan keputusan AI (di kode, bukan di AI)

Skor total = 35% Indonesia→Mandarin + 35% Mandarin→Indonesia
+ 20% menulis Mandarin + 10% kesungguhan.

| Hasil | Syarat |
|---|---|
| **Lolos** | total ≥ 70 dan tanpa tanda bahaya |
| **Perlu ditinjau** | total 40–69, curiga mesin penerjemah, bio tidak serius, atau AI gagal menilai |
| **Ditolak AI** | total < 40, jawaban asal/kosong, mencoba memanipulasi penilaian, atau konten tidak pantas — pelamar bisa mengulang |

Admin tetap bisa memverifikasi siapa pun, apa pun hasilnya.

## Batas & soal

- Tiap pelamar maksimal **3 tes per hari** (`MAX_ATTEMPTS_PER_DAY`).
- Ubah soal di Supabase → **Table Editor → interpreter_test_questions**:
  tambah baris (`kind`: `id_zh`, `zh_id`, atau `intro`) atau set
  `is_active` = false. Aplikasi memilih soal acak setiap tes.
