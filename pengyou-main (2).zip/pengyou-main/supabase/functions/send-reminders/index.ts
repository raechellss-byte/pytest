// ============================================================
// Edge Function: send-reminders
// 1. Membuat baris pengingat untuk dokumen jatuh tempo H-30/14/7
// 2. Mengirim email lewat Resend ke pemilik dokumen
// 3. Menandai pengingat sebagai 'sent'
//
// Dijadwalkan harian lewat Supabase Cron.
// Perlu secret: RESEND_API_KEY (dari resend.com)
// ============================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const DOC_LABELS: Record<string, string> = {
  arc: "ARC (Kartu Izin Tinggal)",
  passport: "Paspor",
  work_permit: "Izin Kerja",
  insurance: "Asuransi",
  health_check: "Cek Kesehatan",
  contract: "Kontrak Kerja",
  other: "Dokumen",
};

const APP_URL = "https://pengyouapp.netlify.app";
const FROM = "PENGYOU <onboarding@resend.dev>"; // ganti ke domain terverifikasi bila ada

function emailHtml(name: string, docLabel: string, days: number, expiry: string) {
  return `
  <div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;background:#FBF6F3;border-radius:16px;overflow:hidden">
    <div style="background:linear-gradient(135deg,#B01E2C,#E23744);padding:24px;color:#fff">
      <h1 style="margin:0;font-size:22px">🔔 Pengingat Dokumen PENGYOU</h1>
    </div>
    <div style="padding:24px;color:#2A2320">
      <p>Halo <b>${name}</b>,</p>
      <p style="font-size:18px">Dokumen <b>${docLabel}</b> Anda akan
      <b style="color:#E23744">kedaluwarsa dalam ${days} hari</b> (berlaku s/d ${expiry}).</p>
      <p>Segera perpanjang agar Anda tidak kehilangan asuransi kesehatan (NHI)
      atau menjadi tidak berdokumen. Butuh pendamping mengurus? PENGYOU siap bantu.</p>
      <a href="${APP_URL}" style="display:inline-block;margin-top:12px;background:#E23744;color:#fff;
      padding:12px 22px;border-radius:12px;text-decoration:none;font-weight:bold">Buka PENGYOU</a>
      <p style="color:#999;font-size:12px;margin-top:24px">
      Anda menerima email ini karena mendaftarkan dokumen di PENGYOU.</p>
    </div>
  </div>`;
}

Deno.serve(async () => {
  const debug: Record<string, unknown> = {};
  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );
    const resendKey = Deno.env.get("RESEND_API_KEY");

    // 1. Buat pengingat hari ini (H-30/14/7).
    await supabase.rpc("create_expiry_reminders");

    // 2. Ambil pengingat pending + data dokumen & pengguna.
    const { data: pending, error } = await supabase
      .from("reminders")
      .select("id, days_before, document_id, user_id, "
        + "documents(document_type, expiry_date), "
        + "users(full_name, email)")
      .eq("status", "pending")
      .limit(100);
    if (error) throw new Error(error.message);
    debug.pending = pending?.length ?? 0;

    let sent = 0;
    let failed = 0;
    for (const r of pending ?? []) {
      const email = (r as any).users?.email;
      const name = (r as any).users?.full_name ?? "Sahabat";
      const docType = (r as any).documents?.document_type ?? "other";
      const expiry = (r as any).documents?.expiry_date ?? "";
      const days = (r as any).days_before ?? 0;
      const label = DOC_LABELS[docType] ?? "Dokumen";

      let ok = false;
      if (resendKey && email) {
        try {
          const res = await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${resendKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              from: FROM,
              to: email,
              subject: `⏰ ${label} Anda kedaluwarsa dalam ${days} hari`,
              html: emailHtml(name, label, days, expiry),
            }),
          });
          ok = res.ok;
          if (!ok) debug.lastError = await res.text();
        } catch (e) {
          debug.lastError = String(e);
        }
      }

      // Tandai status (sent bila email terkirim / tidak ada provider → tetap sent
      // agar tidak menumpuk; ganti ke 'failed' bila mau ulang).
      await supabase
        .from("reminders")
        .update({ status: ok ? "sent" : "failed", sent_at: new Date().toISOString() })
        .eq("id", (r as any).id);
      ok ? sent++ : failed++;
    }

    return new Response(
      JSON.stringify({ ok: true, sent, failed, hasResendKey: !!resendKey, debug }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );
  } catch (e) {
    return new Response(
      JSON.stringify({ ok: false, error: String((e as Error)?.message ?? e), debug }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );
  }
});
