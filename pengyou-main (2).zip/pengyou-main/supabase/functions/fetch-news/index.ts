// ============================================================
// Edge Function: fetch-news  (GDELT — ramah server, gratis, tanpa API key)
// Deploy sebagai slug `rapid-worker`.
//
// Menarik berita berbahasa Indonesia dari GDELT untuk 3 kategori:
//   🇹🇼 Taiwan   — kabar Taiwan (untuk PMI di Taiwan)
//   💰 Ekonomi  — ekonomi Indonesia (rupiah, inflasi, IHSG, makro/mikro…)
//   🇮🇩 Indonesia — hot news tanah air (karhutla, banjir, gempa, bencana…)
//
// DESAIN TAHAN-BANTING (anti timeout & rate-limit):
//   • CUKUP 1 request GDELT (query gabungan luas) — bukan 3 paralel / 2 berurutan.
//     Ini penting: GDELT membatasi 1 request / 5 detik per IP, dan IP egress
//     Supabase dipakai banyak orang. Satu request = paling kecil kena limit,
//     paling cepat (~2 dtk), dan tidak akan timeout.
//   • Hasilnya dipilah ke kategori berdasar REGEX JUDUL (biar relevan, anti-noise).
//   • Kalau kena rate-limit (GDELT balas teks "Please limit requests" ber-status
//     200), retry singkat maksimal 2x @5 dtk. Kalau tetap gagal → balas 200 apa
//     adanya (0 berita), cron berikutnya coba lagi. TIDAK PERNAH crash/500.
//   • Fallback: kalau query gabungan kosong, sekali coba "Taiwan sourcelang:..."
//     supaya kategori Taiwan tetap keisi.
//
// Simpan HANYA judul + cuplikan pendek + link (aman hak cipta).
// Butuh unique index PENUH di news.source_url (migrasi 006) utk upsert onConflict.
// ============================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

// --- Filter judul per kategori (case-insensitive) ---
const TAIWAN =
  /taiwan|taipei|taoyuan|taichung|tainan|kaohsiung|keelung|hsinchu|chiayi|miaoli|changhua|nantou|yunlin|pingtung|yilan|hualien|taitung|penghu|kinmen|matsu|台灣|臺灣|台湾|台北|臺北|新北|桃園|台中|臺中|台南|臺南|高雄|基隆|新竹|嘉義|苗栗|彰化|南投|雲林|屏東|宜蘭|花蓮|台東|臺東|澎湖|金門|馬祖/i;

const EKONOMI =
  /ekonomi|rupiah|inflasi|deflasi|ihsg|\bsaham\b|suku bunga|bank indonesia|ekspor|impor|\bphk\b|umkm|investasi|apbn|pertumbuhan ekonomi|resesi|dolar|neraca dagang|makro|mikro|\bpdb\b|fiskal|moneter|\bbbm\b|subsidi|pajak|harga pangan/i;

const INDONESIA =
  /kebakaran|karhutla|kabut asap|banjir|gempa|erupsi|gunung|longsor|bencana|tsunami|cuaca ekstrem|angin kencang|kekeringan|evakuasi|banjir bandang/i;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// Ambil artikel GDELT; sadar rate-limit (balasan teks "Please limit...").
async function gdelt(
  query: string,
  timespan: string,
  max: number,
): Promise<{ articles: Record<string, unknown>[]; status: number; note: string }> {
  const url =
    "https://api.gdeltproject.org/api/v2/doc/doc?query=" +
    encodeURIComponent(query) +
    `&mode=ArtList&format=json&maxrecords=${max}&timespan=${timespan}&sort=DateDesc`;

  for (let attempt = 0; attempt < 3; attempt++) {
    let text = "";
    let status = 0;
    try {
      const res = await fetch(url, { headers: { "User-Agent": "PengyouBot/1.0" } });
      status = res.status;
      text = await res.text();
    } catch (_) {
      status = -1;
    }
    const limited = text.includes("Please limit requests");
    if (!limited) {
      try {
        const articles = (JSON.parse(text).articles ?? []) as Record<string, unknown>[];
        console.log(`GDELT ok status=${status} articles=${articles.length}`);
        return { articles, status, note: "ok" };
      } catch (_) {
        console.log(`GDELT nonjson status=${status} len=${text.length}`);
        return { articles: [], status, note: "nonjson" };
      }
    }
    console.log(`GDELT rate-limited, attempt ${attempt + 1}, tunggu 5s…`);
    await sleep(5000);
  }
  return { articles: [], status: 429, note: "rate-limited" };
}

function seendateToIso(s: string): string {
  if (!s || s.length < 15) return new Date().toISOString();
  const iso = `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}T` +
    `${s.slice(9, 11)}:${s.slice(11, 13)}:${s.slice(13, 15)}Z`;
  const d = new Date(iso);
  return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
}

function categorize(title: string): { cat: string; emoji: string } | null {
  if (TAIWAN.test(title)) return { cat: "Taiwan", emoji: "🇹🇼" };
  if (EKONOMI.test(title)) return { cat: "Ekonomi", emoji: "💰" };
  if (INDONESIA.test(title)) return { cat: "Indonesia", emoji: "🇮🇩" };
  return null;
}

const PER_CATEGORY = 8;
const QUERY =
  "(Taiwan OR ekonomi OR rupiah OR inflasi OR IHSG OR investasi OR banjir OR gempa OR kebakaran OR karhutla OR bencana OR erupsi OR longsor) sourcelang:indonesian";

Deno.serve(async () => {
  const debug: Record<string, unknown> = {};
  try {
    // 1 request luas.
    let g = await gdelt(QUERY, "10d", 250);
    debug.main = { status: g.status, articles: g.articles.length, note: g.note };

    // Fallback: kalau kosong, sekali coba khusus Taiwan (jeda 5 dtk hormati limit).
    if (g.articles.length === 0 && g.note !== "rate-limited") {
      await sleep(5200);
      const t = await gdelt("Taiwan sourcelang:indonesian", "14d", 75);
      debug.fallback = { status: t.status, articles: t.articles.length, note: t.note };
      g = t;
    }

    const seen = new Set<string>();
    const rows: Record<string, unknown>[] = [];
    const countByCat: Record<string, number> = { Taiwan: 0, Ekonomi: 0, Indonesia: 0 };

    for (const a of g.articles) {
      const title = String(a.title ?? "").trim();
      const link = String(a.url ?? "").trim();
      if (!title || !link || seen.has(link)) continue;
      const hit = categorize(title);
      if (!hit) continue;
      if (countByCat[hit.cat] >= PER_CATEGORY) continue;
      seen.add(link);
      countByCat[hit.cat]++;
      const domain = String(a.domain ?? "").trim();
      const image = String(a.socialimage ?? "").trim();
      rows.push({
        title,
        summary: domain ? `Baca selengkapnya di ${domain}` : title,
        category: hit.cat,
        emoji: hit.emoji,
        source_name: domain || "GDELT",
        source_url: link,
        image_url: image || null,
        published_at: seendateToIso(String(a.seendate ?? "")),
        is_active: true,
        is_external: true,
      });
    }
    debug.saved = { ...countByCat, total: rows.length };

    let saveError: string | null = null;
    if (rows.length > 0) {
      const supabase = createClient(
        Deno.env.get("SUPABASE_URL") ?? "",
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      );
      const resp = await supabase
        .from("news")
        .upsert(rows, { onConflict: "source_url", ignoreDuplicates: true });
      saveError = resp?.error ? (resp.error.message ?? JSON.stringify(resp.error)) : null;
      try {
        await supabase.rpc("prune_old_news");
      } catch (_) { /* abaikan */ }
    }

    return new Response(
      JSON.stringify({ ok: saveError === null, fetched: rows.length, saveError, debug }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );
  } catch (e) {
    console.error("FATAL", e);
    return new Response(
      JSON.stringify({ ok: false, error: String((e as Error)?.message ?? e), debug }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );
  }
});
