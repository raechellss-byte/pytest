# Cara mengaktifkan berita otomatis (auto-refresh)

Berita otomatis ditarik dari Google News RSS oleh sebuah **Edge Function**
(`fetch-news`) yang dijadwalkan berjalan berkala. Ikuti langkah ini **sekali**.

## 1. Jalankan migrasi 006

Di Supabase → **SQL Editor**, jalankan isi file
`supabase/migrations/006_news_autofetch.sql`.

## 2. Buat Edge Function lewat dashboard

1. Buka Supabase → menu **Edge Functions** (ikon petir).
2. Klik **Create a function** (atau **Deploy a new function** → *Via Editor*).
3. Nama fungsi: **`fetch-news`** (harus sama persis).
4. Hapus kode contoh, lalu **salin seluruh isi** file
   `supabase/functions/fetch-news/index.ts` dan tempel.
5. Klik **Deploy**.
6. Buka tab **Details/Settings** fungsi itu → matikan **"Verify JWT"**
   (Enforce JWT) agar penjadwal boleh memanggilnya. `SERVICE_ROLE_KEY`
   sudah otomatis tersedia di dalam fungsi, jadi tetap aman.

## 3. Uji sekali

Di halaman fungsi, klik **Invoke**/**Run** (atau kirim request tes).
Buka **Table Editor → news** — seharusnya terisi banyak berita baru.
Kalau ada error, buka tab **Logs** fungsi tersebut.

## 4. Jadwalkan otomatis (tiap 6 jam)

**Cara termudah (UI):**
1. Supabase → **Integrations → Cron** (atau **Database → Cron Jobs**).
2. **Create job** → beri nama `refresh-news`.
3. Schedule: `0 */6 * * *` (tiap 6 jam) — atau `0 0 * * *` untuk sekali sehari.
4. Type: **Supabase Edge Function** → pilih **fetch-news**.
5. Simpan.

**Alternatif (SQL, butuh pg_cron + pg_net aktif):**
```sql
select cron.schedule('refresh-news', '0 */6 * * *', $$
  select net.http_post(
    url := 'https://nxjkkkqoewwdxenjvtjq.functions.supabase.co/fetch-news',
    headers := '{"Content-Type":"application/json"}'::jsonb
  );
$$);
```

## Selesai

Aplikasi otomatis menampilkan berita terbaru di bagian **"🔥 Hot 24 Jam
Terakhir"** dan daftar **"Kabar & Info Taiwan"**. Berita lama (>14 hari)
dibersihkan otomatis.

> Catatan hak cipta: fungsi ini hanya menyimpan **judul + cuplikan pendek +
> link** ke sumber asli (agregasi seperti Google News), bukan menyalin isi
> artikel. Pengguna diarahkan ke situs sumber untuk membaca lengkap.
