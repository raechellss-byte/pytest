# Cara mengaktifkan notifikasi email pengingat dokumen

Fungsi `send-reminders` membuat pengingat H-30/14/7 lalu mengirim email lewat
**Resend** (gratis). Notifikasi di dalam aplikasi sudah jalan tanpa ini; email
adalah pengiriman "proaktif" ke inbox pengguna.

## 1. Daftar Resend & ambil API key

1. Buka **https://resend.com** → daftar gratis (bisa dengan Google).
2. Menu **API Keys** → **Create API Key** → salin (bentuknya `re_...`).
3. (Untuk pengujian) Resend mengizinkan kirim dari `onboarding@resend.dev`
   **hanya ke email akun Resend Anda sendiri**. Untuk kirim ke email pengguna
   lain, Anda perlu **verifikasi domain** di Resend (menu Domains) — bisa nanti.

## 2. Simpan API key sebagai secret di Supabase

1. Supabase → **Edge Functions → Secrets** (atau Project Settings → Edge Functions).
2. Tambah secret: **Name** `RESEND_API_KEY`, **Value** = key `re_...` Anda → Save.

## 3. Deploy fungsi

1. Supabase → **Edge Functions** → **Deploy a new function → Via Editor**.
2. Nama: **`send-reminders`**.
3. Tempel isi `supabase/functions/send-reminders/index.ts` → **Deploy**.
4. Tab **Settings** → matikan **Verify JWT** → Save.

## 4. Uji

Klik **Test / Send Request**. Respons kira-kira:
```json
{ "ok": true, "sent": 2, "failed": 0, "hasResendKey": true }
```
- `hasResendKey: false` → secret belum terpasang (ulangi langkah 2).
- `sent > 0` → email terkirim. Cek inbox.
- Kalau belum ada dokumen yang jatuh tempo H-30/14/7, `pending` = 0 (wajar).

> Tips uji cepat: tambahkan dokumen dengan tanggal kedaluwarsa **tepat 30, 14,
> atau 7 hari** dari hari ini, lalu jalankan fungsi.

## 5. Jadwalkan harian (cron)

Supabase → **Integrations → Cron** → Create job:
- Name: `daily-reminders`
- Schedule: `0 1 * * *` (setiap hari jam 08:00 WIB ≈ 01:00 UTC)
- Type: **Edge Function** → **send-reminders**

Selesai — pengguna otomatis diingatkan lewat email sebelum dokumennya habis.

## Catatan

- Notifikasi **di dalam aplikasi** (tab Notifikasi) tidak butuh ini — sudah jalan.
- LINE bisa ditambahkan nanti (butuh LINE Official Account).
- Tanpa `RESEND_API_KEY`, fungsi tetap jalan tapi tidak mengirim email
  (pengingat ditandai `failed` agar bisa dicoba lagi setelah key dipasang).
