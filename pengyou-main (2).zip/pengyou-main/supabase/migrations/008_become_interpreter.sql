-- ============================================================
-- Alur "Jadi Penerjemah" + keamanan peran
-- Jalankan setelah 007_admin.sql
-- ============================================================

-- Kolom foto ID untuk verifikasi.
alter table public.interpreter_profiles
  add column if not exists id_photo_path text;

-- ---------- Keamanan: cegah eskalasi peran ----------
-- Trigger membalikkan perubahan peran yang tidak sah.
-- Yang diizinkan: admin mengubah apa pun; client → interpreter (self-daftar).
create or replace function public.guard_role_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role then
    if not public.is_admin()
       and not (old.role = 'client' and new.role = 'interpreter') then
      new.role := old.role; -- tolak perubahan (mis. client → admin)
    end if;
  end if;
  return new;
end; $$;

drop trigger if exists users_guard_role on public.users;
create trigger users_guard_role before update on public.users
  for each row execute function public.guard_role_change();

-- ---------- RPC: jadi penerjemah ----------
create or replace function public.become_interpreter(
  p_bio text default null,
  p_city text default null,
  p_hourly_rate numeric default null
)
returns void language plpgsql security definer set search_path = public as $$
declare cur_role text;
begin
  select role into cur_role from users where id = auth.uid();
  if cur_role is null then raise exception 'Belum login'; end if;

  -- Naikkan client → interpreter (jangan turunkan admin/institution).
  if cur_role = 'client' then
    update users set role = 'interpreter' where id = auth.uid();
  end if;

  insert into interpreter_profiles (user_id, bio, city, hourly_rate, is_verified, is_available)
  values (auth.uid(), p_bio, p_city, p_hourly_rate, false, true)
  on conflict (user_id) do update
    set bio = coalesce(excluded.bio, interpreter_profiles.bio),
        city = coalesce(excluded.city, interpreter_profiles.city),
        hourly_rate = coalesce(excluded.hourly_rate, interpreter_profiles.hourly_rate);
end; $$;

-- ============================================================
-- Storage: bucket 'verification' untuk foto ID (admin boleh baca)
-- ============================================================
insert into storage.buckets (id, name, public) values ('verification','verification', false)
on conflict (id) do nothing;

drop policy if exists "veri_upload_own" on storage.objects;
create policy "veri_upload_own" on storage.objects for insert
  with check (bucket_id = 'verification'
    and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "veri_read_own_or_admin" on storage.objects;
create policy "veri_read_own_or_admin" on storage.objects for select
  using (bucket_id = 'verification'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
