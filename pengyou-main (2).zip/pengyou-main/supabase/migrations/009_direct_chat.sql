-- ============================================================
-- Chat langsung (direct message) antar dua pengguna
-- — client bisa menghubungi penerjemah sebelum memesan.
-- Jalankan setelah 001.
-- ============================================================

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references public.users (id) on delete cascade,
  user_b uuid not null references public.users (id) on delete cascade,
  last_message text,
  last_message_at timestamptz,
  created_at timestamptz not null default now(),
  unique (user_a, user_b),
  check (user_a < user_b) -- pasangan dinormalisasi (urut), 1 percakapan per pasangan
);

create table public.direct_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations (id) on delete cascade,
  sender_id uuid not null references public.users (id),
  content text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index idx_dm_convo on public.direct_messages (conversation_id, created_at);

-- Ambil / buat percakapan dengan pengguna lain (mis. penerjemah).
create or replace function public.get_or_create_conversation(p_other uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare a uuid; b uuid; cid uuid;
begin
  if auth.uid() is null then raise exception 'Belum login'; end if;
  if p_other = auth.uid() then raise exception 'Tidak bisa chat dengan diri sendiri'; end if;
  if auth.uid() < p_other then a := auth.uid(); b := p_other;
  else a := p_other; b := auth.uid(); end if;
  select id into cid from conversations where user_a = a and user_b = b;
  if cid is null then
    insert into conversations (user_a, user_b) values (a, b) returning id into cid;
  end if;
  return cid;
end; $$;

-- Perbarui ringkasan percakapan setiap ada pesan baru.
create or replace function public.touch_conversation()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update conversations
     set last_message = new.content, last_message_at = new.created_at
   where id = new.conversation_id;
  return new;
end; $$;

drop trigger if exists dm_touch on public.direct_messages;
create trigger dm_touch after insert on public.direct_messages
  for each row execute function public.touch_conversation();

-- ---------- RLS ----------
alter table public.conversations enable row level security;
alter table public.direct_messages enable row level security;

create policy "convo_participant" on public.conversations for select
  using (auth.uid() = user_a or auth.uid() = user_b);

create policy "dm_select" on public.direct_messages for select
  using (conversation_id in (
    select id from public.conversations
    where auth.uid() = user_a or auth.uid() = user_b));

create policy "dm_insert" on public.direct_messages for insert
  with check (sender_id = auth.uid() and conversation_id in (
    select id from public.conversations
    where auth.uid() = user_a or auth.uid() = user_b));

-- Realtime untuk chat langsung.
do $$ begin
  alter publication supabase_realtime add table public.direct_messages;
exception when duplicate_object then null;
end $$;
