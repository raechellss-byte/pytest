-- ============================================================
-- Tandai pesan chat langsung sebagai terbaca (untuk badge)
-- Jalankan setelah 009_direct_chat.sql
-- ============================================================

create or replace function public.mark_messages_read(p_conversation_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  update direct_messages set is_read = true
  where conversation_id = p_conversation_id
    and sender_id <> auth.uid()
    and is_read = false
    and conversation_id in (
      select id from conversations
      where auth.uid() = user_a or auth.uid() = user_b
    );
end; $$;
