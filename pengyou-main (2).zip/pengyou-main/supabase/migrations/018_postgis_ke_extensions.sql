-- ============================================================
-- 018: Pindahkan PostGIS dari skema public ke skema extensions.
--      Membereskan Security Advisor "RLS Disabled in Public" pada
--      public.spatial_ref_sys (dan peringatan "Extension in Public").
--
-- 013 tidak bisa membereskannya: spatial_ref_sys milik supabase_admin,
-- jadi akun postgres tidak bisa mengaktifkan RLS atau mencabut hak di
-- tabel itu. Jalan keluar yang disarankan Supabase: PostGIS di skema
-- extensions (bawaan dashboard), yang tidak terbuka lewat API.
--
-- PostGIS tidak bisa dipindah skema begitu saja, jadi dicopot lalu
-- dipasang ulang. Kolom lokasi ikut terhapus saat dicopot, maka titiknya
-- dicadangkan dulu lalu dikembalikan persis (termasuk lokasi GPS).
--
-- Cara pakai: SQL Editor → tempel SELURUH isi file → Run (sekali).
-- Semua langkah ada dalam satu blok: bila ada yang gagal, tidak ada
-- yang berubah. Aman dijalankan ulang (PostGIS yang sudah pindah dilewati).
-- Bila ada objek lain (buatan sendiri di dashboard) yang memakai PostGIS,
-- skrip BERHENTI dan menyebutkan namanya, bukan ikut menghapusnya.
--
-- SETELAH Run berhasil: Project Settings → General → Restart project.
-- Koneksi database yang sudah terbuka masih mengingat PostGIS yang lama;
-- tanpa restart, Cari Terdekat / peta bisa error "no spatial operator
-- found for 'st_dwithin'" sampai koneksi itu diganti. Koneksi baru normal.
-- ============================================================
do $mig$
declare
  v_schema text;
  v_lain text;
begin
  perform set_config('search_path', 'public, extensions', true);

  select n.nspname into v_schema
    from pg_extension e join pg_namespace n on n.oid = e.extnamespace
   where e.extname = 'postgis';
  if v_schema is distinct from 'public' then
    raise notice 'PostGIS ada di skema %, tidak dipindah.', coalesce(v_schema, '(tidak terpasang)');
    return;
  end if;

  -- Extension lain yang memakai PostGIS akan ikut terhapus → berhenti.
  select string_agg(e.extname, ', ') into v_lain
    from pg_depend d join pg_extension e on e.oid = d.objid
   where d.classid = 'pg_extension'::regclass
     and d.refclassid = 'pg_extension'::regclass
     and d.refobjid = (select oid from pg_extension where extname = 'postgis');
  if v_lain is not null then
    raise exception 'Dibatalkan, tidak ada yang diubah. Extension ini memakai PostGIS: %', v_lain;
  end if;

  -- Daftar objek database buatan pengguna (bukan bagian extension), untuk
  -- memastikan CASCADE hanya menghapus 4 objek yang dibuat ulang di bawah.
  create function pg_temp._objek() returns setof text language sql as $q$
    with ext as (
      select classid, objid from pg_depend
       where deptype = 'e' and refclassid = 'pg_extension'::regclass
    ), rel as (
      select c.oid, c.relname, c.relkind, n.nspname
        from pg_class c join pg_namespace n on n.oid = c.relnamespace
       where n.nspname !~ '^pg_' and n.nspname <> 'information_schema'
         and not exists (select 1 from ext where ext.classid = 'pg_class'::regclass and ext.objid = c.oid)
         and not exists (select 1 from pg_index i join ext
                           on ext.classid = 'pg_class'::regclass and ext.objid = i.indrelid
                          where i.indexrelid = c.oid)
    )
    select format('relasi %I.%I', nspname, relname) from rel
     where relkind in ('r', 'p', 'v', 'm', 'f', 'i', 'S')
    union all
    select format('kolom %I.%I.%I', r.nspname, r.relname, a.attname)
      from rel r join pg_attribute a on a.attrelid = r.oid
     where r.relkind in ('r', 'p', 'v', 'm', 'f') and a.attnum > 0 and not a.attisdropped
    union all
    select format('default %I.%I.%I', r.nspname, r.relname, a.attname)
      from rel r join pg_attrdef d on d.adrelid = r.oid
      join pg_attribute a on a.attrelid = r.oid and a.attnum = d.adnum
    union all
    select format('constraint %I pada %I.%I', co.conname, r.nspname, r.relname)
      from rel r join pg_constraint co on co.conrelid = r.oid
    union all
    select format('trigger %I pada %I.%I', t.tgname, r.nspname, r.relname)
      from rel r join pg_trigger t on t.tgrelid = r.oid where not t.tgisinternal
    union all
    select format('policy %I pada %I.%I', p.polname, r.nspname, r.relname)
      from rel r join pg_policy p on p.polrelid = r.oid
    union all
    select format('fungsi %I.%I', n.nspname, p.proname)
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname !~ '^pg_' and n.nspname <> 'information_schema'
       and not exists (select 1 from ext where ext.classid = 'pg_proc'::regclass and ext.objid = p.oid)
    union all
    select format('tipe %I.%I', n.nspname, t.typname)
      from pg_type t join pg_namespace n on n.oid = t.typnamespace
     where t.typtype = 'd' and n.nspname !~ '^pg_' and n.nspname <> 'information_schema'
       and not exists (select 1 from ext where ext.classid = 'pg_type'::regclass and ext.objid = t.oid)
  $q$;
  create temp table _sebelum on commit drop as select x from pg_temp._objek() x;

  -- 1. Cadangkan titik lokasi.
  create temp table _lokasi on commit drop as
    select 'ip'::text as tbl, id, st_x(location::geometry) as lng, st_y(location::geometry) as lat
      from public.interpreter_profiles where location is not null
    union all
    select 'bk', id, st_x(location::geometry), st_y(location::geometry)
      from public.bookings where location is not null;

  -- 2. Pasang ulang PostGIS di skema extensions.
  drop extension postgis cascade;

  select string_agg(x, ', ' order by x) into v_lain from (
    select x from _sebelum
    except select x from pg_temp._objek() x
    except select unnest(array[
      'kolom public.interpreter_profiles.location',
      'kolom public.bookings.location',
      'relasi public.idx_interpreter_location',
      'fungsi public.city_point'])
  ) s;
  if v_lain is not null then
    raise exception 'Dibatalkan, tidak ada yang diubah. Objek ini juga memakai PostGIS dan akan ikut terhapus: %', v_lain;
  end if;

  create extension postgis with schema extensions;

  -- 3. Kembalikan kolom, isinya, dan index peta.
  alter table public.interpreter_profiles add column location extensions.geography(Point, 4326);
  alter table public.bookings add column location extensions.geography(Point, 4326);

  update public.interpreter_profiles t
     set location = st_setsrid(st_makepoint(c.lng, c.lat), 4326)::geography
    from _lokasi c
   where c.tbl = 'ip' and c.id = t.id;
  -- Pemulihan bukan perubahan pesanan: updated_at jangan ikut berubah.
  alter table public.bookings disable trigger bookings_touch;
  update public.bookings t
     set location = st_setsrid(st_makepoint(c.lng, c.lat), 4326)::geography
    from _lokasi c
   where c.tbl = 'bk' and c.id = t.id;
  alter table public.bookings enable trigger bookings_touch;

  create index idx_interpreter_location
    on public.interpreter_profiles using gist (location);

  -- 4. Fungsi yang memakai PostGIS: search_path kini juga extensions.
  create or replace function public.city_point(p_city text)
  returns geography language sql immutable set search_path = public, extensions as $f$
    select case p_city
      when 'Taichung'  then st_makepoint(120.6736, 24.1477)
      when 'Taipei'    then st_makepoint(121.5654, 25.0330)
      when 'Taoyuan'   then st_makepoint(121.3010, 24.9936)
      when 'Kaohsiung' then st_makepoint(120.3014, 22.6273)
      when 'Tainan'    then st_makepoint(120.2270, 22.9999)
      when 'Hsinchu'   then st_makepoint(120.9675, 24.8138)
    end::geography;
  $f$;

  create or replace function public.nearest_interpreters(
    p_lng double precision,
    p_lat double precision,
    p_max_km double precision default 20
  )
  returns table (
    interpreter_id uuid,
    user_id uuid,
    full_name text,
    city text,
    bio text,
    hourly_rate numeric,
    rating_avg numeric,
    rating_count int,
    distance_km double precision
  )
  language sql stable security definer set search_path = public, extensions as $f$
    select
      ip.id,
      ip.user_id,
      u.full_name,
      ip.city,
      ip.bio,
      ip.hourly_rate,
      ip.rating_avg,
      ip.rating_count,
      st_distance(ip.location, st_makepoint(p_lng, p_lat)::geography) / 1000
    from interpreter_profiles ip
    join users u on u.id = ip.user_id
    where ip.is_verified
      and ip.is_available
      and ip.location is not null
      and st_dwithin(ip.location, st_makepoint(p_lng, p_lat)::geography, p_max_km * 1000)
    order by ip.location <-> st_makepoint(p_lng, p_lat)::geography
    limit 50;
  $f$;

  create or replace function public.set_my_location(p_lng double precision, p_lat double precision)
  returns void language sql security definer set search_path = public, extensions as $f$
    update interpreter_profiles
       set location = st_makepoint(p_lng, p_lat)::geography
     where user_id = auth.uid();
  $f$;

  create or replace function public.interpreters_for_map(
    p_lng double precision default 120.6736,
    p_lat double precision default 24.1477,
    p_max_km double precision default 60
  )
  returns table (
    interpreter_id uuid,
    full_name text,
    rating_avg numeric,
    hourly_rate numeric,
    lng double precision,
    lat double precision
  )
  language sql stable security definer set search_path = public, extensions as $f$
    select ip.id, u.full_name, ip.rating_avg, ip.hourly_rate,
           st_x(ip.location::geometry), st_y(ip.location::geometry)
    from interpreter_profiles ip
    join users u on u.id = ip.user_id
    where ip.is_verified and ip.is_available and ip.location is not null
      and st_dwithin(ip.location, st_makepoint(p_lng, p_lat)::geography, p_max_km * 1000)
    limit 100;
  $f$;

  perform pg_notify('pgrst', 'reload schema');
end $mig$;

-- Cek hasil (yang diharapkan: extensions, true, jumlah sama seperti sebelumnya).
select
  (select n.nspname from pg_extension e join pg_namespace n on n.oid = e.extnamespace
    where e.extname = 'postgis')                                   as postgis_di_skema,
  to_regclass('public.spatial_ref_sys') is null                    as spatial_ref_sys_keluar_dari_public,
  (select count(*) from public.interpreter_profiles
    where location is not null)                                    as penerjemah_berlokasi;
