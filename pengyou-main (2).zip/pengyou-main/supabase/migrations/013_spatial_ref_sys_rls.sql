-- ============================================================
-- 013: Kunci tabel PostGIS `spatial_ref_sys` (Security Advisor:
--      "RLS Disabled in Public").
-- Tabel ini dibuat otomatis oleh extension PostGIS (dipakai untuk
-- nearest_interpreters / kolom geography). Isinya data referensi
-- koordinat (EPSG), bukan data user — tapi tanpa RLS bisa diubah lewat API.
-- Skrip mencoba: (1) RLS + izin baca saja; bila bukan pemilik tabel,
-- (2) cabut hak tulis anon/authenticated. Tidak error di kedua kasus.
-- HASIL di project ini (Okt 2026): rls_aktif = false, anon_bisa_tulis = true.
-- Tabel dimiliki supabase_admin, jadi user postgres tidak bisa mengubahnya
-- (REVOKE pun diam-diam tak berefek). Perbaikan sebenarnya: minta Supabase
-- Support menjalankan ENABLE ROW LEVEL SECURITY + policy SELECT di atas.
-- Risiko bila dibiarkan: data referensi koordinat bisa diubah lewat API
-- (mis. SRID 4326 dihapus → nearest_interpreters error). Bukan data user.
-- DISELESAIKAN oleh 018_postgis_ke_extensions.sql (PostGIS pindah ke skema
-- extensions, jadi spatial_ref_sys tidak lagi terbuka lewat API).
-- ============================================================
do $$
begin
  begin
    alter table public.spatial_ref_sys enable row level security;
    if not exists (select 1 from pg_policies
                   where schemaname = 'public' and tablename = 'spatial_ref_sys'
                     and policyname = 'spatial_ref_sys_read') then
      create policy spatial_ref_sys_read on public.spatial_ref_sys
        for select using (true);
    end if;
  exception when insufficient_privilege then
    begin
      revoke insert, update, delete, truncate on public.spatial_ref_sys
        from anon, authenticated;
    exception when insufficient_privilege then
      raise notice 'Tabel milik supabase_admin, tidak bisa diubah (aman diabaikan)';
    end;
  end;
end $$;

-- Cek hasil
select
  (select relrowsecurity from pg_class
    where oid = 'public.spatial_ref_sys'::regclass)              as rls_aktif,
  has_table_privilege('anon', 'public.spatial_ref_sys', 'INSERT') as anon_bisa_tulis;
