-- ============================================================
-- Tabel berita/info untuk halaman Beranda
-- Jalankan di Supabase SQL Editor setelah 001_initial_schema.sql
-- ============================================================

create table public.news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  summary text not null,
  body text,
  category text not null default 'Info',
  emoji text default '📰',
  source_name text,
  source_url text,
  published_at timestamptz not null default now(),
  is_active boolean not null default true
);

alter table public.news enable row level security;

-- Semua orang boleh membaca berita aktif (halaman publik, tanpa login).
create policy "news_public_read" on public.news for select using (is_active);

-- Hanya admin yang boleh menulis/mengubah berita.
create policy "news_admin_write" on public.news for all
  using (exists (select 1 from public.users u
                 where u.id = auth.uid() and u.role = 'admin'));

-- Contoh isi awal (silakan admin edit/tambah lewat Table Editor).
insert into public.news (title, summary, category, emoji, source_name) values
('Jangan sampai ARC Anda kedaluwarsa',
 'ARC/izin kerja yang lewat tanggal bisa membuat Anda kehilangan asuransi kesehatan (NHI) dan berisiko jadi tidak berdokumen. Daftarkan dokumen Anda di aplikasi ini agar diingatkan 30, 14, dan 7 hari sebelumnya.',
 'Dokumen', '🪪', 'Info Komunitas'),
('Hotline 1955 — bantuan bahasa Indonesia 24 jam',
 'Pemerintah Taiwan menyediakan hotline 1955 gratis, 24 jam, dengan layanan interpretasi bahasa Indonesia lewat telepon untuk keluhan ketenagakerjaan. Untuk pendampingan fisik (rumah sakit, imigrasi), gunakan penerjemah di aplikasi ini.',
 'Layanan', '📞', 'Info Komunitas'),
('Pastikan kartu NHI Anda aktif',
 'Kartu National Health Insurance (NHI) membuat biaya berobat jauh lebih murah. Kartu ini terkait dengan status izin tinggal Anda — jaga agar ARC tetap berlaku.',
 'Kesehatan', '🏥', 'Info Komunitas'),
('Simpan kontrak kerja Anda baik-baik',
 'Kontrak kerja adalah bukti penting bila terjadi sengketa gaji atau jam kerja. Foto dan simpan salinannya di menu Dokumen agar tidak hilang.',
 'Ketenagakerjaan', '📄', 'Info Komunitas'),
('Butuh pendamping ke rumah sakit?',
 'Menurut data, hanya sekitar setengah pekerja migran yang sakit benar-benar mengakses layanan kesehatan — sering karena tidak ada pendamping bahasa. Cari penerjemah terdekat lewat tab Cari.',
 'Kesehatan', '🤝', 'Info Komunitas');
