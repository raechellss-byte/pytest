-- ============================================================
-- Tes bahasa calon penerjemah, dinilai AI (Edge Function screen-interpreter).
-- AI hanya memberi skor + ringkasan; persetujuan tetap di tangan admin
-- (Panel Admin → Verifikasi Penerjemah, 1 klik). Foto KTP tidak dikirim ke AI.
-- Jalankan setelah 016_interpreter_search.sql
-- ============================================================

-- ---------- Bank soal (admin bisa menambah/mengubah lewat Table Editor) ----------
create table if not exists public.interpreter_test_questions (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('id_zh', 'zh_id', 'intro')),
  prompt text not null,
  context text, -- situasi, mis. "Rumah sakit"
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.interpreter_test_questions enable row level security;
drop policy if exists "itq_read" on public.interpreter_test_questions;
create policy "itq_read" on public.interpreter_test_questions for select
  to authenticated using (is_active);
drop policy if exists "itq_admin" on public.interpreter_test_questions;
create policy "itq_admin" on public.interpreter_test_questions for all
  using (public.is_admin()) with check (public.is_admin());

insert into public.interpreter_test_questions (kind, context, prompt)
select * from (values
  ('id_zh', 'Rumah sakit', 'Dokter, ibu saya sudah tiga hari demam dan batuk terus.'),
  ('id_zh', 'Kantor imigrasi', 'Saya ingin memperpanjang ARC. Dokumen apa saja yang perlu saya bawa?'),
  ('id_zh', 'Pengaduan tenaga kerja', 'Majikan saya belum membayar gaji saya bulan ini.'),
  ('id_zh', 'Apotek', 'Obat ini diminum berapa kali sehari, sebelum atau sesudah makan?'),
  ('id_zh', 'Agensi', 'Kontrak kerja saya habis bulan depan. Apakah saya boleh pindah majikan?'),
  ('id_zh', 'Darurat', 'Tolong panggilkan ambulans, ada orang pingsan di sini.'),
  ('zh_id', 'Rumah sakit', '請您先到一樓掛號，再到三樓內科候診。'),
  ('zh_id', 'Kantor imigrasi', '您的居留證下個月到期，請記得提前申請展延。'),
  ('zh_id', 'Kontrak kerja', '這份契約寫明每個月休假四天。'),
  ('zh_id', 'Apotek', '這個藥飯後吃，一天三次，吃完可能會想睡覺。'),
  ('zh_id', 'Pengaduan tenaga kerja', '如果雇主沒有付加班費，可以撥打1955申訴。'),
  ('zh_id', 'Dokumen', '請在這裡簽名，並寫上今天的日期。'),
  ('intro', null, 'Perkenalkan diri Anda dalam bahasa Mandarin (3–5 kalimat): nama, asal, sudah berapa lama di Taiwan, dan pengalaman membantu orang lain.'),
  ('intro', null, 'Dalam bahasa Mandarin (3–5 kalimat), ceritakan kenapa Anda ingin menjadi penerjemah untuk sesama PMI.')
) as v(kind, context, prompt)
where not exists (select 1 from public.interpreter_test_questions);

-- ---------- Riwayat penilaian (1 baris per percobaan; ditulis server saja) ----------
create table if not exists public.interpreter_screenings (
  id uuid primary key default gen_random_uuid(),
  interpreter_id uuid not null references public.interpreter_profiles (id) on delete cascade,
  user_id uuid not null references public.users (id) on delete cascade,
  answers jsonb not null,          -- [{question_id, kind, context, prompt, answer}]
  scores jsonb,                    -- skor per kriteria dari AI
  total int,
  verdict text check (verdict in ('pass', 'review', 'reject')),
  summary text,                    -- untuk admin
  feedback text,                   -- untuk pelamar
  flags text[] not null default '{}',
  model text,
  created_at timestamptz not null default now()
);

create index if not exists idx_screenings_user
  on public.interpreter_screenings (user_id, created_at desc);

alter table public.interpreter_screenings enable row level security;
-- Tidak ada policy insert/update: hanya Edge Function (service role) yang menulis.
drop policy if exists "screenings_read" on public.interpreter_screenings;
create policy "screenings_read" on public.interpreter_screenings for select
  using (user_id = auth.uid() or public.is_admin());

-- ---------- Hasil terakhir di profil (untuk daftar admin & halaman Profil) ----------
alter table public.interpreter_profiles
  add column if not exists ai_total int,
  add column if not exists ai_verdict text check (ai_verdict in ('pass', 'review', 'reject')),
  add column if not exists ai_summary text,
  add column if not exists ai_feedback text,
  add column if not exists ai_flags text[],
  add column if not exists ai_screened_at timestamptz;

-- Trigger 016 + kolom hasil AI ikut dikunci dari perubahan lewat API.
create or replace function public.interpreter_profile_guard()
returns trigger language plpgsql set search_path = public as $$
begin
  -- Lokasi otomatis = titik tengah kota bila belum ada, atau bila kota
  -- diganti tanpa lokasi baru (GPS tetap menimpa lewat set_my_location).
  if new.city is not null and (
       new.location is null
       or (tg_op = 'UPDATE'
           and new.city is distinct from old.city
           and new.location::text is not distinct from old.location::text)) then
    new.location := coalesce(public.city_point(new.city), new.location);
  end if;

  -- Pengguna biasa tidak boleh memverifikasi diri / mengubah rating / nilai AI.
  if tg_op = 'UPDATE' and current_user in ('authenticated', 'anon')
     and not public.is_admin() then
    new.is_verified    := old.is_verified;
    new.rating_avg     := old.rating_avg;
    new.rating_count   := old.rating_count;
    new.user_id        := old.user_id;
    new.ai_total       := old.ai_total;
    new.ai_verdict     := old.ai_verdict;
    new.ai_summary     := old.ai_summary;
    new.ai_feedback    := old.ai_feedback;
    new.ai_flags       := old.ai_flags;
    new.ai_screened_at := old.ai_screened_at;
  end if;
  return new;
end; $$;
