-- ============================================================
-- 019: Bereskan peringatan Security Advisor & Performance Advisor.
-- Jalankan setelah 018. Aman dijalankan ulang. Hak akses data TIDAK
-- berubah (diuji: tiap peran × tiap tabel × baca/ubah/hapus/tambah
-- identik dengan sebelum 019), kecuali fungsi yang memang tidak boleh
-- dipanggil sembarang orang (bagian A).
--
-- A. "Public Can Execute SECURITY DEFINER Function": fungsi yang berjalan
--    dengan hak pemilik bisa dipanggil siapa saja lewat /rest/v1/rpc.
--    - fungsi trigger: tidak untuk dipanggil lewat API sama sekali;
--    - create_expiry_reminders & prune_old_news: hanya server (edge
--      function memakai service role) — sebelumnya tamu pun bisa memicu
--      penghapusan berita lama;
--    - fungsi pengguna/admin: hanya untuk yang sudah login;
--    - Cari Terdekat, peta, set lokasi, verifikasi admin: tidak perlu hak
--      pemilik karena aturan tabel (RLS) sudah mengizinkan isinya.
-- B. "Function Search Path Mutable": touch_updated_at.
-- C. "Auth RLS Initialization Plan": auth.uid() / is_admin() di aturan
--    tabel dibungkus (select ...) supaya dihitung sekali per query, bukan
--    per baris. Aturan yang hanya berlaku untuk pengguna login diberi
--    TO authenticated (tidak dicek untuk tamu).
-- D. "Multiple Permissive Policies": aturan admin digabung ke aturan biasa
--    (OR), sehingga tiap peran × aksi cukup diperiksa oleh satu aturan.
-- ============================================================

-- ---------- A. Hak menjalankan fungsi ----------
revoke execute on function public.handle_new_user(),
                           public.refresh_interpreter_rating(),
                           public.touch_conversation()
  from public, anon, authenticated;

revoke execute on function public.create_expiry_reminders(),
                           public.prune_old_news()
  from public, anon, authenticated;
grant execute on function public.create_expiry_reminders(),
                          public.prune_old_news()
  to service_role;

revoke execute on function public.is_admin(),
                           public.admin_stats(),
                           public.admin_set_verified(uuid, boolean),
                           public.become_interpreter(text, text, numeric),
                           public.get_or_create_conversation(uuid),
                           public.mark_messages_read(uuid),
                           public.set_my_location(double precision, double precision)
  from public, anon;
grant execute on function public.is_admin(),
                          public.admin_stats(),
                          public.admin_set_verified(uuid, boolean),
                          public.become_interpreter(text, text, numeric),
                          public.get_or_create_conversation(uuid),
                          public.mark_messages_read(uuid),
                          public.set_my_location(double precision, double precision)
  to authenticated, service_role;

-- Isi yang dibaca/diubah fungsi ini sudah diizinkan RLS untuk pemanggilnya.
alter function public.nearest_interpreters(double precision, double precision, double precision) security invoker;
alter function public.interpreters_for_map(double precision, double precision, double precision) security invoker;
alter function public.set_my_location(double precision, double precision) security invoker;
alter function public.admin_set_verified(uuid, boolean) security invoker;

-- ---------- B. search_path ----------
alter function public.touch_updated_at() set search_path = public;

-- ---------- C & D. Aturan tabel (RLS) ----------
-- bookings
drop policy if exists admin_read_bookings on public.bookings;
drop policy if exists bookings_select_own on public.bookings;
drop policy if exists bookings_select on public.bookings;
create policy bookings_select on public.bookings for select to authenticated
  using ((select auth.uid()) = client_id
         or interpreter_id in (select id from public.interpreter_profiles
                                where user_id = (select auth.uid()))
         or (select public.is_admin()));
drop policy if exists bookings_insert_client on public.bookings;
create policy bookings_insert_client on public.bookings for insert to authenticated
  with check ((select auth.uid()) = client_id and status = 'requested');
drop policy if exists bookings_update_parties on public.bookings;
create policy bookings_update_parties on public.bookings for update to authenticated
  using ((select auth.uid()) = client_id
         or interpreter_id in (select id from public.interpreter_profiles
                                where user_id = (select auth.uid())));

-- calendar_notes, documents
drop policy if exists notes_own on public.calendar_notes;
create policy notes_own on public.calendar_notes for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
drop policy if exists documents_own on public.documents;
create policy documents_own on public.documents for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

-- conversations, direct_messages
drop policy if exists convo_participant on public.conversations;
create policy convo_participant on public.conversations for select to authenticated
  using ((select auth.uid()) = user_a or (select auth.uid()) = user_b);
drop policy if exists dm_select on public.direct_messages;
create policy dm_select on public.direct_messages for select to authenticated
  using (conversation_id in (select id from public.conversations
                              where (select auth.uid()) = user_a or (select auth.uid()) = user_b));
drop policy if exists dm_insert on public.direct_messages;
create policy dm_insert on public.direct_messages for insert to authenticated
  with check (sender_id = (select auth.uid())
              and conversation_id in (select id from public.conversations
                                       where (select auth.uid()) = user_a or (select auth.uid()) = user_b));

-- interpreter_profiles (tamu: hanya yang terverifikasi)
drop policy if exists admin_manage_profiles on public.interpreter_profiles;
drop policy if exists profiles_update_self on public.interpreter_profiles;
drop policy if exists profiles_select on public.interpreter_profiles;
drop policy if exists profiles_select_anon on public.interpreter_profiles;
drop policy if exists profiles_update on public.interpreter_profiles;
drop policy if exists profiles_admin_insert on public.interpreter_profiles;
drop policy if exists profiles_admin_delete on public.interpreter_profiles;
create policy profiles_select_anon on public.interpreter_profiles for select to anon
  using (is_verified);
create policy profiles_select on public.interpreter_profiles for select to authenticated
  using (is_verified or (select auth.uid()) = user_id or (select public.is_admin()));
create policy profiles_update on public.interpreter_profiles for update to authenticated
  using ((select auth.uid()) = user_id or (select public.is_admin()))
  with check ((select auth.uid()) = user_id or (select public.is_admin()));
create policy profiles_admin_insert on public.interpreter_profiles for insert to authenticated
  with check ((select public.is_admin()));
create policy profiles_admin_delete on public.interpreter_profiles for delete to authenticated
  using ((select public.is_admin()));

-- interpreter_screenings
drop policy if exists screenings_read on public.interpreter_screenings;
create policy screenings_read on public.interpreter_screenings for select to authenticated
  using (user_id = (select auth.uid()) or (select public.is_admin()));

-- interpreter_services & language_pairs (baca: semua; kelola: pemiliknya)
drop policy if exists services_manage_self on public.interpreter_services;
drop policy if exists services_insert_self on public.interpreter_services;
drop policy if exists services_update_self on public.interpreter_services;
drop policy if exists services_delete_self on public.interpreter_services;
create policy services_insert_self on public.interpreter_services for insert to authenticated
  with check (interpreter_id in (select id from public.interpreter_profiles
                                  where user_id = (select auth.uid())));
create policy services_update_self on public.interpreter_services for update to authenticated
  using (interpreter_id in (select id from public.interpreter_profiles
                             where user_id = (select auth.uid())));
create policy services_delete_self on public.interpreter_services for delete to authenticated
  using (interpreter_id in (select id from public.interpreter_profiles
                             where user_id = (select auth.uid())));

drop policy if exists admin_read_langpairs on public.language_pairs;
drop policy if exists langpairs_manage_self on public.language_pairs;
drop policy if exists langpairs_insert_self on public.language_pairs;
drop policy if exists langpairs_update_self on public.language_pairs;
drop policy if exists langpairs_delete_self on public.language_pairs;
create policy langpairs_insert_self on public.language_pairs for insert to authenticated
  with check (interpreter_id in (select id from public.interpreter_profiles
                                  where user_id = (select auth.uid())));
create policy langpairs_update_self on public.language_pairs for update to authenticated
  using (interpreter_id in (select id from public.interpreter_profiles
                             where user_id = (select auth.uid())));
create policy langpairs_delete_self on public.language_pairs for delete to authenticated
  using (interpreter_id in (select id from public.interpreter_profiles
                             where user_id = (select auth.uid())));

-- interpreter_test_questions (hanya pengguna login; admin melihat & mengelola semua)
drop policy if exists itq_admin on public.interpreter_test_questions;
drop policy if exists itq_read on public.interpreter_test_questions;
drop policy if exists itq_admin_insert on public.interpreter_test_questions;
drop policy if exists itq_admin_update on public.interpreter_test_questions;
drop policy if exists itq_admin_delete on public.interpreter_test_questions;
create policy itq_read on public.interpreter_test_questions for select to authenticated
  using (is_active or (select public.is_admin()));
create policy itq_admin_insert on public.interpreter_test_questions for insert to authenticated
  with check ((select public.is_admin()));
create policy itq_admin_update on public.interpreter_test_questions for update to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));
create policy itq_admin_delete on public.interpreter_test_questions for delete to authenticated
  using ((select public.is_admin()));

-- liuli_progress, sehat_data, push_tokens (data milik sendiri)
drop policy if exists liuli_progress_select_own on public.liuli_progress;
drop policy if exists liuli_progress_insert_own on public.liuli_progress;
drop policy if exists liuli_progress_update_own on public.liuli_progress;
drop policy if exists liuli_progress_delete_own on public.liuli_progress;
create policy liuli_progress_select_own on public.liuli_progress for select to authenticated
  using ((select auth.uid()) = user_id);
create policy liuli_progress_insert_own on public.liuli_progress for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy liuli_progress_update_own on public.liuli_progress for update to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy liuli_progress_delete_own on public.liuli_progress for delete to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists sehat_data_select_own on public.sehat_data;
drop policy if exists sehat_data_insert_own on public.sehat_data;
drop policy if exists sehat_data_update_own on public.sehat_data;
drop policy if exists sehat_data_delete_own on public.sehat_data;
create policy sehat_data_select_own on public.sehat_data for select to authenticated
  using ((select auth.uid()) = user_id);
create policy sehat_data_insert_own on public.sehat_data for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy sehat_data_update_own on public.sehat_data for update to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy sehat_data_delete_own on public.sehat_data for delete to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists push_tokens_select_own on public.push_tokens;
drop policy if exists push_tokens_insert_own on public.push_tokens;
drop policy if exists push_tokens_update_own on public.push_tokens;
drop policy if exists push_tokens_delete_own on public.push_tokens;
create policy push_tokens_select_own on public.push_tokens for select to authenticated
  using ((select auth.uid()) = user_id);
create policy push_tokens_insert_own on public.push_tokens for insert to authenticated
  with check ((select auth.uid()) = user_id);
create policy push_tokens_update_own on public.push_tokens for update to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy push_tokens_delete_own on public.push_tokens for delete to authenticated
  using ((select auth.uid()) = user_id);

-- map_places & news (tamu: yang aktif; admin: semua + kelola)
drop policy if exists map_places_admin on public.map_places;
drop policy if exists map_places_read on public.map_places;
drop policy if exists map_places_read_anon on public.map_places;
drop policy if exists map_places_admin_insert on public.map_places;
drop policy if exists map_places_admin_update on public.map_places;
drop policy if exists map_places_admin_delete on public.map_places;
create policy map_places_read_anon on public.map_places for select to anon
  using (is_active);
create policy map_places_read on public.map_places for select to authenticated
  using (is_active or (select public.is_admin()));
create policy map_places_admin_insert on public.map_places for insert to authenticated
  with check ((select public.is_admin()));
create policy map_places_admin_update on public.map_places for update to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));
create policy map_places_admin_delete on public.map_places for delete to authenticated
  using ((select public.is_admin()));

drop policy if exists news_admin_write on public.news;
drop policy if exists news_public_read on public.news;
drop policy if exists news_read_anon on public.news;
drop policy if exists news_read on public.news;
drop policy if exists news_admin_insert on public.news;
drop policy if exists news_admin_update on public.news;
drop policy if exists news_admin_delete on public.news;
create policy news_read_anon on public.news for select to anon
  using (is_active);
create policy news_read on public.news for select to authenticated
  using (is_active or (select public.is_admin()));
create policy news_admin_insert on public.news for insert to authenticated
  with check ((select public.is_admin()));
create policy news_admin_update on public.news for update to authenticated
  using ((select public.is_admin())) with check ((select public.is_admin()));
create policy news_admin_delete on public.news for delete to authenticated
  using ((select public.is_admin()));

-- messages, payments, reminders, reviews (pihak yang terlibat)
drop policy if exists messages_select_parties on public.messages;
create policy messages_select_parties on public.messages for select to authenticated
  using (booking_id in (select b.id from public.bookings b
                         where b.client_id = (select auth.uid())
                            or b.interpreter_id in (select id from public.interpreter_profiles
                                                     where user_id = (select auth.uid()))));
drop policy if exists messages_insert_parties on public.messages;
create policy messages_insert_parties on public.messages for insert to authenticated
  with check (sender_id = (select auth.uid())
              and booking_id in (select b.id from public.bookings b
                                  where b.client_id = (select auth.uid())
                                     or b.interpreter_id in (select id from public.interpreter_profiles
                                                              where user_id = (select auth.uid()))));
drop policy if exists payments_select_parties on public.payments;
create policy payments_select_parties on public.payments for select to authenticated
  using (booking_id in (select b.id from public.bookings b
                         where b.client_id = (select auth.uid())
                            or b.interpreter_id in (select id from public.interpreter_profiles
                                                     where user_id = (select auth.uid()))));
drop policy if exists reminders_select_own on public.reminders;
create policy reminders_select_own on public.reminders for select to authenticated
  using ((select auth.uid()) = user_id);
drop policy if exists reviews_insert_parties on public.reviews;
create policy reviews_insert_parties on public.reviews for insert to authenticated
  with check (reviewer_id = (select auth.uid())
              and booking_id in (select b.id from public.bookings b
                                  where b.status = 'completed'
                                    and (b.client_id = (select auth.uid())
                                         or b.interpreter_id in (select id from public.interpreter_profiles
                                                                  where user_id = (select auth.uid())))));

-- users (baca: semua seperti sebelumnya; ubah: diri sendiri / admin)
drop policy if exists admin_manage_users on public.users;
drop policy if exists users_update_self on public.users;
drop policy if exists users_update on public.users;
drop policy if exists users_admin_insert on public.users;
drop policy if exists users_admin_delete on public.users;
create policy users_update on public.users for update to authenticated
  using ((select auth.uid()) = id or (select public.is_admin()))
  with check ((select auth.uid()) = id or (select public.is_admin()));
create policy users_admin_insert on public.users for insert to authenticated
  with check ((select public.is_admin()));
create policy users_admin_delete on public.users for delete to authenticated
  using ((select public.is_admin()));

notify pgrst, 'reload schema';
