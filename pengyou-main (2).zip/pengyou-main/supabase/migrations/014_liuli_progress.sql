-- ============================================================
-- 014: Progres Belajar Mandarin per akun (sinkron antar perangkat)
--      + kolom ringkas untuk pengingat belajar (push).
--
-- `data` = snapshot lengkap dari aplikasi (kartu SRS, rentetan, koleksi,
-- pengaturan). Kolom lain disalin dari snapshot supaya edge function
-- `notify-study` bisa memilih siapa yang perlu diingatkan tanpa membuka JSON.
-- ============================================================

create table if not exists public.liuli_progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  streak int not null default 0,
  last_day text,                    -- tanggal lokal terakhir belajar (YYYY-MM-DD)
  today_count int not null default 0,
  daily_goal int not null default 20,
  remind boolean not null default true,
  remind_hour int not null default 20 check (remind_hour between 0 and 23),
  tz_offset int not null default 480, -- menit dari UTC (Taiwan = +480)
  updated_at timestamptz not null default now()
);

create index if not exists idx_liuli_progress_remind
  on public.liuli_progress (remind, updated_at);

alter table public.liuli_progress enable row level security;

-- User hanya boleh membaca & menulis progresnya sendiri.
drop policy if exists "liuli_progress_select_own" on public.liuli_progress;
create policy "liuli_progress_select_own" on public.liuli_progress
  for select using (auth.uid() = user_id);

drop policy if exists "liuli_progress_insert_own" on public.liuli_progress;
create policy "liuli_progress_insert_own" on public.liuli_progress
  for insert with check (auth.uid() = user_id);

drop policy if exists "liuli_progress_update_own" on public.liuli_progress;
create policy "liuli_progress_update_own" on public.liuli_progress
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "liuli_progress_delete_own" on public.liuli_progress;
create policy "liuli_progress_delete_own" on public.liuli_progress
  for delete using (auth.uid() = user_id);
