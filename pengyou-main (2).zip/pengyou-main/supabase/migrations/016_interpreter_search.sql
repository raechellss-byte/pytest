-- ============================================================
-- Penerjemah baru langsung bisa ditemukan di "Cari Terdekat"
-- + tutup celah keamanan peran & verifikasi.
-- Jalankan setelah 015_sehat_data.sql
--
-- Masalah yang diperbaiki:
-- 1. Daftar "Jadi Penerjemah" tidak mengisi kolom location, padahal
--    nearest_interpreters & interpreters_for_map mensyaratkan location.
--    Akibatnya penerjemah yang sudah diverifikasi tetap tidak muncul,
--    kecuali ia menekan "Set lokasi saya dari GPS" di Profil.
-- 2. Penerjemah bisa memverifikasi dirinya sendiri (update is_verified
--    lewat API), karena policy profiles_update_self tidak membatasi kolom.
-- 3. Daftar akun dengan metadata role='admin' langsung menjadi admin.
-- ============================================================

-- ---------- Titik tengah kota (samakan dengan AppConfig.cities di app) ----------
create or replace function public.city_point(p_city text)
returns geography language sql immutable set search_path = public as $$
  select case p_city
    when 'Taichung'  then st_makepoint(120.6736, 24.1477)
    when 'Taipei'    then st_makepoint(121.5654, 25.0330)
    when 'Taoyuan'   then st_makepoint(121.3010, 24.9936)
    when 'Kaohsiung' then st_makepoint(120.3014, 22.6273)
    when 'Tainan'    then st_makepoint(120.2270, 22.9999)
    when 'Hsinchu'   then st_makepoint(120.9675, 24.8138)
  end::geography;
$$;

-- ---------- Trigger profil penerjemah ----------
-- SECURITY INVOKER (bawaan): current_user = 'authenticated' bila diubah lewat
-- API oleh pengguna; di dalam RPC security definer (admin_set_verified,
-- refresh_interpreter_rating, dll.) current_user = pemilik fungsi.
create or replace function public.interpreter_profile_guard()
returns trigger language plpgsql set search_path = public as $$
begin
  -- Lokasi otomatis = titik tengah kota bila belum ada, atau bila kota
  -- diganti tanpa lokasi baru (GPS tetap menimpa lewat set_my_location).
  if new.city is not null and (
       new.location is null
       or (tg_op = 'UPDATE'
           and new.city is distinct from old.city
           and new.location::text is not distinct from old.location::text)) then
    new.location := coalesce(public.city_point(new.city), new.location);
  end if;

  -- Pengguna biasa tidak boleh memverifikasi diri / mengubah rating.
  if tg_op = 'UPDATE' and current_user in ('authenticated', 'anon')
     and not public.is_admin() then
    new.is_verified  := old.is_verified;
    new.rating_avg   := old.rating_avg;
    new.rating_count := old.rating_count;
    new.user_id      := old.user_id;
  end if;
  return new;
end; $$;

drop trigger if exists interpreter_profiles_guard on public.interpreter_profiles;
create trigger interpreter_profiles_guard
  before insert or update on public.interpreter_profiles
  for each row execute function public.interpreter_profile_guard();

-- Isi lokasi penerjemah lama yang sudah memilih kota tapi belum punya titik.
update public.interpreter_profiles
   set location = public.city_point(city)
 where location is null and city is not null;

-- ---------- Signup: hanya 'client' atau 'interpreter' dari metadata ----------
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_role text := case when new.raw_user_meta_data->>'role' = 'interpreter'
                      then 'interpreter' else 'client' end;
begin
  insert into public.users (id, email, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', 'Pengguna'),
    v_role
  );
  if v_role = 'interpreter' then
    insert into public.interpreter_profiles (user_id) values (new.id);
  end if;
  return new;
end;
$$;

-- ---------- Penjaga peran: percayai SQL Editor / Table Editor ----------
-- Sebelumnya SECURITY DEFINER, sehingga admin pun tidak bisa mengubah peran
-- lewat Table Editor (is_admin() selalu false tanpa login). Kini hanya
-- perubahan lewat API (authenticated/anon) yang diperiksa.
create or replace function public.guard_role_change()
returns trigger language plpgsql security invoker set search_path = public as $$
begin
  if new.role is distinct from old.role
     and current_user in ('authenticated', 'anon')
     and not public.is_admin()
     and not (old.role = 'client' and new.role = 'interpreter') then
    new.role := old.role; -- tolak perubahan (mis. client → admin)
  end if;
  return new;
end; $$;
