-- ============================================================
-- Peta: tempat/lembaga penting + koordinat penerjemah
-- Jalankan setelah 007_admin.sql (butuh is_admin).
-- ============================================================

create table public.map_places (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'agency'
    check (category in ('agency','immigration','hospital','station','office','other')),
  lat double precision not null,
  lng double precision not null,
  address text,
  note text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.map_places enable row level security;

create policy "map_places_read" on public.map_places for select using (is_active);
create policy "map_places_admin" on public.map_places for all
  using (public.is_admin()) with check (public.is_admin());

-- Titik referensi publik di Taichung (koordinat perkiraan — admin bisa perbaiki
-- lewat Table Editor). Ini tempat umum berguna untuk PMI, bukan bisnis fiktif.
insert into public.map_places (name, category, lat, lng, note) values
('Stasiun Taichung (Taichung Railway Station)', 'station', 24.1369, 120.6851,
  'Stasiun utama — titik kumpul & transportasi'),
('Kantor Imigrasi Taichung (NIA)', 'immigration', 24.1610, 120.6460,
  'Urusan ARC, izin tinggal, dan imigrasi'),
('Taichung Veterans General Hospital', 'hospital', 24.1799, 120.6015,
  'Rumah sakit besar — sering butuh pendamping bahasa'),
('China Medical University Hospital', 'hospital', 24.1519, 120.7206,
  'Rumah sakit besar di pusat kota');

-- RPC: penerjemah terverifikasi + koordinat untuk ditampilkan di peta.
create or replace function public.interpreters_for_map(
  p_lng double precision default 120.6736,
  p_lat double precision default 24.1477,
  p_max_km double precision default 60
)
returns table (
  interpreter_id uuid,
  full_name text,
  rating_avg numeric,
  hourly_rate numeric,
  lng double precision,
  lat double precision
)
language sql stable security definer set search_path = public as $$
  select ip.id, u.full_name, ip.rating_avg, ip.hourly_rate,
         st_x(ip.location::geometry), st_y(ip.location::geometry)
  from interpreter_profiles ip
  join users u on u.id = ip.user_id
  where ip.is_verified and ip.is_available and ip.location is not null
    and st_dwithin(ip.location, st_makepoint(p_lng, p_lat)::geography, p_max_km * 1000)
  limit 100;
$$;
