-- ============================================================
-- Tambah tipe dokumen 'insurance' (asuransi) & 'health_check'
-- Jalankan di Supabase SQL Editor setelah 001.
-- ============================================================

alter table public.documents drop constraint if exists documents_document_type_check;

alter table public.documents
  add constraint documents_document_type_check
  check (document_type in
    ('arc','passport','work_permit','contract','insurance','health_check','other'));
