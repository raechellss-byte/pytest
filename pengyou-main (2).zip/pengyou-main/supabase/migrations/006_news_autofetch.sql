-- ============================================================
-- 006: Persiapan berita otomatis (auto-fetch dari Google News RSS)
-- Jalankan setelah 002_news.sql & 004_news_banner.sql.
--
-- VERSI DIPERBAIKI: unique index pada source_url dibuat PENUH (bukan partial),
-- karena Edge Function fetch-news memakai upsert `ON CONFLICT (source_url)`,
-- yang MEWAJIBKAN unique index non-partial persis di kolom source_url.
-- (Index partial `where source_url is not null` akan membuat upsert gagal:
--  "no unique or exclusion constraint matching the ON CONFLICT specification".)
--
-- Aman menggantikan versi lama & aman dijalankan berulang (idempotent):
-- index lama (partial ATAU penuh) di-drop dulu, lalu dibuat ulang sebagai penuh.
-- ============================================================

-- Tandai berita hasil tarik otomatis agar mudah dibersihkan.
alter table public.news add column if not exists is_external boolean not null default false;

-- Dedupe: satu baris per URL sumber.
-- Buang index lama apa pun bentuknya, lalu buat ulang sebagai unique index PENUH.
-- (NULL dianggap unik masing-masing di Postgres, jadi berita tanpa source_url
--  tetap boleh banyak.)
drop index if exists public.uq_news_source_url;
create unique index uq_news_source_url on public.news (source_url);

-- Percepat query "24 jam terakhir" dan urutan terbaru.
create index if not exists idx_news_published on public.news (published_at desc);

-- Bersihkan berita eksternal lama (>14 hari) agar tabel tetap ramping.
create or replace function public.prune_old_news()
returns void language sql security definer set search_path = public as $$
  delete from public.news
   where is_external = true
     and published_at < now() - interval '14 days';
$$;
