-- ============================================================
-- 015: Riwayat Sehat Rantau per akun (klinik tersimpan, catatan berobat,
--      riwayat pencarian). Riwayat hanya disimpan untuk pengguna yang
--      sudah masuk; data ini ikut akun sehingga bisa dibuka di HP lain.
--
-- `data` = snapshot dari aplikasi:
--   { at, saved: [...], visits: [...], history: [...] }
-- Catatan berobat bersifat pribadi → RLS: hanya pemilik yang bisa akses.
-- ============================================================

create table if not exists public.sehat_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.sehat_data enable row level security;

drop policy if exists "sehat_data_select_own" on public.sehat_data;
create policy "sehat_data_select_own" on public.sehat_data
  for select using (auth.uid() = user_id);

drop policy if exists "sehat_data_insert_own" on public.sehat_data;
create policy "sehat_data_insert_own" on public.sehat_data
  for insert with check (auth.uid() = user_id);

drop policy if exists "sehat_data_update_own" on public.sehat_data;
create policy "sehat_data_update_own" on public.sehat_data
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "sehat_data_delete_own" on public.sehat_data;
create policy "sehat_data_delete_own" on public.sehat_data
  for delete using (auth.uid() = user_id);
