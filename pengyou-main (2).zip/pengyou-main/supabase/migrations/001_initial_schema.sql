-- ============================================================
-- MVP Penerjemah & Pendamping TKI Taiwan — skema awal
-- Jalankan di Supabase SQL Editor (atau `supabase db push`)
-- ============================================================

create extension if not exists postgis;

-- ---------- users (profil publik, terhubung ke auth.users) ----------
create table public.users (
  id uuid primary key references auth.users (id) on delete cascade,
  email text,
  phone text,
  full_name text not null,
  role text not null default 'client' check (role in ('client','interpreter','institution','admin')),
  preferred_language text not null default 'id' check (preferred_language in ('id','zh')),
  line_user_id text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------- interpreter_profiles ----------
create table public.interpreter_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.users (id) on delete cascade,
  bio text,
  city text,
  location geography(Point, 4326),
  hourly_rate numeric(10,2),
  currency text not null default 'TWD',
  is_verified boolean not null default false,
  rating_avg numeric(3,2) not null default 0,
  rating_count int not null default 0,
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);

create index idx_interpreter_location
  on public.interpreter_profiles using gist (location);

-- ---------- language_pairs ----------
create table public.language_pairs (
  id uuid primary key default gen_random_uuid(),
  interpreter_id uuid not null references public.interpreter_profiles (id) on delete cascade,
  source_language text not null,
  target_language text not null,
  proficiency text not null default 'fluent' check (proficiency in ('basic','fluent','native','certified'))
);

-- ---------- service_categories ----------
create table public.service_categories (
  id uuid primary key default gen_random_uuid(),
  name_id text not null,
  name_zh text not null,
  slug text not null unique,
  description text
);

insert into public.service_categories (name_id, name_zh, slug) values
  ('Medis / Rumah Sakit', '醫療', 'medis'),
  ('Administrasi / Imigrasi', '行政/移民', 'imigrasi'),
  ('Hukum / Kontrak Kerja', '法律/勞動合約', 'hukum'),
  ('Dokumen', '文件', 'dokumen'),
  ('Lainnya', '其他', 'lainnya');

-- ---------- interpreter_services ----------
create table public.interpreter_services (
  id uuid primary key default gen_random_uuid(),
  interpreter_id uuid not null references public.interpreter_profiles (id) on delete cascade,
  category_id uuid not null references public.service_categories (id) on delete cascade,
  custom_rate numeric(10,2),
  unique (interpreter_id, category_id)
);

-- ---------- bookings ----------
create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.users (id),
  interpreter_id uuid not null references public.interpreter_profiles (id),
  category_id uuid references public.service_categories (id),
  service_type text not null default 'onsite' check (service_type in ('onsite','phone','document')),
  status text not null default 'requested'
    check (status in ('requested','accepted','in_progress','completed','cancelled')),
  scheduled_at timestamptz not null,
  duration_minutes int not null default 60,
  location_address text,
  location geography(Point, 4326),
  description text,
  agreed_price numeric(10,2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_bookings_client on public.bookings (client_id);
create index idx_bookings_interpreter on public.bookings (interpreter_id);

-- ---------- messages ----------
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings (id) on delete cascade,
  sender_id uuid not null references public.users (id),
  content text not null,
  attachment_url text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create index idx_messages_booking on public.messages (booking_id, created_at);

-- ---------- reviews ----------
create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings (id) on delete cascade,
  reviewer_id uuid not null references public.users (id),
  reviewee_id uuid not null references public.users (id),
  rating int not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now(),
  unique (booking_id, reviewer_id)
);

-- ---------- payments (disiapkan, aktif di fase lanjut) ----------
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings (id),
  amount numeric(10,2) not null,
  commission numeric(10,2) not null default 0,
  currency text not null default 'TWD',
  status text not null default 'pending',
  provider_ref text,
  paid_at timestamptz
);

-- ---------- documents ----------
create table public.documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  document_type text not null check (document_type in ('arc','passport','work_permit','contract','other')),
  document_number text,
  file_path text,
  issue_date date,
  expiry_date date not null,
  is_renewed boolean not null default false,
  created_at timestamptz not null default now()
);

create index idx_documents_expiry
  on public.documents (expiry_date)
  where is_renewed = false;

-- ---------- reminders ----------
create table public.reminders (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references public.documents (id) on delete cascade,
  user_id uuid not null references public.users (id) on delete cascade,
  days_before int not null,
  scheduled_date date not null,
  channel text not null default 'email' check (channel in ('email','line','push')),
  status text not null default 'pending' check (status in ('pending','sent','failed')),
  sent_at timestamptz,
  unique (document_id, days_before)
);

-- ============================================================
-- RPC: pencarian penerjemah terdekat (index GiST + operator <->)
-- ============================================================
create or replace function public.nearest_interpreters(
  p_lng double precision,
  p_lat double precision,
  p_max_km double precision default 20
)
returns table (
  interpreter_id uuid,
  user_id uuid,
  full_name text,
  city text,
  bio text,
  hourly_rate numeric,
  rating_avg numeric,
  rating_count int,
  distance_km double precision
)
language sql stable security definer set search_path = public as $$
  select
    ip.id,
    ip.user_id,
    u.full_name,
    ip.city,
    ip.bio,
    ip.hourly_rate,
    ip.rating_avg,
    ip.rating_count,
    st_distance(ip.location, st_makepoint(p_lng, p_lat)::geography) / 1000
  from interpreter_profiles ip
  join users u on u.id = ip.user_id
  where ip.is_verified
    and ip.is_available
    and ip.location is not null
    and st_dwithin(ip.location, st_makepoint(p_lng, p_lat)::geography, p_max_km * 1000)
  order by ip.location <-> st_makepoint(p_lng, p_lat)::geography
  limit 50;
$$;

-- RPC: set lokasi profil penerjemah (client tidak bisa menulis geography langsung)
create or replace function public.set_my_location(p_lng double precision, p_lat double precision)
returns void language sql security definer set search_path = public as $$
  update interpreter_profiles
     set location = st_makepoint(p_lng, p_lat)::geography
   where user_id = auth.uid();
$$;

-- ============================================================
-- Trigger: buat baris users saat signup (metadata: full_name, role)
-- ============================================================
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.users (id, email, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', 'Pengguna'),
    coalesce(new.raw_user_meta_data->>'role', 'client')
  );
  if coalesce(new.raw_user_meta_data->>'role','client') = 'interpreter' then
    insert into public.interpreter_profiles (user_id) values (new.id);
  end if;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================
-- Trigger: update rating_avg setelah review masuk
-- ============================================================
create or replace function public.refresh_interpreter_rating()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update interpreter_profiles ip
     set rating_avg = sub.avg_rating,
         rating_count = sub.cnt
    from (
      select r.reviewee_id, avg(r.rating)::numeric(3,2) as avg_rating, count(*)::int as cnt
      from reviews r
      where r.reviewee_id = new.reviewee_id
      group by r.reviewee_id
    ) sub
   where ip.user_id = sub.reviewee_id;
  return new;
end;
$$;

create trigger on_review_created
  after insert on public.reviews
  for each row execute function public.refresh_interpreter_rating();

-- Trigger updated_at bookings
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

create trigger bookings_touch before update on public.bookings
  for each row execute function public.touch_updated_at();

-- ============================================================
-- Fungsi pengingat harian (dipanggil pg_cron)
-- ============================================================
create or replace function public.create_expiry_reminders()
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into reminders (document_id, user_id, days_before, scheduled_date, channel)
  select d.id, d.user_id, v.days_before, current_date, 'email'
  from documents d
  cross join (values (30),(14),(7)) as v(days_before)
  where d.is_renewed = false
    and d.expiry_date - current_date = v.days_before
  on conflict (document_id, days_before) do nothing;
end;
$$;

-- Aktifkan pg_cron di dashboard (Database > Extensions), lalu:
-- select cron.schedule('check-expiring-documents', '0 0 * * *',
--   $$ select public.create_expiry_reminders(); $$);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.users enable row level security;
alter table public.interpreter_profiles enable row level security;
alter table public.language_pairs enable row level security;
alter table public.service_categories enable row level security;
alter table public.interpreter_services enable row level security;
alter table public.bookings enable row level security;
alter table public.messages enable row level security;
alter table public.reviews enable row level security;
alter table public.payments enable row level security;
alter table public.documents enable row level security;
alter table public.reminders enable row level security;

-- users: semua bisa lihat nama (untuk profil publik), hanya diri sendiri yang edit
create policy "users_select" on public.users for select using (true);
create policy "users_update_self" on public.users for update using (auth.uid() = id);

-- interpreter_profiles: publik bisa lihat yang verified; pemilik bisa lihat & edit miliknya
create policy "profiles_select" on public.interpreter_profiles for select
  using (is_verified or auth.uid() = user_id);
create policy "profiles_update_self" on public.interpreter_profiles for update
  using (auth.uid() = user_id);

create policy "langpairs_select" on public.language_pairs for select using (true);
create policy "langpairs_manage_self" on public.language_pairs for all
  using (interpreter_id in (select id from public.interpreter_profiles where user_id = auth.uid()));

create policy "categories_select" on public.service_categories for select using (true);

create policy "services_select" on public.interpreter_services for select using (true);
create policy "services_manage_self" on public.interpreter_services for all
  using (interpreter_id in (select id from public.interpreter_profiles where user_id = auth.uid()));

-- bookings: hanya client & penerjemah terkait
create policy "bookings_select_own" on public.bookings for select
  using (
    auth.uid() = client_id
    or interpreter_id in (select id from public.interpreter_profiles where user_id = auth.uid())
  );
create policy "bookings_insert_client" on public.bookings for insert
  with check (auth.uid() = client_id and status = 'requested');
create policy "bookings_update_parties" on public.bookings for update
  using (
    auth.uid() = client_id
    or interpreter_id in (select id from public.interpreter_profiles where user_id = auth.uid())
  );

-- messages: hanya pihak dalam booking terkait
create policy "messages_select_parties" on public.messages for select
  using (booking_id in (
    select b.id from public.bookings b
    where b.client_id = auth.uid()
       or b.interpreter_id in (select id from public.interpreter_profiles where user_id = auth.uid())
  ));
create policy "messages_insert_parties" on public.messages for insert
  with check (
    sender_id = auth.uid()
    and booking_id in (
      select b.id from public.bookings b
      where b.client_id = auth.uid()
         or b.interpreter_id in (select id from public.interpreter_profiles where user_id = auth.uid())
    )
  );

-- reviews: hanya pihak booking yang completed
create policy "reviews_select" on public.reviews for select using (true);
create policy "reviews_insert_parties" on public.reviews for insert
  with check (
    reviewer_id = auth.uid()
    and booking_id in (
      select b.id from public.bookings b
      where b.status = 'completed'
        and (b.client_id = auth.uid()
             or b.interpreter_id in (select id from public.interpreter_profiles where user_id = auth.uid()))
    )
  );

-- payments: hanya pihak terkait, read-only dari client
create policy "payments_select_parties" on public.payments for select
  using (booking_id in (
    select b.id from public.bookings b
    where b.client_id = auth.uid()
       or b.interpreter_id in (select id from public.interpreter_profiles where user_id = auth.uid())
  ));

-- documents & reminders: hanya pemilik
create policy "documents_own" on public.documents for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "reminders_select_own" on public.reminders for select using (auth.uid() = user_id);

-- ============================================================
-- Storage: bucket privat untuk dokumen
-- Buat bucket 'documents' (private) di dashboard, lalu policy:
-- ============================================================
-- Jalankan setelah bucket dibuat:
insert into storage.buckets (id, name, public) values ('documents','documents', false)
on conflict (id) do nothing;

create policy "docs_upload_own" on storage.objects for insert
  with check (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "docs_read_own" on storage.objects for select
  using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "docs_delete_own" on storage.objects for delete
  using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);

-- ============================================================
-- Realtime untuk chat
-- ============================================================
alter publication supabase_realtime add table public.messages;
