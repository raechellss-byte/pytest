-- ============================================================
-- Memo/catatan pribadi untuk tab Kalender
-- Jalankan setelah 001_initial_schema.sql
-- ============================================================

create table public.calendar_notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  title text not null,
  note text,
  event_date date not null,
  created_at timestamptz not null default now()
);

create index idx_calendar_notes_user_date
  on public.calendar_notes (user_id, event_date);

alter table public.calendar_notes enable row level security;

create policy "notes_own" on public.calendar_notes for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);
