-- ============================================================
-- Tambah gambar & penanda "featured" untuk banner Beranda
-- Jalankan setelah 002_news.sql
-- ============================================================

alter table public.news add column if not exists image_url text;
alter table public.news add column if not exists is_featured boolean not null default false;

-- Jadikan beberapa berita tampil di banner berputar (silakan admin ubah).
update public.news set is_featured = true
where title in (
  'Jangan sampai ARC Anda kedaluwarsa',
  'Hotline 1955 — bantuan bahasa Indonesia 24 jam',
  'Butuh pendamping ke rumah sakit?'
);

-- Contoh berita banner dengan gambar (opsional; ganti image_url sesuka Anda).
insert into public.news (title, summary, category, emoji, source_name, is_featured, image_url)
values
('Panduan lengkap Taipei 101',
 'Cara ke sana, tips masuk observatory, dan tempat menarik di sekitarnya.',
 'Wisata', '🏙️', 'PENGYOU', true,
 'https://images.unsplash.com/photo-1470004914212-05527e49370b?w=800&q=60');
