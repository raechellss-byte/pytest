-- ============================================================
-- Panel Admin: hak akses admin + statistik
-- Jalankan setelah 001–006.
-- ============================================================

-- Fungsi pembantu: apakah pengguna saat ini admin?
-- SECURITY DEFINER agar membaca users tanpa memicu RLS (hindari rekursi).
create or replace function public.is_admin()
returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.users where id = auth.uid() and role = 'admin'
  );
$$;

-- ---------- Policy admin (ditambahkan, digabung OR dengan policy lama) ----------

-- users: admin boleh melihat & mengubah semua
drop policy if exists "admin_manage_users" on public.users;
create policy "admin_manage_users" on public.users for all
  using (public.is_admin()) with check (public.is_admin());

-- interpreter_profiles: admin boleh melihat yang BELUM terverifikasi & mengubah
drop policy if exists "admin_manage_profiles" on public.interpreter_profiles;
create policy "admin_manage_profiles" on public.interpreter_profiles for all
  using (public.is_admin()) with check (public.is_admin());

-- bookings: admin boleh memantau semua pesanan
drop policy if exists "admin_read_bookings" on public.bookings;
create policy "admin_read_bookings" on public.bookings for select
  using (public.is_admin());

-- language_pairs & interpreter_services: admin boleh lihat (untuk detail profil)
drop policy if exists "admin_read_langpairs" on public.language_pairs;
create policy "admin_read_langpairs" on public.language_pairs for select
  using (public.is_admin());

-- news: pastikan admin bisa kelola (pakai is_admin biar konsisten)
drop policy if exists "news_admin_write" on public.news;
create policy "news_admin_write" on public.news for all
  using (public.is_admin()) with check (public.is_admin());

-- ============================================================
-- RPC statistik untuk dashboard admin (aman: cek admin dulu)
-- ============================================================
create or replace function public.admin_stats()
returns json language plpgsql security definer set search_path = public as $$
declare result json;
begin
  if not public.is_admin() then
    raise exception 'Akses ditolak: hanya admin';
  end if;
  select json_build_object(
    'total_users', (select count(*) from users),
    'clients', (select count(*) from users where role = 'client'),
    'interpreters', (select count(*) from users where role = 'interpreter'),
    'verified_interpreters', (select count(*) from interpreter_profiles where is_verified),
    'pending_interpreters', (select count(*) from interpreter_profiles where not is_verified),
    'total_bookings', (select count(*) from bookings),
    'completed_bookings', (select count(*) from bookings where status = 'completed'),
    'active_bookings', (select count(*) from bookings
        where status in ('requested','accepted','in_progress')),
    'total_documents', (select count(*) from documents),
    'total_news', (select count(*) from news),
    'total_reviews', (select count(*) from reviews)
  ) into result;
  return result;
end; $$;

-- Verifikasi/tolak penerjemah lewat RPC (opsional, bisa juga update langsung).
create or replace function public.admin_set_verified(p_profile_id uuid, p_verified boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then
    raise exception 'Akses ditolak: hanya admin';
  end if;
  update interpreter_profiles set is_verified = p_verified where id = p_profile_id;
end; $$;
