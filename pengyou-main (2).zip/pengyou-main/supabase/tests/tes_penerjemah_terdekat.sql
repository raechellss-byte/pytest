-- ============================================================
-- TES: "Jadi Penerjemah" → verifikasi admin → "Cari Terdekat"
--
-- Jalankan di Supabase → SQL Editor (setelah 016_interpreter_search.sql).
-- Aman untuk data asli: akun & data tes dibuat lalu DIBATALKAN lagi
-- (rollback). Karena itu hasil tes sengaja tampil sebagai pesan ERROR —
-- baca baris "HASIL" di dalamnya.
-- ============================================================
do $tes$
declare
  -- Titik referensi: Stasiun Taichung (lihat 010_map.sql).
  st_lng constant double precision := 120.6851;
  st_lat constant double precision := 24.1369;
  u_calon  uuid := gen_random_uuid(); -- client yang daftar "Jadi Penerjemah"
  u_jauh   uuid := gen_random_uuid(); -- penerjemah kedua, ±9 km dari stasiun
  u_daftar uuid := gen_random_uuid(); -- daftar akun langsung sebagai penerjemah
  u_admin  uuid := gen_random_uuid();
  u_nakal  uuid := gen_random_uuid(); -- daftar dengan metadata role 'admin'
  p_calon uuid; p_jauh uuid; p_daftar uuid;
  v_ids uuid[];
  v_num double precision;
  oks boolean[] := '{}';
  names text[] := '{}';
  lulus int := 0;
  laporan text := '';
begin
  -- ---------- Akun tes (seperti daftar lewat aplikasi) ----------
  insert into auth.users (instance_id, id, aud, role, email,
                          raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
  select '00000000-0000-0000-0000-000000000000', x.id, 'authenticated', 'authenticated',
         'tes-' || x.id || '@contoh.test', '{"provider":"email"}', x.meta::jsonb, now(), now()
  from (values
    (u_calon,  '{"full_name":"Tes Calon","role":"client"}'),
    (u_jauh,   '{"full_name":"Tes Jauh","role":"client"}'),
    (u_daftar, '{"full_name":"Tes Daftar","role":"interpreter"}'),
    (u_admin,  '{"full_name":"Tes Admin","role":"admin"}'),
    (u_nakal,  '{"full_name":"Tes Nakal","role":"admin"}')
  ) as x(id, meta);

  -- Admin tes diangkat lewat SQL (seperti admin asli lewat Table Editor).
  update public.users set role = 'admin' where id = u_admin;

  oks := array_append(oks, ((select role from public.users where id = u_nakal) = 'client'));
  names := array_append(names, 'Daftar akun dengan role "admin" di metadata → tetap client');

  oks := array_append(oks, ((select role from public.users where id = u_calon) = 'client'));
  names := array_append(names, 'Akun baru tercatat sebagai client');

  -- ---------- 1. Calon penerjemah mengisi form "Jadi Penerjemah" ----------
  perform set_config('request.jwt.claims',
    json_build_object('sub', u_calon, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u_calon::text, true);
  perform set_config('role', 'authenticated', true);
  perform public.become_interpreter(
    'Mahasiswa di Taichung, biasa mendampingi ke rumah sakit', 'Taichung', 400);
  select id into p_calon from public.interpreter_profiles where user_id = u_calon;
  insert into public.language_pairs (interpreter_id, source_language, target_language)
  values (p_calon, 'id', 'zh');
  perform set_config('role', 'none', true);

  oks := array_append(oks, coalesce((
    select u.role = 'interpreter' and not ip.is_verified
    from public.users u join public.interpreter_profiles ip on ip.user_id = u.id
    where u.id = u_calon), false));
  names := array_append(names, 'Jadi Penerjemah: peran → interpreter, profil dibuat, status menunggu');

  oks := array_append(oks, coalesce((
    select st_distance(location, st_makepoint(120.6736, 24.1477)::geography) < 1
    from public.interpreter_profiles where id = p_calon), false));
  names := array_append(names, 'Lokasi otomatis terisi dari kota (pusat Taichung)');

  -- ---------- 2. Sebelum diverifikasi ----------
  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
  perform set_config('role', 'anon', true);
  oks := array_append(oks, not exists (
    select 1 from public.nearest_interpreters(st_lng, st_lat, 20)
    where interpreter_id = p_calon));
  perform set_config('role', 'none', true);
  names := array_append(names, 'Belum diverifikasi → BELUM muncul di Cari Terdekat');

  -- Coba memverifikasi diri sendiri & memalsukan rating lewat API.
  perform set_config('request.jwt.claims',
    json_build_object('sub', u_calon, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u_calon::text, true);
  perform set_config('role', 'authenticated', true);
  update public.interpreter_profiles
     set is_verified = true, rating_avg = 5, rating_count = 99
   where user_id = u_calon;
  perform set_config('role', 'none', true);
  oks := array_append(oks, coalesce((
    select not is_verified and rating_count = 0
    from public.interpreter_profiles where id = p_calon), false));
  names := array_append(names, 'Penerjemah TIDAK bisa memverifikasi dirinya sendiri');
  -- Kembalikan bila celah masih ada, supaya langkah berikutnya tetap adil.
  update public.interpreter_profiles
     set is_verified = false, rating_avg = 0, rating_count = 0
   where id = p_calon;

  -- ---------- 3. Admin memverifikasi ----------
  perform set_config('request.jwt.claims',
    json_build_object('sub', u_admin, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u_admin::text, true);
  perform set_config('role', 'authenticated', true);
  perform public.admin_set_verified(p_calon, true);
  perform set_config('role', 'none', true);

  -- Pencarian sebagai tamu (tanpa login), seperti tombol "Cari Terdekat".
  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
  perform set_config('role', 'anon', true);
  select distance_km into v_num from public.nearest_interpreters(st_lng, st_lat, 20)
   where interpreter_id = p_calon;
  oks := array_append(oks, (v_num is not null));
  names := array_append(names, 'Setelah diverifikasi admin → MUNCUL di Cari Terdekat (tamu, radius 20 km)');
  oks := array_append(oks, coalesce(v_num between 1.0 and 2.5, false));
  names := array_append(names, format('Jarak benar: pusat kota ↔ stasiun ≈ 1,7 km (hasil: %s km)',
                           coalesce(round(v_num::numeric, 2)::text, '-')));
  oks := array_append(oks, not exists (
    select 1 from public.nearest_interpreters(121.5654, 25.0330, 50)
    where interpreter_id = p_calon));
  names := array_append(names, 'Tidak muncul untuk pencarian dari Taipei (±130 km)');
  perform set_config('role', 'none', true);

  -- ---------- 4. GPS & urutan terdekat ----------
  perform set_config('request.jwt.claims',
    json_build_object('sub', u_jauh, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u_jauh::text, true);
  perform set_config('role', 'authenticated', true);
  perform public.become_interpreter('Pekerja pabrik, fasih Mandarin', 'Taichung', 300);
  perform public.set_my_location(120.6015, 24.1799); -- ±9 km dari stasiun
  select id into p_jauh from public.interpreter_profiles where user_id = u_jauh;

  perform set_config('request.jwt.claims',
    json_build_object('sub', u_calon, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u_calon::text, true);
  perform public.set_my_location(120.6860, 24.1380); -- ±150 m dari stasiun

  perform set_config('request.jwt.claims',
    json_build_object('sub', u_admin, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u_admin::text, true);
  perform public.admin_set_verified(p_jauh, true);

  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
  perform set_config('role', 'anon', true);
  select array_agg(interpreter_id), min(distance_km) filter (where interpreter_id = p_calon)
    into v_ids, v_num
    from public.nearest_interpreters(st_lng, st_lat, 20);
  oks := array_append(oks, coalesce(array_position(v_ids, p_calon) < array_position(v_ids, p_jauh)
                         and v_num < 0.5, false));
  names := array_append(names, 'Lokasi GPS dipakai & yang terdekat tampil paling atas');

  oks := array_append(oks, exists (
    select 1 from public.interpreters_for_map(st_lng, st_lat, 60)
    where interpreter_id = p_jauh));
  names := array_append(names, 'Peta penerjemah ikut menampilkan yang terverifikasi');
  perform set_config('role', 'none', true);

  -- ---------- 5. Ubah profil ----------
  perform set_config('request.jwt.claims',
    json_build_object('sub', u_calon, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u_calon::text, true);
  perform set_config('role', 'authenticated', true);
  update public.interpreter_profiles set city = 'Taipei' where user_id = u_calon;
  perform set_config('role', 'anon', true);
  oks := array_append(oks, exists (
    select 1 from public.nearest_interpreters(121.5654, 25.0330, 5)
    where interpreter_id = p_calon));
  names := array_append(names, 'Pindah kota di Profil (tanpa GPS) → titik ikut pindah ke Taipei');

  perform set_config('role', 'authenticated', true);
  update public.interpreter_profiles set is_available = false where user_id = u_calon;
  perform set_config('role', 'anon', true);
  oks := array_append(oks, not exists (
    select 1 from public.nearest_interpreters(121.5654, 25.0330, 5)
    where interpreter_id = p_calon));
  names := array_append(names, 'Matikan "Tersedia menerima pesanan" → hilang dari pencarian');
  perform set_config('role', 'none', true);

  -- ---------- 6. Daftar akun langsung sebagai "Saya penerjemah" ----------
  perform set_config('request.jwt.claims',
    json_build_object('sub', u_daftar, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u_daftar::text, true);
  perform set_config('role', 'authenticated', true);
  update public.interpreter_profiles
     set city = 'Kaohsiung', bio = 'Lulusan bahasa Mandarin', hourly_rate = 350
   where user_id = u_daftar;
  select id into p_daftar from public.interpreter_profiles where user_id = u_daftar;

  perform set_config('request.jwt.claims',
    json_build_object('sub', u_admin, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u_admin::text, true);
  perform public.admin_set_verified(p_daftar, true);

  perform set_config('request.jwt.claims', '', true);
  perform set_config('request.jwt.claim.sub', '', true);
  perform set_config('role', 'anon', true);
  oks := array_append(oks, (p_daftar is not null and exists (
    select 1 from public.nearest_interpreters(120.3014, 22.6273, 5)
    where interpreter_id = p_daftar)));
  names := array_append(names, 'Daftar sebagai "Saya penerjemah" + isi kota di Profil → muncul di Kaohsiung');
  perform set_config('role', 'none', true);

  -- ---------- 7. Keamanan peran ----------
  update public.users set role = 'institution' where id = u_nakal;
  oks := array_append(oks, ((select role from public.users where id = u_nakal) = 'institution'));
  names := array_append(names, 'Peran bisa diubah admin lewat SQL Editor / Table Editor');

  perform set_config('request.jwt.claims',
    json_build_object('sub', u_nakal, 'role', 'authenticated')::text, true);
  perform set_config('request.jwt.claim.sub', u_nakal::text, true);
  perform set_config('role', 'authenticated', true);
  update public.users set role = 'admin' where id = u_nakal;
  perform set_config('role', 'none', true);
  oks := array_append(oks, ((select role from public.users where id = u_nakal) <> 'admin'));
  names := array_append(names, 'Pengguna biasa TIDAK bisa mengangkat dirinya jadi admin lewat API');

  -- ---------- Laporan (lalu batalkan semua data tes) ----------
  for i in 1 .. coalesce(array_length(oks, 1), 0) loop
    laporan := laporan || case when oks[i] then '✅ ' else '❌ ' end
               || i || '. ' || names[i] || E'\n';
    if oks[i] then lulus := lulus + 1; end if;
  end loop;
  raise exception E'HASIL: % dari % LULUS%\n\n%\n(Pesan ini memang tampil sebagai ERROR: semua akun & data tes sudah dibatalkan otomatis.)',
    lulus, array_length(oks, 1),
    case when lulus = array_length(oks, 1) then ' 🎉' else ' — ADA YANG GAGAL' end,
    laporan;
end $tes$;
