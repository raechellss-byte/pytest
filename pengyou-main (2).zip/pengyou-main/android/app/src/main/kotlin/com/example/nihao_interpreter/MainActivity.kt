package com.example.nihao_interpreter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
