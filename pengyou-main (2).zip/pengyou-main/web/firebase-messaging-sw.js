/* Service worker Firebase Cloud Messaging untuk PENGYOU (web).
 * Menangani notifikasi saat tab ditutup / di latar belakang.
 * Konfigurasi di bawah ini publik (sama dengan firebaseConfig web app). */
importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: 'AIzaSyCZo0wZmH2srsCSNGmic9UTfmjbmXuL8AI',
  authDomain: 'pengyou-3d147.firebaseapp.com',
  projectId: 'pengyou-3d147',
  storageBucket: 'pengyou-3d147.firebasestorage.app',
  messagingSenderId: '91670127733',
  appId: '1:91670127733:web:e7af33ae55c2fb0108843c',
});

const messaging = firebase.messaging();

// Pesan bertipe "notification" sudah ditampilkan otomatis oleh Firebase —
// menampilkannya lagi di sini membuat notifikasi dobel. Jadi hanya pesan
// data-only (mis. pengingat belajar) yang ditampilkan manual.
messaging.onBackgroundMessage(function (payload) {
  if (!payload || payload.notification) return;
  const d = payload.data || {};
  self.registration.showNotification(d.title || 'PENGYOU', {
    body: d.body || '',
    icon: '/icons/Icon-192.png',
    badge: '/icons/Icon-192.png',
    tag: d.tag || undefined,
    data: { link: d.link || '/' },
  });
});

// Klik notifikasi → fokus tab PENGYOU yang terbuka (pindah ke link), atau buka baru.
// (Notifikasi yang ditampilkan Firebase sendiri tidak punya data.link → biarkan.)
self.addEventListener('notificationclick', function (event) {
  const link = event.notification.data && event.notification.data.link;
  if (!link) return;
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
      for (const c of list) {
        if (c.url.startsWith(self.location.origin) && 'focus' in c) {
          return c.focus().then(function (w) {
            return w && 'navigate' in w ? w.navigate(link) : w;
          });
        }
      }
      return clients.openWindow(link);
    })
  );
});
